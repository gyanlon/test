package com.newhope.nlbp.pig.mobi.resource.version;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.newhope.nlbp.facade.mobile.api.sys.VersionService;
import com.newhope.nlbp.mobile.common.bean.BaseResponse;


@RestController
@RequestMapping(value = "/pig/mobile/version")
public class VersionCompare {
	
	@Autowired
	private VersionService versionService; 
	@RequestMapping(method = RequestMethod.GET)
	@io.swagger.annotations.ApiOperation(value = "手机版本号检查", httpMethod = "GET", response = BaseResponse.class, notes = "手机版本号检查，插入现在APP版本号，如果小于系统版本号，STATUS返回1，如果一样不需要返回")
	public @ResponseBody String compare(
			@RequestParam(value = "versionNum", required = false, defaultValue = "1.0.0") String versionNum) {
		
		
		System.out.println("versionNum"+versionNum);
		
		return  JSON.toJSONString(versionService.versionCompare(versionNum));
		
		
	}

}

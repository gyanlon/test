package com.newhope.nlbp.pig.mobi.resource;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.newhope.nlbp.common.bean.base.page.PageBean;
import com.newhope.nlbp.common.model.NlbpSysTaskModel;
import com.newhope.nlbp.facade.sys.task.NlbpSysTaskService;
import com.newhope.nlbp.mobile.common.bean.BaseResponse;
import com.newhope.nlbp.pig.mobi.resource.common.UserUtils;

import io.swagger.annotations.ApiOperation;

/**
 * 待办任务
 * 
 * @author yuanhaosheng
 * @version 2017-08-22
 */
@RestController
@RequestMapping(value = "/pig/mobile/task")
public class NlbpSysTaskResource {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private UserUtils userUtils;

	@Autowired
	private NlbpSysTaskService nlbpSysTaskService;

	
	/**
	 * 
	 * 方法名：getTaskByGoupList 查询待办任务分组信息
	 * 
	 * @param NlbpSysTaskModel
	 * @param req
	 * @return
	 * @Exception 异常对象
	 */
	@RequestMapping(value = "/getTaskByGoupList", method = RequestMethod.GET)	
	@ApiOperation(value = "待办任务查询", httpMethod = "GET", response = BaseResponse.class, notes = "查询待办任务分组信息")
	@ResponseBody
	public String getTaskByGoupList(HttpServletRequest req, NlbpSysTaskModel param) {
		BaseResponse<List<Map<String,Object>>> result = new BaseResponse<List<Map<String,Object>>>();
		
		try {
			List<Map<String,Object>> lstObject = nlbpSysTaskService.getTaskByGoup(param);

			result.setResult(lstObject);
			result.setStatus(1);
			result.setMessage("sucess");
		} catch (Exception e) {
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
		}
		return JSON.toJSONString(result);
	}

	/**
	 * 
	 * 方法名：getTaskByGoupList 查询待办任务分组信息
	 * 
	 * @param NlbpSysTaskModel
	 * @param req
	 * @return
	 * @Exception 异常对象
	 */
	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "/getTaskDetailList", method = RequestMethod.GET)	
	@ApiOperation(value = "待办任务明细列表", httpMethod = "GET", response = BaseResponse.class, notes = "查询待办任务明细信息")
	@ResponseBody
	public String getTaskDetailList(HttpServletRequest req, NlbpSysTaskModel param) {
		BaseResponse<PageBean> result = new BaseResponse<PageBean>();
		
		try {
			PageBean page = nlbpSysTaskService.getTaskDetailList(param, userUtils.getPageBean(req));

			result.setResult(page);
			result.setStatus(1);
			result.setMessage("sucess");
		} catch (Exception e) {
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
		}
		return JSON.toJSONString(result);
	}

	/**
	 * 
	 * 方法名：查询所有暂存事件分组信息
	 * 
	 * @param NlbpSysTaskModel
	 * @param req
	 * @return
	 * @Exception 异常对象
	 */
	@RequestMapping(value = "/getTempAllByDocNoList", method = RequestMethod.GET)	
	@ApiOperation(value = "查询所有暂存事件分组信息", httpMethod = "GET", response = BaseResponse.class, notes = "查询所有暂存事件分组信息")
	@ResponseBody
	public String getTempAllByDocNoList(HttpServletRequest req, NlbpSysTaskModel param) {
		BaseResponse<PageBean> result = new BaseResponse<PageBean>();
		
		try {
			PageBean page = nlbpSysTaskService.getTempAllByDocNoList(param, userUtils.getPageBean(req));

			result.setResult(page);
			result.setStatus(1);
			result.setMessage("sucess");
		} catch (Exception e) {
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
		}
		return JSON.toJSONString(result);
	}

	/**
	 * 
	 * 方法名：查询所有暂存事件分组信息
	 * 
	 * @param NlbpSysTaskModel
	 * @param req
	 * @return
	 * @Exception 异常对象
	 */
	@RequestMapping(value = "/getTempAllByDocNoListNoPage", method = RequestMethod.GET)	
	@ApiOperation(value = "查询所有暂存事件分组信息", httpMethod = "GET", response = BaseResponse.class, notes = "查询所有暂存事件分组信息")
	@ResponseBody
	public String getTempAllByDocNoListNoPage(HttpServletRequest req, NlbpSysTaskModel param) {
		BaseResponse<List<Map<String,Object>>> result = new BaseResponse<List<Map<String,Object>>>();
		
		try {
			List<Map<String,Object>> lstResult = nlbpSysTaskService.getTempAllByDocNoListNoPage(param);

			result.setResult(lstResult);
			result.setStatus(1);
			result.setMessage("sucess");
		} catch (Exception e) {
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
		}
		return JSON.toJSONString(result);
	}
}

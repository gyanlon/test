package com.newhope.nlbp.pig.mobi.resource;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.dubbo.common.utils.StringUtils;
import com.alibaba.fastjson.JSON;
import com.google.common.base.Strings;
import com.newhope.nlbp.common.bean.DocNumEnum;
import com.newhope.nlbp.common.bean.base.page.PageBean;
import com.newhope.nlbp.common.bean.base.page.ResultJson;
import com.newhope.nlbp.common.bean.pig.turnherd.HybridizationTransferGroupItemBean;
import com.newhope.nlbp.common.bean.pig.wean.NlbpPigWeanPreAdoptionBean;
import com.newhope.nlbp.common.exception.NlbpBizException;
import com.newhope.nlbp.common.model.NlbpPigWeanPreAdoptionHeadModel;
import com.newhope.nlbp.facade.pig.childbirth.NlbpPigChildbirthService;
import com.newhope.nlbp.facade.pig.wean.NlbpPigWeanPreAdoptionService;
import com.newhope.nlbp.facade.sys.countertable.NlbpSysCountertableService;
import com.newhope.nlbp.mobile.common.bean.BaseResponse;
import com.newhope.nlbp.pig.mobi.resource.common.UserUtils;

import io.swagger.annotations.ApiOperation;

/**
 * 产房管理-断奶前寄养Controller
 * 
 */
@RestController
@RequestMapping(value = "/pig/mobile/weanpreadoption")
public class WeanPreAdoption {

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private NlbpPigWeanPreAdoptionService nlbpPigWeanPreAdoptionService;
	
	@Autowired
	private NlbpSysCountertableService nlbpSysCountertableService;
	
	@Autowired
	private NlbpPigChildbirthService nlbpPigChildbirthService;

	@Autowired
	private UserUtils userUtils;
	
	/**
	 * 
	 * 方法名：getList 获取断奶记录维护界面数据列表
	 * 
	 * @param nlbpChildBirthBean
	 * @param req
	 * @return
	 * @Exception 异常对象
	 */
	@SuppressWarnings("rawtypes")
	@RequestMapping("getList")
	@ApiOperation(value = "断奶前寄养查询", httpMethod = "POST", response = BaseResponse.class, notes = "通过日期，配种批，猪群类型，耳号，胎次查询")
	@ResponseBody
	public String getList(NlbpPigWeanPreAdoptionBean bean, HttpServletRequest req) {
		logger.info("WeanPreAdoption.getList");
		Map<String, String> param = new HashMap<String, String>();
		// 公司
		if (bean.getCompanyId() != null) {
			param.put("companyId", bean.getCompanyId().toString());
		}
		// 猪场
		if (bean.getFarmId() != null) {
			param.put("farmId", bean.getFarmId().toString());
		}
		// 生产线
		if (bean.getProdLineId() != null) {
			param.put("prodLineId", bean.getProdLineId().toString());
		}
		// 猪舍
		if (bean.getHouseId() != null) {
			param.put("houseId", bean.getHouseId().toString());
		}
		// 单元
		if (bean.getUnitId() != null) {
			param.put("unitId", bean.getUnitId().toString());
		}
		// 断奶批
		if (bean.getBatchId() != null) {
			param.put("batchId", bean.getBatchId().toString());
		}
		// 耳牌号
		if (bean.getEarId() != null) {
			param.put("earId", bean.getEarId().toString());
		}
		// 耳牌号
		if (bean.getEarNo() != null) {
			param.put("earNo", bean.getEarNo());
		}
		// 断奶开始时间
		if (!Strings.isNullOrEmpty(bean.getDateBegin())) {
			param.put("dateBegin", bean.getDateBegin());
		}
		// 断奶结束时间
		if (!Strings.isNullOrEmpty(bean.getDateEnd())) {
			param.put("dateEnd", bean.getDateEnd());
		}
		PageBean page = nlbpPigWeanPreAdoptionService.searchList(param, userUtils.getPageBean(req));
		return JSON.toJSONString(page);
	}

	/**
	 * 断奶记录 更新/新增  保存
	 * @param bean
	 * @return
	 * @throws ParseException 
	 */
	@RequestMapping(value= "addOrUpdateRecord")
	@ApiOperation(value = "断奶前记录 更新/新增  保存", httpMethod = "POST", response = BaseResponse.class, notes = "断奶记录 更新/新增  保存")
	@ResponseBody
	public ResultJson addOrUpdateRecord(@RequestBody NlbpPigWeanPreAdoptionBean bean) throws ParseException{
		logger.info("WeanPreAdoption.addOrUpdateRecord NlbpPigWeanPreAdoptionBean : " + bean);
		if(bean.getItemList() == null || bean.getItemList().size() == 0 || 
				org.apache.commons.lang3.StringUtils.isEmpty(bean.getItemList().get(0).getEarNo())){
			return ResultJson.getDefeatResult("没有要保存的数据");
		}
		// 头表数据 
		NlbpPigWeanPreAdoptionHeadModel model = bean.toConvertHeadModel();	
		Date date = new Date();
		if (StringUtils.isBlank(bean.getDocNo())){
			model.setCreationDate(date);
			model.setDocNo(this.nlbpSysCountertableService.getNewCode(DocNumEnum.CFJYQ.getCode()));
		}
		model.setLastUpdateDate(date);
		bean.setNlbpPigWeanPreAdoptionHeadModel(model);
		try {
			boolean result = nlbpPigWeanPreAdoptionService.addOrUpdateRecord(bean, bean.getStatus());
			if(!result){
				return ResultJson.getDefeatResult("无法添加重复耳牌号");
			}
		} catch (NlbpBizException e) {
			logger.error("addOrUpdateRecord",e);
			return ResultJson.getDefeatResult();
		}
		return ResultJson.getSuccessResult();
	}
		
	/**
	 * 断奶记录列表页批量提交
	 * 
	 * @param ids
	 * @return
	 */
	@RequestMapping(value= "commitStatusByIds")
	@ResponseBody
	public ResultJson commitStatusByIds(@RequestBody String ids){
		logger.info("WeanPreAdoption commitStatusByIds  ids : " + ids);
		ResultJson json = ResultJson.getSuccessResult();
		try {
			nlbpPigWeanPreAdoptionService.commitStatusByIds(ids);
		} catch (NlbpBizException e) {
			logger.error("commitStatusByIds",e);
			json = ResultJson.getDefeatResult();
		}
		return json;
	}
	
	/**
	 * 获取其他关联业务数据记录信息
	 * 
	 * @param dnBatchId
	 * @param earNo
	 * @return
	 */
	@RequestMapping(value= "getThirdInfo")
	@ResponseBody
	public ResultJson getThirdInfo(String earNos){
		logger.info("WeanAftAdoption getThirdInfo earNo: " + earNos);
		ResultJson json = ResultJson.getSuccessResult();
		List<HybridizationTransferGroupItemBean> list = new ArrayList<HybridizationTransferGroupItemBean>();
		for(int i = 0; i < earNos.split(",").length; i++){
			try {
				// 根据母猪耳号，取出断奶批和单元信息
				HybridizationTransferGroupItemBean transferInfo = nlbpPigChildbirthService.getTransferInfoByEarNum(Long.valueOf(earNos.split(",")[i]));
				list.add(transferInfo);
			} catch (NlbpBizException e) {
				//e.printStackTrace();
				logger.error("getThirdInfo",e);
				json = ResultJson.getDefeatResult();
			}
		}
		json.setData(list);
		return json;
	}
	
}

package com.newhope.nlbp.pig.mobi.resource;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.dubbo.common.utils.StringUtils;
import com.alibaba.fastjson.JSON;
import com.google.common.base.Strings;
import com.newhope.nlbp.common.bean.DocNumEnum;
import com.newhope.nlbp.common.bean.base.page.PageBean;
import com.newhope.nlbp.common.bean.base.page.ResultJson;
import com.newhope.nlbp.common.bean.pig.turnherd.HybridizationTransferGroupItemBean;
import com.newhope.nlbp.common.bean.pig.wean.NlbpPigWeanAftAdoptionBean;
import com.newhope.nlbp.common.constant.ConstantBusi;
import com.newhope.nlbp.common.exception.NlbpBizException;
import com.newhope.nlbp.common.model.NlbpPigStyModel;
import com.newhope.nlbp.common.model.NlbpPigWeanAftAdoptionHeadModel;
import com.newhope.nlbp.facade.pig.childbirth.NlbpPigChildbirthService;
import com.newhope.nlbp.facade.pig.earnumberfile.NlbpPigEarNumberFileService;
import com.newhope.nlbp.facade.pig.pigSty.NlbpPigStyService;
import com.newhope.nlbp.facade.pig.wean.NlbpPigWeanAftAdoptionService;
import com.newhope.nlbp.facade.sys.countertable.NlbpSysCountertableService;
import com.newhope.nlbp.mobile.common.bean.BaseResponse;
import com.newhope.nlbp.pig.mobi.resource.common.UserUtils;

import io.swagger.annotations.ApiOperation;

/**
 * 产房管理-断奶后寄养Controller
 * 
 */
@RestController
@RequestMapping(value = "/pig/mobile/weanaftadoption")
public class WeanAftAdoption {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private NlbpPigWeanAftAdoptionService nlbpPigWeanAftAdoptionService;

	@Autowired
	private NlbpSysCountertableService nlbpSysCountertableService;

	@Autowired
	private NlbpPigChildbirthService nlbpPigChildbirthService;

	@Autowired
	private UserUtils userUtils;
	
	@Autowired
 	private NlbpPigStyService styService;//猪舍
	
	@Autowired
	private NlbpPigEarNumberFileService earNumberFileService;

	/**
	 * 
	 * 方法名：getList 获取断奶记录维护界面数据列表
	 * 
	 * @param nlbpChildBirthBean
	 * @param req
	 * @return
	 * @Exception 异常对象
	 */
	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "getList", method = RequestMethod.GET)
	@ApiOperation(value = "断奶后寄养查询", httpMethod = "GET", response = BaseResponse.class, notes = "通过日期，配种批，猪群类型，耳号，胎次查询")
	@ResponseBody
	public String getList(HttpServletRequest req, NlbpPigWeanAftAdoptionBean bean) {
		logger.info("WeanAftAdoption getList");
		Map<String, String> param = new HashMap<String, String>();
		// 公司
		if (bean.getCompanyId() != null) {
			param.put("companyId", bean.getCompanyId().toString());
		}
		// 猪场
		if (bean.getFarmId() != null) {
			param.put("farmId", bean.getFarmId().toString());
		}
		// 生产线
		if (bean.getProdLineId() != null) {
			param.put("prodLineId", bean.getProdLineId().toString());
		}
		// 猪舍
		if (bean.getHouseId() != null) {
			param.put("houseId", bean.getHouseId().toString());
		}
		// 单元
		if (bean.getUnitId() != null) {
			param.put("unitId", bean.getUnitId().toString());
		}
		// 断奶批
		if (bean.getBatchId() != null) {
			param.put("batchId", bean.getBatchId().toString());
		}
		// 耳牌号id
		if (bean.getEarId() != null) {
			param.put("earId", bean.getEarId().toString());
		}

		// 耳牌号
		if (bean.getEarNo() != null) {
			param.put("earNo", bean.getEarNo());
		}
		// 断奶后寄养开始时间
		if (!Strings.isNullOrEmpty(bean.getDateBegin())) {
			param.put("dateBegin", bean.getDateBegin());
		}
		// 断奶后寄养结束时间
		if (!Strings.isNullOrEmpty(bean.getDateEnd())) {
			param.put("dateEnd", bean.getDateEnd());
		}
		// app只查询提交的记录
		if (!Strings.isNullOrEmpty(bean.getDateEnd())) {
			param.put("status", ConstantBusi.RECODE_SUBMIT);
		}
		PageBean page = nlbpPigWeanAftAdoptionService.searchList(param, userUtils.getPageBean(req));
		return JSON.toJSONString(page);
	}

	/**
	 * 断奶记录 更新/新增 保存
	 * 
	 * @param bean
	 * @return
	 * @throws ParseException
	 */
	@RequestMapping(value = "addOrUpdateRecord")
	@ApiOperation(value = "断奶后记录 更新/新增  保存", httpMethod = "POST", response = BaseResponse.class, notes = "断奶记录 更新/新增  保存")
	@ResponseBody
	public ResultJson addOrUpdateRecord(@RequestBody NlbpPigWeanAftAdoptionBean bean) throws ParseException {
		logger.info("WeanAftAdoption addOrUpdateRecord  NlbpPigWeanAftAdoptionBean : " + bean);
		if (bean.getItemList() == null || bean.getItemList().size() == 0) {
			return ResultJson.getDefeatResult("没有要保存的数据");
		} else {
			for (int i = 0; i < bean.getItemList().size(); i++) {
				if (org.apache.commons.lang3.StringUtils.isEmpty(bean.getItemList().get(i).getEarNo())) {
					return ResultJson.getDefeatResult("耳牌号是必填项");
				} else if (bean.getItemList().get(i).getToUnitId() == null
						|| bean.getItemList().get(i).getToUnitId() == 0) {
					return ResultJson.getDefeatResult("去向单元是必填项");
				}
			}
		}
		// 头表数据
		NlbpPigWeanAftAdoptionHeadModel model = bean.toConvertHeadModel();
		Date date = new Date();
		if (StringUtils.isBlank(bean.getDocNo())) {
			model.setCreationDate(date);
			model.setDocNo(this.nlbpSysCountertableService.getNewCode(DocNumEnum.CFJYH.getCode()));
		}
		model.setLastUpdateDate(date);
		bean.setNlbpPigWeanAftAdoptionHeadModel(model);
		try {
			boolean result = nlbpPigWeanAftAdoptionService.addOrUpdateRecord(bean, bean.getStatus());
			if (!result) {
				return ResultJson.getDefeatResult("无法添加重复耳牌号");
			}
		} catch (NlbpBizException e) {
			logger.error("addOrUpdateRecord", e);
			return ResultJson.getDefeatResult();
		}
		return ResultJson.getSuccessResult();
	}
	
	/**
	 * 根据id删除断奶记录
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value= "deleteRecordByIds")
	@ApiOperation(value = "通过行id删除断奶行数据", httpMethod = "POST", response = BaseResponse.class, notes = "通过行id删除断奶行数据")
	@ResponseBody
	public ResultJson deleteRecordByIds(String ids){
		logger.info("WeanAftAdoption deleteRecordByIds  ids : " + ids);
		ResultJson json = ResultJson.getSuccessResult();
		try {
			nlbpPigWeanAftAdoptionService.deleteRecordByIds(ids);
		} catch (NlbpBizException e) {
			logger.error("deleteRecordByIds", e);
			json = ResultJson.getDefeatResult();
		}
		return json;
	}

	/**
	 * 断奶记录列表页批量提交
	 * 
	 * @param ids
	 * @return
	 */
	@RequestMapping(value = "commitStatusByIds")
	@ResponseBody
	public ResultJson commitStatusByIds(@RequestBody String ids) {
		logger.info("WeanAftAdoption commitStatusByIds  ids : " + ids);
		ResultJson json = ResultJson.getSuccessResult();
		try {
			nlbpPigWeanAftAdoptionService.commitStatusByIds(ids);
		} catch (NlbpBizException e) {
			logger.error("commitStatusByIds1", e);
			json = ResultJson.getDefeatResult(e.getMessage());
		} catch (ParseException e) {
			logger.error("commitStatusByIds2", e);
			json = ResultJson.getDefeatResult("单据日期错误");
		}
		return json;
	}

	/**
	 * 获取其他关联业务数据记录信息
	 * 
	 * @param dnBatchId
	 * @param earNo
	 * @return
	 */
	@RequestMapping(value = "getThirdInfo")
	@ApiOperation(value = "通过earId获取其他关联业务数据记录信息", httpMethod = "GET", response = BaseResponse.class, notes = "通过earId获取其他关联业务数据记录信息")
	@ResponseBody
	public String getThirdInfo(String earNos) {
		logger.info("WeanAftAdoption getThirdInfo earNo: " + earNos);
		BaseResponse<List<Map<String, Object>>> result = new BaseResponse<List<Map<String, Object>>>();
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		for (int i = 0; i < earNos.split(",").length; i++) {
			try {
				HybridizationTransferGroupItemBean transferInfo = nlbpPigChildbirthService
						.getTransferInfoByEarNum(Long.valueOf(earNos.split(",")[i]));
				Map<String, Object> resultMap = new HashMap<String, Object>();
				if (transferInfo != null) {
					resultMap = nlbpPigWeanAftAdoptionService.getThirdInfo(transferInfo.getWeaningBatchPk(),
							Long.valueOf(earNos.split(",")[i]));
				}
				resultMap.put("transferInfo", transferInfo);
				list.add(resultMap);
			} catch (NlbpBizException e) {
				logger.error("getThirdInfo", e);
				result.setStatus(0);
				result.setMessage("failure:" + e.getMessage());
			}
		}
		result.setResult(list);
		result.setStatus(1);
		result.setMessage("sucess");
		return JSON.toJSONString(result);
	}

	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "getLineByHead", method = RequestMethod.GET)
	@ApiOperation(value = "通过头Id查询行", httpMethod = "GET", response = BaseResponse.class, notes = "通过头Id查询行")
	@ResponseBody
	public String getLineByHead(HttpServletRequest req, String id, String earIds) {
		BaseResponse<PageBean> result = new BaseResponse<PageBean>();
		
		try {
			
			Map<String, String> param = new HashMap<String, String>();
			if (id != null) {
				param.put("id", id);
			}
			if (earIds != null) {
				param.put("earIds", earIds);
			}
			PageBean page = nlbpPigWeanAftAdoptionService.searchListByHead(param, userUtils.getPageBean(req));
			result.setStatus(1);
			result.setResult(page);
			
		} catch (Exception e) {
			result.setStatus(0);
			result.setMessage(e.getMessage());
		}
		
		return JSON.toJSONString(result);
	}
	
	/**
	 * 根据条件查询耳号列表
	 * @date 2017年8月14日 上午14:04:01
	 * @param houseId
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "/getEarList", method = {RequestMethod.GET})
	@ApiOperation(value = "耳号列表查询", httpMethod = "GET", response = BaseResponse.class, notes = "通过用户输入，查询耳号列表")
	@ResponseBody
	public String getEarAllList(HttpServletRequest req) {
		BaseResponse <List> result = new BaseResponse<List>();
		Map<String, Object> param = new HashMap<String, Object>();
		//猪舍
		param.put("houseId", req.getParameter("houseId"));
		//引种批次号
		param.put("batchId", req.getParameter("batchId"));
		//单元号
		param.put("untiId", req.getParameter("untiId"));
		//耳牌号
		param.put("queryEarNumb", req.getParameter("queryEarNumb"));
		//是否离场
		param.put("isLeave", req.getParameter("isLeave"));
		//档案状态：入群，淘汰
		param.put("fileType", req.getParameter("fileType"));
		//猪只性别
		param.put("pigSex", req.getParameter("pigSex"));
		//当前批次ID
		param.put("crurrentBatchId",  req.getParameter("crurrentBatchId"));
		//当前批次
		param.put("crurrentBatchNo",  req.getParameter("crurrentBatchNo"));
		//生长阶段
		param.put("parturitionType", req.getParameter("parturitionType"));
		param.put("queryBatchNo",  req.getParameter("queryBatchNo"));
		param.put("currentEventType", req.getParameter("currentEventType")); // 
		try{
			NlbpPigStyModel filter = new NlbpPigStyModel();
			filter.setId(Long.parseLong(req.getParameter("houseId")));
			filter.setStyType("BIRTH_STY");
			List<Map> styList = styService.getSty(filter);
			int unitFlg = 0;
			if(styList.size() > 0){
				if(styList.get(0).get("id") != null){
					String styId = styList.get(0).get("id")+"";
					if(styId.equals(req.getParameter("houseId"))){
						List list = earNumberFileService.getEarnumbAll(param);
						result.setResult(list);
						unitFlg = 1;
					}
				}
			}
			if(unitFlg == 0){
				result.setStatus(0);
				result.setMessage("寄养录入：猪舍不是产房舍");
				return JSON.toJSONString(result);
			}
			result.setStatus(1);
			result.setMessage("sucess");
		}catch(Exception e){
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
		}
		return JSON.toJSONString(result);
	}

}

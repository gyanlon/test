package com.newhope.nlbp.pig.mobi.login;

import org.springframework.context.ApplicationContext;
import org.springframework.web.context.ContextLoader;


public class AppContext {
	
	private static ApplicationContext springContext = ContextLoader.getCurrentWebApplicationContext();

	public static ApplicationContext getSpringContext() {
		return springContext;
	}

	public static void setSpringContext(ApplicationContext springContext) {
		AppContext.springContext = springContext;
	}

	
}

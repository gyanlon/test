package com.newhope.nlbp.pig.mobi.resource;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.newhope.nlbp.common.bean.base.page.PageBean;
import com.newhope.nlbp.common.bean.pig.empathemaRecord.EmpathemaSearchBean;
import com.newhope.nlbp.common.constant.ConstantBusi;
import com.newhope.nlbp.common.exception.NlbpBizException;
import com.newhope.nlbp.common.model.NlbpPigEmpathemaRecordHeadModel;
import com.newhope.nlbp.common.model.NlbpPigEmpathemaRecordLineModel;
import com.newhope.nlbp.common.model.NlbpSysDictItemModel;
import com.newhope.nlbp.facade.common.sys.SysDictItemService;
import com.newhope.nlbp.facade.pig.empathemaRecord.EmpathemaRecordService;
import com.newhope.nlbp.mobile.common.bean.BaseResponse;
import com.newhope.nlbp.pig.mobi.resource.common.UserUtils;

import io.swagger.annotations.ApiOperation;

/**
 * 查情服务
 * 
 * @author hudp
 *
 */
@RestController
@RequestMapping(value = "/pig/mobile/empathema")
public class EmpathemaResource {

	@Autowired
	private EmpathemaRecordService empathemaRecordService;
	@Autowired
	private SysDictItemService sysDictItemService;
	@Autowired
	private UserUtils userUtils;

	/**
	 * 查情记录查询
	 * 
	 * @param req
	 * @param query
	 * @return
	 */
	@RequestMapping(value = "/getList", method = RequestMethod.POST, consumes = "application/json")
	@ApiOperation(value = "查情记录查询", httpMethod = "POST", response = BaseResponse.class, notes = "通过起止日期,引种批,耳牌号,发情次数,日龄,体重查询查情记录")
	@ResponseBody
	public String getList(HttpServletRequest req, @RequestBody EmpathemaSearchBean bean) {
		BaseResponse<PageBean> result = new BaseResponse<PageBean>();
		try {
			bean.setLineStatus(ConstantBusi.RECODE_SUBMIT);
			PageBean page = empathemaRecordService.searchList(bean, userUtils.getPageBean(req));
			if(page.getPageSize() == 0){
				page.setPageSize(1);
			}
			result.setResult(page);
			result.setStatus(1);
			result.setMessage("sucess");
		} catch (Exception e) {
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
		}
		return JSON.toJSONString(result);
	}
	
	/**
	 * 批量转入查情记录查询
	 * 
	 * @param req
	 * @param query
	 * @return
	 */
	@RequestMapping(value = "/getEmpathemaInitList", method = RequestMethod.POST, consumes = "application/json")
	@ApiOperation(value = "批量转入查情记录查询", httpMethod = "POST", response = BaseResponse.class, notes = "根据耳号ID,录入日期,查询查情列表")
	@ResponseBody
	public String getEmpathemaInitList(@RequestBody EmpathemaSearchBean bean){
		
		BaseResponse<NlbpPigEmpathemaRecordHeadModel> result = new BaseResponse<NlbpPigEmpathemaRecordHeadModel>();
		List<NlbpPigEmpathemaRecordLineModel> lineList = new ArrayList<NlbpPigEmpathemaRecordLineModel>();
		NlbpPigEmpathemaRecordHeadModel head = new NlbpPigEmpathemaRecordHeadModel();
		try{
			String[] earIdArr = bean.getEarIds().split(",");
			EmpathemaSearchBean param = new EmpathemaSearchBean();
			List<Long> earIdList = new ArrayList<Long>();
			for(String earId : earIdArr){
				earIdList.add(Long.valueOf(earId));
			}
			param.setCreateDate(bean.getCreateDate());
			param.setEarIdList(earIdList);
			lineList = empathemaRecordService.getEmpathemaInitList(param);
			head.setLineList(lineList);
			result.setResult(head);
			result.setStatus(1);
			result.setMessage("sucess");
		}catch(Exception e){
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
		}
		return JSON.toJSONString(result);
	}

	/**
	 * 暂存查情记录查询
	 * 
	 * @param req
	 * @param query
	 * @return
	 */
	@RequestMapping(value = "/getEmpathemaTempList", method = RequestMethod.GET)
	@ApiOperation(value = "暂存查情记录查询", httpMethod = "GET", response = BaseResponse.class, notes = "根据头ID，查询查情列表")
	@ResponseBody
	public String getEmpathemaTempList(@RequestParam(value = "headId") String headId){
		
		BaseResponse<NlbpPigEmpathemaRecordHeadModel> result = new BaseResponse<NlbpPigEmpathemaRecordHeadModel>();
		NlbpPigEmpathemaRecordHeadModel head = new NlbpPigEmpathemaRecordHeadModel();
		try{
			head = empathemaRecordService.getEmpathemaRecordDataById(Long.valueOf(headId));
			result.setResult(head);
			result.setStatus(1);
			result.setMessage("sucess");
		}catch(Exception e){
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
		}
		return JSON.toJSONString(result);
	}
	
	/**
	 * 数据校验
	 * @param lineList
	 * @return
	 */
	private String checkItem(List<NlbpPigEmpathemaRecordLineModel> lineList){
		String message = null;
		
		List<Long> earIdList = new ArrayList<Long>();
		for(NlbpPigEmpathemaRecordLineModel line : lineList){
			if(earIdList.contains(line.getEarId())){
				message = "failure:耳号不能重复";
				return message;
			}
			earIdList.add(line.getEarId());
			if(line.getEarId() == null) {
				message = "failure:耳号为空";
				return message;
			}
			if(line.getWeight() == null) {
				message = "failure:体重为空";
				return message;
			}
			if(line.getEmpathemaPerf() == null) {
				message = "failure:发情表现为空";
				return message;
			}
		}
		
		return message;
	}
	
	/**
	 * 查情记录保存
	 * 
	 * @param req
	 * @param query
	 * @return
	 */
	@RequestMapping(value = "/addOrUpdate", method = RequestMethod.POST, consumes = "application/json")
	@ApiOperation(value = "查情记录保存", httpMethod = "POST", response = BaseResponse.class, notes = "查情记录保存")
	@ResponseBody
	public String addOrUpdate(@RequestBody NlbpPigEmpathemaRecordHeadModel headModel) {
		BaseResponse<Map<String, Object>> result = new BaseResponse<Map<String, Object>>();

		String message = this.checkItem(headModel.getLineList());
		if(message != null) {
			result.setStatus(0);
			result.setMessage(message);
			return JSON.toJSONString(result);
		}
		try {
			empathemaRecordService.addOrUpdateEmpathemaRecord(headModel);
			result.setStatus(1);
			result.setMessage("sucess");
		} catch (NlbpBizException e) {
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
		} catch (Exception e) {
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
		}
		return JSON.toJSONString(result);
	}

	/**
	 * 查情记录提交
	 * 
	 * @param req
	 * @param query
	 * @return
	 */
	@RequestMapping(value = "/submit", method = RequestMethod.POST, consumes = "application/json")
	@ApiOperation(value = "查情记录提交", httpMethod = "POST", response = BaseResponse.class, notes = "查情记录提交")
	@ResponseBody
	public String submit(@RequestBody NlbpPigEmpathemaRecordHeadModel headModel) {
		BaseResponse<Map<String, Object>> result = new BaseResponse<Map<String, Object>>();
		
		String message = this.checkItem(headModel.getLineList());
		if(message != null) {
			result.setStatus(0);
			result.setMessage(message);
			return JSON.toJSONString(result);
		}
		try {
			empathemaRecordService.submit(headModel);
			result.setStatus(1);
			result.setMessage("sucess");
		} catch (NlbpBizException e) {
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
		} catch (Exception e) {
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
		}
		return JSON.toJSONString(result);
	}
	
	/**
	 * 查情记录删除
	 * 
	 * @param req
	 * @param query
	 * @return
	 */
	@RequestMapping(value = "/delList", method = RequestMethod.GET)
	@ApiOperation(value = "查情记录删除", httpMethod = "GET", response = BaseResponse.class, notes = "根据行ID，删除查情列表记录")
	@ResponseBody
	public String delList(@RequestParam(value = "lineIds") String lineIds){
		
		BaseResponse<List<NlbpPigEmpathemaRecordLineModel>> result = new BaseResponse<List<NlbpPigEmpathemaRecordLineModel>>();
		try{
			String[] lineIdArr = lineIds.split(",");
			for(String lineId : lineIdArr){
				empathemaRecordService.deleteLine(Long.valueOf(lineId));
			}
			result.setStatus(1);
			result.setMessage("sucess");
		}catch(Exception e){
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
		}
		return JSON.toJSONString(result);
	}
	
	/**
	 * 耳号列表查询
	 * 
	 * @param req
	 * @param query
	 * @return
	 */
	@RequestMapping(value = "/getEarList", method = RequestMethod.POST)
	@ApiOperation(value = "查情耳号列表查询", httpMethod = "POST", response = BaseResponse.class, notes = "通过猪舍,录入日期查询耳号列表")
	@ResponseBody
	public String getEarList(@RequestBody EmpathemaSearchBean bean) {
		Map<String, Object> param = new HashMap<String, Object>();
		
		param.put("sexType", ConstantBusi.RESERVE_PIG_SEX_SOW);
		param.put("docStatus", ConstantBusi.RECODE_SUBMIT);
		param.put("houseId", bean.getQueryHouseId());
		//param.put("batchId", bean.getQueryBatchId());
		param.put("createDate", bean.getCreateDate());
		
		BaseResponse<List<Map<String, Object>>> result = new BaseResponse<List<Map<String, Object>>>();
		
		result.setResult(empathemaRecordService.getEarListByEmpathema(param));
		result.setStatus(1);
		result.setMessage("sucess");
		return JSON.toJSONString(result);
	}
	
	/**
	 * 发情表现列表查询
	 * 
	 * @param req
	 * @param query
	 * @return
	 */
	@RequestMapping(value = "/getEmpathemaPerf", method = RequestMethod.POST)
	@ApiOperation(value = "发情表现列表查询", httpMethod = "POST", response = BaseResponse.class, notes = "查询发情表现列表")
	@ResponseBody
	public String getEmpathemaPerf() {
		BaseResponse<List<NlbpSysDictItemModel>> result = new BaseResponse<List<NlbpSysDictItemModel>>();
		List<NlbpSysDictItemModel> model = sysDictItemService.findSysDictItemList("PIG_EMPATHEMA_BEHAVIOR", "ZHS");
		result.setResult(model);
		result.setStatus(1);
		result.setMessage("sucess");
		return JSON.toJSONString(result);
	}
}

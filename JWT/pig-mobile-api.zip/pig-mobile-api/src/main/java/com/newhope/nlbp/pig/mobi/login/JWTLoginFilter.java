package com.newhope.nlbp.pig.mobi.login;

import java.io.IOException;
import java.util.Collection;
import java.util.Map;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import com.fasterxml.jackson.databind.ObjectMapper;

class JWTLoginFilter extends AbstractAuthenticationProcessingFilter {

	public JWTLoginFilter(String url, AuthenticationManager authManager) {
        super(new AntPathRequestMatcher(url));
        setAuthenticationManager(authManager);
	}

	@Override
	public Authentication attemptAuthentication(
			HttpServletRequest req, HttpServletResponse res)
			throws AuthenticationException, IOException, ServletException {
		
		

	    // JSON反序列化成 AccountCredentials
		
		ServletInputStream  ris=req.getInputStream();
		
	Map<String,String[]> map=	req.getParameterMap();
	
	  // 第三种：推荐，尤其是容量大时
	         System.out.println("第三种：通过Map.entrySet遍历key和value");
	         for (Map.Entry<String, String[]> entry : map.entrySet()) {
	             //Map.entry<Integer,String> 映射项（键-值对）  有几个方法：用上面的名字entry
	             //entry.getKey() ;entry.getValue(); entry.setValue();
	             //map.entrySet()  返回此映射中包含的映射关系的 Set视图。
	             System.out.println("key= " + entry.getKey());
	             for(int i=0; i<entry.getValue().length;i++)
	             { System.out.println(entry.getValue()[i]);
	            	 
	             }
	             
	         }
	
	
   
	//	AccountCredentials creds = new ObjectMapper().readValue(req.getInputStream(), AccountCredentials.class);
    AccountCredentials creds=new AccountCredentials();
    String username=req.getParameter("username");
    String password=req.getParameter("password");
    creds.setPassword(password);
    creds.setUsername(username);
	
    res.setHeader("Access-Control-Allow-Origin", "*");

        // 返回一个验证令牌
        return getAuthenticationManager().authenticate(
				new UsernamePasswordAuthenticationToken(
						creds.getUsername(),
						creds.getPassword()
				)
		);
	}


	@Override
	protected void successfulAuthentication(
			HttpServletRequest req,
			HttpServletResponse res, FilterChain chain,
			Authentication auth) throws IOException, ServletException {
		
		Collection<GrantedAuthority> c = (Collection<GrantedAuthority>) auth.getAuthorities();
		String tmp="";
		for (GrantedAuthority str : c) {
			
			tmp=str.getAuthority();
		    
		}
		  res.setHeader("Access-Control-Allow-Origin", "*");
		
		TokenAuthenticationService.addAuthentication(res, tmp.trim());
	}



    @Override
    protected void unsuccessfulAuthentication(HttpServletRequest request, HttpServletResponse response, AuthenticationException failed) throws IOException, ServletException {
        response.setContentType("application/json");
        response.setStatus(HttpServletResponse.SC_OK);
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.getOutputStream().println(JSONResult.fillResultString(403, "用户密码错误", JSONObject.NULL));
    }
}
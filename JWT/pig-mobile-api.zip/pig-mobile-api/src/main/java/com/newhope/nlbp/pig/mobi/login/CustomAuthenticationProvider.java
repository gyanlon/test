package com.newhope.nlbp.pig.mobi.login;

import java.util.ArrayList;


import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;

import com.newhope.nlbp.common.bean.sys.user.NlbpLoginBean;
import com.newhope.nlbp.facade.user.LoginService;

//自定义身份认证验证组件
class CustomAuthenticationProvider implements AuthenticationProvider {

	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {
		// 获取认证的用户名 & 密码
		String name = authentication.getName();
		String password = authentication.getCredentials().toString();

		NlbpLoginBean userBean = new NlbpLoginBean();

		LoginService loginService = AppContext.getSpringContext().getBean(LoginService.class);

		userBean = loginService.login(name, password);

		// 认证逻辑
		if (userBean.getStatus() == 1) {

			// 这里设置权限和角色
			ArrayList<GrantedAuthority> authorities = new ArrayList<>();
			authorities.add(new GrantedAuthorityImpl(userBean.getUser()));

			// 生成令牌
			Authentication auth = new UsernamePasswordAuthenticationToken(name, password, authorities);
			return auth;
		} else {
			throw new BadCredentialsException("密码错误~");
		}
	}

	// 是否可以提供输入类型的认证服务
	@Override
	public boolean supports(Class<?> authentication) {
		return authentication.equals(UsernamePasswordAuthenticationToken.class);
	}

}

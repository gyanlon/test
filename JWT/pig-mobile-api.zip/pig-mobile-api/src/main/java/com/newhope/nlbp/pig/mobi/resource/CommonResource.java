package com.newhope.nlbp.pig.mobi.resource;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.newhope.nlbp.common.bean.pig.NlbpSysOnhandBean;
import com.newhope.nlbp.common.model.NlbpPigBatchModel;
import com.newhope.nlbp.common.model.NlbpPigBreedLineModel;
import com.newhope.nlbp.common.model.NlbpPigHogpenModel;
import com.newhope.nlbp.common.model.NlbpPigStyModel;
import com.newhope.nlbp.common.model.NlbpPigTechnicianHeadModel;
import com.newhope.nlbp.common.model.NlbpPigUnitManagementModel;
import com.newhope.nlbp.common.tools.NumberUtils;
import com.newhope.nlbp.facade.pig.breedingBatch.BatchService;
import com.newhope.nlbp.facade.pig.earnumberfile.NlbpPigEarNumberFileService;
import com.newhope.nlbp.facade.pig.growthPhase.GrowthPhaseService;
import com.newhope.nlbp.facade.pig.pigHogpen.NlbpPigHogpenService;
import com.newhope.nlbp.facade.pig.pigSty.NlbpPigStyService;
import com.newhope.nlbp.facade.pig.technician.NlbpPigTechnicianService;
import com.newhope.nlbp.facade.pig.unitmanage.NlbpPigUnitManagementService;
import com.newhope.nlbp.facade.sys.onhand.NlbpSysOnhandService;
import com.newhope.nlbp.mobile.common.bean.BaseResponse;

import io.swagger.annotations.ApiOperation;

/**
 * 
 * @author zhaochen
 * @date 2017年8月12日 上午14:00:01
 * @dec app提供配种服务
 */
@RestController
@RequestMapping(value = "/pig/mobile/common")
public class CommonResource {

	@Autowired
	private NlbpPigTechnicianService nlbpPigTechnicianService;
	@Autowired
 	private NlbpPigStyService styService;//猪舍
	@Autowired
	private BatchService batchService;
	@Autowired
	private NlbpPigUnitManagementService nlbpPigUnitManagementService;//单元
	@Autowired
	private NlbpPigEarNumberFileService earNumberFileService;
	@Autowired
	private NlbpSysOnhandService onhandService;
	@Autowired
 	private GrowthPhaseService growthPhaseService;
	@Autowired
 	private NlbpPigHogpenService hogpenService;//猪场
	/**
	 * 技术员列表查询
	 * @author zhaochen
	 * @date 2017年8月12日 上午14:04:01
	 * @param headId
	 * @return
	 */
	@RequestMapping(value = "/getTechList", method = {RequestMethod.GET})
	@ApiOperation(value = "技术要求列表查询", httpMethod = "GET", response = BaseResponse.class, notes = "通过用户输入，技术要求列表查询")
	@ResponseBody
	public String getTechList(HttpServletRequest req,NlbpPigBreedLineModel query){
		BaseResponse <List<NlbpPigTechnicianHeadModel>> result = new BaseResponse<List<NlbpPigTechnicianHeadModel>>();
		NlbpPigTechnicianHeadModel nlbpPigTechnicianHead = new NlbpPigTechnicianHeadModel();
		List<NlbpPigTechnicianHeadModel> list = nlbpPigTechnicianService.findList(nlbpPigTechnicianHead);
		try{
			result.setResult(list);
			result.setStatus(1);
			result.setMessage("sucess");
		}catch(Exception e){
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
		}
		return JSON.toJSONString(result);
	}
	
	/**
	 * 舍信息查询
	 * @author zhaochen
	 * @date 2017年8月12日 上午14:04:01
	 * @param hogpenid    styType
	 * @return
	 */
	@RequestMapping(value = "/getStyInfo", method = {RequestMethod.POST})
	@ApiOperation(value = "舍信息查询", httpMethod = "POST", response = BaseResponse.class, notes = "根据猪场，类型，找到对应的舍信息")
	@ResponseBody
	public String getStyInfo(HttpServletRequest req,@RequestBody NlbpPigStyModel filter){
		BaseResponse <List<Map>> result = new BaseResponse<List<Map>>();
		try{
			List<Map> styList = styService.getSty(filter);
			result.setResult(styList);
			result.setStatus(1);
			result.setMessage("sucess");
		}catch(Exception e){
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
		}
		return JSON.toJSONString(result);
	}
	
	/**
	 * 配种批查询
	 * @author zhaochen
	 * @date 2017年8月8日 上午14:04:01
	 * @param headId
	 * @return
	 */
	@RequestMapping(value = "/getBatchList", method = {RequestMethod.GET})
	@ApiOperation(value = "批查询", httpMethod = "GET", response = BaseResponse.class, notes = "通过用户输入，模糊查询批")
	@ResponseBody
	public String getBatchList(HttpServletRequest req) {
		
		BaseResponse <List<Map>> result = new BaseResponse<List<Map>>();
		String batchType = req.getParameter("batchType");
		NlbpPigBatchModel mode = new NlbpPigBatchModel();
		if(batchType.equals("ALL")){
			batchType = null;
		}
		String status = req.getParameter("status");
		if(StringUtils.isNotEmpty(status)){
			mode.setStatus(status);
		}
		
		String sexCode = req.getParameter("sexCode");
		if(StringUtils.isNotEmpty(sexCode)){
			mode.setSex(sexCode);
		}
		mode.setBatchType(batchType);
		// 猪场
		String pigHogIdStr = req.getParameter("pigHogId");
		if(pigHogIdStr != null){
			Long pigHogId = Long.parseLong(pigHogIdStr);
			if (pigHogId > 0) {
				mode.setPigHogId(pigHogId);
			}
		}
		
		// 猪舍
		String sty = req.getParameter("pigStyId");
		if(sty!=null){
			mode.setPigPigstyId(Long.parseLong(sty));
		}
		String orgId = req.getParameter("orgId");
		if(StringUtils.isEmpty(orgId)){
			result.setStatus(0);
			result.setMessage("failure:组织Id为空");
			return JSON.toJSONString(result);
		}
		
		String batchCode = req.getParameter("batchCode");
		mode.setBatchType(batchType);
		mode.setBatchNumber(batchCode);
		mode.setOrganizationId(Long.parseLong(orgId));
		
		try{
			List<Map> batchList = batchService.getBatch(mode);
			result.setResult(batchList);
			result.setStatus(1);
			result.setMessage("sucess");
		}catch(Exception e){
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
		}
		return JSON.toJSONString(result);
	}
	
	/**
	 * 根据猪舍查询单元
	 * @author zhaochen
	 * @date 2017年8月14日 上午14:04:01
	 * @param styId
	 * @return
	 */
	@RequestMapping(value = "/getUnitListBySty", method = {RequestMethod.GET})
	@ApiOperation(value = "单元查询", httpMethod = "GET", response = BaseResponse.class, notes = "通过用户输入的舍ID，模糊查询单元")
	@ResponseBody
	public String getUnitListBySty(HttpServletRequest req) {
		String styIdStr = req.getParameter("styId");
		Long styId = Long.parseLong(styIdStr);
		BaseResponse <List> result = new BaseResponse<List>();
		if(NumberUtils.isEmptyLong(styId)){
			result.setStatus(0);
			result.setMessage("failure:舍Id不存在");
			return JSON.toJSONString(result);
		}

		NlbpPigUnitManagementModel unitModel = new NlbpPigUnitManagementModel();
		unitModel.setStyId(styId);
		
		try{
			List list = nlbpPigUnitManagementService.findList(unitModel);
			result.setResult(list);
			result.setStatus(1);
			result.setMessage("sucess");
		}catch(Exception e){
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
		}
		return JSON.toJSONString(result);
	}
	
	/**
	 * 根据条件查询耳号列表
	 * @author zhaochen
	 * @date 2017年8月14日 上午14:04:01
	 * @param houseId
	 * @return
	 */
	@RequestMapping(value = "/getEarAllList", method = {RequestMethod.GET})
	@ApiOperation(value = "耳号列表查询", httpMethod = "GET", response = BaseResponse.class, notes = "通过用户输入，查询耳号列表")
	@ResponseBody
	public String getEarAllList(HttpServletRequest req) {
		BaseResponse <List> result = new BaseResponse<List>();
		Map<String, Object> param = new HashMap<String, Object>();
		//猪舍
		param.put("houseId", req.getParameter("houseId"));
		//引种批次号
		param.put("batchId", req.getParameter("batchId"));
		//单元号
		param.put("untiId", req.getParameter("untiId"));
		//耳牌号
		param.put("queryEarNumb", req.getParameter("queryEarNumb"));
		//是否离场
		param.put("isLeave", req.getParameter("isLeave"));
		//档案状态：入群，淘汰
		param.put("fileType", req.getParameter("fileType"));
		//猪只性别
		param.put("pigSex", req.getParameter("pigSex"));
		//当前批次ID
		param.put("crurrentBatchId",  req.getParameter("crurrentBatchId"));
		//当前批次
		param.put("crurrentBatchNo",  req.getParameter("crurrentBatchNo"));
		//生长阶段
		param.put("parturitionType", req.getParameter("parturitionType"));
		param.put("queryBatchNo",  req.getParameter("queryBatchNo"));
		param.put("currentEventType", req.getParameter("currentEventType")); // 
		try{
			List list = earNumberFileService.getEarnumbAll(param);
			result.setResult(list);
			result.setStatus(1);
			result.setMessage("sucess");
		}catch(Exception e){
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
		}
		return JSON.toJSONString(result);
	}
	
	/**
	 * @描述:		猪只存栏服务
	 * @作者: 	yangf  
	 * @日期: 	2017年8月21日 下午1:39:32  
	 * @返回值:	String
	 */
	@RequestMapping(value = "/getOnhand", method = {RequestMethod.POST})
	@ApiOperation(value = "猪只即使存栏", httpMethod = "POST", response = BaseResponse.class, notes = "猪只即使存栏获取")
	@ResponseBody
	public String getOnhand(@RequestBody NlbpSysOnhandBean bean,HttpServletRequest req){
		BaseResponse<List> result= new BaseResponse<List>(); 
		
		Map<String, Object> param = new HashMap<String, Object>();
		
		//猪场
		param.put("farmId", bean.getHogpenId());
		//引种批次号
		param.put("batchId", bean.getBatchId());
		//单元号
		param.put("untiId", bean.getUnitId());
		//舍
		param.put("styId", bean.getStyId());
		//猪只类型
		String growthType = bean.getGrowthType();
		if(bean.getGrowthType() != null){
			if(growthType.indexOf(',') != -1){
				param.put("batchTypeNoChild", bean.getGrowthType());
				param.put("growthType",null);
			}else{
				param.put("growthType",bean.getGrowthType());
			}
		}
		//去重flg
		param.put("qcflg", bean.getQcflg());
		//猪群类型
		if(StringUtils.isNotEmpty(bean.getBatchType())){
			param.put("batchType",bean.getBatchType());
		}
		try{
			List m = onhandService.getOnhand(param);
			result.setStatus(1);
			result.setMessage("success");
			result.setResult(m);
		}catch(Exception e){
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
		}
		
		return JSON.toJSONString(result);
	}
	/**
	 * @描述:		猪只类型
	 * @作者: 	yangf  
	 * @日期: 	2017年8月21日 下午2:55:05  
	 * @返回值:	String
	 */
	@RequestMapping(value = "/getGrowthPhase", method = {RequestMethod.GET})
	@ApiOperation(value = "生长阶段", httpMethod = "GET", response = BaseResponse.class, notes = "获取生长阶段")
	@ResponseBody
	public String getGrowthPhase(){
		BaseResponse<List<Map>> result= new BaseResponse<List<Map>>(); 
		try{
			List<Map> m = growthPhaseService.getGrowthPhase();
			result.setStatus(1);
			result.setMessage("success");
			result.setResult(m);
		}catch(Exception e){
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
		}
		return JSON.toJSONString(result);
	}
	/**
	 * @描述:		猪场查询
	 * @作者: 	yangf  
	 * @日期: 	2017年8月21日 下午3:01:42  
	 * @返回值:	String
	 */
	@RequestMapping(value = "/getPigHogList", method = {RequestMethod.GET})
	@ApiOperation(value = "猪场", httpMethod = "GET", response = BaseResponse.class, notes = "获取猪场")
	@ResponseBody
	public String getPigHogList(HttpServletRequest req){
		BaseResponse<List> result= new BaseResponse<List>(); 
		try{
			NlbpPigHogpenModel model = new NlbpPigHogpenModel();
			model.setOrganizationId(Long.valueOf(req.getParameter("organizationId")));
			
			List m = hogpenService.getListByFilter(model);
			result.setStatus(1);
			result.setMessage("success");
			result.setResult(m);
		}catch(Exception e){
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
		}
		
		return JSON.toJSONString(result);
	}
}

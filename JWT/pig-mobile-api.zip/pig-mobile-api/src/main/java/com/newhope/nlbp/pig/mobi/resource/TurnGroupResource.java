package com.newhope.nlbp.pig.mobi.resource;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.newhope.nlbp.common.bean.base.page.PageBean;
import com.newhope.nlbp.common.bean.pig.NlbpPigBatchBean;
import com.newhope.nlbp.common.bean.pig.turnGroup.NlbpPigTurnGroupHeaderBean;
import com.newhope.nlbp.common.bean.pig.turnGroup.NlbpPigTurnGroupLineBean;
import com.newhope.nlbp.common.bean.pig.turnGroup.PigTurnGroupBean;
import com.newhope.nlbp.common.constant.ConstantBusi;
import com.newhope.nlbp.common.exception.NlbpBizException;
import com.newhope.nlbp.facade.pig.breedingBatch.BatchService;
import com.newhope.nlbp.facade.pig.earnumberfile.NlbpPigEarNumberFileService;
import com.newhope.nlbp.facade.pig.turnGroup.TurnGroupService;
import com.newhope.nlbp.mobile.common.bean.BaseResponse;
import com.newhope.nlbp.pig.mobi.resource.common.UserUtils;

import io.swagger.annotations.ApiOperation;



@RestController
@RequestMapping(value = "/pig/mobile/turnGroup")
public class TurnGroupResource {

	@Autowired
	private BatchService batchService;
	@Autowired
	private TurnGroupService turnGroupService;
	
	@Autowired
	private UserUtils userUtils;
	@Autowired
	private NlbpPigEarNumberFileService earNumberFileService;

	/**
	 * @描述:		获取转入批次
	 * @作者: 	yangf  
	 * @日期: 	2017年8月16日 上午9:19:16  
	 * @返回值:	String
	 */
	@RequestMapping( value = "/getGotoBatchNo", method = {RequestMethod.POST})
	@ApiOperation(value = "转入批次获取", httpMethod = "POST", response = BaseResponse.class, notes = "通过猪舍、生长阶段获取批次")
	@ResponseBody
	public String getGotoBatchNo(@RequestBody NlbpPigBatchBean bean){
		Long farmId = bean.getPigHogId();
		if(farmId != null){
			farmId = Long.valueOf(farmId);
		}
		Long houseId = bean.getPigPigstyId();
		if(houseId != null){
			houseId = Long.valueOf(houseId);
		}
		
		String pigType = bean.getPigType();
		List<String> batchTypes = new ArrayList<String>();
		if (ConstantBusi.RESERVE_PIG_SOW.equals(pigType) || ConstantBusi.PRODUCTION_PIG_BOAR.equals(pigType)) {// 01:后备母猪,03:生产公猪
			batchTypes.add(ConstantBusi.PIG_BATCH_YZ);
		} else if (ConstantBusi.PRODUCTION_PIG_SOW.equals(pigType)) { // 04:生产母猪
			batchTypes.add(ConstantBusi.PIG_BATCH_PZ);
			batchTypes.add(ConstantBusi.PIG_BATCH_DN);
		} else {
			batchTypes.add(ConstantBusi.PIG_BATCH_SZ);
		}
		
		BaseResponse<List> result= new BaseResponse<List>(); 
		try{
			List<Map> m = batchService.getMultiBatch(batchTypes, farmId, houseId);
			result.setStatus(1);
			result.setMessage("success");
			result.setResult(m);
		}catch(Exception e){
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
		}	
		return JSON.toJSONString(result);
	}
	
	/**
	 * @描述:		获取转群记录
	 * @作者: 	yangf  
	 * @日期: 	2017年8月16日 下午6:29:07  
	 * @返回值:	String
	 */
	@RequestMapping( value = "/getTurnGroupData", method = {RequestMethod.POST})
	@ApiOperation(value = "转群记录获取", httpMethod = "POST", response = BaseResponse.class, notes = "通过查询条件，获取转群记录")
	@ResponseBody
	public String getTurnGroupData(@RequestBody PigTurnGroupBean bean,HttpServletRequest req){

		BaseResponse<PageBean> result= new BaseResponse<PageBean>(); 
		try{
			PageBean page = turnGroupService.getTurnGroupData(bean, userUtils.getPageBean(req));
			if(page.getPageSize() == 0){
				page.setPageSize(1);
			}
			result.setStatus(1);
			result.setMessage("success");
			result.setResult(page);
		}catch(Exception e){
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
			return JSON.toJSONString(result);
		}
		return JSON.toJSONString(result);
	}
	
	/**
	 * @描述:		暂存
	 * @作者: 	yangf  
	 * @日期: 	2017年8月16日 下午6:28:49  
	 * @返回值:	String
	 */
	@RequestMapping(value = "/addOrUpdate", method = {RequestMethod.POST})
	@ApiOperation(value = "转群记录保存", httpMethod = "POST", response = BaseResponse.class, notes = "转群记录保存")
	@ResponseBody
	public String addOrUpdate(@RequestBody NlbpPigTurnGroupHeaderBean bean){
		BaseResponse<String> result= new BaseResponse<String>(); 
		try {
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		String recordDateStr = sdf.format(bean.getRecordDate());
		for (NlbpPigTurnGroupLineBean item : bean.getItemList()) {
			item.setOrganizationId(bean.getOrganizationId());
			Map<String,Object> param = new HashMap<String,Object>();
			param.put("earId", item.getEarFilePk());
			param.put("headerId", item.getHeaderId());
			param.put("currentHoggeryPk", bean.getCurrentHoggeryPk());
			param.put("gotoHoggeryPk",bean.getGotoHoggeryPk());
			param.put("recordDate",recordDateStr);
			int temp = turnGroupService.checkEarNumRepeat(param);
			if(temp > 0){
				result.setStatus(0);
				result.setMessage("failure:" + "耳牌号：" + item.getEarFileName() + "有重复单据！");
				return JSON.toJSONString(result);
			}
		}
		
		
			String temp = turnGroupService.addOrUpdate(bean);
			result.setStatus(1);
			result.setMessage("success");
			result.setResult(temp);
		} catch (NlbpBizException e) {
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
			return JSON.toJSONString(result);
		}
		return JSON.toJSONString(result);
	}
	
	/**
	 * @描述:		提交
	 * @作者: 	yangf  
	 * @日期: 	2017年8月16日 下午6:28:36  
	 * @返回值:	String
	 */
	@RequestMapping( value="submit" , method = {RequestMethod.POST})
	@ApiOperation(value = "转群记录提交", httpMethod = "POST", response = BaseResponse.class, notes = "转群记录提交")
	@ResponseBody
	public String submit(HttpServletRequest request,@RequestBody NlbpPigTurnGroupHeaderBean bean){
		BaseResponse<String> result= new BaseResponse<String>(); 
		try {
			String temp = turnGroupService.submit(bean);
			result.setStatus(1);
			result.setMessage("success");
			result.setResult(temp);
		} catch (NlbpBizException e) {
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
			return JSON.toJSONString(result);
		}
		return JSON.toJSONString(result);
	}
	
	@RequestMapping( value="delete" , method = {RequestMethod.GET})
	@ApiOperation(value = "转群记录提交", httpMethod = "GET", response = BaseResponse.class, notes = "转群记录提交")
	@ResponseBody
	public String delete(@RequestParam(value = "lineIds") String lineIds) throws NlbpBizException{
		BaseResponse<String> result= new BaseResponse<String>(); 
		try {
			String[] lineIdArr = lineIds.split(",");
			for(String lineId : lineIdArr){
				turnGroupService.delete(Long.valueOf(lineId));
			}
			result.setStatus(1);
			result.setMessage("success");
		} catch (NlbpBizException e) {
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
			return JSON.toJSONString(result);
		}
		return JSON.toJSONString(result);
	}
	
	/**
     * @描述:		获取所有提交转群的批次
     * @作者: 	yangf  
     * @日期: 	2017年9月5日 下午7:50:22  
     * @返回值:	List<Map>
     */
	@RequestMapping( value="getBatchByTurnGroup" , method = {RequestMethod.GET})
	@ApiOperation(value = "已转群批次", httpMethod = "GET", response = BaseResponse.class, notes = "获取所有提交转群的批次")
	@ResponseBody
    public String getBatchByTurnGroup(PigTurnGroupBean bean){
		BaseResponse<List<Map>> result= new BaseResponse<List<Map>>(); 
		try {
			List<Map> m = turnGroupService.getBatchByTurnGroup(bean);
			result.setStatus(1);
			result.setMessage("success");
			result.setResult(m);
		} catch (NlbpBizException e) {
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
			return JSON.toJSONString(result);
		}
		return JSON.toJSONString(result);
		
    }
	
	/**
	 * @描述:		配怀转群去向不等于产房舍时获取耳号逻辑
	 * @作者: 	yangf  
	 * @日期: 	2017年9月6日 下午5:05:10  
	 * @返回值:	List
	 */
	@RequestMapping(value = "/getEarForPZZQ", method = {RequestMethod.GET})
	@ApiOperation(value = "耳号列表查询", httpMethod = "GET", response = BaseResponse.class, notes = "查询耳号列表")
	@ResponseBody
	public String getEarForPZZQ(HttpServletRequest req){
		BaseResponse <List> result = new BaseResponse<List>();
		Map<String, Object> param = new HashMap<String, Object>();
		//猪舍
		param.put("houseId", req.getParameter("houseId"));
		//引种批次号
		param.put("batchId", req.getParameter("batchId"));
		//单元号
		param.put("untiId", req.getParameter("untiId"));
		//耳牌号
		param.put("queryEarNumb", req.getParameter("queryEarNumb"));
		//是否离场
		param.put("isLeave", req.getParameter("isLeave"));
		//档案状态：入群，淘汰
		param.put("fileType", req.getParameter("fileType"));
		//猪只性别
		param.put("pigSex", req.getParameter("pigSex"));
		//当前批次ID
		param.put("crurrentBatchId",  req.getParameter("crurrentBatchId"));
		//当前批次
		param.put("crurrentBatchNo",  req.getParameter("crurrentBatchNo"));
		//生长阶段
		param.put("parturitionType", req.getParameter("parturitionType"));
		param.put("queryBatchNo",  req.getParameter("queryBatchNo"));
		param.put("currentEventType", req.getParameter("currentEventType")); // 
		try{
			List list = earNumberFileService.getEarForPZZQ(param);
			result.setResult(list);
			result.setStatus(1);
			result.setMessage("sucess");
		}catch(Exception e){
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
		}
		return JSON.toJSONString(result);
	    
	}

}

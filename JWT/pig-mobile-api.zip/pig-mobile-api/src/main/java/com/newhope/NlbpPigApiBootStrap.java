package com.newhope;

public class NlbpPigApiBootStrap extends WebBootStrap {

	public static void main(String[] args) throws Exception {
		
		WebBootStrap.builder(args).run();
	}
}

package com.newhope.nlbp.pig.mobi.resource;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.google.common.base.Strings;
import com.newhope.nlbp.common.bean.base.page.PageBean;
import com.newhope.nlbp.common.bean.pig.turnherd.SowPregnancyCheckBean;
import com.newhope.nlbp.common.bean.pig.turnherd.SowPregnancyCheckItemBean;
import com.newhope.nlbp.common.constant.ConstantBusi;
import com.newhope.nlbp.common.model.NlbpPigBatchModel;
import com.newhope.nlbp.common.model.NlbpPigStyModel;
import com.newhope.nlbp.common.model.PregnancyCheckRecord;
import com.newhope.nlbp.common.tools.DateUtil;
import com.newhope.nlbp.facade.pig.breedingBatch.BatchService;
import com.newhope.nlbp.facade.pig.pigSty.NlbpPigStyService;
import com.newhope.nlbp.facade.pig.productionManagePlatform.SowPregnancyCheckService;
import com.newhope.nlbp.mobile.common.bean.BaseResponse;
import com.newhope.nlbp.pig.mobi.resource.common.UserUtils;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/pig/mobile/pregnancy")
public class PregnancyResource {
	
	@Autowired
	private SowPregnancyCheckService pregnancyService;

	@Autowired
	private UserUtils userUtils;

	@Autowired
	private BatchService batchService;
	
	@Autowired
 	private NlbpPigStyService styService;

	@SuppressWarnings("rawtypes")
	@RequestMapping("/list")
	@ApiOperation(value = "妊娠检查记录查询", httpMethod = "POST", response = BaseResponse.class, notes = "通过起止日期、当前批次、耳号、检查结果，查询妊娠检查记录")
	@ResponseBody
	public String list(HttpServletRequest req, @RequestBody PregnancyCheckRecord query) {
		BaseResponse<PageBean> result = new BaseResponse<PageBean>();
		if (query.getOrgId() == null) {
			result.setStatus(0);
			result.setMessage("failure:组织Id为空");
			return JSON.toJSONString(result);
		}
		if (query.getHogpenId() == null) {
			result.setStatus(0);
			result.setMessage("failure:猪场Id为空");
			return JSON.toJSONString(result);
		}
		
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("queryPigFarmName", query.getHogpenId());// 猪场ID
		
		// 猪舍ID
		Long hoggeryId = 0L;
		NlbpPigStyModel filter = new NlbpPigStyModel();
		filter.setHogpenid(query.getHogpenId());
		filter.setStyType("BREED_STY");
		List<Map> styList = styService.getSty(filter);
		if (styList.size() > 0) {
			if (styList.get(0).get("id") != null) {
				hoggeryId = Long.parseLong(styList.get(0).get("id") + "");
			} else {
				// 校验猪舍ID
				result.setStatus(0);
				result.setMessage("failure:缺少参数（猪舍ID）");
				return JSON.toJSONString(result);
			}
		}
		param.put("queryHoggery", hoggeryId);
		
		String queryStartDate = query.getBeginDate();// 起止日期
		if (!Strings.isNullOrEmpty(queryStartDate)) {
			Date startDate = DateUtil.parseDate(queryStartDate, DateUtil.DATE_FMT_2);
			param.put("queryStartDate", startDate);
		}
		String queryEndDate = query.getEndDate();// 起止日期
		if (!Strings.isNullOrEmpty(queryEndDate)) {
			Date endDate = DateUtil.parseDate(queryEndDate, DateUtil.DATE_FMT_2);
			param.put("queryEndDate", endDate);
		}
		param.put("batchId", query.getBatchId());// 批次ID
		
		if (query.getEarIds() != null && query.getEarIds().length() > 0) {
			String[] earIdArr = query.getEarIds().split(",");
			List<Long> earIds = new ArrayList<Long>();
			for (String earIdStr : earIdArr) {
				earIds.add(Long.parseLong(earIdStr));
			}
			param.put("earIds", earIds);// 耳牌号ID			
		}
		
		param.put("earCode", query.getEarCode());// 耳牌号编码
		param.put("queryHybridizationResult", query.getCheckResultCode());// 检查结果编码
		param.put("itemStatus", ConstantBusi.RECODE_SUBMIT);// 只查询已提交的
		try {
			PageBean page = pregnancyService.getList(param, userUtils.getPageBean(req));
			if(page.getPageSize() == 0) {
				page.setPageSize(1);
			}
			result.setResult(page);
			result.setStatus(1);
			result.setMessage("sucess");
		} catch (Exception e) {
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
		}
		return JSON.toJSONString(result);
	}

	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "/getBatchList", method = { RequestMethod.POST })
	@ApiOperation(value = "配种批查询", httpMethod = "POST", response = BaseResponse.class, notes = "通过用户输入，模糊查询配种批")
	@ResponseBody
	public String getBatchList(HttpServletRequest req, @RequestBody PregnancyCheckRecord query) {
		BaseResponse<List<Map>> result = new BaseResponse<List<Map>>();
		if (query.getOrgId() == null) {
			result.setStatus(0);
			result.setMessage("failure:组织Id为空");
			return JSON.toJSONString(result);
		}
		if (query.getHogpenId() == null) {
			result.setStatus(0);
			result.setMessage("failure:猪场Id为空");
			return JSON.toJSONString(result);
		}

		NlbpPigBatchModel mode = new NlbpPigBatchModel();
		mode.setBatchType(ConstantBusi.PIG_BATCH_PZ);
		mode.setBatchNumber(query.getBatchCode());
		mode.setOrganizationId(query.getOrgId());
		mode.setPigHogId(query.getHogpenId());
		try {
			List<Map> batchList = batchService.getBatch(mode);
			result.setResult(batchList);
			result.setStatus(1);
			result.setMessage("sucess");
		} catch (Exception e) {
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
		}
		return JSON.toJSONString(result);
	}

	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "/getEarList", method = RequestMethod.POST)
	@ApiOperation(value = "耳号列表查询", httpMethod = "POST", response = BaseResponse.class, notes = "通过用户输入，模糊查询耳号列表")
	@ResponseBody
	public String getEarList(HttpServletRequest req, @RequestBody PregnancyCheckRecord query) {
		BaseResponse<List> result = new BaseResponse<List>();
		if (query.getOrgId() == null) {
			result.setStatus(0);
			result.setMessage("failure:组织Id为空");
			return JSON.toJSONString(result);
		}
		if (query.getHogpenId() == null) {
			result.setStatus(0);
			result.setMessage("failure:猪场Id为空");
			return JSON.toJSONString(result);
		}
		
		try {
			// 猪舍ID
			Long hoggeryId = 0L;
			NlbpPigStyModel filter = new NlbpPigStyModel();
			filter.setHogpenid(query.getHogpenId());
			filter.setStyType("BREED_STY");
			List<Map> styList = styService.getSty(filter);
			if (styList.size() > 0) {
				if (styList.get(0).get("id") != null) {
					hoggeryId = Long.parseLong(styList.get(0).get("id") + "");
				} else {
					// 校验猪舍ID
					result.setStatus(0);
					result.setMessage("failure:缺少参数（猪舍ID）");
					return JSON.toJSONString(result);
				}
			}
			
			Map<String, Object> inParam = new HashMap<String, Object>();
			inParam.put("styId", hoggeryId);
			List<Map<String, Object>> ears = pregnancyService.getEarAndBreedInfo(inParam);
			result.setResult(ears);
			result.setStatus(1);
			result.setMessage("sucess");
		} catch (Exception e) {
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
		}
		return JSON.toJSONString(result);
	}
	
	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "/getEarInfos", method = RequestMethod.POST)
	@ApiOperation(value = "耳号列表查询", httpMethod = "POST", response = BaseResponse.class, notes = "查询耳号列表")
	@ResponseBody
	public String getEarInfos(HttpServletRequest req, @RequestBody PregnancyCheckRecord query) {
		BaseResponse<List> result = new BaseResponse<List>();
		
		List<Long> earIds = new ArrayList<Long>();
		String earIdsStr = query.getEarIds();
		if (earIdsStr != null && earIdsStr.length() > 0) {
			String[] earIdArr = query.getEarIds().split(",");
			for (String earIdStr : earIdArr) {
				earIds.add(Long.parseLong(earIdStr));
			}
		}
		
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("earIds", earIds);
		
		try {
			List<Map<String, Object>> earInfos = pregnancyService.getEarAndBreedInfo(param);
			result.setResult(earInfos);
			result.setStatus(1);
			result.setMessage("sucess");
		} catch (Exception e) {
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
		}
		return JSON.toJSONString(result);
	}

	@RequestMapping(value = "/getHybridizationResult", method = RequestMethod.POST)
	@ApiOperation(value = "获取配种结果", httpMethod = "POST", response = BaseResponse.class, notes = "获取配种结果")
	@ResponseBody
	public String getHybridizationResult(HttpServletRequest req, @RequestBody PregnancyCheckRecord query) {
		BaseResponse<List<Map<String, Object>>> result = new BaseResponse<List<Map<String, Object>>>();
		try {
			List<Map<String, Object>> list = pregnancyService.getPzResult();
			result.setResult(list);
			result.setStatus(1);
			result.setMessage("sucess");
		} catch (Exception e) {
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
		}
		return JSON.toJSONString(result);
	}

	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "/saveOrSubmit", method = RequestMethod.POST)
	@ApiOperation(value = "录入妊娠检查记录", httpMethod = "POST", response = BaseResponse.class, notes = "Flag为0：保存，Flag为1：提交，将妊娠检查记录保存到数据库中")
	@ResponseBody
	public String saveOrSubmit(HttpServletRequest req, @RequestBody SowPregnancyCheckBean headModel) {
		BaseResponse<Map<String, Object>> result = new BaseResponse<Map<String, Object>>();
		Set<String> earSet = new HashSet<String>();
		try {
			// 校验组织ID
			if (headModel.getOrgId() == null) {
				result.setStatus(0);
				result.setMessage("failure:缺少参数（组织ID）");
				return JSON.toJSONString(result);
			}
			// 校验猪场ID
			if (headModel.getHoggeryPk() == null) {
				result.setStatus(0);
				result.setMessage("failure:缺少参数（猪场ID）");
				return JSON.toJSONString(result);
			}
			
			NlbpPigStyModel filter = new NlbpPigStyModel();
			filter.setHogpenid(headModel.getHoggeryPk());
			filter.setStyType("BREED_STY");
			List<Map> styList = styService.getSty(filter);
			if (styList.size() > 0) {
				if (styList.get(0).get("id") != null) {
					headModel.setPigstyPk(Long.parseLong(styList.get(0).get("id") + ""));
				} else {
					// 校验猪舍ID
					result.setStatus(0);
					result.setMessage("failure:缺少参数（猪舍ID）");
					return JSON.toJSONString(result);
				}
			}
			
			// 校验日期
			if (headModel.getRecordDate() == null) {
				result.setStatus(0);
				result.setMessage("failure:缺少参数（日期）");
				return JSON.toJSONString(result);
			}

			List<SowPregnancyCheckItemBean> itemList = headModel.getItemList();
			for (int i = 0; i < itemList.size(); i++) {
				SowPregnancyCheckItemBean lineModel = itemList.get(i);
				// 校验行表母猪耳号ID
				if (lineModel.getSowEarFilePk() == null) {
					result.setStatus(0);
					result.setMessage("failure:缺少参数（母猪耳号ID）");
					return JSON.toJSONString(result);
				}
				
				if(earSet.contains(lineModel.getSowEarFilePk() + "")) {
					result.setStatus(0);
					result.setMessage("妊娠录入：耳号重复");
					return JSON.toJSONString(result);
				}
				
				// 校验检查结果
				if (lineModel.getHybridizationResultCode() == null) {
					result.setStatus(0);
					result.setMessage("failure:缺少参数（检查结果）");
					return JSON.toJSONString(result);
				}
				// 校验操作员ID
				if (lineModel.getTechnicianPk() == null) {
					result.setStatus(0);
					result.setMessage("failure:缺少参数（操作员ID）");
					return JSON.toJSONString(result);
				}
				earSet.add(lineModel.getSowEarFilePk() + "");
			}
			// 新增、提交
			String flag = req.getParameter("flag");
			headModel.setFlag(flag);
			pregnancyService.addOrUpdate(headModel);
			result.setStatus(1);
		} catch (Exception e) {
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
		}
		return JSON.toJSONString(result);
	}
	
	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "/cancel", method = RequestMethod.POST)
	@ApiOperation(value = "作废", httpMethod = "POST", response = BaseResponse.class, notes = "作废")
	@ResponseBody
	public String cancel(HttpServletRequest req, @RequestBody PregnancyCheckRecord query) {
		BaseResponse<List> result = new BaseResponse<List>();
		try {
			String ids = query.getIds();
			pregnancyService.delRecordBatch(ids);
			result.setStatus(1);
			result.setMessage("sucess");
		} catch (Exception e) {
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
		}
		return JSON.toJSONString(result);
	}
	
	@RequestMapping(value = "/batchTrans", method = RequestMethod.POST)
	@ApiOperation(value = "批量转录", httpMethod = "POST", response = BaseResponse.class, notes = "批量转录")
	@ResponseBody
	public String batchTrans(HttpServletRequest req, @RequestBody PregnancyCheckRecord query) {
		BaseResponse<SowPregnancyCheckBean> result = new BaseResponse<SowPregnancyCheckBean>();
		try {
			Long headId = Long.parseLong(query.getHeadId());
			Map<String, Object> inParam = new HashMap<String, Object>();
			inParam.put("mainPk", headId);
			inParam.put("itemStatus", ConstantBusi.RECODE_TEMP);
			SowPregnancyCheckBean pregnancyCheck = pregnancyService.getPregnancyInfo(inParam);
			result.setResult(pregnancyCheck);
			result.setStatus(1);
			result.setMessage("sucess");
		} catch (Exception e) {
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
		}
		return JSON.toJSONString(result);
	}

}

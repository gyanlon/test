package com.newhope.nlbp.pig.mobi.resource.common;

import java.util.Calendar;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.newhope.nlbp.common.bean.base.page.PageBean;

@Service
public class UserUtils {
	@Autowired
	private HttpServletRequest request;
	
	public User getUserInfor()
	{
		User user=new User();
		
		
		String header=request.getHeader("Authorization");
		
		
		
	
		header=header.substring(header.indexOf(".")+1,header.lastIndexOf("."));
			
		String userJson=Base64Util.decode(header);
		

		JSONObject obj=JSON.parseObject(userJson);	
		String username=obj.get("sub").toString();
		user.setUserName(username);
		
		return user;
		
		
	}
	
	/**
	 * 获取page对象
	 * 
	 * @param request
	 * @return page对象
	 */
	public <T> PageBean<T> getPageBean(HttpServletRequest request) {
		int pageNo = 1; // 当前页码
		int pageSize = 20; // 每页行数
		String orderBy = ""; // 排序字段
		String order = ""; // 排序顺序
		if (StringUtils.isNotEmpty(request.getParameter("page")))
			pageNo = Integer.valueOf(request.getParameter("page"));
		if (StringUtils.isNotEmpty(request.getParameter("rows")))
			pageSize = Integer.valueOf(request.getParameter("rows"));
		if (StringUtils.isNotEmpty(request.getParameter("sort")))
			orderBy = request.getParameter("sort").toString();
		if (StringUtils.isNotEmpty(request.getParameter("order")))
			order = request.getParameter("order").toString();
		return new PageBean<T>(pageNo, pageSize, orderBy, order);

	}

	/**
	 * date2比date1多的天数
	 * 
	 * @param date1
	 * @param date2
	 * @return
	 */
	public int differentDays(Date date1, Date date2) {
		Calendar cal1 = Calendar.getInstance();
		cal1.setTime(date1);

		Calendar cal2 = Calendar.getInstance();
		cal2.setTime(date2);
		int day1 = cal1.get(Calendar.DAY_OF_YEAR);
		int day2 = cal2.get(Calendar.DAY_OF_YEAR);

		int year1 = cal1.get(Calendar.YEAR);
		int year2 = cal2.get(Calendar.YEAR);
		if (year1 != year2) // 同一年
		{
			int timeDistance = 0;
			for (int i = year1; i < year2; i++) {
				if (i % 4 == 0 && i % 100 != 0 || i % 400 == 0) // 闰年
				{
					timeDistance += 366;
				} else // 不是闰年
				{
					timeDistance += 365;
				}
			}

			return timeDistance + (day2 - day1);
		} else // 不同年
		{
			System.out.println("判断day2 - day1 : " + (day2 - day1));
			return day2 - day1;
		}
	}
}

//package com.newhope.nlbp.pig.mobi.resource.common;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.ResponseBody;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.alibaba.fastjson.JSON;
//import com.newhope.nlbp.common.model.NlbpPigHogpenModel;
//import com.newhope.nlbp.common.model.NlbpPigStyModel;
//import com.newhope.nlbp.common.model.NlbpPigUnitManagementModel;
//import com.newhope.nlbp.facade.pig.growthPhase.GrowthPhaseService;
//import com.newhope.nlbp.facade.pig.pigHogpen.NlbpPigHogpenService;
//import com.newhope.nlbp.facade.pig.pigSty.NlbpPigStyService;
//import com.newhope.nlbp.facade.pig.unitmanage.NlbpPigUnitManagementService;
//import com.newhope.nlbp.facade.pig.webservice.EbsWebService;
//import com.newhope.nlbp.facade.sys.onhand.NlbpSysOnhandService;
//import com.newhope.nlbp.mobile.common.bean.BaseResponse;
//
//import io.swagger.annotations.ApiOperation;
///**
// * 
// * @desc: pig-api  
// * @author: yangf  
// * @createTime: 2017年8月11日 上午9:30:38  
// * @history:  
// * @version: v1.0
// */
//@RestController
//@RequestMapping(value = "/pig/mobile/common")
//public class PigComponentResource {
//
//	@Autowired
// 	private GrowthPhaseService growthPhaseService;
//	
//	@Autowired
// 	private NlbpPigStyService styService;//猪舍
//	
//	@Autowired
// 	private NlbpPigHogpenService hogpenService;//猪场
//	
//	@Autowired
//	private NlbpPigUnitManagementService nlbpPigUnitManagementService;//单元
//	
//	@Autowired
//	private NlbpSysOnhandService onhandService;
//	
//	@Autowired
//	private EbsWebService ebsWebService;//EBS 接口
//	
//
//	/**
//	 * @描述:		生长阶段
//	 * @作者: 	yangf  
//	 * @日期: 	2017年8月11日 上午10:16:50  
//	 * @返回值:	List<Map>
//	 */
//	@RequestMapping("/getGrowthPhase")
//	@ApiOperation(value = "生长阶段", httpMethod = "GET", response = BaseResponse.class, notes = "获取生长阶段")
//	@ResponseBody
//	public String getGrowthPhase(){
//		BaseResponse<List<Map>> result= new BaseResponse<List<Map>>(); 
//		try{
//			List<Map> m = growthPhaseService.getGrowthPhase();
//			result.setStatus(1);
//			result.setMessage("success");
//			result.setResult(m);
//		}catch(Exception e){
//			result.setStatus(0);
//			result.setMessage("failure:" + e.getMessage());
//		}
//		return JSON.toJSONString(result);
//	}
//	/**
//	 * @描述:		猪场查询
//	 * @作者: 	yangf  
//	 * @日期: 	2017年8月11日 上午10:21:51  
//	 * @返回值:	List
//	 */
//	@RequestMapping("/getPigHogList")
//	@ApiOperation(value = "猪场", httpMethod = "GET", response = BaseResponse.class, notes = "获取猪场")
//	@ResponseBody
//	public String getPigHogList(HttpServletRequest request,HttpServletResponse response,NlbpPigHogpenModel model){
//		BaseResponse<List> result= new BaseResponse<List>(); 
//		try{
//			List m = hogpenService.getListByFilter(model);
//			result.setStatus(1);
//			result.setMessage("success");
//			result.setResult(m);
//		}catch(Exception e){
//			result.setStatus(0);
//			result.setMessage("failure:" + e.getMessage());
//		}
//		
//		return JSON.toJSONString(result);
//	}
//	
//    /**
//     * @描述:		猪舍查询
//     * @作者: 	yangf  
//     * @日期: 	2017年8月11日 上午9:30:26  
//     * @返回值:	List<Map>
//     */
//	@RequestMapping("/getStyList")
//	@ApiOperation(value = "猪舍查询", httpMethod = "GET", response = BaseResponse.class, notes = "通过猪场，获取猪场下的猪舍")
//	@ResponseBody
//	public String getStyList(HttpServletRequest request, NlbpPigStyModel filter){
//		BaseResponse<List<Map>> result= new BaseResponse<List<Map>>(); 
//		if(filter==null){
//			filter=new NlbpPigStyModel();
//		}
//		try{
//			List<Map> m = styService.getSty(filter);
//			result.setStatus(1);
//			result.setMessage("success");
//			result.setResult(m);
//		}catch(Exception e){
//			result.setStatus(0);
//			result.setMessage("failure:" + e.getMessage());
//		}
//		return JSON.toJSONString(result);
//	}
//	
//	@RequestMapping("/getOnhand")
//	@ApiOperation(value = "猪只即使存栏", httpMethod = "POST", response = BaseResponse.class, notes = "猪只即使存栏获取")
//	@ResponseBody
//	public String getOnhand(HttpServletRequest req,HttpServletResponse response){
//		BaseResponse<List> result= new BaseResponse<List>(); 
//		
//		Map<String, Object> param = new HashMap<String, Object>();
//		
//		//猪场
//		param.put("farmId", req.getParameter("farmId"));
//		//引种批次号
//		param.put("batchId", req.getParameter("batchId"));
//		//单元号
//		param.put("untiId", req.getParameter("untiId"));
//		//耳牌号
//		param.put("styId", req.getParameter("styId"));
//		//是否离场
//		param.put("growthType", req.getParameter("growthType"));
//		//档案状态：入群，淘汰
//		param.put("batchNumber", "%" + req.getParameter("batchNumber") + "%");
//		
//		try{
//			List m = onhandService.getOnhand(param);
//			result.setStatus(1);
//			result.setMessage("success");
//			result.setResult(m);
//		}catch(Exception e){
//			result.setStatus(0);
//			result.setMessage("failure:" + e.getMessage());
//		}
//		
//		return JSON.toJSONString(result);
//	}
//	
//	/**
//	 * @描述:		单元
//	 * @作者: 	yangf  
//	 * @日期: 	2017年8月11日 上午10:26:23  
//	 * @返回值:	List<NlbpPigUnitManagementModel>
//	 */
//	@RequestMapping("/getUnitList/{pigStyId}")
//	@ApiOperation(value = "单元", httpMethod = "GET", response = BaseResponse.class, notes = "通过猪舍，获取单元")
//	@ResponseBody
//	public String getUnitList(@PathVariable("pigStyId") Long pigStyId,NlbpPigUnitManagementModel nlbpPigUnitManagement){
//		BaseResponse<List<NlbpPigUnitManagementModel>> result= new BaseResponse<List<NlbpPigUnitManagementModel>>(); 
//		NlbpPigUnitManagementModel mode = new NlbpPigUnitManagementModel();
//		mode.setStyId(pigStyId);
//		try{
//			List<NlbpPigUnitManagementModel> m = nlbpPigUnitManagementService.findList(mode);
//			result.setStatus(1);
//			result.setMessage("success");
//			result.setResult(m);
//		}catch(Exception e){
//			result.setStatus(0);
//			result.setMessage("failure:" + e.getMessage());
//		}
//		return JSON.toJSONString(result);
//		
//	}
//	
//	
//
////	/**
////	 * 根据物料number、养殖场id查询猪对应的仓库及其库存列表
////	 * @author zhaohai
////	 * @date: 2017年2月6日 上午10:23:25
////	 * @return
////	 */
////	@SuppressWarnings("rawtypes")
////	@RequestMapping("/getPigItemQtyInfor/{farmId}/{itemCode}")
////	@ResponseBody
////	public List<Map> getPigItemQtyInfor(@PathVariable("farmId") Long farmId,@PathVariable("itemCode") String itemCode){
////		return ebsWebService.getPigItemQtyInfor(farmId,itemCode);
////	}
//
//}

package com.newhope.nlbp.pig.mobi;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;

@Configuration
@ImportResource( value = { "classpath:/dubbo-client.xml" } )
public class DubboClientAutoConfig {

}

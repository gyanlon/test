package com.newhope.nlbp.pig.mobi.login;

import org.springframework.security.core.GrantedAuthority;

import com.alibaba.fastjson.JSON;
import com.newhope.nlbp.common.bean.sys.user.NlbpUserBean;

class GrantedAuthorityImpl implements GrantedAuthority{
    /**
	 * 
	 */
	private static final long serialVersionUID = -2489141515508156965L;
	private NlbpUserBean authority;

    public GrantedAuthorityImpl(NlbpUserBean authority) {
        this.authority = authority;
    }

    public void setAuthority(NlbpUserBean authority) {
        this.authority = authority;
    }

    @Override
    public String  getAuthority() {
        return JSON.toJSONString(authority);
    }
}

package com.newhope.nlbp.pig.mobi.resource;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.google.common.base.Strings;
import com.newhope.nlbp.common.bean.DocNumEnum;
import com.newhope.nlbp.common.bean.base.page.PageBean;
import com.newhope.nlbp.common.bean.pig.childbirth.ChildBirthParamBean;
import com.newhope.nlbp.common.bean.pig.childbirth.GetOtherInfoForChildBirthBean;
import com.newhope.nlbp.common.bean.pig.childbirth.NlbpChildBirthBean;
import com.newhope.nlbp.common.bean.pig.childbirth.NlbpChildBirthLineBean;
import com.newhope.nlbp.common.bean.pig.turnherd.HybridizationTransferGroupItemBean;
import com.newhope.nlbp.common.constant.pig.PigProductionFileStatus;
import com.newhope.nlbp.common.constant.pig.PigProductionPlatformEvent;
import com.newhope.nlbp.common.exception.NlbpBizException;
import com.newhope.nlbp.common.model.NlbpPigBreedLineModel;
import com.newhope.nlbp.common.model.NlbpPigChildbirthLineModel;
import com.newhope.nlbp.common.model.NlbpPigChildbirthModel;
import com.newhope.nlbp.common.model.NlbpPigEarNumberFileModel;
import com.newhope.nlbp.facade.pig.childbirth.NlbpPigChildbirthService;
import com.newhope.nlbp.facade.sys.countertable.NlbpSysCountertableService;
import com.newhope.nlbp.mobile.common.bean.BaseResponse;
import com.newhope.nlbp.pig.mobi.resource.common.UserUtils;

import io.swagger.annotations.ApiOperation;

/**
 * 产房管理-分娩Controller
 * 
 * @author yuanhaosheng
 * @version 2017-08-17
 */
@RestController
@RequestMapping(value = "/pig/mobile/childbirth")
public class NlbpPigChildBirthResource {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private UserUtils userUtils;

	@Autowired
	private NlbpPigChildbirthService nlbpPigChildbirthService;

	@Autowired
	private NlbpSysCountertableService nlbpSysCountertableService;

	
	/**
	 * 
	 * 方法名：getList 获取分娩记录维护界面数据列表 创建人：yhs
	 * 
	 * @param nlbpChildBirthBean
	 * @param req
	 * @return
	 * @Exception 异常对象
	 */
	@RequestMapping(value = "/getList", method = RequestMethod.POST)	
	@ApiOperation(value = "分娩记录查询", httpMethod = "POST", response = BaseResponse.class, notes = "通过公司id、来源场线ID、 来源猪舍ID、来源单元ID、起始日期、 截止日期、 断奶批ID、耳号ID、 胎次查询分娩记录")
	@ResponseBody
	public String getList(HttpServletRequest req, NlbpChildBirthBean bean) {
		BaseResponse<PageBean> result = new BaseResponse<PageBean>();
		Map<String, String> param = new HashMap<String, String>();

		// 耳号code
		if (bean.getEarNumCode() != null) {
			param.put("earNumCode", bean.getEarNumCode());
		}
		
		// 总仔数开始
		if (bean.getStartTotalPiglets() != null) {
			param.put("startTotalPiglets", bean.getStartTotalPiglets().toString());
		}
		
		// 总仔数结束
		if (bean.getEndTotalPiglets() != null) {
			param.put("endTotalPiglets", bean.getEndTotalPiglets().toString());
		}
		
		// 胎次开始
		if (bean.getStartBirthsNum() != null) {
			param.put("startBirthsNum", bean.getStartBirthsNum().toString());
		}
		
		// 胎次结束
		if (bean.getEndBirthsNum() != null) {
			param.put("endBirthsNum", bean.getEndBirthsNum().toString());
		}
		
		// 活仔数开始
		if (bean.getStartLiveNum() != null) {
			param.put("startLiveNum", bean.getStartLiveNum().toString());
		}
		
		// 活仔数结束
		if (bean.getEndLiveNum() != null) {
			param.put("endLiveNum", bean.getEndLiveNum().toString());
		}
		
		// 状态
		if (StringUtils.isNotBlank(bean.getcStatus())) {
			param.put("cStatus", bean.getcStatus().toString());
		} else {
			result.setStatus(0);
			result.setMessage("failure:状态为空");
			return JSON.toJSONString(result);
		}
		
		// 猪场
		if (bean.getPigfarmId() != null) {
			param.put("pigfarmId", bean.getPigfarmId().toString());
		} else {
			result.setStatus(0);
			result.setMessage("failure:猪场Id为空");
			return JSON.toJSONString(result);
		}

		// 生产线
		if (bean.getBirthLineId() != null) {
			param.put("birthLineId", bean.getBirthLineId().toString());
		}

		// 猪舍
		if (bean.getPigNestId() != null) {
			param.put("pigNestId", bean.getPigNestId().toString());
		}

		// 单元
		if (bean.getUnitId() != null) {
			param.put("unitId", bean.getUnitId().toString());
		}

		// 断奶批
		if (!Strings.isNullOrEmpty(bean.getBatchWeaning())) {
			param.put("batchWeaning", bean.getBatchWeaning());
		}

		// 耳牌号
		if (bean.getEarNum() != null) {
			param.put("earNum", bean.getEarNum().toString());
		}

		// 分娩开始时间
		if (!Strings.isNullOrEmpty(bean.getBeginBirthDate())) {
			param.put("beginBirthDate", bean.getBeginBirthDate());
		}

		// 分娩结束时间
		if (!Strings.isNullOrEmpty(bean.getEndBirthDate())) {
			param.put("endBirthDate", bean.getEndBirthDate());
		}

		// 活仔数
		if (!Strings.isNullOrEmpty(bean.getLiveNum())) {
			param.put("liveNum", bean.getLiveNum());
		}

		try {
			PageBean page = nlbpPigChildbirthService.searchList(param, userUtils.getPageBean(req));

			result.setResult(page);
			result.setStatus(1);
			result.setMessage("sucess");
		} catch (Exception e) {
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
		}
		return JSON.toJSONString(result);
	}

	/**
	 * 分娩记录 更新/新增 保存
	 * 
	 * @param bean
	 * @return
	 * @throws ParseException
	 */
	@RequestMapping(value = "/addOrUpdateRecord", method = RequestMethod.POST)
	@ApiOperation(value = "分娩记录保存/提交", httpMethod = "POST", response = BaseResponse.class, notes = "将分娩记录 保存/提交 到数据库中")
	@ResponseBody	
	public String addOrUpdateRecord(@RequestBody NlbpChildBirthBean bean) {
		BaseResponse<NlbpChildBirthBean> result = new BaseResponse<NlbpChildBirthBean>();
		
		Set<String> earNumSet = new HashSet<String>();
		
		List<NlbpChildBirthLineBean> itenBeanList = bean.getItemList();
		for (NlbpChildBirthLineBean itemBean : itenBeanList) {
			if(earNumSet.contains(itemBean.getEarNum()+"")){
				result.setStatus(0);
				result.setMessage("耳号不能重复");
				return JSON.toJSONString(result);
			}
			earNumSet.add(itemBean.getEarNum()+"");
		}
		
		// 头表数据
		NlbpPigChildbirthModel model;
		try {

			model = bean.toConvertChildbirthModel();

			if (bean.getDocumentsId() == null) {
				model.setDocumentsNum(this.nlbpSysCountertableService.getNewCode(DocNumEnum.CFFM.getCode()));
			}
			Date date = new Date();
			model.setCreationDate(date);
			model.setLastUpdateDate(date);

			bean.setChildbirthModel(model);

			NlbpChildBirthBean resultBean = null;

			resultBean = nlbpPigChildbirthService.addOrUpdateChildBirth(bean);
			resultBean.setId(resultBean.getChildbirthModel().getId());
			resultBean.setDocumentsId(resultBean.getChildbirthModel().getId());

			result.setStatus(1);
			result.setResult(resultBean);
		} catch (Exception e) {
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());

			logger.error("addOrUpdateRecord", e.getMessage());
		}

		return JSON.toJSONString(result);
	}

	/**
	 * 根据id获取编辑画面用分娩记录
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/getRecordDataByHeadId", method = RequestMethod.GET)
	@ApiOperation(value = "查看明细", httpMethod = "GET", response = BaseResponse.class, notes = "根据头ID取出相关明细记录")
	@ResponseBody	
	public String getRecordDataById(Long headId) {
		BaseResponse<NlbpChildBirthBean> result = new BaseResponse<NlbpChildBirthBean>();
		try {

			NlbpChildBirthBean bean = nlbpPigChildbirthService.getRecordDataByHeadId(headId);
			
			result.setResult(bean);
			result.setStatus(1);
		} catch (NlbpBizException e) {
			result.setStatus(0);
			result.setMessage(e.getMessage());
			logger.error("getRecordDataById", e);
		}

		return JSON.toJSONString(result);
	}
	
	/**
	 * 根据id获取编辑画面用分娩记录
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/getRecordDataByHeadIdTemp", method = RequestMethod.GET)
	@ApiOperation(value = "查看暂存的明细", httpMethod = "GET", response = BaseResponse.class, notes = "根据头ID取出相关暂存的明细记录")
	@ResponseBody	
	public String getRecordDataByHeadIdTemp(Long headId) {
		BaseResponse<NlbpChildBirthBean> result = new BaseResponse<NlbpChildBirthBean>();
		try {

			NlbpChildBirthBean bean = nlbpPigChildbirthService.getRecordDataByHeadIdTemp(headId);
			
			result.setResult(bean);
			result.setStatus(1);
		} catch (NlbpBizException e) {
			result.setStatus(0);
			result.setMessage(e.getMessage());
			logger.error("getRecordDataById", e);
		}

		return JSON.toJSONString(result);
	}

	/**
	 * 根据id删除分娩记录
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/deleteChildBirth", method = RequestMethod.GET)
	@ApiOperation(value = "删除记录", httpMethod = "GET", response = BaseResponse.class, notes = "根据行ID删除相关明细记录")
	@ResponseBody
	public String deleteChildBirth(String ids) {
		BaseResponse<NlbpChildBirthBean> result = new BaseResponse<NlbpChildBirthBean>();
		try {

			nlbpPigChildbirthService.deleteChildBirthById(ids);
			result.setStatus(1);
		} catch (NlbpBizException e) {
			result.setStatus(0);
			result.setMessage(e.getMessage());
			logger.error("deleteChildBirth", e);
		}

		return JSON.toJSONString(result);
	}

	/**
	 * 根据母猪耳牌号取得公猪耳牌号
	 * 
	 * @param earNoId 母猪耳牌id, earNum 母猪耳牌号
	 * @return
	 * @Exception 异常对象
	 */
	@RequestMapping(value = "/getFartherEarNoByMotherEarNo", method = RequestMethod.GET)
	@ApiOperation(value = "根据母猪耳号取相关信息", httpMethod = "GET", response = BaseResponse.class, notes = "根据母猪耳号取相关信息")
	@ResponseBody
	public String getFartherEarNoByMotherEarNo(Long earNoId, String earNum) {
		
		BaseResponse<Map<String,Object>> result = new BaseResponse<Map<String,Object>>();
		Map<String,Object> map = new HashMap<String, Object>();
		
		try {
			// 获取该耳牌号母猪的上一个事件是否是“孕检怀孕”
			NlbpPigEarNumberFileModel eventModel = nlbpPigChildbirthService.getEventTypeByEarNo(earNoId);
			
			if (eventModel != null){
				if (!PigProductionFileStatus.PIG_FILE_STATUS_PREGNANCY_TEST.equals(eventModel.getCurrentEventType())){
					result.setStatus(0);
					result.setMessage(("该耳牌号种猪前一事件为非“孕检怀孕”事件，不能添加分娩记录，请确认"));
				}
			}else{
				result.setStatus(0);
				result.setMessage(("该耳牌号种猪前一事件为非“孕检怀孕”事件，不能添加分娩记录，请确认"));
			}
			
			NlbpPigBreedLineModel beanResult  = nlbpPigChildbirthService.getFartherEarNoByMotherEarNo(earNoId);
			
			// 通过母猪 耳号取断奶批和单元
			HybridizationTransferGroupItemBean transfreBean = nlbpPigChildbirthService.getTransferInfoByEarNum(earNoId);
			
			// 获取仔猪死亡数
			if (transfreBean != null && transfreBean.getWeaningBatchPk() != null){
				Map<String, Object> deathInfo = nlbpPigChildbirthService.getDeathNumAndWeightForChild(transfreBean.getWeaningBatchPk(), earNoId);
								
				if (deathInfo != null){
					map.put("deathNum", deathInfo.get("deathInfo"));
				}else{
					map.put("deathNum", 0);
				}
			}
			
			// 获取ebs配怀工单号
			String hyEbsOrderNo = nlbpPigChildbirthService.getHyEBSOrderNo(earNum);
			map.put("hyEbsOrderNo", hyEbsOrderNo);						
			map.put("earInfo", beanResult);			
			map.put("transfreInfo", transfreBean);
			
			result.setResult(map);			
			result.setStatus(1);
		} catch (NlbpBizException e) {
			result.setStatus(0);
			result.setMessage(e.getMessage());
			logger.error("deleteChildBirth", e);
		}

		return JSON.toJSONString(result);
		
	}
	
	/**
	 * 批量根据母猪耳牌号取得公猪耳牌号
	 * 
	 * @param earNoId 母猪耳牌id, earNum 母猪耳牌号
	 * @return
	 * @Exception 异常对象
	 */
	@RequestMapping(value = "/getFartherEarNoByMotherEarNoList", method = RequestMethod.POST)
	@ApiOperation(value = "批量根据母猪耳号取相关信息", httpMethod = "POST", response = BaseResponse.class, notes = "批量根据母猪耳号取相关信息")
	@ResponseBody
	public String getFartherEarNoByMotherEarNoList(@RequestBody ChildBirthParamBean param) {
		
		BaseResponse<List<Map<String,Object>>> result = new BaseResponse<List<Map<String,Object>>>();
		List<Map<String,Object>> lstResult = new ArrayList<Map<String,Object>>();
			
		try {
			for (GetOtherInfoForChildBirthBean bean : param.getItemList()){
				Map<String,Object> map = new HashMap<String, Object>();
				// 获取该耳牌号母猪的上一个事件是否是“孕检怀孕”
				NlbpPigEarNumberFileModel eventModel = nlbpPigChildbirthService.getEventTypeByEarNo(bean.getEarId());
				
				if (eventModel != null){
					if (!PigProductionFileStatus.PIG_FILE_STATUS_PREGNANCY_TEST.equals(eventModel.getCurrentEventType())){
						result.setStatus(0);
						result.setMessage(("该耳牌号种猪前一事件为非“孕检怀孕”事件，不能添加分娩记录，请确认"));
					}
				}else{
					result.setStatus(0);
					result.setMessage(("该耳牌号种猪前一事件为非“孕检怀孕”事件，不能添加分娩记录，请确认"));
				}
				
				NlbpPigBreedLineModel beanResult  = nlbpPigChildbirthService.getFartherEarNoByMotherEarNo(bean.getEarId());
				
				// 通过母猪 耳号取断奶批和单元
				HybridizationTransferGroupItemBean transfreBean = nlbpPigChildbirthService.getTransferInfoByEarNum(bean.getEarId());
				
				// 获取仔猪死亡数
				if (transfreBean != null && transfreBean.getWeaningBatchPk() != null){
					Map<String, Object> deathInfo = nlbpPigChildbirthService.getDeathNumAndWeightForChild(transfreBean.getWeaningBatchPk(), bean.getEarId());
									
					if (deathInfo != null){
						map.put("deathNum", deathInfo.get("deathInfo"));
					}else{
						map.put("deathNum", 0);
					}
				}
				
				// 获取ebs配怀工单号
				String hyEbsOrderNo = nlbpPigChildbirthService.getHyEBSOrderNo(bean.getEarNum());
				map.put("hyEbsOrderNo", hyEbsOrderNo);						
				map.put("earInfo", beanResult);			
				map.put("transfreInfo", transfreBean);
				
				lstResult.add(map);
			}
			
			result.setResult(lstResult);			
			result.setStatus(1);
		} catch (NlbpBizException e) {
			result.setStatus(0);
			result.setMessage(e.getMessage());
			logger.error("deleteChildBirth", e);
		}

		return JSON.toJSONString(result);
		
	}
}

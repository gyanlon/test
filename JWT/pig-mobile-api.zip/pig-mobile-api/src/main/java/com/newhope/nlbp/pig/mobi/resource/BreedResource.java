package com.newhope.nlbp.pig.mobi.resource;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.newhope.nlbp.common.bean.base.page.PageBean;
import com.newhope.nlbp.common.constant.ConstantBusi;
import com.newhope.nlbp.common.model.NlbpPigBreedHeadModel;
import com.newhope.nlbp.common.model.NlbpPigBreedLineModel;
import com.newhope.nlbp.common.model.NlbpPigStyModel;
import com.newhope.nlbp.common.model.NlbpSysDictItemModel;
import com.newhope.nlbp.facade.common.sys.SysDictItemService;
import com.newhope.nlbp.facade.pig.breed.BreedService;
import com.newhope.nlbp.facade.pig.earnumberfile.NlbpPigEarNumberFileService;
import com.newhope.nlbp.facade.pig.empathemaRecord.EmpathemaRecordService;
import com.newhope.nlbp.facade.pig.pigSty.NlbpPigStyService;
import com.newhope.nlbp.facade.pig.semenCollection.SemenCollectionService;
import com.newhope.nlbp.facade.sys.order.NlbpSysOrderManagementService;
import com.newhope.nlbp.mobile.common.bean.BaseResponse;
import com.newhope.nlbp.pig.mobi.resource.common.UserUtils;

import io.swagger.annotations.ApiOperation;


/**
 * 
 * @author zhaochen
 * @date 2017年8月8日 上午14:00:01
 * @dec app提供、配种服务
 */
@RestController
@RequestMapping(value = "/pig/mobile/breed")
public class BreedResource {

	@Autowired
	private BreedService breedService;
	@Autowired
	private UserUtils userUtils;
	@Autowired
	private NlbpPigEarNumberFileService earNumberFileService;
	@Autowired
	private SemenCollectionService semenCollectionService;
	@Autowired
	private EmpathemaRecordService empathemaRecordService;
	@Autowired
	private NlbpSysOrderManagementService nlbpSysOrderManagementService;
	@Autowired
	private SysDictItemService sysDictItemService;
	@Autowired
 	private NlbpPigStyService styService;//猪舍
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	/**
	 * 配种列表查询
	 * @author zhaochen
	 * @date 2017年8月8日 上午14:04:01
	 * @param headId
	 * @return
	 */
	@RequestMapping("/list")
	@ApiOperation(value = "配种记录查询", httpMethod = "POST", response = BaseResponse.class, notes = "通过配种日期，配种批，猪群类型，耳号，胎次，查询配种记录")
	@ResponseBody
	public String list(HttpServletRequest req,@RequestBody NlbpPigBreedLineModel query) {
		BaseResponse <PageBean> result = new BaseResponse<PageBean>();
		//组织ID非空校验
		if(query.getOrgId() == null){
			result.setStatus(0);
			result.setMessage("配种记录查询：组织Id为空");
			return JSON.toJSONString(result);
		}
		//猪场ID非空校验
		if(query.getFarmId() == null){
			result.setStatus(0);
			result.setMessage("配种记录查询：猪场Id为空");
			return JSON.toJSONString(result);
		}
		
		//猪群类型 0后备 1经产
		if(query.getType() == null){
			result.setStatus(0);
			result.setMessage("配种记录查询：猪群类型为空");
			return JSON.toJSONString(result);
		}
		query.setStatus(ConstantBusi.RECODE_SUBMIT);
		try{
			PageBean page = breedService.getList(query, userUtils.getPageBean(req));
			if(page.getPageSize() == 0){
				page.setPageSize(1);
			}
			result.setResult(page);
			result.setStatus(1);
			result.setMessage("sucess");
		}catch(Exception e){
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
		}
		return JSON.toJSONString(result);
	}
	
	
	/**
	 * 耳号查询
	 * @author zhaochen
	 * @date 2017年8月8日 上午14:04:01
	 * @param headId
	 * @return
	 */
	@RequestMapping(value = "/getEarList", method = RequestMethod.POST)
	@ApiOperation(value = "耳号列表查询", httpMethod = "POST", response = BaseResponse.class, notes = "通过用户输入，模糊查询耳号列表")
	@ResponseBody
	public String getEarList(HttpServletRequest req,@RequestBody NlbpPigBreedLineModel query){
		
		BaseResponse <List> result = new BaseResponse<List>();
		//猪场ID非空校验
		if(query.getFarmId() == null){
			result.setStatus(0);
			result.setMessage("耳号查询：猪场Id（farmId）为空");
			return JSON.toJSONString(result);
		}
		logger.info("入参FarmId:" + query.getFarmId());
//		if(query.getPigType() == null){
//			result.setStatus(0);
//			result.setMessage("failure:猪群类型（pigType）为空");
//			return JSON.toJSONString(result);
//		}
		if(query.getQueryStartDate() == null){
			result.setStatus(0);
			result.setMessage("耳号查询：配种日期（queryStartDate）为空");
			return JSON.toJSONString(result);
		}
		logger.info("入参QueryStartDate:" + query.getQueryStartDate());
		if(query.getHouseId() == null){
			result.setStatus(0);
			result.setMessage("耳号查询：猪舍为空");
			return JSON.toJSONString(result);
		}
		logger.info("入参HouseId:" + query.getHouseId());
		try{
			NlbpPigStyModel filter = new NlbpPigStyModel();
			filter.setHogpenid(query.getFarmId());
			filter.setStyType("BREED_STY");
			List<Map> styList = styService.getSty(filter);
			int unitFlg = 0;
			if(styList.size() > 0){
				if(styList.get(0).get("id") != null){
					logger.info("查询猪场配怀舍:" + styList.get(0).get("id"));
					String styId = styList.get(0).get("id")+"";
					if(styId.equals(query.getHouseId()+"")){
						List<Map<String, Object>> earFileList = empathemaRecordService.getEmpathemaEarFileApp(query.getHouseId(), query.getQueryStartDate(), query.getEarCodeSow());
						result.setResult(earFileList);
						unitFlg = 1;
					}
				}
			}
			
			if(unitFlg == 0){
				result.setStatus(0);
				result.setMessage("配种录入：猪舍不是配怀舍");
				return JSON.toJSONString(result);
			}
			
			result.setStatus(1);
			result.setMessage("sucess");
		}catch(Exception e){
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
		}
		return JSON.toJSONString(result);
	}
	
	/**
	 * 精液批次查询
	 * @author zhaochen
	 * @date 2017年8月8日 上午14:04:01
	 * @param headId
	 * @return
	 */
	@RequestMapping(value = "/getSemenBatch", method = RequestMethod.POST)
	@ApiOperation(value = "精液批次查询", httpMethod = "POST", response = BaseResponse.class, notes = "通过用户输入，精液批次查询列表")
	@ResponseBody
	public String getSemenBatch(HttpServletRequest req,@RequestBody NlbpPigBreedLineModel query){
		BaseResponse <List<Map<String, Object>>> result = new BaseResponse<List<Map<String, Object>>>();
		
		//组织ID非空校验
		if(query.getOrgId() == null){
			result.setStatus(0);
			result.setMessage("精液批次查询：组织Id为空");
			return JSON.toJSONString(result);
		}
//		//猪场ID非空校验
//		if(query.getFarmId() == null){
//			result.setStatus(0);
//			result.setMessage("failure:猪场Id为空");
//			return JSON.toJSONString(result);
//		}
//		//猪场ID非空校验
//		if(query.getHouseId() == null){
//			result.setStatus(0);
//			result.setMessage("failure:猪舍Id为空");
//			return JSON.toJSONString(result);
//		}
//		
//		//猪群类型 0后备 1经产
//		if(query.getType() == null){
//			result.setStatus(0);
//			result.setMessage("failure:猪群类型为空");
//			return JSON.toJSONString(result);
//		}
		
//		//耳号id
//		if(query.getEarIdSow() == null){
//			result.setStatus(0);
//			result.setMessage("failure:耳号ID为空");
//			return JSON.toJSONString(result);
//		}
		
		try{
			if(StringUtils.isNotEmpty(query.getSemenBatchCode())){
				query.setSemenBatchCode(null);
			}
			List<Map<String, Object>> list = semenCollectionService.getSemenBatchAppList(query.getType(), null, query.getHouseId(), query.getEarIdSow(),query.getSemenBatchCode());
			result.setResult(list);
			result.setStatus(1);
			result.setMessage("sucess");
		}catch(Exception e){
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
		}
		return JSON.toJSONString(result);
	}
	
	
	
	/**
	 * 配种录入
	 * @author zhaochen
	 * @date 2017年8月8日 上午14:04:01
	 * @return
	 */
	@RequestMapping(value = "/saveOrSubmit", method = RequestMethod.POST)
	@ApiOperation(value = "配种录入", httpMethod = "POST", response = BaseResponse.class, notes = "Flg为0：保存，Flg为1：提交，将配种记录保存到数据库中")
	@ResponseBody
	public String saveOrSubmit(HttpServletRequest req,@RequestBody NlbpPigBreedHeadModel headModel){
		Set<String> breedSet = new HashSet<String>();
		BaseResponse<Map<String,Object>> result = new BaseResponse<Map<String,Object>>();
		if(headModel.getCreator() != null){
			headModel.setCreatedBy(Long.parseLong(headModel.getCreator()));
		}
		try{
		//校验组织ID
			NlbpPigStyModel filter = new NlbpPigStyModel();
			if(headModel.getOrgId() == null){
				result.setStatus(0);
				result.setMessage("配种录入：缺少参数（组织ID）");
				return JSON.toJSONString(result);
			}
		//校验猪场ID	
			if(headModel.getFarmId() == null){
				result.setStatus(0);
				result.setMessage("配种录入：缺少参数（猪场ID）");
				return JSON.toJSONString(result);
			}
			filter.setHogpenid(headModel.getFarmId());
			filter.setStyType("BREED_STY");
			List<Map> styList = styService.getSty(filter);
			if(styList.size() > 0){
				if(styList.get(0).get("id") != null){
					headModel.setHouseId(Long.parseLong(styList.get(0).get("id") + ""));
				}else{
		//校验猪舍ID
					result.setStatus(0);
					result.setMessage("配种录入：猪舍不是配怀舍");
					return JSON.toJSONString(result);
				}
			}
			String date = headModel.getDate();
		//校验配种日期
			if(StringUtils.isEmpty(date)){
				result.setStatus(0);
				result.setMessage("配种录入：缺少参数（配种日期）");
				return JSON.toJSONString(result);
			}
			List<Map<String, Object>> earFileList = empathemaRecordService.getEmpathemaEarFileApp(headModel.getHouseId(), date,"");
			Map<String,Map<String,Object>> earFileMap = new HashMap<String,Map<String,Object>>();
			for(Map<String,Object> earFile : earFileList){
				earFileMap.put(earFile.get("earId")+"", earFile);
			}
			
			List<NlbpPigBreedLineModel> lineList = headModel.getLineList();
			if(lineList.size() == 0){
				result.setStatus(0);
				result.setMessage("配种录入：缺少配种行信息");
				return JSON.toJSONString(result);
			}
			for(int i=0;i<lineList.size();i++){
				NlbpPigBreedLineModel lineModel = lineList.get(i);
				
				lineModel.setOrgId(headModel.getOrgId());
				lineModel.setFarmId(headModel.getFarmId());
				lineModel.setHouseId(headModel.getHouseId());
				//引种批Code
				if(earFileMap == null){
					result.setStatus(0);
					result.setMessage("配种录入：行表耳号在耳号列表查询中找不到");
					return JSON.toJSONString(result);
				}
		//校验行表母猪耳号ID
				if(lineModel.getEarIdSow() == null){
					result.setStatus(0);
					result.setMessage("配种录入：缺少参数（母猪耳号ID）");
					return JSON.toJSONString(result);
				}
		//校验精液批次编码
				if(StringUtils.isEmpty(lineModel.getSemenBatchCode())){
					result.setStatus(0);
					result.setMessage("配种录入：缺少参数（精液批次编码）");
					return JSON.toJSONString(result);
				}
		//校验精液批次ID
				if(lineModel.getSemenBatchId() == null){
					result.setStatus(0);
					result.setMessage("配种录入：缺少参数（精液批次ID）");
					return JSON.toJSONString(result);
				}
		//校验精液使用份数
				if(lineModel.getSemenQuantity() == null){
					result.setStatus(0);
					result.setMessage("配种录入：缺少参数（精液使用份数）");
					return JSON.toJSONString(result);
				}
		//校验公猪耳号编码
				if(StringUtils.isEmpty(lineModel.getEarCodeBoar())){
					result.setStatus(0);
					result.setMessage("配种录入：缺少参数（公猪耳号编码）");
					return JSON.toJSONString(result);
				}
		//校验公猪耳号ID
				if(lineModel.getEarIdBoar() == null){
					result.setStatus(0);
					result.setMessage("配种录入：缺少参数（公猪耳号Id）");
					return JSON.toJSONString(result);
				}
		//校验操作员ID
				if(lineModel.getEmployeeId() == null){
					result.setStatus(0);
					result.setMessage("配种录入：缺少参数（操作员ID）");
					return JSON.toJSONString(result);
				}
		//校验操作员名称
				if(StringUtils.isEmpty(lineModel.getEmployeeName())){
					result.setStatus(0);
					result.setMessage("配种录入：缺少参数（操作员ID）");
					return JSON.toJSONString(result);
				}
		//校验发情表现
				if(StringUtils.isEmpty(lineModel.getEmpathemaPerf())){
					result.setStatus(0);
					result.setMessage("配种录入：缺少参数（发情表现）");
					return JSON.toJSONString(result);
				}
				
				if(breedSet.contains(lineModel.getEarIdSow() +"")){
					result.setStatus(0);
					result.setMessage("配种录入：母猪耳号重复");
					return JSON.toJSONString(result);
				}
				
				Map<String,Object> earInfo = earFileMap.get(lineModel.getEarIdSow()+"");
				
				if(earInfo == null){
					result.setStatus(0);
					result.setMessage("配种录入：母猪不是待配种的猪");
					return JSON.toJSONString(result);
				}
				
				
				String batchCode = earInfo.get("batchCode")+"";
				lineModel.setBatchCode(batchCode);
				
				lineModel.setEarCodeSow(earInfo.get("earCode")+"");
				
				//引种批Id
				Long batchId = 0l;
				if(earInfo.get("batchId") != null){
					batchId = (Long)earInfo.get("batchId");
				}
				lineModel.setBatchId(batchId);
				//当前胎次
				int currentParity = 0;
				if(earInfo.get("currentParity") != null){
					currentParity = Integer.parseInt(earInfo.get("currentParity")+"");
				}
				
				if(lineModel.getWeight() == null){
					if(earInfo.get("weight") != null){
						lineModel.setWeight(Double.parseDouble(earInfo.get("weight")+""));
					}else{
						lineModel.setWeight(0.0);
					}
				}
				
				lineModel.setCurrentParity(currentParity);
				//耳号编码
				String earCodeSow = earInfo.get("earCode") + "";
				lineModel.setEarCodeSow(earCodeSow);
	//*			//发情表现
//				String empathemaPerf = earInfo.get("empathemaPerf") + "";
//				lineModel.setEmpathemaPerf("PIG_EMPATHEMA_BEHAVIOR_STILL");
				String empathemaPerfText = lineModel.getEmpathemaPerf();
				lineModel.setEmpathemaPerfText(empathemaPerfText);
				//发情次数
				int empathemaCount = 0;
				if(earInfo.get("empathemaCount") != null){
					empathemaCount = (Integer)earInfo.get("empathemaCount");
				}
				
				lineModel.setEmpathemaCount(empathemaCount);
				//后备工单号
				String reserveOrderNo = "";
				if(earInfo.get("reserveOrderNo") != null){
					reserveOrderNo = earInfo.get("reserveOrderNo") + "";
				}
				lineModel.setReserveOrderNo(reserveOrderNo);
				//日龄
				Date birthDate = (Date)earInfo.get("birthDate");
				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date breedDate = format.parse(date + " 00:00:00");
				lineModel.setDayAge(userUtils.differentDays(birthDate,breedDate));
				//配种次数
				Long earId = lineModel.getEarIdSow();
				Map<String, Object> map = breedService.getRecentBreedByEarId(earId, date);
				int breedTimes = 0;
				if(map.get("currentBreedTimes") != null){
					breedTimes = Integer.parseInt(map.get("currentBreedTimes")+"");
				}else{
					if(map.get("breedTimes") != null){
						breedTimes = Integer.parseInt(map.get("breedTimes")+"") + 1;
					}
				}
				lineModel.setBreedTimes(breedTimes);
	//*			
				if(map.get("firstBreedRecord") != null){
					lineModel.setFirstBreedRecord(Long.parseLong(map.get("firstBreedRecord") + ""));
				}
				
				//breedTypeText  breedType
				List<NlbpSysDictItemModel> dictList = sysDictItemService.findSysDictItemList("BREED_TYPE", "ZHS");
				Map<String,NlbpSysDictItemModel> jyMap = new HashMap<String, NlbpSysDictItemModel>();
				for(NlbpSysDictItemModel dict : dictList){
					jyMap.put(dict.getDescription(), dict);
				}
				lineModel.setBreedType(jyMap.get("人工鲜精").getDictItemCode());
				lineModel.setBreedTypeText("人工鲜精");
				
				//breedDurationText  breedDuration
				List<NlbpSysDictItemModel> dictDurationList = sysDictItemService.findSysDictItemList("PIG_BREED_DURATION", "ZHS");
				Map<String,NlbpSysDictItemModel> durationMap = new HashMap<String, NlbpSysDictItemModel>();
				for(NlbpSysDictItemModel dict : dictDurationList){
					durationMap.put(dict.getDictItemName(), dict);
				}
		//校验配种时间
				if(lineModel.getBreedDurationText() == null){
					result.setStatus(0);
					result.setMessage("配种录入：缺少参数（配种时间上，下午）");
					return JSON.toJSONString(result);
				}
				//BreedDurationText 画面传入				
				lineModel.setBreedDuration(durationMap.get(lineModel.getBreedDurationText()).getDictItemCode());
				if(lineModel.getCreator() != null){
					lineModel.setCreatedBy(Long.parseLong(lineModel.getCreator()));
				}
				//配怀工单
				String orderNo = nlbpSysOrderManagementService.getOrderNoByEarNum(earCodeSow);
				lineModel.setOrderNo(orderNo);
				if(lineModel.getLineId() != null){
					lineModel.setId(Long.parseLong(lineModel.getLineId()));
				}
				breedSet.add(earId + "");
			}
			String submitFlg = req.getParameter("submitFlg");
			headModel = breedService.addOrUpdate(headModel,submitFlg);
			result.setStatus(1);
		}catch(Exception e ){
			result.setStatus(0);
			if(e.getMessage().indexOf("存栏数据为负") != -1){
				result.setMessage("failure:存栏数据为负");
			}else{
				result.setMessage("failure:" + e.getMessage());
			}
			e.getStackTrace();
		}
		return JSON.toJSONString(result);
	}
	

	/**
	 * 转录列表查询
	 * @author zhaochen
	 * @date 2017年8月8日 上午14:04:01
	 * @param headId
	 * @return
	 */
	@RequestMapping(value = "/getBreedInitList", method = RequestMethod.POST)
	@ApiOperation(value = "转录列表查询", httpMethod = "POST", response = BaseResponse.class, notes = "根据用户选择的猪只信息，初始化配种列表")
	@ResponseBody
	public String getBreedInitList(HttpServletRequest req,@RequestParam(value = "earIds") String earIds,@RequestParam(value = "headId") String headId){
		BaseResponse <NlbpPigBreedHeadModel> result = new BaseResponse<NlbpPigBreedHeadModel>();
		try{
			NlbpPigBreedHeadModel head = earNumberFileService.getBreedAppInitLineList(earIds,headId,ConstantBusi.RECODE_TEMP);
			result.setResult(head);
			result.setStatus(1);
			result.setMessage("sucess");
		}catch(Exception e){
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
		}
		return JSON.toJSONString(result);
	}
	
	
	/**
	 * 配种明细删除
	 * @author zhaochen
	 * @date 2017年8月8日 上午14:04:01
	 * @param lineId
	 * @return
	 */
	@RequestMapping("/delete")
	@ApiOperation(value = "配种行删除", httpMethod = "POST", response = BaseResponse.class, notes = "配种行删除")
	@ResponseBody
	public String list(HttpServletRequest req,@RequestParam(value = "lineIds") String lineIds) {
		BaseResponse <String> result = new BaseResponse<String>();
		//组织ID非空校验
		try{
			String[] lineId_arr = lineIds.split(",");
			for(String lineIdStr : lineId_arr){
				Long lineId = Long.parseLong(lineIdStr);
				breedService.deleteLine(lineId);
			}
			result.setStatus(1);
			result.setMessage("sucess");
		}catch(Exception e){
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
		}
		return JSON.toJSONString(result);
	}
}

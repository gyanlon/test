package com.newhope.nlbp.pig.mobi.resource;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.google.common.base.Strings;
import com.newhope.nlbp.common.bean.DocNumEnum;
import com.newhope.nlbp.common.bean.base.page.PageBean;
import com.newhope.nlbp.common.bean.pig.childbirth.NlbpChildBirthLineBean;
import com.newhope.nlbp.common.bean.pig.turnherd.HybridizationTransferGroupItemBean;
import com.newhope.nlbp.common.bean.pig.wean.NlbpPigWeanBean;
import com.newhope.nlbp.common.bean.pig.wean.NlbpPigWeanLineBean;
import com.newhope.nlbp.common.constant.ConstantBusi;
import com.newhope.nlbp.common.constant.pig.PigProductionFileStatus;
import com.newhope.nlbp.common.model.NlbpPigEarNumberFileModel;
import com.newhope.nlbp.common.model.NlbpPigStyModel;
import com.newhope.nlbp.common.model.NlbpPigWeanHeadModel;
import com.newhope.nlbp.facade.pig.childbirth.NlbpPigChildbirthService;
import com.newhope.nlbp.facade.pig.earnumberfile.NlbpPigEarNumberFileService;
import com.newhope.nlbp.facade.pig.pigSty.NlbpPigStyService;
import com.newhope.nlbp.facade.pig.wean.NlbpPigWeanService;
import com.newhope.nlbp.facade.sys.countertable.NlbpSysCountertableService;
import com.newhope.nlbp.mobile.common.bean.BaseResponse;
import com.newhope.nlbp.pig.mobi.resource.common.UserUtils;

import io.swagger.annotations.ApiOperation;

/**
 * 
 * @author zhaochen
 * @date 2017年8月14日 上午14:00:01
 * @dec app提供断奶服务
 */
@RestController
@RequestMapping(value = "/pig/mobile/wean")
public class WeanResource {

	@Autowired
	private NlbpPigWeanService nlbpPigWeanService;
	@Autowired
	private UserUtils userUtils;
	@Autowired
	private NlbpSysCountertableService nlbpSysCountertableService;
	@Autowired
 	private NlbpPigStyService styService;//猪舍
	@Autowired
	private NlbpPigEarNumberFileService earNumberFileService;
	@Autowired
	private NlbpPigChildbirthService nlbpPigChildbirthService;
	/**
	 * 断奶列表查询
	 * @author zhaochen
	 * @date 2017年8月14日 上午14:04:01
	 * @param headId
	 * @return
	 */
	@RequestMapping("/list")
	@ApiOperation(value = "断奶记录查询", httpMethod = "POST", response = BaseResponse.class, notes = "通过断奶日期，断奶批，耳号，胎次，查询断奶记录")
	@ResponseBody
	public String list(HttpServletRequest req,@RequestBody NlbpPigWeanBean query) {
		BaseResponse <PageBean> result = new BaseResponse<PageBean>();
		Map<String, String> param = new HashMap<String, String>();

		// 猪场
		if (query.getFarmId() != null) {
			param.put("farmId", query.getFarmId().toString());
		}else{
			result.setStatus(0);
			result.setMessage("断奶记录查询:缺少参数（猪场ID）");
			return JSON.toJSONString(result);
		}

		// 猪舍
		if (query.getHouseId() != null) {
			param.put("houseId", query.getHouseId().toString());
		}
		
		// 胎次
		if (query.getBirthTimes() != null) {
			param.put("birthTimes", query.getBirthTimes());
		}

		// 断奶批
		if (query.getBatchId() != null) {
			param.put("batchId", query.getBatchId().toString());
		}

		// 耳牌号
		if (query.getEarId() != null) {
			param.put("earId", query.getEarId().toString());
		}

		// 断奶开始时间
		if (!Strings.isNullOrEmpty(query.getDateBegin())) {
			param.put("dateBegin", query.getDateBegin());
		}

		// 断奶结束时间
		if (!Strings.isNullOrEmpty(query.getDateEnd())) {
			param.put("dateEnd", query.getDateEnd());
		}

		// 耳号查询
		if (!Strings.isNullOrEmpty(query.getEarNo())) {
			param.put("earNo", query.getEarNo());
		}
		// 单元
		if (query.getUnitId() != null) {
			param.put("unitId", query.getUnitId() + "");
		}
		param.put("status", ConstantBusi.RECODE_SUBMIT);
		PageBean page = nlbpPigWeanService.searchList(param, userUtils.getPageBean(req));
		try{
			if(page.getPageSize() == 0){
				page.setPageSize(1);
			}
			result.setResult(page);
			result.setStatus(1);
			result.setMessage("sucess");
		}catch(Exception e){
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
		}
		return JSON.toJSONString(result);
	}
	
	
	/**
	 * 断奶录入
	 * @author zhaochen
	 * @date 2017年8月14日 上午14:04:01
	 * @return
	 */
	@RequestMapping(value = "/saveOrSubmit", method = RequestMethod.POST)
	@ApiOperation(value = "断奶录入", httpMethod = "POST", response = BaseResponse.class, notes = "Flg为0：保存，Flg为1：提交，将断奶记录保存到数据库中")
	@ResponseBody
	public String saveOrSubmit(HttpServletRequest req,@RequestBody NlbpPigWeanBean bean){
		Set<String> earSet = new HashSet<String>();
		BaseResponse<Map<String,Object>> result = new BaseResponse<Map<String,Object>>();
		try {
			
			// 头表数据 
			NlbpPigWeanHeadModel model = bean.toConvertHeadModel();
			Date date = new Date();
			if (StringUtils.isBlank(bean.getDocNo())){
				model.setCreationDate(date);
				model.setDocNo(this.nlbpSysCountertableService.getNewCode(DocNumEnum.CFDN.getCode()));
			}
			model.setLastUpdateDate(date);

			NlbpPigStyModel filter = new NlbpPigStyModel();
			filter.setHogpenid(model.getFarmId());
			filter.setStyType("BIRTH_STY");
			List<Map> styList = styService.getSty(filter);
			if(styList.size() > 0){
				if(styList.get(0).get("id") != null){
					model.setHouseId(Long.parseLong(styList.get(0).get("id") + ""));
				}else{
		//校验猪舍ID
					result.setStatus(0);
					result.setMessage("断奶录入：缺少参数（猪舍ID）");
					return JSON.toJSONString(result);
				}
			}
			
			bean.setNlbpPigWeanHeadModel(model);
			String submitFlg = req.getParameter("submitFlg");
			
			List<NlbpPigWeanLineBean> itemList = bean.getItemList();
			for(int i=0;i<itemList.size();i++){
				Long earNumId = itemList.get(i).getEarId();
				
				String earCode = itemList.get(i).getEarNo();
				if(StringUtils.isNotEmpty(earCode)){
					if(earSet.contains(earNumId+"")){
						result.setStatus(0);
						result.setMessage("断奶录入：耳号"+earCode+"重复");
						return JSON.toJSONString(result);
					}
				}
//				if(earNumId == null){
//					result.setStatus(0);
//					result.setMessage("断奶录入：请选择耳号");
//					return JSON.toJSONString(result);
//				}
				
				if(itemList.get(i).getWeanNum() == null){
					result.setStatus(0);
					result.setMessage("断奶录入：请输入断奶数");
					return JSON.toJSONString(result);
				}
				
				if(itemList.get(i).getWeanWeight() == null){
					result.setStatus(0);
					result.setMessage("断奶录入：请输入断奶重");
					return JSON.toJSONString(result);
				}
				
				// 获取该耳牌号母猪的上一个事件是否是分娩
				NlbpPigEarNumberFileModel eventModel = nlbpPigChildbirthService.getEventTypeByEarNo(earNumId);
				if (eventModel != null){
					if (!PigProductionFileStatus.PIG_FILE_STATUS_DELIVERY.equals(eventModel.getCurrentEventType())){
						result.setStatus(0);
						result.setMessage("断奶录入：该耳牌号种猪前一事件为非分娩事件，不能添加断奶记录，请确认");
						return JSON.toJSONString(result);
					}
				}else{
					result.setStatus(0);
					result.setMessage("断奶录入：该耳牌号种猪前一事件为非分娩事件，不能添加断奶记录，请确认");
					return JSON.toJSONString(result);
				}
				
				// 根据母猪耳号，取出断奶批和单元信息
				HybridizationTransferGroupItemBean transferInfo = nlbpPigChildbirthService.getTransferInfoByEarNum(earNumId);
				Map<String,Object> map = new HashMap<String,Object>();
				if (transferInfo != null){
					map = nlbpPigWeanService.getChildBirthAndAdoptionInfo(earNumId,transferInfo.getWeaningBatchPk());
					String ebsOrderNo = nlbpPigWeanService.getEBSOrderNo(transferInfo.getWeaningBatchPk());
					map.put("ebsOrderNo", ebsOrderNo);
				}
				
				//工单号
				itemList.get(i).setEbsOrderNo(map.get("ebsOrderNo") + "");
				//死亡数
				Map<String,Double> deathInfoMap = (Map)map.get("deathInfoMap");
				Double deathNum = deathInfoMap.get("deathNum");
				if(deathNum != null){
					itemList.get(i).setDeathNum(deathNum.intValue());
				}
				
				//死亡重
				Double deathWeight = deathInfoMap.get("deathWeight");
				if(deathWeight != null){
					itemList.get(i).setDeathWeight(deathWeight);
				}
				
				NlbpChildBirthLineBean  birthLine = (NlbpChildBirthLineBean)map.get("birthLineBean");
				//活仔
				Long aliveNum = birthLine.getChildLivesNum();
				if(aliveNum != null){
					itemList.get(i).setAliveNum(aliveNum.intValue());
				}
				
				//公猪
				if(birthLine.getBoarNum() != null){
					int childNumM = birthLine.getBoarNum();
					itemList.get(i).setChildNumM(childNumM);
				}else{
					itemList.get(i).setChildNumM(0);
				}
				
				//母猪
				if(birthLine.getSowNum() != null){
					int childNumF = birthLine.getSowNum();
					itemList.get(i).setChildNumF(childNumF);
				}else{
					itemList.get(i).setChildNumF(0);
				}
				
				//窝号
				Long broodNo = birthLine.getNestNum();
				itemList.get(i).setBroodNo(broodNo + "");
				
				//断奶日龄
				String birthDate = birthLine.getBirthDate();
				Date now = new Date();
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				Date dnDate = sdf.parse(birthDate);
				int days = userUtils.differentDays(dnDate, now);
				itemList.get(i).setWeanDayAge(days);
			
				//胎次
				Long birthTimes = birthLine.getBirthsNum();
				if(birthTimes != null){
					itemList.get(i).setBirthTimes(birthTimes.intValue());
				}
				if(itemList.get(i).getLineId() != null){
					itemList.get(i).setId(itemList.get(i).getLineId());
				}
				earSet.add(earNumId+"");
			}
			nlbpPigWeanService.addOrUpdateRecord(bean,submitFlg);
			result.setStatus(1);
		}catch(Exception e ){
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
		}
		return JSON.toJSONString(result);
	}
	
	/**
	 * 转录断奶列表查询
	 * @author zhaochen
	 * @date 2017年8月15日 上午14:04:01
	 * @param headId
	 * @return
	 */
	@RequestMapping(value = "/getWeanInitList", method = RequestMethod.POST)
	@ApiOperation(value = "转录断奶列表查询", httpMethod = "POST", response = BaseResponse.class, notes = "根据用户选择的猪只信息，初始化断奶列表")
	@ResponseBody
	public String getWeanInitList(HttpServletRequest req,@RequestParam(value = "earIds") String earIds,@RequestParam(value = "headId") String headId){
		BaseResponse <NlbpPigWeanBean> result = new BaseResponse<NlbpPigWeanBean>();
		try{
			NlbpPigWeanBean weanBean = earNumberFileService.getWeanAppInitLineList(earIds,headId,ConstantBusi.RECODE_TEMP);
			result.setResult(weanBean);
			result.setStatus(1);
		}catch(Exception e ){
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
		}
		return JSON.toJSONString(result);
	}
	
	/**
	 * 配种明细删除
	 * @author zhaochen
	 * @date 2017年8月8日 上午14:04:01
	 * @param lineId
	 * @return
	 */
	@RequestMapping("/delete")
	@ApiOperation(value = "删除断奶行记录", httpMethod = "POST", response = BaseResponse.class, notes = "删除断奶行记录。")
	@ResponseBody
	public String list(HttpServletRequest req,@RequestParam(value = "lineIds") String lineIds) {
		BaseResponse <String> result = new BaseResponse<String>();
		//组织ID非空校验
		try{
			nlbpPigWeanService.deleteRecordByIds(lineIds);
			result.setStatus(1);
			result.setMessage("sucess");
		}catch(Exception e){
			result.setStatus(0);
			result.setMessage("failure:" + e.getMessage());
		}
		return JSON.toJSONString(result);
	}
}

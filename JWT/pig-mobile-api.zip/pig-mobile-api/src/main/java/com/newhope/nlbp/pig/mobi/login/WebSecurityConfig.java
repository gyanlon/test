package com.newhope.nlbp.pig.mobi.login;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.http.HttpMethod;

@Configuration
@EnableWebSecurity
class WebSecurityConfig extends WebSecurityConfigurerAdapter {

    // 设置 HTTP 验证规则
	@Override
	protected void configure(HttpSecurity http) throws Exception {
        // 关闭csrf验证
		http.csrf().disable()
		.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS).and()

                // 对请求进行认证
                .authorizeRequests()
                // 所有 / 的所有请求 都放行/pig/mobile/download
				.antMatchers("/").permitAll()
                // 所有 /login 的POST请求 都放行
				.antMatchers(HttpMethod.OPTIONS).permitAll()
				.antMatchers(HttpMethod.POST).permitAll()
				.antMatchers(HttpMethod.GET).permitAll()
				.antMatchers(HttpMethod.GET, "/pig/mobile/login").permitAll()
				.antMatchers(HttpMethod.GET, "/pig/mobile/version").permitAll()
				.antMatchers(HttpMethod.GET, "/pig/mobile/download").permitAll()
				.antMatchers(HttpMethod.GET, "/swagger-ui.html").permitAll()
				
				
				
				//TODO
				.antMatchers(HttpMethod.GET, "/pig/mobile/common/getTechList").permitAll()
				.antMatchers(HttpMethod.GET, "/pig/mobile/common/getUnitListBySty").permitAll()
				.antMatchers(HttpMethod.POST, "/pig/mobile/common/getStyInfo").permitAll()
				.antMatchers(HttpMethod.GET, "/pig/mobile/common/getEarAllList").permitAll()
				.antMatchers(HttpMethod.POST, "/pig/mobile/common/getOnhand").permitAll()
				.antMatchers(HttpMethod.GET, "/pig/mobile/common/getGrowthPhase").permitAll()
				.antMatchers(HttpMethod.GET, "/pig/mobile/common/getPigHogList").permitAll()
				
				.antMatchers(HttpMethod.POST, "/pig/mobile/breed/getBreedInitList").permitAll()
				.antMatchers(HttpMethod.POST, "/pig/mobile/breed/saveOrSubmit").permitAll()
				.antMatchers(HttpMethod.POST, "/pig/mobile/breed/getSemenBatch").permitAll()
				.antMatchers(HttpMethod.POST, "/pig/mobile/breed/getEarList").permitAll()
				.antMatchers(HttpMethod.GET, "/pig/mobile/common/getBatchList").permitAll()
				.antMatchers(HttpMethod.POST, "/pig/mobile/breed/list").permitAll()
				.antMatchers(HttpMethod.POST, "/pig/mobile/wean/list").permitAll()
				.antMatchers(HttpMethod.POST, "/pig/mobile/wean/saveOrSubmit").permitAll()
				.antMatchers(HttpMethod.POST, "/pig/mobile/wean/getWeanInitList").permitAll()
				
				.antMatchers(HttpMethod.POST, "/pig/mobile/pregnancy/list").permitAll()
				.antMatchers(HttpMethod.POST, "/pig/mobile/pregnancy/getBatchList").permitAll()
				.antMatchers(HttpMethod.POST, "/pig/mobile/pregnancy/getEarList").permitAll()
				.antMatchers(HttpMethod.POST, "/pig/mobile/pregnancy/getHybridizationResult").permitAll()
				.antMatchers(HttpMethod.POST, "/pig/mobile/pregnancy/saveOrSubmit").permitAll()
				.antMatchers(HttpMethod.POST, "/pig/mobile/pregnancy/cancel").permitAll()
				.antMatchers(HttpMethod.POST, "/pig/mobile/pregnancy/batchTrans").permitAll()
				// 分娩开始
				.antMatchers(HttpMethod.POST, "/pig/mobile/childbirth/getList").permitAll()
				.antMatchers(HttpMethod.POST, "/pig/mobile/childbirth/addOrUpdateRecord").permitAll()
				.antMatchers(HttpMethod.GET, "/pig/mobile/childbirth/getRecordDataByHeadId").permitAll()
				.antMatchers(HttpMethod.GET, "/pig/mobile/childbirth/deleteChildBirth").permitAll()		
				.antMatchers(HttpMethod.GET, "/pig/mobile/childbirth/getFartherEarNoByMotherEarNo").permitAll()		
				// 分娩结束
				
				.antMatchers(HttpMethod.POST, "/pig/mobile/empathema/getList").permitAll()
				.antMatchers(HttpMethod.POST, "/pig/mobile/empathema/getEmpathemaInitList").permitAll()
				.antMatchers(HttpMethod.POST, "/pig/mobile/empathema/getEmpathemaTempList").permitAll()
				.antMatchers(HttpMethod.POST, "/pig/mobile/empathema/delList").permitAll()
				.antMatchers(HttpMethod.POST, "/pig/mobile/empathema/submit").permitAll()
				.antMatchers(HttpMethod.POST, "/pig/mobile/empathema/getEarList").permitAll()
				.antMatchers(HttpMethod.POST, "/pig/mobile/empathema/getEmpathemaPerf").permitAll()
				
				.antMatchers(HttpMethod.POST, "/pig/mobile/weanpreadoption/getList").permitAll()
				.antMatchers(HttpMethod.POST, "/pig/mobile/weanaftadoption/getList").permitAll()
				.antMatchers(HttpMethod.POST, "/pig/mobile/weanpreadoption/addOrUpdateRecord").permitAll()
				.antMatchers(HttpMethod.POST, "/pig/mobile/weanaftadoption/addOrUpdateRecord").permitAll()
				
				.antMatchers(HttpMethod.POST, "/pig/mobile/turnGroup/getGotoBatchNo").permitAll()
				.antMatchers(HttpMethod.POST, "/pig/mobile/turnGroup/addOrUpdate").permitAll()
				.antMatchers(HttpMethod.POST, "/pig/mobile/turnGroup/submit").permitAll()
				.antMatchers(HttpMethod.POST, "/pig/mobile/turnGroup/getTurnGroupData").permitAll()
				
//				.antMatchers(HttpMethod.POST).permitAll()
//				.antMatchers(HttpMethod.GET).permitAll()
				
           //      添加权限检测
           //      所有请求需要身份认证
				.anyRequest().authenticated()
				
            .and()
				// 添加一个过滤器 所有访问 /login 的请求交给 JWTLoginFilter 来处理 这个类处理所有的JWT相关内容
				.addFilterBefore(new JWTLoginFilter("/pig/mobile/login", authenticationManager()),
                        UsernamePasswordAuthenticationFilter.class)
				// 添加一个过滤器验证其他请求的Token是否合法
				.addFilterBefore(new JWTAuthenticationFilter(),
						UsernamePasswordAuthenticationFilter.class);

    }

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        // 使用自定义身份验证组件
        auth.authenticationProvider(new CustomAuthenticationProvider());

    }
}
package com.newhope.nlbp.pig.mobi.resource;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;



@RestController
@RequestMapping(value = "/hello")
public class HelloWorldResource {
	
	
	@RequestMapping(method = RequestMethod.GET)
	@io.swagger.annotations.ApiOperation(value = "测试", httpMethod = "GET", response = HelloWorldResource.class, notes = "测试，通过传递一个用户名，接口返回一个打招呼的信息，如：Jack，Hello")
	public @ResponseBody String sayHello(
			@RequestParam(value = "name", required = false, defaultValue = "Jack") String name) {
		
//		BaseResponse <hello> hello2= new BaseResponse(); 
//		
//		hello data= new hello();
//		hello2.setStatus(1);
//		hello2.setMessage("sucess");
//		data.setReturnMeg("Welcome "+name);
//		hello2.setResult(data);
//		return JSON.toJSONString(hello2);
		return null;
	}

}

package com.newhope.nlbp.pig.mobi.resource.login;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;

import com.newhope.nlbp.facade.user.LoginService;

import com.newhope.nlbp.pig.mobi.resource.common.UserUtils;


import io.swagger.annotations.ApiImplicitParam;

@RestController
@RequestMapping(value = "/pig/mobile/changepass")
public class ChangePassword  {
	
	
		@Autowired
		UserUtils userutil;
		@Autowired
		LoginService loginService;
	
	 
	@RequestMapping(method = RequestMethod.GET)
	@io.swagger.annotations.ApiOperation(value="修改密码", notes="修改密码")
    @ApiImplicitParam(name = "newPass", value = "新密码密码", required = true, dataType = "String")
	
	public @ResponseBody String compare(
			@RequestParam(value = "oldPass", required = true) String oldPass,@RequestParam(value = "newPass", required = true) String newPass) {

		
		
		return  JSON.toJSONString(loginService.changePassword(newPass, oldPass, userutil.getUserInfor().getUserName()));
		
		
	}

}
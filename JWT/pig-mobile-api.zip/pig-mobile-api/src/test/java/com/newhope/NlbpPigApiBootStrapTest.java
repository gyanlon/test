package com.newhope;

public class NlbpPigApiBootStrapTest extends WebBootStrap {

	public static void main(String[] args) throws Exception {
		System.setProperty("spring.cloud.config.label", "RD-SIT");
		System.setProperty("log4j.configurationFile", "log4j2.xml");
		WebBootStrap.builder(args).run();
	}
}

#!/bin/sh

# target path
target_path=$1

jar_name=$2
jar_version=0.2.0-SNAPSHOT
cp ${target_path}/${jar_name}-${jar_version}.jar .

ImageName=$2
ImageVersion=0.2.0

# template Dockerfile 
template_file=/var/lib/jenkins/apps/template/Dockerfile

# copy and replace template Dockerfile to this directory
cp ${template_file} .
sed -i 's/$JarName/'$jar_name'-'$jar_version'.jar/g' $(find ./ -name "Dockerfile")

docker build --tag 192.168.0.196:5000/${ImageName}:${ImageVersion} .
docker push 192.168.0.196:5000/${ImageName}:${ImageVersion}


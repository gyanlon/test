docker build --tag 192.168.0.196:5000/nginx-lb:0.0.1 .

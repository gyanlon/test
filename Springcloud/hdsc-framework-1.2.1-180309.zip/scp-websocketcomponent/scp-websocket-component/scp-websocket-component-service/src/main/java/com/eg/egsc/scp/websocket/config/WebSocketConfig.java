package com.eg.egsc.scp.websocket.config;



import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.socket.WebSocketHandler;
import org.springframework.web.socket.config.annotation.EnableWebSocket;
import org.springframework.web.socket.config.annotation.WebSocketConfigurer;
import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry;

import com.eg.egsc.scp.websocket.container.EgscScpVideointercomappWsRealDataHandler;
import com.eg.egsc.scp.websocket.container.HandshakeInterceptor;
import com.eg.egsc.scp.websocket.container.RealDataWebSocketHandler;
import com.eg.egsc.scp.websocket.container.WarnWebSocketHandler;

 
/**
 * @see WebSocket Config WebSocket配置及注册
 * @Class WebSocket Config
 * @Author pengzhixiang
 * @Create In 2017/12/27
 * @version V 0.1
 * 
 */
@Configuration
@EnableWebSocket
public class WebSocketConfig extends WebMvcConfigurerAdapter implements
        WebSocketConfigurer {
	@Autowired
	private Environment env;
	private static final Logger logger = LoggerFactory.getLogger(WebSocketConfig.class);
	
    public WebSocketConfig() {
    }

    @Override
    public void registerWebSocketHandlers(WebSocketHandlerRegistry registry) {
        // 用来注册websocket server实现类
    	logger.info("registry websocket start!");
    	String paths = env.getProperty("websocket.paths", "");
    	if(StringUtils.isBlank(paths)){
    		return;
    	}
    	String[] pathArr = paths.split(",");
    	if(null != pathArr){
    		for(String path : pathArr){
    			if(StringUtils.isNotBlank(path)){
    				registry.addHandler(realDataWebSocketHandler(), path).addInterceptors(new HandshakeInterceptor()).setAllowedOrigins("*");
    		        registry.addHandler(realDataWebSocketHandler(), path).addInterceptors(new HandshakeInterceptor()).setAllowedOrigins("*").withSockJS();
    		        logger.info("registry websocket : "+path);
    			}
    		}
    	}
    	//
    	String egsc_scp_videointercomapp_readData_path="/webSocket/egsc_scp_videointercomapp/readData";
    	registry.addHandler(egscScpVideointercomappWsRealDataHandler(), egsc_scp_videointercomapp_readData_path).addInterceptors(new HandshakeInterceptor()).setAllowedOrigins("*");
    	registry.addHandler(realDataWebSocketHandler(), egsc_scp_videointercomapp_readData_path).addInterceptors(new HandshakeInterceptor()).setAllowedOrigins("*").withSockJS();
    	logger.info("registry websocket : "+egsc_scp_videointercomapp_readData_path);
    	 
    	logger.info("registry websocket success!");
    }

    @Bean
    public WebSocketHandler realDataWebSocketHandler() {
        return new RealDataWebSocketHandler();
    }

    @Bean
    public WebSocketHandler warnWebSocketHandler() {
        return new WarnWebSocketHandler();
    }
    
    @Bean
    public WebSocketHandler egscScpVideointercomappWsRealDataHandler() {
        return new EgscScpVideointercomappWsRealDataHandler();
    }

}

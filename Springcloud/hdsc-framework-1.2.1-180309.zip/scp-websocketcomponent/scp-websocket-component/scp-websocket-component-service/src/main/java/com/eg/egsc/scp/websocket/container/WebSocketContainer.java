package com.eg.egsc.scp.websocket.container;

 
import com.eg.egsc.scp.websocket.bean.WebSocketResult;
import com.eg.egsc.scp.websocket.exception.WebSocketUnknowTypeException;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * @see web sokcet 连接容器
 * @Class WebSocketContainer
 * @Author pengzhixiang
 * @Create In 2017/12/27
 * @version V 0.1
 * 
 */
public class WebSocketContainer {
    private static final Logger logger = LoggerFactory.getLogger(WebSocketContainer.class);
    public static Map<Integer, List<WebSocketSession>> typeSocketsMap = Maps.newConcurrentMap();

    public static void addSession(Integer type, WebSocketSession session) throws WebSocketUnknowTypeException {
        if (WebSocketTypeEnum.isUnknowType(type)) {
            logger.info("unknow type [{}]", type);
            throw new WebSocketUnknowTypeException("unknow webSocket type of [" + type + "]");
        }
        List<WebSocketSession> socketSessions = typeSocketsMap.get(type);
        if (Objects.isNull(socketSessions)) socketSessions = Lists.newArrayList();
        socketSessions.add(session);
        typeSocketsMap.put(type, socketSessions);
    }

    /**
     * 根据类型推送
     * @param <T>
     *
     * @param type
     * @param msg
     */
    public static <T> void sendOfType(Integer type, final WebSocketResult<T> msg) {
        if (WebSocketTypeEnum.isUnknowType(type)) {
            logger.info("unknow type [{}]", type);
            throw new WebSocketUnknowTypeException("unknow webSocket type of [" + type + "]");
        }
        if (typeSocketsMap.get(type) == null) return;

        typeSocketsMap.get(type).parallelStream().forEach(session -> {
            try {
                session.sendMessage(new TextMessage(msg.asJson()));
            } catch (IOException e) {
                logger.error("send msg error", e);
            }
        });

    }

    /**
     * 刷新移除已经关闭的session
     */
    public static void flush() {
        typeSocketsMap.keySet().parallelStream().forEach(
                key -> typeSocketsMap.get(key).removeIf(session -> !session.isOpen())
        );
    }

    public static void removeOfType(Integer type, WebSocketSession session) {
        List<WebSocketSession> socketSessions = typeSocketsMap.get(type);
        if (!Objects.isNull(socketSessions) && !socketSessions.isEmpty())
            socketSessions.remove(session);
    }

    /**
     * 获取当前session连接数
     *
     * @return
     */
    public static Integer currentSize() {
        Integer sumSize = 0;
        for (Integer integer : typeSocketsMap.keySet()) sumSize += typeSocketsMap.get(integer).size();
        return sumSize;
    }


}

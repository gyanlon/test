package com.eg.egsc.scp.websocket.container;

import java.util.Arrays;
import java.util.Objects;



/**
 * @see WebSocket Type Enum
 * @Class WebSocketTypeEnum
 * @Author pengzhixiang
 * @Create In 2017/12/27
 * @version V 0.1
 * 
 */
public enum WebSocketTypeEnum {
    REAL_DATA(1, "实时数据"), WARN(2, "预警"), EGSC_SCP_VIDEOINTERCOMAPP_WS_REAL_DATA(1000, "EGSC_SCP_VIDEOINTERCOMAPP_WS_REAL_DATA");
    private Integer type;
    private String desc;

    WebSocketTypeEnum(Integer type, String desc) {
        this.type = type;
        this.desc = desc;
    }

    /**
     * 是否不是这两类类型
     *
     * @param type
     * @return
     */
    public static boolean isUnknowType(Integer type) {
        return !Arrays.stream(WebSocketTypeEnum.values()).anyMatch(webSocketType -> Objects.equals(webSocketType.type(), type));
    }

    public Integer type() {
        return type;
    }

    public String desc() {
        return desc;
    }

    @Override
    public String toString() {
        return "WebSocketTypeEnum{" +
                "type=" + type +
                ", desc='" + desc + '\'' +
                '}';
    }
}

package com.eg.egsc.scp.websocket.api;



import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.eg.egsc.framework.client.dto.RequestDto;
import com.eg.egsc.framework.client.dto.ResponseDto;
import com.eg.egsc.framework.service.base.api.BaseApiController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;


/**
 * @see  Websocket Api  
 * @Class WebsocketApi
 * @Author pengzhixiang
 * @Create In 2017/12/27
 * @version V 0.1
 * 
 */
@Api(value = "websocket相关api")
@RestController
@RequestMapping(value = "/api/websocket")
public class WebsocketApi extends BaseApiController {
	
  protected final Logger logger = LoggerFactory.getLogger(WebsocketApi.class);

  @ApiOperation(value = "getHelloWorld")
  @RequestMapping(value = "/getHelloWorld", method = RequestMethod.GET)
  public ResponseDto getHelloWorld() {
    // UserDto userDto = req.getData();
    ResponseDto res = super.getDefaultResponseDto();
    res.setData("hello,world!");
    return res;
  }
 

  @ApiOperation(value = "getHelloWorld2")
  @RequestMapping(value = "/getHelloWorld2", method = RequestMethod.POST)
  public ResponseDto getHelloWorld2(@RequestBody RequestDto req) {
    ResponseDto result = new ResponseDto();
    try {

    	result.setData(req.getData());
    	
    } catch (Exception e) {
      logger.error(e.getMessage());
      result.setMessage("get失败！");
    }
    return result;
  }
  
 

}

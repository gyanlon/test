package com.eg.egsc.scp.websocket.container;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.*;

import com.eg.egsc.scp.websocket.bean.WebSocketResult;


/**
 * @see 实时数据 web推送
 * @Class EgscScpVideointercomappWsRealDataHandler
 * @Author pengzhixiang
 * @Create In 2017/12/27
 * @version V 0.1
 * 
 */
@Component
public class EgscScpVideointercomappWsRealDataHandler implements WebSocketHandler {

    private static final Logger logger = LoggerFactory.getLogger(EgscScpVideointercomappWsRealDataHandler.class);

    // 连接成功 记录连接
    @Override
    public void afterConnectionEstablished(WebSocketSession session) throws Exception {
        logger.info("real data websocket connection success. current connection size [{}]", WebSocketContainer.currentSize());
        WebSocketContainer.addSession(WebSocketTypeEnum.EGSC_SCP_VIDEOINTERCOMAPP_WS_REAL_DATA.type(), session);
        session.sendMessage(new TextMessage(WebSocketResult.success("real data connection success！").asJson()));
    }

    // 接收web发送数据
    @Override
    public void handleMessage(WebSocketSession session, WebSocketMessage<?> wsm) throws Exception {
        String msg = (String) wsm.getPayload();
        System.out.println(msg);
        WebSocketResult<String> wsMsg=new WebSocketResult<String>(msg);
        
        WebSocketContainer.sendOfType(WebSocketTypeEnum.EGSC_SCP_VIDEOINTERCOMAPP_WS_REAL_DATA.type(),wsMsg);
    }

    @Override
    public void handleTransportError(WebSocketSession session, Throwable throwable) throws Exception {
        if (session.isOpen()) {
            session.close();
        }
        logger.error("WebSocket出错！", throwable);
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus cs) throws Exception {
        WebSocketContainer.removeOfType(WebSocketTypeEnum.EGSC_SCP_VIDEOINTERCOMAPP_WS_REAL_DATA.type(),session);
        logger.info("WebSocket关闭！status {}",cs);
    }

    @Override
    public boolean supportsPartialMessages() {
        return false;
    }
}

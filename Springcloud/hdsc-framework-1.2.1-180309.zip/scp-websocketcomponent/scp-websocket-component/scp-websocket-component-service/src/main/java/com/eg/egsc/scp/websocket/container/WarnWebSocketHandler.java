package com.eg.egsc.scp.websocket.container;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.*;

import com.eg.egsc.scp.websocket.bean.WebSocketResult;

 
/**
 * @see 预警 web推送
 * @Class WarnWebSocketHandler
 * @Author pengzhixiang
 * @Create In 2017/12/27
 * @version V 0.1
 * 
 */
@Component
public class WarnWebSocketHandler implements WebSocketHandler {
    private static final Logger logger = LoggerFactory.getLogger(WarnWebSocketHandler.class);

    // 连接成功 记录连接
    @Override
    public void afterConnectionEstablished(WebSocketSession session) throws Exception {
        logger.info("warn websocket connection success. current connection size [{}]", WebSocketContainer.currentSize());
        WebSocketContainer.addSession(WebSocketTypeEnum.WARN.type(), session);
        session.sendMessage(new TextMessage(WebSocketResult.success("warn connection success！").asJson()));
    }

    // 接收web发送数据
    @Override
    public void handleMessage(WebSocketSession wss, WebSocketMessage<?> wsm) throws Exception {
        String msg = (String) wsm.getPayload();
        System.out.println(msg);
    }

    @Override
    public void handleTransportError(WebSocketSession wss, Throwable thrwbl) throws Exception {
        if (wss.isOpen()) {
            wss.close();
        }
        logger.error("WebSocket出错！");
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus cs) throws Exception {
        WebSocketContainer.removeOfType(WebSocketTypeEnum.WARN.type(), session);
        logger.info("WebSocket关闭！status {}", cs);
    }

    @Override
    public boolean supportsPartialMessages() {
        return false;
    }
}

package com.eg.egsc.scp.websocket.exception;


/**
 * @see WebSocket Unknow TypeException
 * @Class WebSocketUnknowTypeException
 * @Author Created by pengzhixiang 
 * @Create In 2017/12/27
 * @version V 0.1
 * 
 */
public class WebSocketUnknowTypeException extends WebSocketException {
    /**
	 * 
	 */
	private static final long serialVersionUID = 126234785091037758L;

	public WebSocketUnknowTypeException(String message) {
        super(message);
    }
}

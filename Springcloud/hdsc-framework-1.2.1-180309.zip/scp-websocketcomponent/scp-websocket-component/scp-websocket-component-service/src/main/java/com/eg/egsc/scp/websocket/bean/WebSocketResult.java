package com.eg.egsc.scp.websocket.bean;

 
import com.eg.egsc.utils.JsonUtil;

 
/**
 * @see  web socket 交互数据结构
 * @Class WebSocketResult
 * @Author pengzhixiang
 * @Create In 2017/12/27
 * @version V 0.1
 * 
 */
public final class WebSocketResult<T> {
    private T data;
    private boolean hasError = false;
    private String errorCode;
    private String errorMsg;

    public WebSocketResult(T data) {
        this.data = data;
    }


    public T getData() {
        return data;
    }

    public boolean isHasError() {
        return hasError;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public WebSocketResult(String errorCode, String errorMsg) {
        this.errorCode = errorCode;
        this.errorMsg = errorMsg;
        this.hasError = true;
    }

    public static WebSocketResult failure(String errorCode, String errorMsg) {
        return new WebSocketResult(errorCode, errorMsg);
    }

    public static <T> WebSocketResult success(T data) {
        return new WebSocketResult(data);
    }

    /**
     * 转换为json
     *
     * @return
     */
    public String asJson() {
        return JsonUtil.toJsonString(this);
    }
}

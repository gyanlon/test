package com.eg.egsc.scp.websocket;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;

import com.eg.egsc.framework.service.core.ApplicationStarter;


/**
 * @see  WebsocketServiceApplication 启动 类
 * @Class WebsocketServiceApplication
 * @Author pengzhixiang
 * @Create In 2017/12/27
 * @version V 0.1
 * 
 */
@SpringBootApplication
// @EnableEurekaClient
@ComponentScan(basePackages = {"com.eg.egsc"})
@MapperScan(basePackages = {"com.eg.egsc.scp"})
public class WebsocketServiceApplication extends SpringBootServletInitializer {

  @Override
  protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
    return builder.sources(WebsocketServiceApplication.class);
  }

  @SuppressWarnings("static-access")
  public static void main(String[] args) {
    new ApplicationStarter().run(WebsocketServiceApplication.class, args);
  }
}

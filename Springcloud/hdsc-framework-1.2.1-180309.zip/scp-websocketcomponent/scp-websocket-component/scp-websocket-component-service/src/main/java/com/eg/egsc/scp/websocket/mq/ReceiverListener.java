package com.eg.egsc.scp.websocket.mq;

import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

import com.eg.egsc.scp.socket.dto.InfoListDto;
import com.eg.egsc.scp.websocket.bean.WebSocketResult;
import com.eg.egsc.scp.websocket.container.WebSocketContainer;
import com.eg.egsc.scp.websocket.container.WebSocketTypeEnum;


/**
 * @see 消费消息
 * @Class ReceiverListener
 * @Author songjie
 * @Create In 2017/12/27
 * @version V 0.1
 * 
 */
@Component
@RabbitListener(queues = "EGSC_SCP_EVENTCOMPONENT_WS_DATA_QUEUE", containerFactory = "rlcFactory")
public class ReceiverListener {
	@RabbitHandler
	public void processUserDto(InfoListDto infoListDto) {
		if (null != infoListDto) {
			System.out.println("【RECEIVE】: default mq:接收消息  infoListDto");
			WebSocketContainer.sendOfType(WebSocketTypeEnum.REAL_DATA.type(),
					new WebSocketResult<InfoListDto>(infoListDto));
		}
	}
}

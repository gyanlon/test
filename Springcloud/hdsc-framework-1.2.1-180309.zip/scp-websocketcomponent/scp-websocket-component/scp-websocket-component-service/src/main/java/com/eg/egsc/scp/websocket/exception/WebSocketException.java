package com.eg.egsc.scp.websocket.exception;

import com.eg.egsc.common.exception.CommonException;

/**
 * @see WebSocket Exception
 * @Class WebSocketException
 * @Author Created by pengzhixiang 
 * @Create In 2017/12/27
 * @version V 0.1
 * 
 */
public class WebSocketException extends CommonException {
    /**
	 * 
	 */
	private static final long serialVersionUID = -6057331185224869184L;

	public WebSocketException(String message) {
        super(message);
    }
}

package com.eg.egsc.scp.socket.dto;

import java.util.List;

import com.eg.egsc.framework.client.dto.BaseBusinessDto;
/**
 * @see   InfoList  信息列表类 
 * @Class InfoListDto
 * @Author songjie
 * @Create In 2017/12/27
 * @version V 0.1
 * 
 */
public class InfoListDto extends BaseBusinessDto {
	/**
	 * @Field long serialVersionUID
	 */
	private static final long serialVersionUID = 1L;
	private List<InfoDto> infoDtos;

	/**
	 * @return the infoDtos
	 */
	public List<InfoDto> getInfoDtos() {
		return infoDtos;
	}

	/**
	 * @param infoDtos
	 *            the infoDtos to set
	 */
	public void setInfoDtos(List<InfoDto> infoDtos) {
		this.infoDtos = infoDtos;
	}

}

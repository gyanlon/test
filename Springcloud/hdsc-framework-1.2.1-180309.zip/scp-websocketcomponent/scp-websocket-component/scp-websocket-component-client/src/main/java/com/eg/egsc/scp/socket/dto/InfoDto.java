package com.eg.egsc.scp.socket.dto;

import com.eg.egsc.framework.client.dto.BaseBusinessDto;


/**
 * @see   InfoDto 信息类 
 * @Class InfoDto
 * @Author songjie
 * @Create In 2017/12/27
 * @version V 0.1
 * 
 */
public class InfoDto extends BaseBusinessDto {
	/**
	 * @Field long serialVersionUID
	 */
	private static final long serialVersionUID = 1L;
	private String type;
	private String status;
	private String info;
	private String time;
	private String xAxis;
	private String yAxis;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getxAxis() {
		return xAxis;
	}

	public void setxAxis(String xAxis) {
		this.xAxis = xAxis;
	}

	public String getyAxis() {
		return yAxis;
	}

	public void setyAxis(String yAxis) {
		this.yAxis = yAxis;
	}

}

/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.demo.client;

import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.eg.egsc.common.exception.CommonException;
import com.eg.egsc.config.AbstractUnitTestSupport;
import com.eg.egsc.scp.demo.dto.UserDto;
import com.eg.egsc.scp.demo.exception.DemoException;


public class TestDemoApiClient extends AbstractUnitTestSupport {

  @Autowired
  private DemoUserClient demoUserClientImpl;

  @Test
  public void testDemoUseClient() {

    try {
      UserDto user = new UserDto();
      user.setBusinessId("buzId");
      user.getExtAttributes().put("ext1", "extvalue1");
      user.getExtAttributes().put("ext2", "extvalue2");
      user.setId("1");
      List<UserDto> list = demoUserClientImpl.getUserList(user);
      logger.info(list.toString());
    } catch (DemoException e) {
      logger.error(e.getMessage());
    } catch (CommonException e) {
      logger.error(e.getMessage());
    }
  }
}

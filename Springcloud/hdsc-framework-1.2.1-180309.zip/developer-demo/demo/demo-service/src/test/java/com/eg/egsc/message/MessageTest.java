/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.message;

import java.util.Locale;

import javax.servlet.ServletRequestEvent;
import javax.servlet.http.HttpServletRequest;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.mock.web.MockServletContext;
import org.springframework.web.context.request.RequestContextListener;

import com.eg.egsc.common.component.i18n.I18nUtils;
import com.eg.egsc.config.AbstractUnitTestSupport;

/**
 * 测试Redis的功能类
 * 
 * @author wanghongben
 * @since 2018年1月11日
 */

public class MessageTest extends AbstractUnitTestSupport {
  protected final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private I18nUtils i18nUtils;
	private static final String EXPKEY = "demo.usermgnt.user.id.notblank";
	private static final String PARAMSKEY = "demo.params";
	private static final String NOTBLANKKEY = "demo.usermgnt.filed.notblank";
	
	private static final String PAKEY = "demo.params.fir";
	private static final String PKEY = "demo.params.sec";
	public HttpServletRequest getHttpRequest(Locale locale){ 
		RequestContextListener listener = new RequestContextListener(); 
		MockServletContext context = new MockServletContext(); 
		MockHttpServletRequest request = new MockHttpServletRequest(context); 
		listener.requestInitialized(new ServletRequestEvent(context, request)); 
		MockHttpSession session = new MockHttpSession(); 
		request.setSession(session);
		request.getLocale().setDefault(locale);
		return request;
	}
	
	
	@Test
	public void messageTest() {
		
	  logger.info("================= 默认语言 =================");
		logger.info("message default = " + i18nUtils.getMessage(EXPKEY));
		logger.info("demo.params default = " + i18nUtils.getMessage(PARAMSKEY, new String[]{PAKEY, PKEY}));
		logger.info("demo.params default1 = " + i18nUtils.getMessage(PARAMSKEY, new String[]{"鸡蛋", "西红柿"}));
		logger.info("demo.params default2 = " + i18nUtils.getMessage("nokey", null, PARAMSKEY, null));//key值不存在
		logger.info("notblankKey default = " + i18nUtils.getMessage(NOTBLANKKEY, new String[]{"必填项"}));
		
		
		logger.info("================= English =================");
		HttpServletRequest request = getHttpRequest(new Locale("en", "US"));
		logger.info("message en1 = " + i18nUtils.getMessage(EXPKEY, null, request));
		logger.info("message en2 = " + i18nUtils.getMessageByLocale(EXPKEY, null, new Locale("en", "US")));
		
		logger.info("demo.params en1 = " + i18nUtils.getMessage(PARAMSKEY, new String[]{PAKEY, PKEY}, request));
		logger.info("demo.params en2 = " + i18nUtils.getMessageByLocale(PARAMSKEY, new String[]{PAKEY, PKEY}, new Locale("en", "US")));
		logger.info("notblankKey en1 = " + i18nUtils.getMessage(NOTBLANKKEY, new String[]{PAKEY}, request));
	}

}

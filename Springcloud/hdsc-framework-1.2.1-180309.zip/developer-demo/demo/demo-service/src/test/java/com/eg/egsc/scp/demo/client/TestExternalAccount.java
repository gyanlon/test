/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.demo.client;

import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.apache.log4j.Logger;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.eg.egsc.common.component.auth.web.FrontType;
import com.eg.egsc.config.AbstractUnitTestSupport;
import com.eg.egsc.framework.client.core.BaseApiClient;
import com.eg.egsc.framework.service.auth.adapter.ExternalAccountLoginAdapterImpl;
import com.eg.egsc.framework.service.auth.adapter.ExternalAccountProvider;
import com.eg.egsc.framework.service.auth.adapter.dto.UserLoginDto;
import com.eg.egsc.scp.demo.dto.UserDto;

public class TestExternalAccount extends AbstractUnitTestSupport {
  protected final Logger logger = Logger.getLogger(this.getClass());
  @Autowired
  private ExternalAccountLoginAdapterImpl externalAccountLoginAdapterImpl;
  @Autowired
  private ExternalAccountProvider externalAccountProvider;

  @Autowired
  private DemoUserClient demoUserClientImpl;

  @Test
  public void testExternalAccountProvider() {
    try {
      UserLoginDto userDto = externalAccountProvider.getAccount();
      logger.info(userDto);
      assertNotNull(userDto);
    } catch (Exception e) {
      logger.error(e.getMessage());
    }
  }

  @Test
  public void testScpUserExternalAccount() {
    try {
      // Login SCP User Admin
      String scpGatewayAddr = "http://192.168.0.161:30940";
      ((BaseApiClient) externalAccountLoginAdapterImpl).setServiceUrl(scpGatewayAddr);
      String token = externalAccountLoginAdapterImpl.login();

      // Set gateway, token and front type when invoking scp API
      ((BaseApiClient) demoUserClientImpl).setServiceUrl(scpGatewayAddr);
      ((BaseApiClient) demoUserClientImpl).setAuthorization(token);
      ((BaseApiClient) demoUserClientImpl).setFrontType(FrontType.SCP_ADMIN_UI.getValue());

      // Do something with demoUserClientImpl
      UserDto user = new UserDto();
      user.setBusinessId("buzId");
      user.setId("1");
      List<UserDto> list = demoUserClientImpl.getUserList(user);
      logger.info(list);
    } catch (Exception e) {
      logger.error(e.getMessage());
    }
  }
}

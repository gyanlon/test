/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.framework.service.auth.service;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.eg.egsc.common.component.auth.adapter.AuthAdapter;
import com.eg.egsc.common.component.auth.model.User;
import com.eg.egsc.common.component.auth.web.FrontType;
import com.eg.egsc.framework.service.auth.adapter.dto.UserLoginDto;

/**
 * @author gaoyanlong
 * @since 2018年2月11日
 */
@Service
public class LoginService {

  private static final Logger logger = LoggerFactory.getLogger(LoginService.class);

  @Autowired
  private AuthAdapter scpUserMgmtAuthAdapterImpl;
  @Autowired
  private AuthAdapter egcUserMgmtAuthAdapterImpl;
  @Autowired
  private AuthAdapter ownerInfoMgmtAuthAdapterImpl;

  public User checkAndGetUser(String frontType, UserLoginDto userLoginDto) {
    logDebug("FrontType is %s", frontType);
    logDebug("userLoginDto (%s) ", userLoginDto);
    User user = null;
    
    String username = userLoginDto.getUsername();
    String password = userLoginDto.getPassword();
    String verifycode = userLoginDto.getVerifycode();
    if (StringUtils.isEmpty(frontType)) {
      logger.warn("Can't determine where is from, FrontType is not set in request header!");
    } else {
      if (frontType.equalsIgnoreCase(FrontType.EGC_OWNER_UI.getValue())
          || frontType.equalsIgnoreCase(FrontType.EGC_MOBILE_UI.getValue())) {

        logDebug("EGC Owner mgnt login");
        user = getValidOwnerInfo(username, password, verifycode);
      } else if (frontType.equalsIgnoreCase(FrontType.EGC_ADMIN_UI.getValue())) {
        logDebug("EGC User mgnt login");
        user = getValidEgcUserInfo(username, password);
      } else {
        logDebug("User mgnt login");
        user = getValidScpUserInfo(username, password);
      }
    }

    return user;
  }

  /**
   * 用户管理
   * 
   * @param username
   * @param password
   * @return User
   */
  protected User getValidScpUserInfo(String username, String password) {
    logDebug("Start to retrieve scp user from user management service");
    User user = scpUserMgmtAuthAdapterImpl.findUser(username, password);
    logDebug("End to retrieve scp user from user management service with result: %s", user);
    return user;
  }

  /**
   * 云端用户管理
   * 
   * @param username
   * @param password
   * @return User
   */
  protected User getValidEgcUserInfo(String username, String password) {
    logDebug("Start to retrieve user from egc user management service");
    User user = egcUserMgmtAuthAdapterImpl.findUser(username, password);
    logDebug("End to retrieve user from egc user management service with result: %s", user);
    return user;
  }

  /**
   * 业主管理
   * 
   * @param username
   * @param password
   * @param verifyCode
   * @return User
   */
  protected User getValidOwnerInfo(String username, String password, String verifyCode) {
    logDebug("Start to retrieve user from owner info management service");
    User user = ownerInfoMgmtAuthAdapterImpl.findUser(username, password, verifyCode);
    logDebug("End to retrieve user from owner info management service with result: ", user);
    return user;
  }

  private void logDebug(String format, Object... args) {
    if (logger.isDebugEnabled()) {
      logger.debug(String.format(format, args));
    }
  }
}

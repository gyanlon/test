/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.framework.service.auth.web;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.cloud.netflix.eureka.EurekaDiscoveryClient.EurekaServiceInstance;
import org.springframework.stereotype.Service;

import com.netflix.appinfo.InstanceInfo;

/**
 * @Class Name GatewayHelper
 * @author gaoyanlong
 * @since 2018年1月6日
 */
@Service
public class ServiceInstanceInfo {
  protected final Logger logger = LoggerFactory.getLogger(ServiceInstanceInfo.class);

  @Autowired
  private DiscoveryClient discoveryClient;

  @Value("${spring.application.name:}")
  private String serviceId;

  public List<String> getServiceIPAndPorts() {
    return getServiceIPAndPorts(serviceId);
  }

  public List<String> getServiceIPs() {

    List<String> ips = new ArrayList<String>();

    for (String ipAndPort : getServiceIPAndPorts()) {
      ips.add(ipAndPort.split(":")[0]);
    }

    return ips;
  }

  public List<String> getServiceIPAndPorts(String sId) {

    List<String> ips = new ArrayList<String>();

    try {
      List<ServiceInstance> instances = discoveryClient.getInstances(sId);
      for (ServiceInstance instance : instances) {
        InstanceInfo instanceInfo = ((EurekaServiceInstance) instance).getInstanceInfo();
        ips.add(String.format("%s:%s", instanceInfo.getIPAddr(), instanceInfo.getPort()));
      }
    } catch (Exception e) {
      logger.warn(String.format("读取服务 %s地址错误", serviceId), e);
    }

    if (logger.isDebugEnabled()) {
      logger.debug(String.format("Servce %s is runing in : %s", sId, ips));
    }
    return ips;
  }
}

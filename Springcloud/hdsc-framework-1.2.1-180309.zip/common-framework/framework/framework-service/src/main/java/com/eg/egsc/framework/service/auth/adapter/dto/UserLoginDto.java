/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.framework.service.auth.adapter.dto;

import com.eg.egsc.framework.client.dto.BaseBusinessDto;

/**
 * UserLoginDto
 * 
 * @author gaoyanlong
 * @since 2018年1月4日
 */
public class UserLoginDto extends BaseBusinessDto {

  /**
   * @Field long serialVersionUID
   */
  private static final long serialVersionUID = 1L;
  private String username;
  private String password;
  private String verifycode;
  private String userType;
  private String loginUrl;
  private String fronttype;

  public UserLoginDto() {
    super();
  }

  /**
   * @param username
   * @param password
   * @param verifyCode
   */
  public UserLoginDto(String username, String password, String verifycode) {
    super();
    this.username = username;
    this.password = password;
    this.verifycode = verifycode;
  }

  /**
   * @param username
   * @param password
   */
  public UserLoginDto(String username, String password) {
    super();
    this.username = username;
    this.password = password;
  }

  public String getFronttype() {
    return fronttype;
  }

  public void setFronttype(String fronttype) {
    this.fronttype = fronttype;
  }


  public String getLoginUrl() {
    return loginUrl;
  }

  public void setLoginUrl(String loginUrl) {
    this.loginUrl = loginUrl;
  }

  public String getUserType() {
    return userType;
  }

  public void setUserType(String userType) {
    this.userType = userType;
  }

  public String getVerifycode() {
    return verifycode;
  }

  public void setVerifycode(String verifycode) {
    this.verifycode = verifycode;
  }

  /**
   * @Return the String username
   */
  public String getUsername() {
    return username;
  }

  /**
   * @Param String username to set
   */
  public void setUsername(String username) {
    this.username = username;
  }

  /**
   * @Return the String password
   */
  public String getPassword() {
    return password;
  }

  /**
   * @Param String password to set
   */
  public void setPassword(String password) {
    this.password = password;
  }

  /*
   * (non-Javadoc)
   * 
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return "UserLoginDto [username=" + username + ", password=" + password + ", verifycode="
        + verifycode + ", userType=" + userType + ", loginUrl=" + loginUrl + ", fronttype="
        + fronttype + "]";
  }
}

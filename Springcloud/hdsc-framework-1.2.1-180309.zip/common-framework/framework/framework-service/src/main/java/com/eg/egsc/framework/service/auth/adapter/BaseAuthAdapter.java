/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.framework.service.auth.adapter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.eg.egsc.common.component.auth.adapter.AuthAdapter;
import com.eg.egsc.common.component.auth.exception.AuthException;
import com.eg.egsc.common.component.auth.model.User;
import com.eg.egsc.common.component.auth.web.vo.UserVo;
import com.eg.egsc.common.component.sequence.SequenceService;
import com.eg.egsc.framework.client.core.BaseApiClient;
import com.eg.egsc.framework.client.dto.ResponseDto;
import com.eg.egsc.framework.service.auth.adapter.dto.UserLoginDto;

/**
 * UserMgmt Authentication & Authorization Adapter Implementation
 * 
 * @author gaoyanlong
 * @since 2018年1月18日
 */

abstract class BaseAuthAdapter extends BaseApiClient implements AuthAdapter {
  protected final Logger logger = LoggerFactory.getLogger(BaseAuthAdapter.class);

  @Autowired
  protected SequenceService sequenceServiceImpl;

  /*
   * (non-Javadoc)
   * 
   * @see com.eg.egsc.common.component.auth.adapter.AuthAdapter#findUser(java.lang.String,
   * java.lang.String)
   */
  @Override
  public User findUser(String username, String password, String verifyCode) throws AuthException {
    String msg = "Doesn't support this operation! Try findUser(String userName, String password). ";
    logger.error(msg);
    throw new AuthException(msg);
  }

  @Override
  public String getContextPath() {
    return "";
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.eg.egsc.common.component.auth.adapter.AuthAdapter#findUser(java.lang.String,
   * java.lang.String, java.lang.String)
   */
  @Override
  public User findUser(String userName, String password) throws AuthException {
    String msg =
        "Doesn't support this operation! Try findUser(String username, String password, String verifyCode).";
    logger.error(msg);
    throw new AuthException(msg);
  }
}

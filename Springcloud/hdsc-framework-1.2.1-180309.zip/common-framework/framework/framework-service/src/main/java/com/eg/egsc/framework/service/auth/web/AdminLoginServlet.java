/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.framework.service.auth.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.MediaType;

import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.eg.egsc.common.component.auth.model.User;
import com.eg.egsc.common.component.auth.utils.JWTUtils;
import com.eg.egsc.common.component.auth.web.UserConverter;
import com.eg.egsc.common.component.auth.web.vo.UserLoginVo;
import com.eg.egsc.common.component.auth.web.vo.UserVo;
import com.eg.egsc.common.component.redis.RedisUtils;
import com.eg.egsc.common.component.utils.JsonUtil;
import com.eg.egsc.common.constant.CommonConstant;
import com.eg.egsc.common.exception.CommonException;
import com.eg.egsc.framework.client.dto.ResponseDto;
import com.eg.egsc.framework.service.auth.adapter.dto.UserLoginDto;
import com.eg.egsc.framework.service.auth.service.LoginService;
import com.eg.egsc.framework.service.util.HttpServletUtil;

/**
 * Admin Login Servlet
 * 
 * @author gaoyanlong
 * @since 2018年1月22日
 */
@WebServlet(urlPatterns = "/admin/login")
public class AdminLoginServlet extends HttpServlet {

  private static final Logger logger = LoggerFactory.getLogger(AdminLoginServlet.class);

  @Autowired
  private RedisUtils redisUtils;

  @Autowired
  private LoginService loginService;

  /**
   * @Field long serialVersionUID
   */
  private static final long serialVersionUID = 1L;

  /*
   * (non-Javadoc)
   * 
   * @see javax.servlet.GenericServlet#init(javax.servlet.ServletConfig)
   */
  @Override
  public void init(ServletConfig config) throws ServletException {
    logger.info("init(config)");
    super.init(config);
  }

  /*
   * (non-Javadoc)
   * 
   * @see javax.servlet.GenericServlet#init()
   */
  @Override
  public void init() throws ServletException {
    logger.info("init");
    super.init();
  }

  @Override
  protected void doGet(HttpServletRequest req, HttpServletResponse resp)
      throws ServletException, IOException {
    logger.info("doGet");
    doPost(req, resp);
  }

  @Override
  protected void doPost(HttpServletRequest req, HttpServletResponse resp)
      throws ServletException, IOException {
    HttpServletUtil.initResponse(resp);

    try {
      UserLoginVo userLoginVo = getLoginUser(req);

      if (userLoginVo == null) {
        // return login failure response
        HttpServletUtil.populateRespons403(req, resp);
        return;
      }

      String frontType = req.getHeader(CommonConstant.FRONT_TYPE);
      UserLoginDto userLoginDto = new UserLoginDto();
      BeanUtils.copyProperties(userLoginDto, userLoginVo);
      User user = loginService.checkAndGetUser(frontType, userLoginDto);
      // if invalid user
      if (user == null) {
        // return login failure response
        HttpServletUtil.populateRespons403(req, resp);
        return;
      }

      // if valid user
      else {

        int jwtMaxAgeMinutes = CommonConstant.JWT_MAX_AGE_MINUTES;

        // Generate jwt token
        logDebug("Start to generate token with user id:", user.getUserId());
        String token = JWTUtils.getToken(user.getUserId(), jwtMaxAgeMinutes);
        logDebug("End to generate token");

        logDebug("Start to save user to redis");
        User simpleUser = (User)BeanUtils.cloneBean(user);
        simpleUser.setUiResources(null);
        redisUtils.setOrigin(CommonConstant.REDIS_KEY_SSO_USER + token, simpleUser,
            60 * CommonConstant.JWT_ONE_STEP_MINUTES);
        logDebug("End to save user to redis : %s -> %s", CommonConstant.REDIS_KEY_SSO_USER + token,
            simpleUser);

        // Save jwt token to cookie
        logDebug("Start to save token to cookie");
        Cookie jwtCookie = new Cookie(CommonConstant.TOKEN_COOKIE_NAME, token);

        // Security
        jwtCookie.setSecure(true);

        jwtCookie.setMaxAge(60 * jwtMaxAgeMinutes);
        // The cookie is active for all path
        jwtCookie.setPath("/");
        resp.addCookie(jwtCookie);
        logDebug("End to save token to cookie: %s", jwtCookie);

        // return response with user data and token
        UserVo userVo = new UserConverter().convert(user);
        userVo.setToken(token);
        populateResponse200(token, userVo, resp);
      }
    } catch (CommonException e) {
      logger.error(e.getMessage(), e);
      HttpServletUtil.populateResponse500(e.getCode(), e.getMessage(), req, resp);
      return;
    } catch (Exception e) {
      logger.error(e.getMessage(), e);
      HttpServletUtil.populateResponse500(CommonConstant.MESSAGE_KEY_INTERNAL_ERROR, e.getMessage(),
          req, resp);
      return;
    }
  }

  /**
   * @param req
   * @return
   * @throws IOException UserLoginVo
   * @throws InvocationTargetException
   * @throws IllegalAccessException
   */
  private UserLoginVo getLoginUser(HttpServletRequest req) throws IOException {
    UserLoginVo userLoginVo = new UserLoginVo();
    if ("POST".equalsIgnoreCase(req.getMethod())
        && MediaType.APPLICATION_JSON.equalsIgnoreCase(req.getContentType())) {
      String reqBody = HttpServletUtil.readContentBody(req);
      logDebug("request body: %s", reqBody);

      userLoginVo = JsonUtil.fromJson(reqBody, UserLoginVo.class);
    } else {
      userLoginVo.setUsername(req.getParameter("username"));
      userLoginVo.setPassword(req.getParameter("password"));
      userLoginVo.setVerifycode(req.getParameter("verifycode"));
    }

    logDebug("Get user (%s) from request", userLoginVo);
    return userLoginVo;
  }

  private void populateResponse200(String token, UserVo user, HttpServletResponse resp)
      throws IOException {
    resp.setStatus(HttpStatus.OK.value());

    PrintWriter print = resp.getWriter();
    String jsonResponse = JsonUtil.toJson(new ResponseDto(CommonConstant.SUCCESS_CODE, user, ""));
    logDebug("Response: %s", jsonResponse);
    logDebug("token: %s", token);
    print.write(jsonResponse);
    print.close();
  }

  private void logDebug(String format, Object... args) {
    if (logger.isDebugEnabled()) {
      logger.debug(String.format(format, args));
    }
  }
}

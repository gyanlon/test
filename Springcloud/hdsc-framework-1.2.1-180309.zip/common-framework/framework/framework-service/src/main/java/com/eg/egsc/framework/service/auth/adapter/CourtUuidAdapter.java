/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.framework.service.auth.adapter;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.eg.egsc.common.component.redis.RedisUtils;
import com.eg.egsc.common.component.sequence.SequenceService;
import com.eg.egsc.common.constant.CommonConstant;
import com.eg.egsc.framework.client.core.BaseApiClient;
import com.eg.egsc.framework.client.dto.BaseBusinessDto;
import com.eg.egsc.framework.client.dto.ResponseDto;

/**
 * 读取小区UUID适配器
 * 
 * @author gaoyanlong
 * @since 2018年1月22日
 */
@Service
public class CourtUuidAdapter extends BaseApiClient {
  protected final Logger logger = LoggerFactory.getLogger(CourtUuidAdapter.class);

  @Autowired
  private SequenceService sequenceServiceImpl;

  @Autowired
  private RedisUtils redisUtils;

  @Value("${egsc.config.courtuuid.service-uri:/scp-mdmapp/api/court/getCourtUuid}")
  private String courtUuidUri;

  public String getCurrentCourtUuid() {

    String courtUuid = (String) redisUtils.getOrigin(CommonConstant.REDIS_KEY_CURRENT_COURTUUID);
    if (StringUtils.isEmpty(courtUuid)) {

      String sysCode = CommonConstant.FRAMEWORK_SYS_CODE;
      String businessId = sequenceServiceImpl.getSequence(sysCode);
      BaseBusinessDto bizDto = new BaseBusinessDto();
      bizDto.setBusinessId(businessId);

      ResponseDto res = post(courtUuidUri, bizDto);
      courtUuid = res.getData(String.class);
      redisUtils.setOrigin(CommonConstant.REDIS_KEY_CURRENT_COURTUUID, courtUuid);
      logger.debug(String.format("Get court uuid (%s) from %s and save it in redis", courtUuid,
          courtUuidUri));
    } else {
      logger.debug(String.format("Get court uuid (%s) from redis (%s)", courtUuidUri, CommonConstant.REDIS_KEY_CURRENT_COURTUUID));
    }

    return courtUuid;
  }


  /*
   * (non-Javadoc)
   * 
   * @see com.eg.egsc.framework.client.core.BaseApiClient#getContextPath()
   */
  @Override
  protected String getContextPath() {
    return "";
  }

}

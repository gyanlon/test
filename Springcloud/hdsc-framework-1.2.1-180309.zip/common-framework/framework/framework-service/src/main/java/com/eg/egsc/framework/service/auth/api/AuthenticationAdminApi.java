/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.framework.service.auth.api;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.eg.egsc.common.component.auth.exception.AuthException;
import com.eg.egsc.common.component.auth.model.User;
import com.eg.egsc.common.component.auth.utils.JWTUtils;
import com.eg.egsc.common.component.auth.web.vo.UserVo;
import com.eg.egsc.common.component.redis.RedisUtils;
import com.eg.egsc.common.component.utils.BeanUtils;
import com.eg.egsc.common.constant.CommonConstant;
import com.eg.egsc.framework.client.dto.RequestDto;
import com.eg.egsc.framework.client.dto.ResponseDto;
import com.eg.egsc.framework.service.auth.adapter.dto.UserLoginDto;
import com.eg.egsc.framework.service.auth.service.LoginService;
import com.eg.egsc.framework.service.auth.web.AdminLoginServlet;
import com.eg.egsc.framework.service.base.api.BaseApiController;

/**
 * @author gaoyanlong
 * @since 2018年2月11日
 */
@RestController
@RequestMapping(value = "/api/admin")
public class AuthenticationAdminApi extends BaseApiController {

  private static final Logger logger = LoggerFactory.getLogger(AuthenticationAdminApi.class);

  @Autowired
  HttpServletRequest request;

  @Autowired
  private LoginService loginService;

  @Autowired
  private RedisUtils redisUtils;

  @RequestMapping(value = "/login", method = RequestMethod.POST)
  public ResponseDto login(@Valid @RequestBody RequestDto<UserLoginDto> req) {
    ResponseDto res = new ResponseDto(CommonConstant.SUCCESS_CODE, null, "success");
    UserLoginDto userLoginDto = req.getData();
    String frontType = request.getHeader(CommonConstant.FRONT_TYPE);
    User user = loginService.checkAndGetUser(frontType, userLoginDto);

    if (user == null) {
      throw new AuthException("framework.network.http.status.401");
    } else {

      logDebug("Start to generate token with user id:%s", user.getUserId());
      int jwtMaxAgeMinutes = CommonConstant.JWT_MAX_AGE_MINUTES;
      String token = JWTUtils.getToken(user.getUserId(), jwtMaxAgeMinutes);
      logDebug("End to generate token");

      logDebug("Start to save user to redis");
      redisUtils.setOrigin(CommonConstant.REDIS_KEY_SSO_USER + token, user,
          60 * CommonConstant.JWT_ONE_STEP_MINUTES);
      logDebug("End to save user to redis : %s -> %s", CommonConstant.REDIS_KEY_SSO_USER + token,
          user);

      UserVo userVo = new UserVo();
      BeanUtils.copyProperties(userVo, user);
      userVo.setToken(token);
      res.setData(userVo);
    }

    return res;
  }

  private void logDebug(String format, Object... args) {
    if (logger.isDebugEnabled()) {
      logger.debug(String.format(format, args));
    }
  }
}

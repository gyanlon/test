/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.framework.service.auth.service;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.eg.egsc.common.component.auth.model.User;
import com.eg.egsc.common.component.auth.utils.RequestIgnoreList;
import com.eg.egsc.common.component.auth.web.SecurityContext;
import com.eg.egsc.common.component.utils.JsonUtil;
import com.eg.egsc.common.constant.CommonConstant;
import com.eg.egsc.framework.client.dto.RequestDto;
import com.eg.egsc.framework.service.util.HttpServletUtil;

/**
 * 鉴权服务
 * 
 * @author gaoyanlong
 * @since 2017年12月20日
 */
/**
 * TODO
 * 
 * @author gaoyanlong
 * @since 2018年2月25日
 */
@Service
public class PermissionService {

  private static final Logger logger = LoggerFactory.getLogger(PermissionService.class);

  @Autowired
  private RequestIgnoreList requestIgnoreList;

  @Value("${spring.application.name:}")
  private String appName;

  /**
   * 判断请求是否有权限
   * @param request
   * @param response
   * @return boolean
   */
  public boolean hasPermission(ServletRequest request, ServletResponse response) {

    HttpServletRequest httpRequest = (HttpServletRequest) request;
    String requestURI = httpRequest.getRequestURI();
    logDebug("Request URI: %s", requestURI);
    logDebug("Response charset: %s, contentType: %s", response.getCharacterEncoding(),
        response.getContentType());

    if (requestIgnoreList.match(request) || isApiInSamePlatform(request)) {
      return true;
    }

    User user = SecurityContext.getUserPrincipal();
    boolean hasPermission = false;
    if (user != null) {
      List<String> serviceIds = user.getServiceIds();
      logDebug("User service Ids: %s", serviceIds);
      hasPermission = hasPermission(serviceIds, requestURI);
    } else {
      logger.error("用户信息为空！");
    }

    if (!hasPermission) {
      logger.error("用户没有此资源访问权限！");
    }
    return hasPermission;
  }
  
  /**
   * 判断是否有权限
   * @param serviceIds
   * @param requestURI
   * @return boolean
   */
  private boolean hasPermission(List<String> serviceIds, String requestURI){
    if (CollectionUtils.isEmpty(serviceIds)) {
      logger.error("用户服务权限列表为空！");
      return false;
    }
    for (String serviceId : serviceIds) {
      if (!StringUtils.isEmpty(serviceId) && serviceId.startsWith("/")
          && requestURI.startsWith(serviceId)) {
        return true;
      }
    }
    return false;
  }

  /**
   * 是否系统间调用
   * 
   * @param request
   * @return boolean
   * @throws IOException
   */
  private boolean isApiInSamePlatform(ServletRequest request) {

    HttpServletRequest httpRequest = ((HttpServletRequest) request);
    return isApi(httpRequest) && isInSamePlatform(httpRequest);
  }

  /**
   * @param req
   * @return boolean
   */
  private boolean isInSamePlatform(HttpServletRequest req) {

    try {
      String reqBody = HttpServletUtil.readContentBody(req);
      logDebug("request body: %s", reqBody);
      RequestDto<?> reqDto = JsonUtil.fromJson(reqBody, RequestDto.class);
      if (reqDto != null && reqDto.getHeader() != null
          && reqDto.getHeader().getSourceSysId() != null) {
        String srcPlatformPrefix = reqDto.getHeader().getSourceSysId().substring(0, 3);
        if (appName.startsWith(srcPlatformPrefix)) {
          return true;
        }
      } else {
        logger.error(String.format("Request Parameter Error: %s", reqBody));
      }
    } catch (IOException e) {
      logger.error(e.getMessage(), e);
    }

    return false;
  }

  /**
   * 
   * @param httpRequest
   * @return boolean
   */
  private boolean isApi(HttpServletRequest httpRequest) {
    String requestURI = httpRequest.getRequestURI();
    return isApiURI(requestURI);
  }

  /**
   * Is API url
   * 
   * @param requestURI
   * @return boolean
   */
  protected boolean isApiURI(String requestURI) {
    if (requestURI.matches(".*?/api/.*")) {
      return true;
    }
    return false;
  }

  private void logDebug(String format, Object... args) {
    if (logger.isDebugEnabled()) {
      logger.debug(String.format(format, args));
    }
  }

  @SuppressWarnings("unused")
  private String getTokenFromCookie(ServletRequest request) {
    HttpServletRequest httpRequest = (HttpServletRequest) request;
    Cookie[] cookies = httpRequest.getCookies();
    String token = null;

    if (null != cookies) {
      for (Cookie cookie : cookies) {
        if (CommonConstant.TOKEN_COOKIE_NAME.equals(cookie.getName())) {
          token = cookie.getValue();
        }
      }
    }

    return token;
  }
}

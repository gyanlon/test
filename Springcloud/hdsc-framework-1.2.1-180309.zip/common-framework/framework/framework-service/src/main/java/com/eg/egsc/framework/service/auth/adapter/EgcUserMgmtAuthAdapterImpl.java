/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.framework.service.auth.adapter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.eg.egsc.common.component.auth.exception.AuthException;
import com.eg.egsc.common.component.auth.model.User;
import com.eg.egsc.common.constant.CommonConstant;

/**
 * UserMgmt Authentication & Authorization Adapter Implementation
 * 
 * @author gaoyanlong
 * @since 2018年1月18日
 */
@Service
public class EgcUserMgmtAuthAdapterImpl extends UserMgmtAuthAdapterImpl {
  protected final Logger logger = LoggerFactory.getLogger(EgcUserMgmtAuthAdapterImpl.class);

  @Override
  public User findUser(String username, String password) throws AuthException {
    super.setAuthUri("/api/user/queryFunctionAuthority");
    User user = super.findUser(username, password);
    if (user != null) {
      user.setCourtUuid(CommonConstant.DEFAULT_COURTUUID);
    }
    return user;
  }

  @Override
  public String getContextPath() {
    return "/egc-usermgmtcomponent";
  }
}

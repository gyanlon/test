/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.framework.service.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;

import com.eg.egsc.common.component.auth.web.FrontType;
import com.eg.egsc.common.component.auth.web.SecurityContext;
import com.eg.egsc.common.component.utils.JsonUtil;

/**
 * Servlet Utility
 * 
 * @author gaoyanlong
 * @since 2018年1月22日
 */
public class HttpServletUtil {

  private HttpServletUtil() {}

  private static final Logger logger = LoggerFactory.getLogger(HttpServletUtil.class);
  private static final String FORMAT_RES = "Response: %s";
  private static final String PRINTWRITER_ERROR = "PrintWriter error!";
  
  public static void initResponse(ServletResponse resp) {

    HttpServletResponse httpResponse = (HttpServletResponse) resp;
    httpResponse.setCharacterEncoding("UTF-8");
    httpResponse.setContentType(MediaType.APPLICATION_JSON_UTF8_VALUE);
    httpResponse.setHeader("Access-Control-Allow-Origin", "*");
    httpResponse.setHeader("Access-Control-Allow-Credentials", "true");
    httpResponse.setHeader("Access-Control-Allow-Methods", "*");
    httpResponse.setHeader("Access-Control-Allow-Headers", "Content-Type,Authorization");
    httpResponse.setHeader("Access-Control-Expose-Headers", "*");
  }

  /**
   * Response 401
   * 
   * @param request
   * @param response void
   */
  public static void populateResponse401(ServletRequest request, ServletResponse response) {
    HttpServletResponse httpResponse = (HttpServletResponse) response;
    httpResponse.setStatus(HttpStatus.UNAUTHORIZED.value());
    PrintWriter print = null;
    try {
      print = response.getWriter();
      String msgKey = "framework.network.http.status.401";
      String jsonResponse = JsonUtil.toJson(
          MessageUtils.getResponseByMessageKey(msgKey, "00401:非法请求【认证失败】", (HttpServletRequest) request));
      logger.error(String.format(FORMAT_RES, jsonResponse));
      print.write(jsonResponse);
      print.close();
    } catch (IOException e) {
      logger.error(PRINTWRITER_ERROR, e);
    }
  }

  /**
   * Response 499
   * 
   * @param request
   * @param response void
   */
  public static void populateResponse499(ServletRequest request, ServletResponse response) {
    HttpServletResponse httpResponse = (HttpServletResponse) response;
    httpResponse.setStatus(499);
    PrintWriter print = null;
    try {
      print = response.getWriter();
      String msgKey = "framework.auth.user.not.in.redis";
      String jsonResponse = JsonUtil.toJson(
          MessageUtils.getResponseByMessageKey(msgKey, "00499:非法请求【缓存无效】", (HttpServletRequest) request));
      logger.error(String.format(FORMAT_RES, jsonResponse));
      print.write(jsonResponse);
      print.close();
    } catch (IOException e) {
      logger.error(PRINTWRITER_ERROR, e);
    }
  }

  /**
   * Is it from Egsc UI?
   * 
   * @param request
   * @return boolean
   */
  public static boolean isFromEgscUI(ServletRequest request) {
    String frontType = ((HttpServletRequest) request).getHeader("FrontType");
    if (StringUtils.isEmpty(frontType)) {
      logger.warn("Can't determine where is from, FrontType is not set in request header!");
    } else {
      SecurityContext.setFrontType(frontType);
    }
    return FrontType.SCP_EGSC_UI.getValue().equalsIgnoreCase(frontType);
  }

  /**
   * Response 403
   * 
   * @param request
   * @param httpResponse
   * @throws IOException void
   */
  public static void populateRespons403(ServletRequest request, ServletResponse response) {

    HttpServletResponse httpResponse = (HttpServletResponse) response;
    httpResponse.setStatus(HttpStatus.FORBIDDEN.value());
    try {
      PrintWriter print = httpResponse.getWriter();
      String msgKey = "framework.network.http.status.403";
      String jsonResponse = JsonUtil.toJson(
          MessageUtils.getResponseByMessageKey(msgKey, "00403:非法请求【无权访问此资源】", (HttpServletRequest) request));

      logger.error(String.format(FORMAT_RES, jsonResponse));
      print.write(jsonResponse);
      print.close();
    } catch (IOException e) {
      logger.error(PRINTWRITER_ERROR, e);
    }
  }

  /**
   * Response 500
   * 
   * @param code
   * @param message
   * @param req
   * @param resp void
   */
  public static void populateResponse500(String code, String msg, ServletRequest request,
      ServletResponse response) throws IOException {
    HttpServletResponse httpResponse = (HttpServletResponse) response;
    httpResponse.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());

    PrintWriter print = httpResponse.getWriter();
    String jsonResponse = JsonUtil
        .toJson(MessageUtils.getResponseByMessageKey(code, msg, (HttpServletRequest) request));
    if (logger.isDebugEnabled()) {
      logger.debug(String.format(FORMAT_RES, jsonResponse));
    }

    print.write(jsonResponse);
    print.close();
  }
  
  /**
   * @param req
   * @throws IOException
   */
  public static String readContentBody(HttpServletRequest req) throws IOException {
    BufferedReader br = req.getReader();
    String str, wholeStr = "";
    while ((str = br.readLine()) != null) {
      wholeStr += str;
    }
    br.close();
    return wholeStr;
  }
}

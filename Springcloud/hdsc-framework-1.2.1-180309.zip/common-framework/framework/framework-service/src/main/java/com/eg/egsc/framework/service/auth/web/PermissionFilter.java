/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.framework.service.auth.web;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.eg.egsc.framework.service.auth.service.PermissionService;
import com.eg.egsc.framework.service.util.HttpServletUtil;

/**
 * Permission Filter
 * 
 * @author gaoyanlong
 * @since 2018年1月11日
 */
public class PermissionFilter implements Filter {
  protected final Logger logger = LoggerFactory.getLogger(PermissionFilter.class);

  private PermissionService permissionService;

  public PermissionService getPermissionService() {
    return permissionService;
  }

  public void setPermissionService(PermissionService permissionService) {
    this.permissionService = permissionService;
  }

  /*
   * (non-Javadoc)
   * 
   * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
   */
  @Override
  public void init(FilterConfig filterConfig) throws ServletException {
    logger.debug("init");
  }

  /*
   * (non-Javadoc)
   * 
   * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest, javax.servlet.ServletResponse,
   * javax.servlet.FilterChain)
   */
  @Override
  public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
      throws IOException, ServletException {

    HttpServletUtil.initResponse((HttpServletResponse) response);

    HttpRequestReaderWrapper requestWrapper = new HttpRequestReaderWrapper((HttpServletRequest) request);
    if (permissionService.hasPermission(requestWrapper, response)) {
      chain.doFilter(requestWrapper, response);
    } else {
      HttpServletUtil.populateRespons403(requestWrapper, response);
    }
  }

  /*
   * (non-Javadoc)
   * 
   * @see javax.servlet.Filter#destroy()
   */
  @Override
  public void destroy() {
    logger.debug("destroy");
  }
}

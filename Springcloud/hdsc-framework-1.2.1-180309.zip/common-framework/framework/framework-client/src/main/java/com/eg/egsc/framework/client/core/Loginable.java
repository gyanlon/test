/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.framework.client.core;

import com.eg.egsc.common.component.auth.exception.AuthException;

/**
 * TODO
 * @author gaoyanlong
 * @since 2018年2月11日
 */
public interface Loginable {

  
  /**
   * 登陆用户
   * @param username
   * @param password
   * @throws AuthException void
   */
  String login(String username, String password) throws AuthException;

}

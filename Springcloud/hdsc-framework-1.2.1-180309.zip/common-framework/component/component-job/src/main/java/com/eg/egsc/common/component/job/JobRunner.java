/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.common.component.job;

/**
 * JobRunner
 * @author songjie
 * @since 2018年2月1日
 */
/**
 * @Deprecated Job实现类可以不用声明实现JobRunner接口，参考 demo-service工程的DemoJob类，since v1.0.2
 */
@Deprecated
public interface JobRunner {
  
	void run();
	
}

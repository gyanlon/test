/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.common.component.auth.web;

import com.eg.egsc.common.component.auth.model.User;

/**
 * Security Context
 * 
 * @author gaoyanlong
 * @since 2018年1月4日
 */
public class SecurityContext {

  private static ThreadLocal<User> userThreadLocal = new ThreadLocal<>();
  private static ThreadLocal<String> tokenLocal = new ThreadLocal<>();
  private static ThreadLocal<String> frontTypeLocal = new ThreadLocal<>();

  private SecurityContext() {

  }

  public static String getUserId() {
    return getUserPrincipal() != null ? getUserPrincipal().getUserId() : null;
  }

  public static String getUserName() {
    return getUserPrincipal() != null ? getUserPrincipal().getUserName() : null;
  }

  public static User getUserPrincipal() {
    return userThreadLocal.get();
  }

  public static void setUserPrincipal(User user) {
    userThreadLocal.set(user);
  }

  public static String getToken() {
    return tokenLocal.get();
  }

  public static void setToken(String token) {
    tokenLocal.set(token);
  }

  public static String getFrontType() {
    return frontTypeLocal.get();
  }

  public static void setFrontType(String frontType) {
    frontTypeLocal.set(frontType);
  }

  public static String getCourtUuid() {
    return getUserPrincipal() != null ? getUserPrincipal().getCourtUuid() : null;
  }
}

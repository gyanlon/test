/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.framework.service.auth.adapter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.eg.egsc.common.component.auth.exception.AuthException;
import com.eg.egsc.common.component.auth.web.vo.UserVo;
import com.eg.egsc.framework.client.core.BaseApiClient;
import com.eg.egsc.framework.client.dto.ResponseDto;
import com.eg.egsc.framework.service.auth.adapter.dto.UserLoginDto;

/**
 * @author gaoyanlong
 * @since 2018年2月11日
 */
@Service
public class ExternalAccountLoginAdapterImpl extends BaseApiClient implements LoginAdapter {

  protected final Logger logger = LoggerFactory.getLogger(ExternalAccountLoginAdapterImpl.class);

  @Autowired
  private ExternalAccountProvider externalAccountProvider;

  @Override
  public String login() throws AuthException {
    UserLoginDto userDto = externalAccountProvider.getAccount();

    if (logger.isDebugEnabled()) {
      logger.debug(userDto.toString());
    }
    setFrontType(userDto.getFronttype());
    ResponseDto res = post(userDto.getLoginUrl(), userDto);
    UserVo user = res.getData(UserVo.class);

    if (user == null) {
      throw new AuthException("framework.network.http.status.401");
    }
    return user.getToken();
  }

  @Override
  protected String getContextPath() {
    return "";
  }
}

/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.framework.service.auth.service;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.eg.egsc.common.component.auth.exception.AuthException;
import com.eg.egsc.common.component.auth.model.User;
import com.eg.egsc.common.component.auth.service.SuperviserService;
import com.eg.egsc.common.component.auth.utils.JWTUtils;
import com.eg.egsc.common.component.auth.web.FrontType;
import com.eg.egsc.common.component.auth.web.SecurityContext;
import com.eg.egsc.common.component.redis.RedisUtils;
import com.eg.egsc.common.constant.CommonConstant;
import com.eg.egsc.common.exception.CommonException;
import com.eg.egsc.framework.service.auth.adapter.CourtUuidAdapter;

/**
 * SuperviserServiceImpl
 * 
 * @author gaoyanlong
 * @since 2018年1月22日
 */
@Service
public class SuperviserServiceImpl implements SuperviserService {

  private static final Logger logger = LoggerFactory.getLogger(SuperviserServiceImpl.class);

  @Autowired
  private RedisUtils redisUtils;

  @Autowired
  private CourtUuidAdapter courtUuidAdapter;

  @Value("${spring.application.name:}")
  private String appName;

  @Autowired
  private AuthenticationService authenticationService;

  private void loginAsAdminWithCourtUUid(String courtUuid) {

    User user = null;
    String token = "";
    if (existsAdminWithCourtUuid()) {
      token = (String) redisUtils.getOrigin(CommonConstant.REDIS_KEY_SSO_ADMIN_TOKEN);
      user = (User) redisUtils.getOrigin(CommonConstant.REDIS_KEY_SSO_USER + token);

    } else {
      user = newAdminUserWithCourtUuid(courtUuid);
      logDebug("create one new admin user : %s", user);

      token = JWTUtils.getToken(user.getUserId());
      logDebug("token : %s", token);

      redisUtils.setOrigin(CommonConstant.REDIS_KEY_SSO_ADMIN_TOKEN, token);
      logDebug("Save admin: %s -> %s", CommonConstant.REDIS_KEY_SSO_ADMIN_TOKEN, token);

      redisUtils.setOrigin(CommonConstant.REDIS_KEY_SSO_USER + token, user);
      logDebug("Save user: %s -> %s", CommonConstant.REDIS_KEY_SSO_USER + token, user);
    }

    logDebug("Start to save user and token in context");
    SecurityContext.setUserPrincipal(user);
    SecurityContext.setToken(token);
    logDebug("End to save user and token in context");
  }

  public void loginAsAdmin() {
    String courtUuid = "";
    logger.info("spring.application.name = " + appName);
    if (StringUtils.isNotEmpty(appName)) {
      if (appName.startsWith("scp-")) {
        courtUuid = courtUuidAdapter.getCurrentCourtUuid();
        SecurityContext.setFrontType(FrontType.SCP_ADMIN_UI.getValue());
      } else if (appName.startsWith("egc-")) {
        courtUuid = CommonConstant.DEFAULT_COURTUUID;
        SecurityContext.setFrontType(FrontType.EGC_ADMIN_UI.getValue());
      } else {
        String msg = String.format("Can't dertermine which platform it is, appName=%s", appName);
        logger.error(msg);
        throw new AuthException(msg);
      }
    } else {
      String msg = "application name is empty!";
      logger.error(msg);
      throw new CommonException(msg);
    }

    this.loginAsAdminWithCourtUUid(courtUuid);
  }

  /**
   * @return boolean
   */
  private boolean existsAdminWithCourtUuid() {
    boolean exist = false;
    String token = (String) redisUtils.getOrigin(CommonConstant.REDIS_KEY_SSO_ADMIN_TOKEN);
    if (StringUtils.isNotBlank(token) && this.authenticationService.isTokenValid(token)) {
      exist = redisUtils.getOrigin(CommonConstant.REDIS_KEY_SSO_USER + token) != null;
    }

    return exist;
  }

  /**
   * Create a new admin user
   * 
   * @param courtUuid
   * 
   * @return User
   */
  private User newAdminUserWithCourtUuid(String courtUuid) {
    User user = new User();
    user.setUserId("admin");
    user.setUserName("admin");
    user.getServiceIds().add("/");

    logger.info("spring.application.name = " + appName);
    if (StringUtils.isNotEmpty(appName)) {
      if (!StringUtils.isEmpty(courtUuid)) {
        user.setCourtUuid(courtUuid);
      }
    }

    return user;
  }

  private void logDebug(String format, Object... args) {
    if (logger.isDebugEnabled()) {
      logger.debug(String.format(format, args));
    }
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.eg.egsc.common.component.auth.service.SuperviserService#loginAsAdmin(javax.servlet.
   * ServletRequest)
   */
  @Override
  public void loginAsAdmin(ServletRequest request) {
    logDebug("start loginAsAdmin");

    String courtUuid = "";
    HttpServletRequest httpRequest = (HttpServletRequest) request;
    String uri = httpRequest.getRequestURI();
    logDebug("appName = %s, uri = %s", appName, uri);

    if (appName.startsWith("scp-") || uri.startsWith("/scp-")) {
      courtUuid = courtUuidAdapter.getCurrentCourtUuid();
    } else if (appName.startsWith("egc-") || uri.startsWith("/egc-")) {
      courtUuid = CommonConstant.DEFAULT_COURTUUID;
    } else {
      String msg =
          String.format("Can't dertermine which platform it is, appName=%s, uri=%s", appName, uri);
      logger.error(msg);
      throw new AuthException(msg);
    }
    logDebug("Get court uuid : %s", courtUuid);

    this.loginAsAdminWithCourtUUid(courtUuid);

    logDebug("end loginAsAdmin");
  }
}

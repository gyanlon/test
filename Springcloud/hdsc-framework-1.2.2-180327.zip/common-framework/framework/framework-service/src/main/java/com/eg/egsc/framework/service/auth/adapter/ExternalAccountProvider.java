/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.framework.service.auth.adapter;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.eg.egsc.framework.service.auth.adapter.dto.UserLoginDto;

/**
 * @author gaoyanlong
 * @since 2018年2月8日
 */
@Component
public class ExternalAccountProvider {

  @Value("${egsc.config.auth.external.account.username:}")
  private String username;
  @Value("${egsc.config.auth.external.account.password:}")
  private String password;
  @Value("${egsc.config.auth.external.login.url:}")
  private String loginUrl;
  @Value("${egsc.config.auth.external.login.fronttype:}")
  private String fronttype;

  public UserLoginDto getAccount() {
    UserLoginDto userLoginDto = new UserLoginDto(username, password);
    userLoginDto.setFronttype(fronttype);
    userLoginDto.setLoginUrl(loginUrl);
    return userLoginDto;
  }
}

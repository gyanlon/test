/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.framework.service.auth.adapter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.eg.egsc.common.component.auth.exception.AuthException;
import com.eg.egsc.common.component.auth.model.User;
import com.eg.egsc.common.exception.CommonException;
import com.eg.egsc.framework.client.core.BaseApiClient;

/**
 * UserMgmt Authentication & Authorization Adapter Implementation
 * 
 * @author gaoyanlong
 * @since 2018年1月18日
 */
@Service
public class ScpUserMgmtAuthAdapterImpl extends UserMgmtAuthAdapterImpl {
  protected final Logger logger = LoggerFactory.getLogger(ScpUserMgmtAuthAdapterImpl.class);

  @Autowired
  private CourtUuidAdapter courtUuidAdapter;

  @Override
  public User findUser(String username, String password) throws AuthException {
    super.setAuthUri("/api/user/queryFunctionAuthority");
    User user = super.findUser(username, password);

    if (user != null) {
      setCourtUuid(user);
    }
    return user;
  }

  @Override
  public String getContextPath() {
    return "/scp-usermgmtcomponent";
  }

  /**
   * Set Court uuid
   * 
   * @param user void
   */
  private void setCourtUuid(User user) {
    if (user != null) {
      ((BaseApiClient) courtUuidAdapter).setServiceUrl(this.getServiceUrl());
      String courtUuid = courtUuidAdapter.getCurrentCourtUuid();
      if (courtUuid == null) {
        throw new CommonException("无法取得小区UUID!", "无法取得小区UUID!");
      }
      user.setCourtUuid(courtUuid);
    }
  }
}

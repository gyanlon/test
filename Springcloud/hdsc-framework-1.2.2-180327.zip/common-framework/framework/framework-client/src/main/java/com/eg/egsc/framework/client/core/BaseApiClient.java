/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.framework.client.core;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.SSLContext;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.ssl.TrustStrategy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import com.eg.egsc.common.component.auth.web.SecurityContext;
import com.eg.egsc.common.component.sequence.SequenceService;
import com.eg.egsc.common.component.utils.JsonUtil;
import com.eg.egsc.common.constant.CommonConstant;
import com.eg.egsc.common.exception.CommonException;
import com.eg.egsc.framework.client.dto.BaseBusinessDto;
import com.eg.egsc.framework.client.dto.Header;
import com.eg.egsc.framework.client.dto.RequestDto;
import com.eg.egsc.framework.client.dto.ResponseDto;

/**
 * Api Client基础类
 * 
 * @author gaoyanlong
 * @since 2018年1月9日
 */
public abstract class BaseApiClient {

  protected final Logger logger = LoggerFactory.getLogger(BaseApiClient.class);

  @Autowired
  private RestTemplate restTemplate;

  @Autowired
  private SequenceService sequenceServiceImpl;

  @Value("${gateway.service-url:}")
  private String gatewayUrl;

  @Value("${gateway.service-url:}")
  private String customGatewayUrl;

  private String defaultHost = "http://localhost:8082";

  @Value("${zuul.service.name:gateway-server}")
  private String zuulServiceName;

  @Value("${spring.application.name}")
  private String appName;

  @Value("${egsc.config.appshortname:UNKOWN}")
  private String appShortName;

  @Value("${egsc.config.ssl.enabled:false}")
  private String sslEnabled;

  @Value("${egsc.config.ssl.pfxpath:UNKOWN}")
  private String pfxpath;

  @Value("${egsc.config.ssl.pfxpwd:UNKOWN}")
  private String pfxpwd;

  @Value("${egsc.config.api.client.readTimeout:10000}")
  private int clientReadTimeout;

  @Value("${egsc.config.api.client.connectTimeout:10000}")
  private int clientConnectTimeout;

  private String frontType;

  private String authorization;

  @Autowired
  private LoadBalancerClient loadBalancerClient;

  public BaseApiClient() {}

  public BaseApiClient(String gatewayUrl) {
    this.gatewayUrl = gatewayUrl;
  }

  protected abstract String getContextPath();

  public void setServiceUrl(String url) {
    logger.info(String.format("Gateway adrress has been changed to : %s", url));
    gatewayUrl = url;
  }

  public void setFrontType(String frontType) {
    this.frontType = frontType;
  }

  public void setAuthorization(String authorization) {
    this.authorization = authorization;
  }

  /**
   * 获得服务地址
   * 
   * @return String
   */
  public String getServiceUrl() {
    if (StringUtils.isBlank(gatewayUrl)) {

      try {
        ServiceInstance serviceInstance = loadBalancerClient.choose(zuulServiceName);
        if (serviceInstance != null) {
          gatewayUrl =
              String.format("http://%s:%s", serviceInstance.getHost(), serviceInstance.getPort());
          logger.info(String.format("链接网关: %s", gatewayUrl));
        } else {
          gatewayUrl = getDefaultGatewayServiceUrl();
          logger.warn(String.format("读取网关服务 %s地址错误， 设置连接地址为: %s", zuulServiceName, gatewayUrl));
        }
      } catch (Exception e) {
        gatewayUrl = getDefaultGatewayServiceUrl();
        logger.warn(String.format("读取网关服务 %s地址错误， 设置连接地址为: %s", zuulServiceName, gatewayUrl), e);
      }
    }
    return gatewayUrl;
  }

  /**
   * @return String
   */
  private String getDefaultGatewayServiceUrl() {
    return StringUtils.isEmpty(customGatewayUrl) ? defaultHost : customGatewayUrl;
  }

  /**
   * 用于访问服务的客户端
   * 
   * @return RestTemplate
   */
  protected RestTemplate getRestTemplate() {
    boolean flag = false;
    try {
      if ("true".equals(sslEnabled)) {
        CloseableHttpClient httpClient = acceptsUntrustedCertsHttpClient();
        if (null != httpClient) {
          HttpComponentsClientHttpRequestFactory clientHttpRequestFactory =
              new HttpComponentsClientHttpRequestFactory(httpClient);

          clientHttpRequestFactory.setReadTimeout(clientReadTimeout);// ms
          clientHttpRequestFactory.setConnectTimeout(clientConnectTimeout);// ms

          restTemplate = new RestTemplate(clientHttpRequestFactory);
          flag = true;
        }
      }
    } catch (KeyManagementException | KeyStoreException | NoSuchAlgorithmException
        | UnrecoverableKeyException | CertificateException | IOException e) {
      logger.error("实例化RestTemplate异常", e);
    }

    if (!flag) {
      SimpleClientHttpRequestFactory clientHttpRequestFactory =
          new SimpleClientHttpRequestFactory();
      clientHttpRequestFactory.setReadTimeout(clientReadTimeout);// ms
      clientHttpRequestFactory.setConnectTimeout(clientConnectTimeout);// ms
      restTemplate = new RestTemplate(clientHttpRequestFactory);
    }

    return restTemplate;
  }

  /**
   * 调用接口，并封装公共框架
   * 
   * @param url
   * @param baseBusinessDto
   * @return ResponseDto
   * @throws CommonException
   */
  protected ResponseDto post(String url, BaseBusinessDto baseBusinessDto) throws CommonException {

    String path = url;
    if (!StringUtils.isEmpty(getContextPath())) {
      path = getContextPath() + url;
    }

    return postWithContextPath(baseBusinessDto, path);
  }

  /**
   * @param baseBusinessDto
   * @param path
   * @return ResponseDto
   */
  protected ResponseDto postWithContextPath(BaseBusinessDto baseBusinessDto, String path) {
    ResponseDto response = null;
    try {
      response = call(path, baseBusinessDto);
    }
    // connect
    catch (ResourceAccessException e) {
      logError(path, baseBusinessDto, e);
      response = processConnectError(e);
      gatewayUrl = getDefaultGatewayServiceUrl();
    }
    // 400
    catch (HttpClientErrorException e) {
      logError(path, baseBusinessDto, e);
      logger.error(e.getMessage(), e);
      response = process4xxError(e);
    }
    // 500
    catch (HttpServerErrorException e) {
      logError(path, baseBusinessDto, e);
      response = process5xxError(e);
    }
    // others
    catch (Exception e) {
      logError(path, baseBusinessDto, e);
      response = processDefaultError(e);
    }

    if (response != null && !CommonConstant.SUCCESS_CODE.equals(response.getCode())) {
      String message = response.getMessage();
      if (StringUtils.isNotEmpty(response.getCode())) {
        message = String.format("%s:%s", response.getCode(), response.getMessage());
      }
      throw new CommonException(message, message);
    }
    return response;
  }

  /**
   * @param e void
   * @return
   */
  private ResponseDto processDefaultError(Exception e) {
    ResponseDto resDto = new ResponseDto(CommonConstant.DEFAULT_SYS_ERROR_CODE, null, "网络连接失败");;
    String errMsg = e.getMessage();
    if (errMsg != null) {
      resDto = new ResponseDto(CommonConstant.DEFAULT_SYS_ERROR_CODE, null, errMsg);
    }

    return resDto;
  }

  /**
   * @param e
   * @return
   */
  private ResponseDto processConnectError(ResourceAccessException e) {
    logger.error(e.getMessage(), e);
    return new ResponseDto(CommonConstant.DEFAULT_SYS_ERROR_CODE, null, "网络连接失败");
  }

  /**
   * @param url
   * @param baseBusinessDto
   * @param e void
   */
  private void logError(String url, BaseBusinessDto baseBusinessDto, Exception e) {
    logger.error(String.format("Access Error - url(%s) request (%s)", url, baseBusinessDto));
    logger.error(e.getMessage(), e);
  }

  /**
   * void
   * 
   * @return
   */
  private ResponseDto process5xxError(HttpServerErrorException e) {
    ResponseDto resDto = null;
    if (HttpStatus.INTERNAL_SERVER_ERROR.equals(e.getStatusCode())) {
      resDto = getResponseDto(e.getResponseBodyAsString());
    }
    if (resDto == null) {
      resDto = new ResponseDto(CommonConstant.DEFAULT_SYS_ERROR_CODE, null, "系统内部错误");
    }

    return resDto;
  }

  private ResponseDto process4xxError(HttpClientErrorException e) {
    ResponseDto resDto = null;
    HttpStatus statusCode = e.getStatusCode();
    if (HttpStatus.UNAUTHORIZED.equals(statusCode) || HttpStatus.FORBIDDEN.equals(statusCode)
        || HttpStatus.NOT_FOUND.equals(statusCode) || HttpStatus.BAD_REQUEST.equals(statusCode)
        || HttpStatus.REQUEST_TIMEOUT.equals(statusCode)) {
      String code = String.format("framework.network.http.status.%d", statusCode.value());
      throw new CommonException(code, "00400:请求错误");
    } else if (statusCode != null) {
      resDto = new ResponseDto(String.format("00%d", statusCode.value()), null,
          statusCode.getReasonPhrase());
    } else {
      resDto = new ResponseDto(CommonConstant.DEFAULT_SYS_ERROR_CODE, null, "系统内部错误");
    }

    return resDto;
  }

  /**
   * @param strRes
   * @return ResponseDto
   */
  private ResponseDto getResponseDto(String strRes) {
    ResponseDto resDto = null;
    try {
      resDto = JsonUtil.fromJson(strRes, ResponseDto.class);
    } catch (Throwable e) {
      logger.debug(e.getMessage());
    }
    return resDto;
  }

  /**
   * 封装公共框架的BusinessId、TargetSysId、SourceSysId
   * 
   * @param url
   * @param baseBusinessDto
   * @return ResponseDto
   */
  private ResponseDto call(String url, BaseBusinessDto baseBusinessDto) {
    RequestDto<BaseBusinessDto> requestDto = new RequestDto<BaseBusinessDto>();
    Header requestHeader = new Header();
    if (sequenceServiceImpl != null) {
      requestHeader.setBusinessId(sequenceServiceImpl.getSequence(appShortName));
    }
    requestHeader.setSourceSysId(baseBusinessDto.getSourceSysId());
    if (StringUtils.isNotEmpty(appName)) {
      requestHeader.setSourceSysId(appName);
    }
    requestHeader.setTargetSysId(baseBusinessDto.getTargetSysId());
    String contextPath = getContextPath(url);
    if (StringUtils.isNotEmpty(contextPath)) {
      requestHeader.setTargetSysId(contextPath);
    }
    requestHeader.setCreateTimestamp(System.currentTimeMillis());
    requestHeader.setCharset("utf-8");
    requestHeader.setContentType("json");
    requestHeader.setExtAttributes(baseBusinessDto.getExtAttributes());

    requestDto.setHeader(requestHeader);

    baseBusinessDto.clearMetaData();
    requestDto.setData(baseBusinessDto);

    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
    headers.add("Accept", MediaType.APPLICATION_JSON_VALUE);

    if (!StringUtils.isEmpty(frontType)) {
      headers.add("FrontType", frontType);
    } else {
      headers.add("FrontType", SecurityContext.getFrontType());
    }
    if (!StringUtils.isEmpty(authorization)) {
      headers.add("Authorization", authorization);
    } else {
      headers.add("Authorization", SecurityContext.getToken());
    }
    HttpEntity<RequestDto<?>> formEntity = new HttpEntity<RequestDto<?>>(requestDto, headers);
    URI uri = URI.create(getServiceUrl() + url);

    logger.info(String.format("post -> %s", uri.toString()));

    if (logger.isDebugEnabled()) {
      logger.debug("Request: " + JsonUtil.toJsonString(requestDto));
    }

    ResponseDto response = null;
    try {
      response = getRestTemplate().postForObject(uri, formEntity, ResponseDto.class);
    } catch (ResourceAccessException e) {
      logger.error(e.getMessage());
      response = callGatewayAgain(url, formEntity);
    }

    if (logger.isDebugEnabled()) {
      logger.debug("Response: " + JsonUtil.toJsonString(response));
    }

    return response;
  }

  /**
   * @param url
   * @param formEntity
   * @return ResponseDto
   */
  private ResponseDto callGatewayAgain(String url, HttpEntity<RequestDto<?>> formEntity) {
    ResponseDto response;
    logger.info("Try to retrieve gateway dynamically!");
    this.gatewayUrl = null;
    URI uri = URI.create(getServiceUrl() + url);
    response = getRestTemplate().postForObject(uri, formEntity, ResponseDto.class);

    return response;
  }



  /**
   * 获得系统上下文
   * 
   * @param url
   * @return String
   */
  private String getContextPath(String url) {
    String contextPath = "";
    if (StringUtils.isNotEmpty(url) && url.startsWith("/") && !url.startsWith("//")) {
      contextPath = url.split("/")[1];
    } else {
      String message = String.format("%s:%s", CommonConstant.DEFAULT_SYS_ERROR_CODE,
          String.format("URL %s 格式不对", url));
      throw new CommonException(message);
    }
    return contextPath;
  }

  /**
   * 
   * @return CloseableHttpClient
   * @throws KeyStoreException
   * @throws NoSuchAlgorithmException
   * @throws KeyManagementException
   * @throws CertificateException
   * @throws IOException
   * @throws UnrecoverableKeyException
   */
  private CloseableHttpClient acceptsUntrustedCertsHttpClient()
      throws KeyStoreException, NoSuchAlgorithmException, KeyManagementException,
      CertificateException, IOException, UnrecoverableKeyException {
    logger.debug("Start acceptsUntrustedCertsHttpClient");

    HttpClientBuilder b = HttpClientBuilder.create();

    KeyStore keyStore = KeyStore.getInstance("PKCS12");
    InputStream instream = this.getClass().getResourceAsStream(pfxpath);
    logger.debug(String.format("client cer path : %s, password: %s", pfxpath, pfxpwd));
    
    if (null == instream) {
      logger.error("Can't load " + pfxpath);
      return null;
    }
    try {
      keyStore.load(instream, pfxpwd.toCharArray());
      logger.debug(String.format("Load %s sucessfully", pfxpath));
    } finally {
      instream.close();
    }

    logger.debug("Load keystore into sslcontext");
    SSLContext sslcontext =
        SSLContexts.custom().loadKeyMaterial(keyStore, pfxpwd.toCharArray()).build();

    logger.debug("initialize one new sslContext and set it to http client builder");
    SSLContext sslContext = new SSLContextBuilder().loadTrustMaterial(null, new TrustStrategy() {
      @Override
      public boolean isTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
        return true;
      }
    }).build();
    b.setSSLContext(sslContext);

    logger.debug("initialize a ssl socket factory");
    SSLConnectionSocketFactory sslSocketFactory = new SSLConnectionSocketFactory(sslcontext,
        new String[] {"TLSv1"}, null, SSLConnectionSocketFactory.getDefaultHostnameVerifier());

    logger.debug("initialize a socket factory registry");
    Registry<ConnectionSocketFactory> socketFactoryRegistry =
        RegistryBuilder.<ConnectionSocketFactory>create()
            .register("http", PlainConnectionSocketFactory.getSocketFactory())
            .register("https", sslSocketFactory).build();

    logger.debug("initialize a http client connection manager with the socket factory registry");
    PoolingHttpClientConnectionManager connMgr =
        new PoolingHttpClientConnectionManager(socketFactoryRegistry);
    connMgr.setMaxTotal(200);
    connMgr.setDefaultMaxPerRoute(100);
    b.setConnectionManager(connMgr);

    logger.debug("build a ssl http client");
    CloseableHttpClient httpClient = b.build();
    
    logger.debug("End acceptsUntrustedCertsHttpClient");
    return httpClient;
  }
}

package com.eg.egsc.framework.client.core;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.text.WordUtils;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

/**
 * 获取多例Client Bean工厂类
 * 
 * @author douguoqiang
 * @since 2018年2月28日
 */
@Component
public class ClientBeanFactory implements ApplicationContextAware {

  private static ApplicationContext applicationContext;

  private static final Map<String, Object> clientBeanMap = new HashMap<String, Object>();

  /**
   * 根据小区ID获取多例client bean
   * 
   * @param communityId 小区ID
   * @param clz 指定Client Bean的类型
   * @return T 返回指定的Client Bean
   */
  @SuppressWarnings("unchecked")
  public static synchronized <T> T getPrototypeInstance(String communityId, Class<T> clz) {
    T newInst = null;
    if (StringUtils.isNotBlank(communityId)) {
      String beanKey = WordUtils.uncapitalize(clz.getSimpleName());
      String mapKey = communityId.concat("_").concat(beanKey);
      if (clientBeanMap.containsKey(mapKey)) {
        newInst = (T) clientBeanMap.get(mapKey);
      } else {
        newInst = applicationContext.getBean(beanKey, clz);
        clientBeanMap.put(mapKey, newInst);
      }
    }
    return newInst;
  }

  /**
   * @param clz
   * @return T
   */
  public static synchronized <T> T getPrototypeInstance(Class<T> clz) {
    String beanKey = WordUtils.uncapitalize(clz.getSimpleName());
    T newInst = applicationContext.getBean(beanKey, clz);
    return newInst;
  }

  public void setApplicationContext(ApplicationContext applicationContext) {
    if (ClientBeanFactory.applicationContext == null) {
      ClientBeanFactory.applicationContext = applicationContext;
    }
  }
}

/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.common.component.auth.service;

import javax.servlet.ServletRequest;

/**
 * @author gaoyanlong
 * @since 2018年1月25日
 */
public interface SuperviserService {
  
  public void loginAsAdmin();

  public void loginAsAdmin(ServletRequest request);

}

/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.common.component.auth.web.vo;

/**
 * UserLoginDto
 * 
 * @author gaoyanlong
 * @since 2018年1月4日
 */
public class UserLoginVo {

  private String username;
  private String password;
  private String verifycode;
  private String userType;

  public UserLoginVo() {
    super();
  }

  /**
   * @param username
   * @param password
   * @param verifycode
   */
  public UserLoginVo(String username, String password, String verifycode) {
    super();
    this.username = username;
    this.password = password;
    this.verifycode = verifycode;
  }

  /**
   * @param username
   * @param password
   */
  public UserLoginVo(String username, String password) {
    super();
    this.username = username;
    this.password = password;
  }

  public String getUserType() {
    return userType;
  }

  public void setUserType(String userType) {
    this.userType = userType;
  }

  public String getVerifycode() {
    return verifycode;
  }

  public void setVerifycode(String verifycode) {
    this.verifycode = verifycode;
  }

  /**
   * @Return the String username
   */
  public String getUsername() {
    return username;
  }

  /**
   * @Param String username to set
   */
  public void setUsername(String username) {
    this.username = username;
  }

  /**
   * @Return the String password
   */
  public String getPassword() {
    return password;
  }

  /**
   * @Param String password to set
   */
  public void setPassword(String password) {
    this.password = password;
  }

  /*
   * (non-Javadoc)
   * 
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return "UserLoginVo [username=" + username + ", password=" + password + ", verifycode="
        + verifycode + "]";
  }
}

/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.common.component.job.support;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.eg.egsc.common.component.job.model.BusinessJobConfig;

/**
 * JobManager
 * 
 * @author songjie
 * @since 2018年1月17日
 */
@Component
public class JobService {
  @Autowired
  private JobManager jobManager;
  private static final Logger LOGGER = LoggerFactory.getLogger(JobService.class);


  /**
   * Private constructor
   */
  private JobService() {}

  /**
   * 创建任务
   * 
   * @param jobConfig
   * @return boolean
   */
  public boolean createJob(BusinessJobConfig jobConfig) {
    if (null == jobConfig) {
      LOGGER.info("参数jobConfig 不能为空！");
      return false;
    }
    if (StringUtils.isBlank(jobConfig.getServiceName())
        || StringUtils.isBlank(jobConfig.getMethodName())
        || StringUtils.isBlank(jobConfig.getCronExpression())) {
      LOGGER.info("创建任务失败，由于服务名称、方法名称或表达式为空。服务名称：" + jobConfig.getServiceName() + " 方法名称："
          + jobConfig.getMethodName() + " 表达式：" + jobConfig.getCronExpression() + " id："
          + jobConfig.getId());
      return false;
    }
    if (jobManager.createJob(jobConfig)) {
      LOGGER.info("创建任务成功。服务名称：" + jobConfig.getServiceName() + " 方法名称：" + jobConfig.getMethodName()
          + " 表达式：" + jobConfig.getCronExpression() + " id：" + jobConfig.getId());
    } else {
      LOGGER.info("创建任务失败。任务已存在," + jobConfig.getServiceName() + " 方法名称："
          + jobConfig.getMethodName() + " id：" + jobConfig.getId());
      return false;
    }
    return true;
  }

  /**
   * 移除一个任务
   * 
   * @param serviceName
   * @param methodName
   * @return boolean
   */
  public boolean removeJob(String serviceName, String methodName) {
    return removeJob(serviceName, methodName, "");
  }

  /**
   * 移除一个任务
   * 
   * @param serviceName
   * @param methodName
   * @param id
   * @return boolean
   */
  public boolean removeJob(String serviceName, String methodName, String id) {
    if (StringUtils.isBlank(serviceName) || StringUtils.isBlank(methodName)) {
      LOGGER.error("参数serviceName 和 methodName 不能为空！");
      return false;
    }
    return removeJob(getJobName(serviceName, methodName, id));
  }

  /**
   * 移除一个任务
   * 
   * @param jobName
   * @return boolean
   */
  public boolean removeJob(String jobName) {
    if (StringUtils.isBlank(jobName)) {
      LOGGER.error("参数jobName 不能为空！");
      return false;
    }
    return jobManager.removeJob(jobName, BusinessJob.BUSINESS_JOB_GROUP_NAME);
  }

  /**
   * 查询是否某任务是否已经存在
   * 
   * @param serviceName
   * @param methodName
   * @return boolean
   */
  public boolean isJobExist(String serviceName, String methodName) {
    return isJobExist(serviceName, methodName, "");
  }

  /**
   * 查询是否某任务是否已经存在
   * 
   * @param serviceName
   * @param methodName
   * @param id
   * @return boolean
   */
  public boolean isJobExist(String serviceName, String methodName, String id) {
    if (StringUtils.isBlank(serviceName) || StringUtils.isBlank(methodName)) {
      LOGGER.error("参数serviceName 和 methodName 不能为空！");
      return false;
    }
    return isJobExist(getJobName(serviceName, methodName, id));
  }

  /**
   * 查询是否某任务是否已经存在
   * 
   * @param jobName
   * @return boolean
   */
  public boolean isJobExist(String jobName) {
    if (StringUtils.isBlank(jobName)) {
      LOGGER.error("参数jobName 不能为空！");
      return false;
    }
    return jobManager.isJobExist(jobName, BusinessJob.BUSINESS_JOB_GROUP_NAME);
  }

  /**
   * 查询所有执行中的任务
   * 
   * @return List<Object[]>
   */
  public List<Object[]> getAllRunningJob() {
    return jobManager.getAllRunningJob();
  }

  public String getJobName(String serviceName, String methodName, String id) {
    if (StringUtils.isBlank(serviceName) || StringUtils.isBlank(methodName)) {
      return "";
    }

    StringBuilder jobName = new StringBuilder(BusinessJob.JOB_NAME_PREFIX).append(serviceName)
        .append("#").append(methodName);
    if (StringUtils.isNotBlank(id)) {
      jobName.append("#").append(id);
    }
    return jobName.toString();
  }
}

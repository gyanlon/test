/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.common.component.job.support;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.eg.egsc.common.component.job.model.BusinessJobConfig;
import com.eg.egsc.common.component.job.model.JobStatus;

/**
 * JobMonitor
 * 
 * @author songjie
 * @since 2018年1月17日
 */
@Component
public class JobMonitor {

  @Autowired
  private QuartzAdapter quartzAdapterImpl;

  @Autowired
  private JobManager jobManager;

  private boolean active = false;

  /**
   * job启动类
   */
  public void start() {
    List<BusinessJobConfig> jobConfigs =
        quartzAdapterImpl.findAllJobConfigs(jobManager.getApplicationContext());
    if (!active) {
      // if no managed jobs, ignore
      if (CollectionUtils.isEmpty(jobConfigs)) {
        return;
      }
      // startup all managed jobs.
      for (BusinessJobConfig jobConfig : jobConfigs) {
        if (JobStatus.DISABLE.getValue().equals(jobConfig.getStatus())) {
          continue;
        }
        jobManager.createJob(jobConfig);
      }
      active = true;
    }
  }

  /**
   * job停止
   */
  public void stop() {
    if (active) {
      /*
       * List<BusinessJobConfig> bjiList = this.getBusinessJobInfoList(); for (BusinessJobConfig bji
       * : bjiList) { String jobName = AbstractJob.JOB_NAME_PREFIX + bji.getServiceName() + "#" +
       * bji.getMethodName(); String jobGroupName = BusinessJob.BUSINESS_JOB_GROUP_NAME;
       * jobManager.removeJob(jobName, jobGroupName); }
       */
      active = false;
    }
  }

  /**
   * job重启
   */
  public void restart() {
    stop();
    start();
  }

  /**
   * 是否活动
   * 
   * @return boolean
   */
  public boolean isActive() {
    return active;
  }

  /**
   * @return List<BusinessJobConfig>
   */
  public List<BusinessJobConfig> getBusinessJobInfoList() {
    return null;// nlbpSysBusinessJobInfoDao.findList(new
    // NlbpSysBusinessJobInfoModel());
  }
}

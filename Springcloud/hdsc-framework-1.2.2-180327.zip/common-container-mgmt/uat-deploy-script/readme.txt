
java_app_deploy : 不使用config-server的部署脚本

java_app_deploy-v2 ：使用config-server的部署脚本

1. 目标服务器/data/{shell,webapps}的owner是appdeploy, 要有755权限
            /data/logs的owner是appdeploy, 要有755权限

2. C++应用：发送给小区运维管理服务器的压缩包,解压到/data/webapps的目录结构是：DAG/bin/{DAG,DAG_uat.json}

3. 两个C++应用：都需要新增一个uat的配置文件。

#!/bin/sh

cd /data/webapps/VC/bin
nohup ./mediaTransferServer $1 > /dev/null 2>/dev/null &


sleep 3
cnt=`ps -ef | grep -v grep | grep mediaTransferServer | wc -l`
if [ $cnt -eq 0 ]
then
	echo "Fail to start mediaTransferServer"
        exit 1
else
	echo "Start mediaTransferServer successfully"
fi

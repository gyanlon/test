#!/bin/sh

#if [ $1 = "scptest" ]
#then
#        configfile="DAG_test.json"
#elif [ $1 = "scptest2" ]
#then
#        configfile="DAG_test2.json"
#fi

# 定义UAT环境的配置文件,目前是由开发人员维护
configfile="DAG_uat.json"
cd /data/webapps/DAG/bin
nohup ./DAG --config=$configfile > /dev/null 2>/dev/null &
sleep 3
cnt=`ps -ef | grep -v grep | grep DAG | wc -l`
if [ $cnt -eq 0 ]
then
	echo "Fail to start DAG"
	exit 1
else
	echo "Start DAG successfully"
fi


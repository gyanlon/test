#!/bin/sh

#serverfile=/var/lib/jenkins/shell/serverinfo.txt
#ip=`grep "^$1.$2=" $serverfile | cut -d= -f2`
#sshport=`grep "^$1.$2.sshport" $serverfile | cut -d= -f2`
#sshuser=`grep "^$1.$2.user" $serverfile | cut -d= -f2`
#if [ -z $sshport ]
#then
#	sshport=`grep "^$1.sshport" $serverfile | cut -d= -f2`
#	sshuser=`grep "^$1.user" $serverfile | cut -d= -f2`
#fi
#env=`echo $1 | cut -b4-`
#configfile=config_$env.xml
#
#echo $ip $sshport $sshuser $configfile
#
#ssh $sshuser@$ip -oPort=$sshport /home/$sshuser/shell/stopvc.sh
#scp -P $sshport bin/* $sshuser@$ip:/home/$sshuser/webapps
#if [ $? -ne 0 ]
#then
#	exit 1
#fi
#ssh $sshuser@$ip -oPort=$sshport /home/$sshuser/shell/startvc.sh $configfile
#if [ $? -ne 0 ]
#then
#	exit 1
#fi
##############
# 定义C++部署脚本的存放路径
cplus_shell_path=/data/shell/c++_app_deploy

# 定义服务器列表存放位置
serverfile=/data/shell/scp-serverinfo.txt

IP_scp_app=`grep "^scptest.app" $serverfile | cut -d= -f2`
sshport=`grep "^scptest.sshport" $serverfile | cut -d= -f2`
sshuser=`grep "^scptest.user" $serverfile | cut -d= -f2`

# 定义UAT环境的配置文件，目前由开发人员维护
configfile=config_uat.xml
echo $IP_scp_app $sshport $sshuser $configfile

# 发送stopvc.sh和startvc.sh脚本到目标服务器
scp -P $sshport $cplus_shell_path/stopvc.sh appdeploy@$IP_scp_app:/data/shell
scp -P $sshport $cplus_shell_path/startvc.sh appdeploy@$IP_scp_app:/data/shell
# 停止旧版应用
ssh $sshuser@$IP_scp_app -oPort=$sshport /data/shell/stopvc.sh
# 在目标服务器上创建vc/bin目录
ssh $sshuser@$IP_scp_app -oPort=$sshport mkdir -p /data/webapps/VC/bin
# 发送新版应用可执行文件和配置文件到目标服务器
scp -P $sshport /data/webapps/VC/bin/* $sshuser@$IP_scp_app:/data/webapps/VC/bin
if [ $? -ne 0 ]
then
        exit 1
fi
ssh $sshuser@$IP_scp_app -oPort=$sshport /data/shell/startvc.sh $configfile

if [ $? -ne 0 ]
then
        exit 1
fi

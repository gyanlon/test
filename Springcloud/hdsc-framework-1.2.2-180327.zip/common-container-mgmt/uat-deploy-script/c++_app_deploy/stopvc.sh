#!/bin/sh

kill -9 `ps -ef|grep mediaTransferServer|grep -v grep|awk '{print $2}'`

echo "Stop success!"

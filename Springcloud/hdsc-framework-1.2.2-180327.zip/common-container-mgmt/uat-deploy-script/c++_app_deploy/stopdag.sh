#!/bin/sh

kill -9 `ps -ef|grep DAG|grep -v grep|awk '{print $2}'`



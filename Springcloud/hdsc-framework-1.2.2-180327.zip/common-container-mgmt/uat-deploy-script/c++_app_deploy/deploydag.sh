#!/bin/sh

#if [ $# -ne 2 ]
#then
#	echo "Usage: %0 env server"
#	exit 1
#fi

# 定义C++部署脚本的存放路径
cplus_shell_path=/data/shell/c++_app_deploy

# 定义服务器列表存放位置
serverfile=/data/shell/scp-serverinfo.txt

IP_scp_app=`grep "^scptest.app" $serverfile | cut -d= -f2`
sshport=`grep "^scptest.sshport" $serverfile | cut -d= -f2`
sshuser=`grep "^scptest.user" $serverfile | cut -d= -f2`

# 发送stopdag.sh和startdag.sh脚本到目标服务器
scp -P $sshport $cplus_shell_path/stopdag.sh appdeploy@$IP_scp_app:/data/shell
scp -P $sshport $cplus_shell_path/startdag.sh appdeploy@$IP_scp_app:/data/shell
# 停止旧版应用
ssh $sshuser@$IP_scp_app -oPort=$sshport /data/shell/stopdag.sh
# 在目标服务器上创建DAG/bin目录
ssh $sshuser@$IP_scp_app -oPort=$sshport mkdir -p /data/webapps/DAG/bin
# 发送新版应用可执行文件和配置文件到目标服务器
scp -P $sshport /data/webapps/DAG/bin/* $sshuser@$IP_scp_app:/data/webapps/DAG/bin
if [ $? -ne 0 ]
then
	exit 1
fi
ssh $sshuser@$IP_scp_app -oPort=$sshport /data/shell/startdag.sh

if [ $? -ne 0 ]
then
	exit 1
fi

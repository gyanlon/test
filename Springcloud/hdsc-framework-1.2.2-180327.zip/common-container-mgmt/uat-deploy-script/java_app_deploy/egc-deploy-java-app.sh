#/bin/bash

#定义java部署脚本的存放路径
java_shell_path=/data/shell/java_app_deploy

# 定义待发布到管理和路由服务器的应用列表，格式为：jar包名=端口号
egc_mgt_list=`cat $java_shell_path/egc_mgt_list.txt`
# 定义待发布到小区应用服务器的应用列表，格式为：jar包名=端口号
egc_app_list=`cat $java_shell_path/egc_app_list.txt`

# 定义小区server列表
serverfile=/data/shell/egc-serverinfo.txt
jardir=/data/webapps

# 获取路由和管理服务器ip
IP_egc_mgt=`grep "^egctest.mgt" $serverfile | cut -d= -f2`

# 获取小区应用服务器ip
IP_egc_app=`grep "^egctest.app" $serverfile | cut -d= -f2`

#获取ssh用户和密码
sshport=`grep "^egctest.sshport" $serverfile | cut -d= -f2`
sshuser=`grep "^egctest.user" $serverfile | cut -d= -f2`

# 部署应用到管理和路由服务器
scp -P 51000 $java_shell_path/startbyname.sh appdeploy@$IP_egc_mgt:/data/shell
scp -P 51000 $java_shell_path/stopbyname.sh appdeploy@$IP_egc_mgt:/data/shell
# 遍历egc_mgt_list.txt获取jar包名、端口号
for line in $egc_mgt_list
do
        if [ -z $line ]
        then
                break
        fi
        echo "line=$line"
	# 读取jar包名和端口号
	jarname=`echo $line | cut -d= -f1`
        echo "get jarname:" $jarname
	jarport=`echo $line | cut -d= -f2`
        echo "get jarport:"$jarport
	scp -P 51000 $jardir/$jarname appdeploy@$IP_egc_mgt:/data/webapps
	# 停止旧版应用
	ssh $sshuser@$IP_egc_mgt -oPort=$sshport /data/shell/stopbyname.sh $jarname
	ssh $sshuser@$IP_egc_mgt -oPort=$sshport sleep 1 
	# 启动新版应用
	ssh $sshuser@$IP_egc_mgt -oPort=$sshport /data/shell/startbyname.sh $jarname $jarport
done

# 部署应用到小区应用服务器
scp -P 51000 $java_shell_path/startbyname.sh appdeploy@$IP_egc_app:/data/shell
scp -P 51000 $java_shell_path/stopbyname.sh appdeploy@$IP_egc_app:/data/shell
# 遍历egc_app_list.txt获取jar包名、端口号
for line in $egc_app_list
do
        if [ -z $line ]
        then
                break
        fi
        echo "line=$line"        
	#读取jar包名和端口号
	jarname=`echo $line | cut -d= -f1`
        echo "get jarname:" $jarname
	jarport=`echo $line | cut -d= -f2`
        echo "get jarport:"$jarport
	scp -P 51000 $jardir/$jarname appdeploy@$IP_egc_app:/data/webapps
	# 停止旧版应用
	ssh $sshuser@$IP_egc_app -oPort=$sshport /data/shell/stopbyname.sh $jarname
	ssh $sshuser@$IP_egc_app -oPort=$sshport sleep 1
	# 启动新版应用
	ssh $sshuser@$IP_egc_app -oPort=$sshport /data/shell/startbyname.sh $jarname $jarport
done


#/bin/bash

#定义java部署脚本的存放路径
java_shell_path=/data/shell/java_app_deploy

# 定义待发布到管理和路由服务器的应用列表，格式为：jar包名=端口号
scp_mgt_list=`cat $java_shell_path/scp_mgt_list.txt`
# 定义待发布到小区应用服务器的应用列表，格式为：jar包名=端口号
scp_app_list=`cat $java_shell_path/scp_app_list.txt`

# 定义小区server列表
serverfile=/data/shell/scp-serverinfo.txt

# 定义存放jar包的路径
jardir=/data/webapps

# 获取路由和管理服务器ip
IP_scp_mgt=`grep "^scptest.mgt" $serverfile | cut -d= -f2`

# 获取小区应用服务器ip
IP_scp_app=`grep "^scptest.app" $serverfile | cut -d= -f2`

#获取ssh用户和密码
sshport=`grep "^scptest.sshport" $serverfile | cut -d= -f2`
sshuser=`grep "^scptest.user" $serverfile | cut -d= -f2`

# 部署应用到管理和路由服务器
scp -P 51000 $java_shell_path/startbyname.sh appdeploy@$IP_scp_mgt:/data/shell
scp -P 51000 $java_shell_path/stopbyname.sh appdeploy@$IP_scp_mgt:/data/shell
# 遍历scp_mgt_list.txt获取jar包名、端口号
for line in $scp_mgt_list
do
        if [ -z $line ]
        then
                break
        fi
        echo "line=$line"
	# 读取jar包名和端口号
	jarname=`echo $line | cut -d= -f1`
        echo "get jarname:" $jarname
	jarport=`echo $line | cut -d= -f2`
        echo "get jarport:"$jarport
	scp -P 51000 $jardir/$jarname appdeploy@$IP_scp_mgt:/data/webapps
	# 停止旧版应用
	ssh $sshuser@$IP_scp_mgt -oPort=$sshport /data/shell/stopbyname.sh $jarname
	ssh $sshuser@$IP_scp_mgt -oPort=$sshport sleep 1 
	# 启动新版应用
	ssh $sshuser@$IP_scp_mgt -oPort=$sshport /data/shell/startbyname.sh $jarname $jarport
done

# 部署应用到小区应用服务器
scp -P 51000 $java_shell_path/startbyname.sh appdeploy@$IP_scp_app:/data/shell
scp -P 51000 $java_shell_path/stopbyname.sh appdeploy@$IP_scp_app:/data/shell
# 遍历scp_app_list.txt获取jar包名、端口号
for line in $scp_app_list
do
        if [ -z $line ]
        then
                break
        fi
        echo "line=$line"        
	#读取jar包名和端口号
	jarname=`echo $line | cut -d= -f1`
        echo "get jarname:" $jarname
	jarport=`echo $line | cut -d= -f2`
        echo "get jarport:"$jarport
	scp -P 51000 $jardir/$jarname appdeploy@$IP_scp_app:/data/webapps
	# 停止旧版应用
	ssh $sshuser@$IP_scp_app -oPort=$sshport /data/shell/stopbyname.sh $jarname
	ssh $sshuser@$IP_scp_app -oPort=$sshport sleep 1
	# 启动新版应用
	ssh $sshuser@$IP_scp_app -oPort=$sshport /data/shell/startbyname.sh $jarname $jarport
done


#!/bin/sh

name=$1

tpid=`ps -ef|grep ${name}|grep -v "$0"|grep -v "grep"|grep -v "kill"|awk '{print $2}'`
echo ${tpid}
if [ ! -z "${tpid}" ]; then
    echo 'Stop Process...'
    kill -15 $tpid
fi
sleep 3 
tpid=`ps -ef|grep ${name}|grep -v "$0"|grep -v "grep"|grep -v "kill"|awk '{print $2}'`
if [ ! -z "${tpid}" ]; then
    echo 'Kill Process!'
    kill -9 $tpid
else
    echo 'Stop Success!'
fi

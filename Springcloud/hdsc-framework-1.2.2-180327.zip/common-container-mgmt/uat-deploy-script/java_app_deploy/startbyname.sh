#!/bin/sh
JAVA_HOME=/app/jdk1.8.0_141
name=$1
port=$2
dir=/data/webapps

sevenchar=`echo $1 | cut -b-7`
if [ $sevenchar = "scp-iot" ]
then
	ARGS="-Xms1024m -Xmx2048m"
elif [ $sevenchar = "gateway" ]
then
        curdate=`date '+%Y%m%d.%H%M%S'`
	ARGS="-server -Xms1024m -Xmx1024m -Xmn512m -Xss256k -XX:MaxMetaspaceSize=256m -XX:SurvivorRatio=4 -XX:TargetSurvivorRatio=70 -XX:+DisableExplicitGC -XX:+UseConcMarkSweepGC -XX:+UseParNewGC -XX:+CMSClassUnloadingEnabled -XX:+UseCMSInitiatingOccupancyOnly -XX:CMSInitiatingOccupancyFraction=70 -XX:+CMSScavengeBeforeRemark -XX:+PrintGC -XX:+PrintGCDetails -XX:+PrintGCDateStamps -XX:+PrintGCTimeStamps -XX:+PrintGCApplicationStoppedTime -XX:+PrintFlagsFinal -Xloggc:/data/gatewaylog/gc.log.$curdate -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/data/gatewaylog/dump_core_pid%p.hprof -XX:ErrorFile=/data/gatewaylog/hs_err_pid%p.log -Dcom.sun.management.jmxremote.port=9000 -Dcom.sun.management.jmxremote.ssl=false -Dcom.sun.management.jmxremote.authenticate=false"
else
	ARGS="-Xmx1024m -Xms256m"
fi
PORTARG="--server.port=${port} --server.context-path=/"

. /etc/profile

echo ${name}
echo ${port}
${JAVA_HOME}/bin/java -Duser.timezone=GMT+08 $ARGS -jar ${dir}/${name} $PORTARG >/dev/null 2>nohup.out &

sleep 5
ps -ef | grep java | grep -v "grep" | grep ${name}
if [ $? -eq 0 ]
then
	echo Start Success!
else
	echo "Fail to start!"
	exit 1
fi

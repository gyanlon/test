#!/bin/sh

NODE_HOME=/usr/local/node-v8.9.1-linux-x64

#cd /var/lib/jenkins/workspace/SCP-UI-framework/egsc-UI
cd egsc-UI

${NODE_HOME}/bin/cnpm install
${NODE_HOME}/bin/npm run build
rm -rf UI.tar
cd dist
tar -cvf ../UI.tar ./*
cd ..
mv UI.tar ..

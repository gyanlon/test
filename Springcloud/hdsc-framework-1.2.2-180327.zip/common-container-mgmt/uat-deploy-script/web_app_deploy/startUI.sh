#!/bin/sh
cd /data/www/html/UI
rm -rf index.html
rm -rf static
tar -xvf UI.tar ./


#!/bin/sh

# 定义web部署脚本的存放路径
web_shell_path=/data/shell/web_app_deploy

# 定义小区server列表
serverfile=$web_shell_path/egc-serverinfo.txt

# 定义存放前端tar包的路径
tardir=/data/webapps


# 获取前端服务器的ip,port,user
IP_egc_app=`grep "^egctest.app" $serverfile | cut -d= -f2`
sshport=`grep "^egctest.sshport" $serverfile | cut -d= -f2`
sshuser=`grep "^egctest.user" $serverfile | cut -d= -f2`

if [ $1 = "adminui" ]
then
        # 打包adminui,在jenkins上完成
	# /var/lib/jenkins/shell/adminUIbuild.sh $2

        # 创建nginx代理的adminUI部署目录  待验证是否必需？
	ssh $sshuser@$IP_egc_app -oPort=$sshport mkdir -p /data/www/html/adminUI
	# 发送adminUI.tar到部署目录
	scp -P $sshport $tardir/adminUI.tar $sshuser@$IP_egc_app:/data/www/html/adminUI
	# 发送启动脚本到目标服务器
        scp -P $sshport $web_shell_path/startAdminUI.sh appdeploy@$IP_egc_app:/data/shell
	# 删除旧版adminUI文件，启动新版adminUI
	ssh $sshuser@$IP_egc_app -oPort=$sshport /data/shell/startAdminUI.sh
	
elif [ $1 = "ui" ]
then
        # 打包ui,在jenkins上完成
	# /var/lib/jenkins/shell/UIbuild.sh

        # 创建nginx代理的UI部署目录  待验证是否必需？
        ssh $sshuser@$IP_egc_app -oPort=$sshport mkdir -p /data/www/html/UI
	# 发送UI.tar到部署目录
	scp -P $sshport $tardir/UI.tar $sshuser@$IP_egc_app:/data/www/html/UI
	# 发送启动脚本到目标服务器
        scp -P $sshport $web_shell_path/startUI.sh appdeploy@$IP_egc_app:/data/shell
        # 删除旧版UI文件，启动新版UI
	ssh $sshuser@$IP_egc_app -oPort=$sshport /data/shell/startUI.sh

fi

#!/bin/sh

NODE_HOME=/usr/local/node-v8.9.1-linux-x64

platform="scp"
if [ $# -ge 1 ]
then
	platform=`echo $1 | cut -b-3`
fi
if [ $platform = "scp" ]
then
	cd egsc-admin-UI
fi

${NODE_HOME}/bin/cnpm install
${NODE_HOME}/bin/npm run build
rm -rf adminUI.tar
cd dist
tar -cvf ../adminUI.tar ./*
cd ..

if [ $platform = "scp" ]
then
	mv adminUI.tar ..
fi

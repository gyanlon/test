#!/bin/sh
cd /data/www/html/adminUI
rm -rf index.html
rm -rf static
tar -xvf adminUI.tar ./

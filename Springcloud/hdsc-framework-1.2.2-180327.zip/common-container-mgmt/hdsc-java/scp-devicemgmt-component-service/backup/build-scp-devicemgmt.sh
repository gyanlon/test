docker build --tag 192.168.0.196:5000/scp-devicemgmt-component-service:0.0.3 .

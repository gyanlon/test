#!/bin/bash --login
pwd
kubectl get node
kubectl delete -f hdsc-apps/hdsc-java/scp-devicemgmt-component-service/controller.yaml
kubectl delete -f hdsc-apps/hdsc-java/scp-devicemgmt-component-service/service.yaml 
sleep 5
kubectl create -f hdsc-apps/hdsc-java/scp-devicemgmt-component-service/service.yaml
sleep 2
kubectl create -f hdsc-apps/hdsc-java/scp-devicemgmt-component-service/controller.yaml

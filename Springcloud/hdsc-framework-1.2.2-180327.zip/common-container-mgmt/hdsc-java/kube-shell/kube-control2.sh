#!/bin/bash --login
pwd
kubectl get node
# change current path to kube-shell
cd /root/hdsc-apps/hdsc-java/kube-shell
# copy yaml file to current path
cp /root/hdsc-apps/hdsc-java/$1/controller.yaml .
cp /root/hdsc-apps/hdsc-java/$1/service.yaml .

# replace image version
sed -i 's/0.3.0/'$2'/g' $(find ./ -name "controller.yaml")
kubectl delete -f controller.yaml
kubectl delete -f service.yaml 
sleep 5
kubectl create -f service.yaml
sleep 2
kubectl create -f controller.yaml
sleep 2
ip_short=`kubectl get pod -o wide|grep $1|awk '{match($7,/([0-9]{3})/,a);print a[1]}'`
#ip_short=`kubectl get pod -o wide|grep $1|awk '{print $7}'|cut -c8-10`
echo "Your app $1 run on server:192.168.0."$ip_short
echo "Please search log at: http://192.168.0."$ip_short":8001"

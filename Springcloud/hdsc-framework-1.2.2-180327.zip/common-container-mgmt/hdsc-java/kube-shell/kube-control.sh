#!/bin/bash --login
pwd
kubectl get node
kubectl delete -f hdsc-apps/hdsc-java/$1/controller.yaml
kubectl delete -f hdsc-apps/hdsc-java/$1/service.yaml 
sleep 5
kubectl create -f hdsc-apps/hdsc-java/$1/service.yaml
sleep 2
kubectl create -f hdsc-apps/hdsc-java/$1/controller.yaml
sleep 2
ip_short=`kubectl get pod -o wide|grep $1|awk '{print $7}'|cut -c8-10`
echo "Your app $1 run on server:192.168.0."$ip_short
echo "please search log at: 192.168.0."$ip_short":8001"

docker build --tag 192.168.0.196:5000/config-server:1.0.0 .

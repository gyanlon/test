        resources:
          limits:
            memory: "1024Mi"
          requests:
            memory: "256Mi"

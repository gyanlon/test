#!/bin/bash --login
pwd
kubectl get node
kubectl delete -f hdsc-apps/hdsc-java/$1/controller.yaml
kubectl delete -f hdsc-apps/hdsc-java/$1/service.yaml 
sleep 5
kubectl create -f hdsc-apps/hdsc-java/$1/service.yaml
sleep 2
kubectl create -f hdsc-apps/hdsc-java/$1/controller.yaml

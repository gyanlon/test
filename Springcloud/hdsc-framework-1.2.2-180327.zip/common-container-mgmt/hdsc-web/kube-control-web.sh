#!/bin/bash --login
#$1=imageversion
pwd
kubectl get node
# change current path to kube-shell
cd /root/hdsc-apps/hdsc-web/kube-shell
# copy yaml file to current path
cp /root/hdsc-apps/hdsc-web/controller.yaml .
cp /root/hdsc-apps/hdsc-web/service.yaml .

# replace image version
sed -i 's/#imageversion#/'$1'/g' $(find ./ -name "controller.yaml")
kubectl delete -f controller.yaml
kubectl delete -f service.yaml
sleep 5
kubectl create -f service.yaml
sleep 2
kubectl create -f controller.yaml
sleep 2

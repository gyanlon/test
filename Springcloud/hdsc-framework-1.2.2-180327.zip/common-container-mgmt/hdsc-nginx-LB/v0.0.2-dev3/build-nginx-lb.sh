docker build --tag 192.168.0.196:5000/nginx-lb:0.0.2-dev3 .
docker push 192.168.0.196:5000/nginx-lb:0.0.2-dev3

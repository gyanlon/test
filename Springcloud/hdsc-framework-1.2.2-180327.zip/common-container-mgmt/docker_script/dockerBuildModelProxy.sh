#!/bin/sh
if [ $3 = "origin/poc2bugfix" -o $3 = "origin/build" ]
then
        jar_version="0.2.0-SNAPSHOT"
else
        jar_version="0.3.0-SNAPSHOT"
fi

# target path
target_path=$1

jar_name=$2
#jar_version=0.3.0-SNAPSHOT
cp ${target_path}/${jar_name}-${jar_version}.jar .

ImageName=$2
#ImageVersion=0.3.0

# template Dockerfile 
template_file=/var/lib/jenkins/apps/scp-modelproxy-component-service/Dockerfile

# copy and replace template Dockerfile to this directory
cp ${template_file} .
sed -i 's/$JarName/'$jar_name'-'$jar_version'.jar/g' $(find ./ -name "Dockerfile")

#docker build --tag 192.168.0.196:5000/${ImageName}:${ImageVersion} .
#docker push 192.168.0.196:5000/${ImageName}:${ImageVersion}
if [ $4 = "dev2" -o $4 = "scp-dev2" ]
then
      #  jar_version="0.2.0-SNAPSHOT"
      ImageVersion=0.2.0

      docker build --tag 192.168.0.196:5000/${ImageName}:${ImageVersion} .
      docker push 192.168.0.196:5000/${ImageName}:${ImageVersion}
      # login 242 master  image=0.2.0
      ssh -p 22 root@192.168.0.242 /root/hdsc-apps/hdsc-java/kube-shell/kube-control2.sh $2 ${ImageVersion} 
else
      #  jar_version="0.3.0-SNAPSHOT"
      ImageVersion=0.3.0

      docker build --tag 192.168.0.196:5000/${ImageName}:${ImageVersion} .
      docker push 192.168.0.196:5000/${ImageName}:${ImageVersion}
      # login 161 master  image=0.3.0
      ssh -p 22 root@192.168.0.161 /root/hdsc-apps/hdsc-java/kube-shell/kube-control2.sh $2 ${ImageVersion}
            
fi

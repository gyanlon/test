/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.common.service.mgmt.test;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.eg.egsc.common.component.audit.service.AuditLogService;
import com.eg.egsc.common.service.mgmt.gateway.ZuulServerApplication;
import com.eg.egsc.common.service.mgmt.gateway.filter.AuthFilter;
import com.eg.egsc.common.service.mgmt.gateway.filter.PermissionFilter;
import com.eg.egsc.common.service.mgmt.gateway.filter.PostRoutingFilter;
import com.eg.egsc.common.service.mgmt.gateway.filter.PreRoutingFilter;
import com.eg.egsc.framework.service.auth.service.AuthenticationService;
import com.eg.egsc.framework.service.auth.service.PermissionService;
import com.netflix.zuul.context.RequestContext;

/**
 * JUnit Test ZuulFilter
 * 
 * @author guofeng
 * @since 2018年2月2日
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({RequestContext.class})
public class ZuulFilterTest {
  
  protected final Logger logger = LoggerFactory.getLogger(ZuulFilterTest.class);

  @InjectMocks
  ZuulServerApplication zuulServerApplication;

  @InjectMocks
  PreRoutingFilter preRoutingFilter;

  @InjectMocks
  AuthFilter authFilter;

  @InjectMocks
  PermissionFilter permissionFilter;

  @InjectMocks
  PostRoutingFilter postRoutingFilter;

  @Mock
  AuditLogService auditLogService;

  @Mock
  AuthenticationService authenticationService;

  @Mock
  PermissionService permissionService;

  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
  }

  @Test
  public void zuulServerApplicationTest() {
    logger.info("************test0***************");
    Assert.assertNotNull(zuulServerApplication.corsFilter());
  }

  @Test
  public void preRoutingFilterTest() {
    logger.info("************test1***************");
    mockPreRoutingFilterMethod();
    Assert.assertEquals(preRoutingFilter.run(), null);
  }

  private void mockPreRoutingFilterMethod() {
    HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
    HttpServletResponse response = Mockito.mock(HttpServletResponse.class);
    PowerMockito.mockStatic(RequestContext.class);
    RequestContext requestContext = new RequestContext();
    requestContext.setRequest(request);
    requestContext.setResponse(response);
    Mockito.when(RequestContext.getCurrentContext()).thenReturn(requestContext);
    Mockito.doAnswer(new Answer<Object>() {
      public Object answer(InvocationOnMock invocation) {
        return null;
      }
    }).when(auditLogService).preRoutingFilter(request);
  }

  @Test
  public void authFilterTest1() {
    logger.info("************test2***************");
    mockAuthFilterMethod1();
    Assert.assertEquals(authFilter.run(), null);
  }

  private void mockAuthFilterMethod1() {
    HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
    HttpServletResponse response = Mockito.mock(HttpServletResponse.class);
    PowerMockito.mockStatic(RequestContext.class);
    RequestContext requestContext = new RequestContext();
    requestContext.setRequest(request);
    requestContext.setResponse(response);
    Mockito.when(RequestContext.getCurrentContext()).thenReturn(requestContext);
    Mockito.doAnswer(new Answer<Object>() {
      public Object answer(InvocationOnMock invocation) {
        return true;
      }
    }).when(authenticationService).authenticate(Mockito.any(), Mockito.any());
  }


  @Test
  public void permissionFilterTest1() {
    logger.info("************test3***************");
    mockPermissionFilterMethod1();
    Assert.assertEquals(permissionFilter.run(), null);
  }

  private void mockPermissionFilterMethod1() {
    HttpServletRequest httpRequest = Mockito.mock(HttpServletRequest.class);
    HttpServletResponse httpResponse = Mockito.mock(HttpServletResponse.class);
    PowerMockito.mockStatic(RequestContext.class);
    RequestContext requestContext = new RequestContext();
    requestContext.setRequest(httpRequest);
    requestContext.setResponse(httpResponse);
    Mockito.when(RequestContext.getCurrentContext()).thenReturn(requestContext);
    Mockito.doAnswer(new Answer<Object>() {
      public Object answer(InvocationOnMock invocation) {
        return true;
      }
    }).when(permissionService).hasPermission(Mockito.any(), Mockito.any());
  }

  @Test
  public void postRoutingFilterTest() {
    logger.info("************test4***************");
    mockPostRoutingFilterMethod();
    Assert.assertEquals(postRoutingFilter.run(), null);
  }

  private void mockPostRoutingFilterMethod() {
    HttpServletRequest httpRequest = Mockito.mock(HttpServletRequest.class);
    HttpServletResponse httpResponse = Mockito.mock(HttpServletResponse.class);
    PowerMockito.mockStatic(RequestContext.class);
    RequestContext requestContext = new RequestContext();
    requestContext.setRequest(httpRequest);
    requestContext.setResponse(httpResponse);
    Mockito.when(RequestContext.getCurrentContext()).thenReturn(requestContext);
    Mockito.doAnswer(new Answer<Object>() {
      public Object answer(InvocationOnMock invocation) {
        return "";
      }
    }).when(auditLogService).postRoutingFilter(httpRequest, httpResponse, "", "");
  }

}

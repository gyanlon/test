/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.common.service.mgmt.gateway.filter;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.eg.egsc.common.component.audit.service.AuditLogService;
import com.eg.egsc.common.component.audit.util.AuditUtil;
import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;

/**
 * Log PreFilter
 * 
 * @author guofeng
 * @since 2018年1月29日
 */
@Component
public class PreRoutingFilter extends ZuulFilter {

  private static final Logger logger = LoggerFactory.getLogger(PreRoutingFilter.class);

  private static final String AUTHORIZATION = "Authorization";

  private static final String FRONTTYPE = "FrontType";
  
  private static final String FROMIP = "FromIp";

  @Autowired
  private AuditLogService auditLogService;
  
  @Value("${egsc.config.log.enabled:false}")
  private boolean logEnabled;

  /*
   * (non-Javadoc)
   * 
   * @see com.netflix.zuul.IZuulFilter#run()
   */
  @Override
  public Object run() {
    logger.info("LogPreRoutingFilter start.");
    RequestContext ctx = RequestContext.getCurrentContext();
    HttpServletRequest request = ctx.getRequest();
    logger.info("Authorization: " + request.getHeader(AUTHORIZATION));
    ctx.addZuulRequestHeader(AUTHORIZATION, request.getHeader(AUTHORIZATION));
    logger.info("FrontType: " + request.getHeader(FRONTTYPE));
    ctx.addZuulRequestHeader(FRONTTYPE, request.getHeader(FRONTTYPE));
    logger.info("RequestURL: " + request.getRequestURL());
    logger.info("RemoteAddr: " + AuditUtil.getIpAddr(request));
    logger.info("X-Forwarded-For: " + request.getHeader("X-Forwarded-For"));
    logger.info("X-Real-IP: " + request.getHeader("X-Real-IP"));
    Map<String, String> map = ctx.getZuulRequestHeaders();
    for (String key : map.keySet()) {
      logger.info("header key: " + key + " header value: " + map.get(key));
    }
    ctx.addZuulResponseHeader(FROMIP, AuditUtil.getIpAddr(request));
    ctx.addZuulRequestHeader(FROMIP, AuditUtil.getIpAddr(request));
    if(logEnabled){
      auditLogService.preRoutingFilter(request);
    }
    ctx.setSendZuulResponse(true);
    ctx.setResponseStatusCode(200);
    ctx.set("isSuccess", true);
    logger.info("LogPreRoutingFilter end.");
    return null;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.netflix.zuul.IZuulFilter#shouldFilter()
   */
  @Override
  public boolean shouldFilter() {
    return true;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.netflix.zuul.ZuulFilter#filterOrder()
   */
  @Override
  public int filterOrder() {
    return 1;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.netflix.zuul.ZuulFilter#filterType()
   */
  @Override
  public String filterType() {
    return "pre";
  }
}

/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.demo.job;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.eg.egsc.common.component.auth.web.vo.UserVo;
import com.eg.egsc.common.component.job.model.BusinessJobConfig;
import com.eg.egsc.common.component.job.support.JobService;

/**
 * 
 * @author songjie
 * @since 2018年2月1日
 */
@Component("demoJobService")
public class DemoJobService {
	@Autowired
	private JobService jobService;
	private static final String OUTPRAMJOB = "outPramJob";
	private static final String OUTPARAM = "outParam";
	private static final String CREATEREPORT = "createReport";
	private static final String OUTNOPARAM = "outNoParam";
	
	/**
	 * 创建带参数job：outPramJob.outParam
	 * 必须设置params属性，不能为null
	 */
	public void createOutJob(){
    	BusinessJobConfig jobConfig = new BusinessJobConfig();
    	jobConfig.setServiceName(OUTPRAMJOB);
    	jobConfig.setMethodName(OUTPARAM);
    	jobConfig.setId("outParam001");
    	jobConfig.setCronExpression("*/10 * * * * ?");
    	jobConfig.setStatus("1");
    	jobConfig.setRunAsAdmin(false);
    	
    	Map<String, Object> params = new HashMap<>();
    	params.put("name", "小明");
    	params.put("age", 20);
    	jobConfig.setParams(params);
    	jobService.createJob(jobConfig);
	}
	
	/**
   * 创建带参数job：outPramJob.outParam
   */
	public void createSecondOutJob(){
      BusinessJobConfig jobConfig = new BusinessJobConfig();
      jobConfig.setServiceName(OUTPRAMJOB);
      jobConfig.setMethodName(OUTPARAM);
      jobConfig.setId("outParam002");
      jobConfig.setCronExpression("*/20 * * * * ?");
      jobConfig.setStatus("1");
      jobConfig.setRunAsAdmin(false);
      
      Map<String, Object> params = new HashMap<>();
      params.put("name", "小黄");
      params.put("age", 22);
      jobConfig.setParams(params);
      jobService.createJob(jobConfig);
  }
	
	/**
	 * 创建带参数job：outPramJob.createReport
	 */
	public void createReportJob(){
    	BusinessJobConfig jobConfig = new BusinessJobConfig();
    	jobConfig.setServiceName(OUTPRAMJOB);
    	jobConfig.setMethodName(CREATEREPORT);
    	jobConfig.setId("createReport001");
    	jobConfig.setCronExpression("*/55 * * * * ?");
    	jobConfig.setStatus("1");
    	jobConfig.setRunAsAdmin(false);
    	
    	Map<String, Object> params = new HashMap<>();
    	params.put("reportNme", "年度总结报告");
    	params.put("status", "未发布");
    	
    	UserVo userVo = new UserVo();
    	userVo.setUserName("小王");
    	userVo.setUserId("111333");
    	params.put("userVo", userVo);
    	jobConfig.setParams(params);
    	jobService.createJob(jobConfig);
	}
	
	/**
   * 创建无参数job：outPramJob.outNoParam
   * 不要设置params属性，params为null时会调用无参的方法
   */
	public void createNoParamJob(){
    BusinessJobConfig jobConfig = new BusinessJobConfig();
    jobConfig.setServiceName(OUTPRAMJOB);
    jobConfig.setMethodName(OUTNOPARAM);
    jobConfig.setId("outNoParam001");
    jobConfig.setCronExpression("*/10 * * * * ?");
    jobConfig.setStatus("1");
    jobConfig.setRunAsAdmin(false);
    
    jobService.createJob(jobConfig);
}
}

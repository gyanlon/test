/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.scp.demo.util;

/**
 * 配置异常信息类
 * @author wanghongben
 * @since 2018年1月11日
 */
public class ErrorCodeConstant {

  private ErrorCodeConstant() {
  }
  
  public static final String DEMO_USERMGNT_USER_ID_NOTBLANK = "demo.usermgnt.user.id.notblank";
  
  public static final String DEMO_USERMGNT_FILED_NOTBLANK = "demo.usermgnt.filed.notblank";

}

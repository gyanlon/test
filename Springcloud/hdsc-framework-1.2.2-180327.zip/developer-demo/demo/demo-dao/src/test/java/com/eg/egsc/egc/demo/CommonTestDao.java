/**
 * Copyright 2017-2025 Evergrande Group.
 */

package com.eg.egsc.egc.demo;

import org.junit.runner.RunWith;
import org.mybatis.spring.annotation.MapperScan;
import org.mybatis.spring.boot.autoconfigure.MybatisAutoConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;



/**
 * 
 * Dao 测试基类.
 * 
 * @author wanghb
 * @since 2018年2月25日
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = {DataSourceAutoConfiguration.class, MybatisAutoConfiguration.class})
@ContextConfiguration(classes = DbConfig.class)
@ComponentScan(basePackages = {"com.eg.egsc"})
@MapperScan(basePackages = {"com.eg.egsc.scp.*.mapper"})
public abstract class CommonTestDao {
  protected Logger logger = LoggerFactory.getLogger(this.getClass());

}

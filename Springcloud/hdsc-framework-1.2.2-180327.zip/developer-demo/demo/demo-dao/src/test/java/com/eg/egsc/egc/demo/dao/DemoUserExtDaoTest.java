/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.egc.demo.dao;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.eg.egsc.common.component.utils.JsonUtil;
import com.eg.egsc.egc.demo.CommonTestDao;
import com.eg.egsc.scp.demo.dao.DemoUserExtDao;


/**
 * 测试DAO的功能类
 * @author wanghongben
 * @since 2018年1月11日
 */
public class DemoUserExtDaoTest extends CommonTestDao{
  protected final Logger logger = LoggerFactory.getLogger(this.getClass());

  @Autowired
  private DemoUserExtDao demoUserExtDao;

  /**
   * 测试信息
   * @throws Exception 
   */
  @Test
  public void tsetGetSysCodeAndDescription() {
     JsonUtil.toJsonString(demoUserExtDao.queryForList("4637"));
  } 
}

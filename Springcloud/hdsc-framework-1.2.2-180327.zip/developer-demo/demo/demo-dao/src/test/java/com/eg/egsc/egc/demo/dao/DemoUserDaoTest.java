/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.egc.demo.dao;

import java.util.Date;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.eg.egsc.common.component.utils.JsonUtil;
import com.eg.egsc.egc.demo.CommonTestDao;
import com.eg.egsc.scp.demo.dao.DemoUserDao;
import com.eg.egsc.scp.demo.mapper.entity.DemoUser;

/**
 * 测试日志DAO的功能类
 * @author wanghongben
 * @since 2018年1月11日
 */

public class DemoUserDaoTest extends CommonTestDao{
  protected final Logger logger = LoggerFactory.getLogger(this.getClass());

  @Autowired
  private DemoUserDao demoUserDao;

   
   /**
   * 
   */
  @Test
   public void testGetAllUser() {
    JsonUtil.toJsonString(demoUserDao.getAllUser());
   }
   
   /**
   * 根据name查询
   * @throws  
   */
  @Test
   public void testGetUserByName() {
     String name="locah";
    JsonUtil.toJsonString(demoUserDao.getUserByName(name));
   }
   
   /**
   * 根据url查询日志信息
   * @throws  
   */
  @Test
   public void testQueryOnePageData() {

    JsonUtil.toJsonString(  demoUserDao.getAllUserByRoleId("263"));
   }
  
  /**
   * 根据条件查询
   * @throws  
   */
  @Test
   public void testqueryOnePageDataByCondition() {
    DemoUser user = new DemoUser();
    user.setUserName("TEST");
    user.setCourtUuid("67234");
    user.setCreateTime(new Date());
    user.setCreateUser("wanger");
    user.setUpdateTime(new Date());
    user.setUpdateUser("wandfer");
    user.setUserDesc("21432");
    JsonUtil.toJsonString(  demoUserDao.queryOnePageDataByCondition(1, 2, user));
   }
}

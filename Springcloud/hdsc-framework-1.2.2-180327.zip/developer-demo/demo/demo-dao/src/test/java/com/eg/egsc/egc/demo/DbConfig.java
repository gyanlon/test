/**
 * Copyright 2017-2025 Evergrande Group.
 */
package com.eg.egsc.egc.demo;


import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

/**
 * 
 * 数据库配置文件.
 * 
 * @author wanghb
 * @since 2018年2月25日
 */
@Configuration
public class DbConfig {

  protected Logger logger = LoggerFactory.getLogger(this.getClass());

  @Value("${spring.datasource.type}")
  private String type;

  @Value("${spring.datasource.driverClassName}")
  private String driverClassName;

  @Value("${spring.datasource.url}")
  private String url;

  @Value("${spring.datasource.username}")
  private String username;

  @Value("${spring.datasource.password}")
  private String password;


  @Value("${spring.datasource.name}")
  private String name;


  @Value("${spring.profiles.active}")
  private String profilesActive;

  /**
   * 创建 dataSource
   * 
   * @return DataSource
   */
  @Bean
  public DataSource dataSource() {

    // Create the DataSource with integration-DB properties
    DriverManagerDataSource dataSource = new DriverManagerDataSource();

    dataSource.setDriverClassName(driverClassName);
    dataSource.setUrl(url);
    dataSource.setUsername(username);
    dataSource.setPassword(password);

    logger.info("profilesActive: " + profilesActive);
    logger.info("DataSource: " + url);
    return dataSource;
  }
}

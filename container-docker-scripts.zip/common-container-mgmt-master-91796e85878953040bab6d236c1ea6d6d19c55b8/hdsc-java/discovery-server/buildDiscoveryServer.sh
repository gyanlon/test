docker build --tag 192.168.0.196:5000/discovery-server:1.0.1 .

#!/bin/bash --login
pwd
kubectl get node
kubectl delete -f hdsc-apps/hdsc-web/controller.yaml
kubectl delete -f hdsc-apps/hdsc-web/service.yaml 
sleep 5
kubectl create -f hdsc-apps/hdsc-web/service.yaml
sleep 2
kubectl create -f hdsc-apps/hdsc-web/controller.yaml

'use strict'
module.exports = {
  NODE_ENV: '"production"',
  API_URL: '"http://localhost:8088"'
}

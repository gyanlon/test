// import { login } from '@/views/UserMgmt/login/apis'

export default {
  getWindowHeight (state) {
    return state.windowHeight
  },
  getHeaderStatus: (state) => {
    return state.headerStatus
  },

  getUserInfo: (state) => {
    /*
    if (state.userRouters === undefined || state.userRouters === null) {
      var params = {
        username: '1111'
      }
      login(params).then(
      function (result) {
        console.log(result.data)
      }).catch(
      function (error) {
        console.log(error)
      }
      )
    }
    */
    return state.userinfo
  },
  getUserResourcePermission: (state) => {
    return state.userResourcePermission
  },
  getUserRouters: (state) => {
    return state.userRouters
  }
}

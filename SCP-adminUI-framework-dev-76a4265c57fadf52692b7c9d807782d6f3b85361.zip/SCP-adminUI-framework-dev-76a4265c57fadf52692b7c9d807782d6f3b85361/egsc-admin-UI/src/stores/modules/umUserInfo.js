// import userMockJsonData from '@/assets/js/userMockJsonData.js'
// import * as types from '../mutation-types'

// initial state
const state = {

}

// getters
const getters = {

}

// actions
const actions = {

}

// mutations
const mutations = {

}

export default {
  state,
  getters,
  actions,
  mutations
}

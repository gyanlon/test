// 显示头部
export const SHOW_HEADER = 'SHOW_HEADER'
// 隐藏头部
export const HIDE_HEADER = 'HIDE_HEADER'

// 设置页面高度
export const SET_WINDOWHEIGHT = 'SET_WINDOWHEIGHT'

// 设置用户信息
export const SET_USERINFO = 'SET_USERINFO'

// 设置用户信息按钮权限信息
export const SET_USERRESOURCEPERMISSION = 'SET_USERRESOURCEPERMISSION'

// 设置用户菜单路径信息
export const SET_USERROUTERS = 'SET_USERROUTERS'

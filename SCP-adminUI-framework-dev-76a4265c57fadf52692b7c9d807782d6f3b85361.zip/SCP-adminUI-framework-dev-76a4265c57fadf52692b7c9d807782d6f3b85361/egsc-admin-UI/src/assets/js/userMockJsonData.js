export default {
  'code': '00000',
  'data': {
    'userId': 'test',
    'userName': '测试用户（系统联调用 不能删除）',
    'department': '测试部门',
    'uuid': '1111',
    'status': '1',
    'roles': [{
      'code': '7cddb5646e0e46bab3776b8dd6526688',
      'name': '游客01'
    }, {
      'code': 'c82f03fc35b44e9facd87fb623e5d877',
      'name': '保安员'
    }, {
      'code': '3fe70de36681482eab6cd9f497cf5b14',
      'name': 'testing'
    }, {
      'code': 'f54386e021674634b500453a40075c6e',
      'name': '测试用角色2'
    }, {
      'code': '1cd4881ff9524678908bd2484d048aea',
      'name': '培训2018第2季'
    }, {
      'code': '5d7be440ab21423186d09643e8585e04',
      'name': 'testwjl'
    }, {
      'code': '1e4d7e6e7ca54659a68a74ad07dd264a',
      'name': '访客01'
    }, {
      'code': 'f023810310bb40c6bebdff099375c6ff',
      'name': '系统管理员'
    }, {
      'code': '73895e3d625346d6befbc49bcbbc0232',
      'name': '我的角色'
    }, {
      'code': '32ac2776380f4de9898306d65bc60ce6',
      'name': 'test2018'
    }],
    'uiResources': [{
      'id': '43ea67759d1d4786b69ea3bbd98a2454',
      'title': '首页',
      'menus': [{
        'id': 'home',
        'title': '首页',
        'url': '/home'
      }]
    }, {
      'id': '06e636f3eecd44729cea23d7599b3a65',
      'title': '模型管理',
      'menus': [{
        'id': 'modelmgmt-modelmgmtindex',
        'title': '模型管理',
        'url': '/modelmgmt/modelmgmtindex',
        'submenus': [{
          'id': 'modelmgmt-modelalgorithmmgmt',
          'title': '模型算法管理',
          'url': '/modelmgmt/modelalgorithmmgmt',
          'submenus': [{
            'id': 'modelmgmt-baseinfomgmt',
            'title': '基本信息管理',
            'url': '/modelmgmt/baseinfomgmt'
          }, {
            'id': 'modelmgmt-programfilemgmt',
            'title': '程序文件管理',
            'url': '/modelmgmt/programfilemgmt'
          }, {
            'id': 'modelmgmt-servicemgmt',
            'title': '服务管理',
            'url': '/modelmgmt/servicemgmt'
          }],
          'items': []
        }, {
          'id': 'modelmgmt-modelexcutionmgmt',
          'title': '模型执行管理',
          'url': '/modelmgmt/modelexcutionmgmt',
          'submenus': [{
            'id': 'modelmgmt-planmgmt',
            'title': '计划管理',
            'url': '/modelmgmt/planmgmt'
          }, {
            'id': 'modelmgmt-taskmgmt',
            'title': '任务管理',
            'url': '/modelmgmt/taskmgmt'
          }],
          'items': []
        }, {
          'id': 'modelmgmt-systemmgmt',
          'title': '系统管理',
          'url': '/modelmgmt/systemmgmt',
          'submenus': [{
            'id': 'modelmgmt-metadatamgmt',
            'title': '元数据管理',
            'url': '/modelmgmt/metadatamgmt'
          }, {
            'id': 'modelmgmt-metacatmgmt',
            'title': '元数据分类管理',
            'url': '/modelmgmt/metacatmgmt'
          }, {
            'id': 'modelmgmt-dispatchnodemgmt',
            'title': '调度节点管理',
            'url': '/modelmgmt/dispatchnodemgmt'
          }, {
            'id': 'modelmgmt-calculatenodemgmt',
            'title': '计算节点管理',
            'url': '/modelmgmt/calculatenodemgmt'
          }, {
            'id': 'modelmgmt-datasyncmgmt',
            'title': '数据同步管理',
            'url': '/modelmgmt/datasyncmgmt'
          }],
          'items': []
        }],
        'items': []
      }]
    }, {
      'id': '226312507c564d259662cbdc0eed959b',
      'title': '设备管理',
      'menus': [{
        'id': 'devicemgmt-devicemgmtindex',
        'title': '设备管理',
        'url': '/devicemgmt/devicemgmtindex',
        'submenus': [{
          'id': 'devicemgmt-deviceregister',
          'title': '设备注册管理',
          'url': '/devicemgmt/deviceregister'
        }, {
          'id': 'devicemgmt-devicestatusmonitor',
          'title': '设备状态监控',
          'url': '/devicemgmt/devicestatusmonitor'
        }, {
          'id': 'devicemgmt-deviceparamconfig',
          'title': '设备参数配置',
          'url': '/devicemgmt/deviceparamconfig'
        }, {
          'id': 'devicemgmt-devicefirmwareupdate',
          'title': '设备固件升级',
          'url': '/devicemgmt/devicefirmwareupdate'
        }],
        'items': []
      }]
    }, {
      'id': '4fd7a30a750a4d5ebeaa42be8a23e074',
      'title': '事件应用',
      'menus': [{
        'id': 'safetyappindex-safetyappindex',
        'title': '事件应用',
        'url': '/safetyappindex/safetyappindex',
        'submenus': [{
          'id': 'safetyappindex-linkageresultapp',
          'title': '联动结果管理',
          'url': '/safetyappindex/linkageresultapp'
        }, {
          'id': 'safetyappindex-linkageruleapp',
          'title': '联动规则管理',
          'url': '/safetyappindex/linkageruleapp'
        }, {
          'id': 'safetyappindex-eventlogapp',
          'title': '事件管理',
          'url': '/safetyappindex/eventlogapp'
        }],
        'items': []
      }]
    }, {
      'id': 'aa7044d51b8e4c6ebbd9b4b93754ee30',
      'title': '地图应用',
      'menus': [{
        'id': 'mapapp-mapappindex',
        'title': '地图应用',
        'url': '/mapapp/mapappindex',
        'submenus': [{
          'id': 'mapapp-mapconfig',
          'title': '地图配置',
          'url': '/mapapp/mapconfig'
        }, {
          'id': 'mapapp-scenemanager',
          'title': '地图场景管理',
          'url': '/mapapp/scenemanager'
        }, {
          'id': 'mapapp-businessmanager',
          'title': '业务数据管理',
          'url': '/mapapp/businessmanager'
        }, {
          'id': null,
          'title': '停车场管理',
          'url': '/mapapp/parkingmanager'
        },
        {
          'id': null,
          'title': '电子围栏管理',
          'url': '/mapapp/fencemanager'
        }],
        'items': []
      }]
    }, {
      'id': '91615c406c814eaca5dfc1edbe89fdc4',
      'title': '主数据管理',
      'menus': [{
        'id': 'mdmapp-mdmappindex',
        'title': '主数据管理',
        'url': '/mdmapp/mdmappindex',
        'submenus': [{
          'id': 'mdmapp-orgmanager',
          'title': '组织管理',
          'url': '/mdmapp/orgmanager'
        }, {
          'id': 'mdmapp-housemanager',
          'title': '房屋管理',
          'url': '/mdmapp/housemanager'
        }, {
          'id': 'mdmapp-personmanager',
          'title': '人员管理',
          'url': '/mdmapp/personmanager'
        }],
        'items': []
      }]
    }, {
      'id': '8e8c904eb32e43199f4ba575e75dfc4f',
      'title': '个性化广播',
      'menus': [{
        'id': 'broadcastapp-broadcastappindex',
        'title': '个性化广播',
        'url': '/broadcastapp/broadcastappindex',
        'submenus': [{
          'id': 'broadcastapp-audiomanager',
          'title': '音频管理',
          'url': '/broadcastapp/audiomanager'
        }, {
          'id': 'broadcastapp-sceneManager',
          'title': '场景管理',
          'url': '/broadcastapp/sceneManager'
        }, {
          'id': 'broadcastapp-regulartask',
          'title': '定时任务',
          'url': '/broadcastapp/regulartask'
        }, {
          'id': 'broadcastapp-actualtask',
          'title': '即时任务',
          'url': '/broadcastapp/actualtask'
        }],
        'items': []
      }]
    }, {
      'id': '488b34db5c964b2eaffd32ab7de6cd17',
      'title': '访客管理',
      'menus': [{
        'id': 'visitorapp-visitorappindex',
        'title': '访客管理',
        'url': '/visitorapp/visitorappindex',
        'submenus': [{
          'id': 'visitorapp-visitorapp',
          'title': '访客管理',
          'url': '/visitorapp/visitorapp'
        }, {
          id: null,
          title: '物业管理',
          url: '/visitorapp/propertyapp'
        }],
        'items': []
      }]
    }, {
      'id': '697ae6bd03234cdbbe6965662e9e3495',
      'title': '门禁应用',
      'menus': [{
        'id': 'accesscontrolapp-accesscontropindex',
        'title': '门禁应用',
        'url': '/accesscontrolapp/accesscontropindex',
        'submenus': [{
          'id': 'accesscontrolapp-devicegroupmgmt',
          'title': '设备组管理',
          'url': '/accesscontrolapp/deviceGroupMgmt'
        }, {
          'id': 'accesscontrolapp-auth',
          'title': '门禁权限管理',
          'url': '/accesscontrolapp/auth'
        }],
        'items': []
      }]
    }, {
      'id': '958c4ae1ae5640db8ea625c015aa01ed',
      'title': '信息展示应用',
      'menus': [{
        'id': 'infoapp-infoappindex',
        'title': '信息展示应用',
        'url': '/infoapp/infoappindex',
        'submenus': [{
          'id': 'infoappindex-materialapp',
          'title': '素材管理',
          'url': '/infoappindex/materialapp'
        }, {
          'id': 'infoappindex-programapp',
          'title': '节目管理',
          'url': '/infoappindex/programapp'
        }, {
          'id': 'infoappindex-scheduleapp',
          'title': '日程管理',
          'url': '/infoappindex/scheduleapp'
        }],
        'items': []
      }]
    }, {
      'id': 'df7862531cf04ae3a7b25761aa7b54b1',
      'title': '视频应用',
      'menus': [{
        'id': 'videogatewayapp-videogatewayindex',
        'title': '视频应用',
        'url': '/videogatewayapp/videogatewayindex',
        'submenus': [{
          'id': 'videogatewayapp-videooption',
          'title': '视频参数配置',
          'url': '/videogatewayapp/videooption'
        }, {
          'id': 'videogatewayapp-videotapetemplate',
          'title': '录像计划模板配置',
          'url': '/videogatewayapp/videotapetemplate'
        }, {
          'id': 'videogatewayapp-videotapeplan',
          'title': '录像计划配置',
          'url': '/videogatewayapp/videotapeplan'
        }, {
          'id': 'videogatewayapp-customgroup',
          'title': '自定义分组',
          'url': '/videogatewayapp/customgroup'
        }, {
          'id': 'videogatewayapp-videodevice',
          'title': '视频设备管理',
          'url': '/videogatewayapp/videodevice'
        }, {
          'id': 'videogatewayapp-videoservice',
          'title': '流媒体服务管理',
          'url': '/videogatewayapp/videoservice'
        }],
        'items': []
      }]
    }, {
      'id': 'af697b6a0398440595595548af4a474c',
      'title': '梯控应用',
      'menus': [{
        'id': 'laddercontrolapp-ladderappindex',
        'title': '梯控应用',
        'url': '/laddercontrolapp/ladderappindex',
        'submenus': [{
          'id': '',
          'icon': null,
          'url': '/ladderappindex/authapp',
          'title': '权限管理'
        },
        {
          'id': '',
          'icon': null,
          'url': '/ladderappindex/eventapp',
          'title': '事件管理'
        }]
      }]
    }, {
      'id': '4ee2a74f8480445880791772f168ad55',
      'title': '卡片管理',
      'menus': [{
        'id': '10',
        'title': '卡片管理',
        'url': '10',
        'submenus': [{
          'id': 'CardMgmtAppIndex',
          'title': '卡片管理',
          'url': '/CardMgmtAppIndex',
          'submenus': [{
            'id': 'CardMgmtAppIndex-queryCard',
            'title': '卡片入库',
            'url': '/CardMgmtAppIndex/storeCard'
          }, {
            'id': 'CardMgmtAppIndex-storeCard',
            'title': '卡片查询',
            'url': '/CardMgmtAppIndex/queryCard'
          }],
          'items': []
        }, {
          'id': 'QrCodeMgmtIndex',
          'title': '二维码管理',
          'url': '/QrCodeMgmtIndex',
          'submenus': [{
            'id': 'QrCodeMgmtIndex-qrCodeQuery',
            'title': '二维码查询',
            'url': '/QrCodeMgmtIndex/qrCodeQuery'
          }],
          'items': []
        }],
        'items': []
      }]
    }, {
      'id': 'a50a6d5a3137435287dd990261d66a1c',
      'title': '物联网总线',
      'menus': [{
        'id': 'iotbusmgmt-iotbusmgmtindex',
        'title': '物联网总线',
        'url': '/iotbusmgmt/iotbusmgmtindex',
        'submenus': [{
          'id': 'iotbusmgmt-appmgmt',
          'title': '应用管理',
          'url': '/iotbusmgmt/appmgmt'
        }, {
          'id': 'iotbusmgmt-eventgroupmgmt',
          'title': '事件组管理',
          'url': '/iotbusmgmt/eventgroupmgmt'
        }, {
          'id': 'iotbusmgmt-submgmt',
          'title': '订阅管理',
          'url': '/iotbusmgmt/submgmt'
        }],
        'items': []
      }]
    }, {
      'id': 'acb4bf6e99d14295869af9d9b5c0f579',
      'title': '系统管理',
      'menus': [{
        'id': '13',
        'title': '系统管理',
        'url': '13',
        'submenus': [{
          'id': 'usermgmt-userauthmgmt',
          'title': '用户权限管理',
          'url': '/usermgmt/userauthmgmt',
          'submenus': [{
            'id': 'usermgmt-usermanagement-user',
            'title': '用户管理',
            'url': '/usermgmt/usermanagement/user'
          }, {
            'id': 'usermgmt-usermanagement-department',
            'title': '部门管理',
            'url': '/usermgmt/usermanagement/department'
          }, {
            'id': 'usermgmt-usermanagement-userGroup',
            'title': '用户组管理',
            'url': '/usermgmt/usermanagement/userGroup'
          }, {
            'id': 'usermgmt-usermanagement-role',
            'title': '角色管理',
            'url': '/usermgmt/usermanagement/role'
          }, {
            'id': 'usermgmt-usermanagement-resource',
            'title': '资源管理',
            'url': '/usermgmt/usermanagement/resource'
          }
            //   , {
            //   'id': null,
            //   'title': '修改密码',
            //   'url': '/usermgmt/pwdedit',
            // }
          ],
          'items': []
        },
        {
          'id': '12',
          'title': '短信网关',
          'url': '12',
          'submenus': [
            {
              'id': null,
              'title': '发送短信',
              'url': '/ismgapp/sendsms'
            }, {
              'id': null,
              'title': '发送历史记录查询',
              'url': '/ismgapp/searchsms'
            }]
        },
        {
          'id': '10',
          'title': '日志管理',
          'url': '10',
          'submenus': [{
            'id': 'logservicecomponent-logserviceindex',
            'title': '日志管理',
            'url': '/logservicecomponent/logserviceindex'
          }],
          'items': []
        }, {
          'id': '18',
          'title': '示例',
          'url': '10',
          'submenus': [
            {
              'id': null,
              'title': '示例',
              'url': '/viewdemo/index'
            },
            {
              'id': null,
              'title': '示例1',
              'url': '/viewdemo/index1'
            },
            {
              'id': null,
              'title': '示例2',
              'url': '/viewdemo/index2',
              'items': ['um_index2_btn1', 'um_index2_btn2']
            }
          ],
          'items': []
        }],
        'items': []
      }]
    }],
    'token': 'eyJhbGciOiJSUzUxMiJ9.eyJzdWIiOiJ0ZXN0IiwiZXhwIjoxNTE2Nzc2NzM4fQ.YhzIOLnjXqfbrPR6f8bAIWaqG5QZwrSjn2HeMhwzp--WOt0EWfW_IW550xBZw2NSPuk4QNX51_6j8nSdCpt7HjFQDTX2InaaDtaeD14gTRiNglNpdoHqF9uDs83LdpaHNKtI2SS8Ks2qB5DSlfXGcE3sDJ2c5Pby-TmEzohdifM'
  },
  'message': ''
}

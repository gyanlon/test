# demo 示例

#示例页面，可以删除，如删除则需要将相关的关联删除，目前首页有引用
# src/views/demo/index.vue
# src/views/demo/index1.vue
# src/views/demo/index2.vue

# demo示例的apis配置src/views/demo/apis/index.js

# demo示例的mock配置src/views/demo/mocks/mock.js

# demo示例的路由配置 src/views/demo/routers/index.js
 
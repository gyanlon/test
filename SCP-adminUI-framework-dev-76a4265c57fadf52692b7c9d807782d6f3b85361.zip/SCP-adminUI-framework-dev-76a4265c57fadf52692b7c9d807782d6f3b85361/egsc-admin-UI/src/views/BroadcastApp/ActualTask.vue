<template>
  <div class="container">
    <div class="hbar clearfix">
      <el-button class="addAudio" type="primary" @click="addAudio">添加</el-button>
      <el-button class="addAudio" type="danger" @click="delBatchTask">批量删除</el-button>
      <add-actual-task ref="addAudio" @reflushData="getTaskData"></add-actual-task>
      <div class="searchBar">
        <el-input placeholder="按即时任务名称模糊查询" :maxlength="20" prefix-icon="el-icon-search" v-model="searchKey" class="audioSearch" @keyup.enter.native="updateList()">
        </el-input>
      </div>
    </div>

    <el-table class="audioTable" :data="tableData" height="100%" stripe border header-cell-class-name="text-align-center" @selection-change="handleSelectionChange" style="width: 100%;">
      <el-table-column fixed="left" v-if="hasSelect" type="selection" width="55">
      </el-table-column>
      <el-table-column label="任务名称" prop="broadcastName">
      </el-table-column>
      <el-table-column label="重复次数" prop="repetitions">
      </el-table-column>
      <el-table-column label="任务等级" prop="taskLevel">
      </el-table-column>
      <el-table-column fixed="right" label="操作" width="250">
        <template slot-scope="scope">
          <el-button class="controlBtn" type="primary" size="mini" @click="playAudio(scope.row)" :disabled="scope.row.playBtnState">播放</el-button>
          <el-button class="controlBtn" type="primary" size="mini" @click="pauseAudio(scope.row)" :disabled="scope.row.pauseBtnState">暂停</el-button>
          <el-button class="controlBtn" type="primary" size="mini" @click="stopAudio(scope.row)" :disabled="scope.row.stopBtnState">停止</el-button>
          <el-button class="controlBtn addAudio" type="danger" size="mini" @click="taskDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination class="pageBar" @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage" :total="total" :page-sizes="pageSizes" :page-size="pageSize" layout="total,sizes,prev,pager,next,jumper">
    </el-pagination>
  </div>
</template>

<script>
import AddActualTask from './components/AddActualTask'
import { getRealtimeList, delRealtimeTask, playRealtimeTask, pauseRealtimeTask } from '@/views/BroadcastApp/apis/index.js'
export default {
  components: {
    AddActualTask
  },
  data () {
    return {
      broadcastType: 0,
      searchKey: '',
      pageNo: 1,
      pageSize: 10,
      currentPage: 1,
      tableData: [],
      selections: [],
      total: 0,
      pageSizes: [10, 20, 30, 40, 50],
      hasSelect: {
        default: false,
        type: Boolean
      },
      playFlag: 0,
      tableLoading: ''
    }
  },
  mounted: function () {
    this.getTaskData()
  },
  methods: {
    getTaskData: function (params = {}) {
      let condition = {}
      condition.pageNo = this.currentPage
      condition.pageSize = this.pageSize
      condition.searchKey = this.searchKey
      condition.broadcastType = this.broadcastType
      this.tableLoading = true
      getRealtimeList(Object.assign({}, condition))
        .then(res => {
          this.tableLoading = true
          if (res.data.code === '00000') {
            let TableD = res.data.data.broadcast
            TableD.map(function (item, index, arr) {
              item.playBtnState = false
              item.pauseBtnState = true
              item.stopBtnState = true
              item.operation = 3
            }, this)
            this.tableData = TableD
            this.total = res.data.data.total
            this.tableLoading = false
          }
        }).catch(err => {
          console.warn(err)
          this.tableLoading = false
        })
    },
    updateList: function () {
      this.getTaskData()
    },
    addAudio: function () {
      this.$refs['addAudio'].openDialog()
    },
    playAudio: function (params) {
      // console.log(params.operation)
      if (params.operation === 3) {
        // params.operation = 3 // 首次播放
        params.playBtnState = true
      } else if (params.operation === 2) {
        params.operation = 2 // 恢复播放
        params.playBtnState = true
        // console.log(params.operation)
      }
      let paramsT = {}
      paramsT.operation = params.operation
      paramsT.playAreaIds = []
      paramsT.playAreaIds = params.bcArLink.playAreaId.split(',')
      paramsT.broadcastId = params.broadcastId
      paramsT.broadcastType = params.broadcastType
      paramsT.recovery = 1
      // console.log(paramsT)
      if (params.playBtnState === true && paramsT.playAreaIds.length > 0) {
        playRealtimeTask(Object.assign({}, paramsT)).then(res => {
          if (res.data.code === '00000') {
            this.$message({
              type: 'success',
              message: res.data.message
            })
            params.operation = 1
            params.playBtnState = true
            params.pauseBtnState = false
            params.stopBtnState = false
            // console.log(params.playState)
          } else if (res.data.code === '00001') {
            this.$message({
              type: 'warning',
              message: res.data.message
            })
            params.playBtnState = false
          }
        }).catch(err => {
          console.warn(err)
        })
      }
    },
    pauseAudio: function (params) {
      let paramsT = {}
      paramsT.operation = 1
      paramsT.playAreaIds = []
      paramsT.playAreaIds = params.bcArLink.playAreaId.split(',')
      paramsT.broadcastId = params.broadcastId
      paramsT.broadcastType = params.broadcastType
      paramsT.recovery = 1
      pauseRealtimeTask(Object.assign({}, paramsT)).then(res => {
        if (res.data.code === '00000') {
          this.$message({
            type: 'success',
            message: res.data.message
          })
          params.playBtnState = false
          params.pauseBtnState = true
          params.stopBtnState = false
          params.operation = 2
          // console.log(params.playState)
        } else if (res.data.code === '00001') {
          this.$message({
            type: 'warning',
            message: res.data.message
          })
          params.pauseBtnState = false
        }
      }).catch(err => {
        console.warn(err)
      })
    },
    stopAudio: function (params) {
      if (params.operation !== 3) {
        let paramsT = {}
        paramsT.operation = 0
        paramsT.playAreaIds = []
        paramsT.playAreaIds = params.bcArLink.playAreaId.split(',')
        paramsT.broadcastId = params.broadcastId
        paramsT.broadcastType = params.broadcastType
        paramsT.recovery = 1
        playRealtimeTask(Object.assign({}, paramsT)).then(res => {
          if (res.data.code === '00000') {
            this.$message({
              type: 'success',
              message: res.data.message
            })
            params.operation = 3
            params.playBtnState = false
            params.pauseBtnState = true
            params.stopBtnState = true
            // console.log(params.playState)
          } else if (res.data.code === '00001') {
            this.$message({
              type: 'warning',
              message: res.data.message
            })
            params.playState = false
          }
        }).catch(err => {
          console.warn(err)
        })
      }
    },
    /**
     * @description 点击table组件复选框触发
     * @param Array val 所有选中行数据
     */
    handleSelectionChange: function (val) {
      this.selections = val
    },
    taskDelete: function (params = {}) {
      this.$confirm('确定要刪除吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
        dangerouslyUseHTMLString: true
      }).then(() => {
        delRealtimeTask(Object.assign({}, { 'broadcastIds': [params.broadcastId], 'broadcastType': 0 })).then(res => {
          if (res.data.code === '00000') {
            // this.deleteTableData([params.broadcastId])
            this.getTaskData()
          }
          this.$message({
            message: res.data.message,
            type: 'success'
          })
        }).catch(err => {
          console.warn(err)
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    /**
 * @description 删除数据成功后，更新列表显示
 * @param Array params 要删除的数据id集合
 */
    deleteTableData: function (params = []) {
      for (let i = 0, len = this.tableData.length; i < len; i++) {
        let k = params.indexOf(this.tableData[i].broadcastId)
        if (k !== -1) {
          params.splice(k, 1)
          this.tableData.splice(i, 1)
          if (params.length === 0) break
          i--
        }
      }
      this.total -= params.length
    },
    /**
     * 分页栏：切换页码
     */
    handleCurrentChange: function (params) {
      this.currentPage = params
      this.getTaskData()
    },
    /**
     * 分页栏：改变每页显示条数
     */
    handleSizeChange: function (params) {
      this.pageSize = params
      this.currentPage = 1
      this.getTaskData()
    },
    /**
     * 批量删除表格数据
     */
    delBatchTask: function (params) {
      if (this.selections.length <= 0) {
        this.$message({
          message: '请至少选择一项！',
          type: 'warning'
        })
        return
      }
      let str = ''
      let keys = []
      for (let i = 0, len = this.selections.length; i < len; i++) {
        if (this.selections[i].broadcastName && i < 3) {
          str += this.selections[i].broadcastName
          if (i < len - 1 && i < 2) {
            str += ','
          }
        }
        keys.push(this.selections[i].broadcastId)
      }
      str = this.selections.length > 3 ? (str + '等') : str
      this.$confirm('确定要刪除 ' + str + ' 的即时广播任务吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
        dangerouslyUseHTMLString: true
      }).then(() => {
        // 在此处调用批量删除的接口
        delRealtimeTask({ 'broadcastIds': keys, 'broadcastType': 0 })
          .then(res => {
            if (res.data.code === '00000') {
              this.getTaskData()
            }
            this.$message({
              message: res.data.message,
              type: 'success'
            })
          }).catch(err => {
            console.warn(err)
          })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.clearfix:before,
.clearfix:after {
  content: "";
  display: table;
  clear: both;
}
.clearfix {
  zoom: 1;
}
.container {
  border: 1px solid #ccc;
  width: 100%;
  height: 100%;
  min-height: 800px;
  padding: 15px;
  box-sizing: border-box;
}
.searchBar {
  float: right;
}
.audioSearch {
  width: 200px;
}
.audioTable {
  height: 600px;
  margin-top: 15px;
}
.controlBtn {
  padding: 7px 7px;
  margin-left: 4px;
}
.pageBar {
  padding: 0;
  margin-top: 10px;
  text-align: right;
}
</style>

<template>
  <div class="container">
    <div class="hbar clearfix">
      <el-button class="addAudio" type="primary" @click="addAudio">添加</el-button>
      <el-button class="addAudio" type="danger" @click="delBatchTask">批量删除</el-button>
      <add-regular-task ref="addRegularTask" @reflushData="getTaskData"></add-regular-task>
      <div class="searchBar">
        <el-input placeholder="按定时任务名称模糊查询" :maxlength="20" prefix-icon="el-icon-search" v-model="searchKey" class="audioSearch" @keyup.enter.native="updateList">
        </el-input>
      </div>
    </div>

    <el-table class="audioTable" :data="tableData" height="100%" stripe border header-cell-class-name="text-align-center" @selection-change="handleSelectionChange" style="width: 100%;">
      <el-table-column fixed="left" v-if="hasSelect" type="selection" width="55">
      </el-table-column>
      <el-table-column label="任务名称" prop="broadcastName">
      </el-table-column>
      <el-table-column label="启动时间" prop="dailyStartTime">
      </el-table-column>
      <el-table-column label="终止时间" prop="dailyEndTime">
      </el-table-column>
      <el-table-column label="重复次数" prop="repetitions">
      </el-table-column>
      <el-table-column label="任务等级" prop="taskLevel">
      </el-table-column>
      <el-table-column fixed="right" label="操作" width="150">
        <template slot-scope="scope">
          <el-button class="controlBtn addAudio" type="danger" @click="taskDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination class="pageBar" @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage" :total="total" :page-sizes="pageSizes" :page-size="pageSize" layout="total,sizes,prev,pager,next,jumper">
    </el-pagination>
  </div>
</template>

<script>
import AddRegularTask from './components/AddRegularTask'
import { getTimingList, delTimingTask } from '@/views/BroadcastApp/apis/index.js'
export default {
  components: {
    AddRegularTask
  },
  data () {
    return {
      searchKey: '',
      broadcastType: 1,
      tableData: [],
      selections: [],
      total: 10,
      currentPage: 1,
      pageSize: 10,
      pageSizes: [10, 20, 30, 40, 50],
      hasSelect: {
        default: false,
        type: Boolean
      },
      tableLoading: ''
    }
  },
  mounted: function () {
    this.getTaskData()
  },
  methods: {
    getTaskData: function (params = {}) {
      let condition = {}
      condition.pageNo = this.currentPage
      condition.pageSize = this.pageSize
      condition.searchKey = this.searchKey
      condition.broadcastType = this.broadcastType
      this.tableLoading = true
      getTimingList(Object.assign({}, condition, params))
        .then(res => {
          if (res.data.code === '00000') {
            // this.tableData = res.data.data.broadcast
            let tableD = res.data.data.broadcast
            this.total = res.data.data.total
            tableD.map(function (item, index, arr) {
              if (typeof item.dailyStartTime === 'string') {
                item.dailyStartTime = item.dailyStartTime.substr(11, 8)
              }
              if (typeof item.dailyEndTime === 'string') {
                item.dailyEndTime = item.dailyEndTime.substr(11, 8)
              }
            })
            /* this.$message({
              message: 'success',
              type: 'success'
            }) */
            this.tableData = tableD
            this.tableLoading = false
          }
        }).catch(err => {
          console.warn(err)
          this.tableLoading = false
        })
    },
    updateList: function () {
      this.getTaskData()
    },
    addAudio: function () {
      this.$refs['addRegularTask'].openDialog()
    },
    /**
     * @description 点击table组件复选框触发
     * @param Array val 所有选中行数据
     */
    handleSelectionChange: function (val) {
      this.selections = val
    },
    taskDelete: function (params = {}) {
      this.$confirm('确定要刪除吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
        dangerouslyUseHTMLString: true
      }).then(() => {
        delTimingTask({ 'broadcastIds': [params.broadcastId], 'broadcastType': 1 }).then(res => {
          let tiptype = 'warning'
          if (res.data.code === '00000') {
            tiptype = 'success'
            // this.deleteTableData([params.broadcastId])
            this.getTaskData()
          }
          this.$message({
            message: res.data.message,
            type: tiptype
          })
        }).catch(err => {
          console.warn(err)
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    /**
     * 分页栏：切换页码
     */
    handleCurrentChange: function (params) {
      this.currentPage = params
      this.getTaskData()
    },
    /**
     * 分页栏：改变每页显示条数
     */
    handleSizeChange: function (params) {
      this.pageSize = params
      this.currentPage = 1
      this.getTaskData()
    },
    /*
    * @description 删除数据成功后，更新列表显示
    * @param Array params 要删除的数据id集合
    */
    deleteTableData: function (params = []) {
      for (let i = 0, len = this.tableData.length; i < len; i++) {
        let k = params.indexOf(this.tableData[i].broadcastId)
        if (k !== -1) {
          params.splice(k, 1)
          this.tableData.splice(i, 1)
          if (params.length === 0) break
          i--
        }
      }
      this.total -= params.length
    },
    /**
     * 批量删除表格数据
     */
    delBatchTask: function (params) {
      if (this.selections.length <= 0) {
        this.$message({
          message: '请至少选择一项！',
          type: 'warning'
        })
        return
      }
      let str = ''
      let keys = []
      for (let i = 0, len = this.selections.length; i < len; i++) {
        if (this.selections[i].broadcastName && i < 3) {
          str += this.selections[i].broadcastName
          if (i < len - 1 && i < 2) {
            str += ','
          }
        }
        keys.push(this.selections[i].broadcastId)
      }
      str = this.selections.length > 3 ? (str + '等') : str
      this.$confirm('确定要刪除 ' + str + ' 的定时广播任务吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
        dangerouslyUseHTMLString: true
      }).then(() => {
        // 在此处调用批量删除的接口
        delTimingTask({ 'broadcastIds': keys, 'broadcastType': 1 })
          .then(res => {
            let tiptype = 'warning'
            if (res.data.code === '00000') {
              tiptype = 'success'
              /* if (keys.length === this.tableData.length) {
                this.tableData = []
                this.getTaskData()
              } else {
                this.deleteTableData(keys)
              } */
              this.getTaskData()
            }
            this.$message({
              message: res.data.message,
              type: tiptype
            })
          }).catch(err => {
            console.warn(err)
          })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.clearfix:before,
.clearfix:after {
  content: "";
  display: table;
  clear: both;
}
.clearfix {
  zoom: 1;
}
.container {
  border: 1px solid #ccc;
  width: 100%;
  height: 100%;
  min-height: 800px;
  padding: 15px;
  box-sizing: border-box;
}
.searchBar {
  float: right;
}
.audioSearch {
  width: 200px;
}
.audioTable {
  height: 600px;
  margin-top: 15px;
}
.controlBtn {
  padding: 7px 7px;
  margin-left: 4px;
}
.pageBar {
  padding: 0;
  margin-top: 10px;
  text-align: right;
}
</style>

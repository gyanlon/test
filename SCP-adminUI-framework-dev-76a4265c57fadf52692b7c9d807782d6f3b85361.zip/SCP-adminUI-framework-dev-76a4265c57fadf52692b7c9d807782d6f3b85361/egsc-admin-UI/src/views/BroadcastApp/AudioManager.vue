<template>
  <div class="container addAudioCon">
    <div class="hbar clearfix">
      <el-button class="addAudio" type="primary" @click="addAudio">添加</el-button>
      <el-button class="addAudio" type="danger" @click="delBatchAudio">批量删除</el-button>
      <add-mutip-audio ref="addAudio" @addAudioSucc="updateList"></add-mutip-audio>
      <div class="searchBar">
        <el-input placeholder="按音频名称模糊查询" :maxlength="20" prefix-icon="el-icon-search" v-model="searchKey" @keyup.enter.native="updateList" class="audioSearch">
        </el-input>
      </div>
    </div>

    <el-table class="audioTable" :data="tableData" height="100%" stripe border header-cell-class-name="text-align-center" @selection-change="handleSelectionChange" style="width: 100%;">
      <el-table-column fixed="left" v-if="hasSelect" type="selection" width="55">
      </el-table-column>
      <el-table-column label="音频名称" prop="audioClipName">
      </el-table-column>
      <el-table-column label="文件格式" prop="audioClipFormat">
      </el-table-column>
      <el-table-column label="创建日期" prop="createTime">
      </el-table-column>
      <el-table-column fixed="right" label="操作" width="150">
        <template slot-scope="scope">
          <el-button class="controlBtn addAudio" type="danger" @click="audioDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination class="pageBar" @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage" :total="total" :page-sizes="pageSizes" :page-size="pageSize" layout="total,sizes,prev,pager,next,jumper">
    </el-pagination>
  </div>
</template>

<script>
import AddMutipAudio from './components/AddMutipAudio'
import { getAudioList, delMutipAudioClip } from '@/views/BroadcastApp/apis/index.js'
export default {
  components: {
    AddMutipAudio
  },
  data () {
    return {
      searchKey: '',
      tableData: [],
      selections: [],
      total: 0,
      currentPage: 1,
      pageSize: 10,
      pageSizes: [10, 20, 30, 40, 50],
      hasSelect: {
        default: false,
        type: Boolean
      },
      tableLoading: false
    }
  },
  mounted: function () {
    this.getData()
  },
  methods: {
    addAudio: function () {
      this.$refs['addAudio'].openDialog()
    },
    updateList: function () {
      this.getData()
    },
    /**
     * 获取音频列表数据
     */
    getData: function (params = {}) {
      let condition = {}
      condition.pageNo = this.currentPage
      condition.pageSize = this.pageSize
      condition.searchKey = this.searchKey
      this.tableLoading = true
      getAudioList(Object.assign({}, condition, params))
        .then(res => {
          if (res.data.code === '00000') {
            let tableD = res.data.data.audioClip
            /* tableD.map(function (item, index, arr) {
              let d = new Date(item.createTime)
              item.createTime = d.toLocaleString()
            }, this) */
            this.tableData = tableD
            this.total = res.data.data.total
            this.tableLoading = false
            /* this.$message({
              message: res.data.message,
              type: 'success'
            }) */
          }
        }).catch(err => {
          console.warn(err)
          this.tableLoading = false
        })
      this.tableLoading = false
    },
    /**
     * @description 点击table组件复选框触发
     * @param Array val 所有选中行数据
     */
    handleSelectionChange: function (val) {
      this.selections = val
    },
    audioDelete: function (params = {}) {
      this.$confirm('确定要刪除吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
        dangerouslyUseHTMLString: true
      }).then(() => {
        delMutipAudioClip({ 'ids': [params.audioClipId] })
          .then(res => {
            if (res.data.code === '00000') {
              // this.deleteTableData([params.audioClipId])
              this.updateList()
            }
            this.$message({
              message: res.data.message,
              type: 'success'
            })
          }).catch(err => {
            console.warn(err)
          })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    /**
     * @description 分页组件当前页变化
     * @param Number val 选择当前页的值
     */
    handleCurrentChange: function (params) {
      this.currentPage = params
      this.getData()
    },
    /**
     * @description 分页组件单页总数变化
     * @param Number val 选择的单页总数得值
     */
    handleSizeChange: function (params) {
      this.pageSize = params
      this.currentPage = 1
      this.getData()
    },
    /**
     * 批量删除表格数据
     */
    delBatchAudio: function (params) {
      if (this.selections.length <= 0) {
        this.$message({
          message: '请至少选择一项！',
          type: 'warning'
        })
        return
      }
      let str = ''
      let keys = []
      for (let i = 0, len = this.selections.length; i < len; i++) {
        if (this.selections[i].audioClipName && i < 3) {
          str += this.selections[i].audioClipName
          if (i < len - 1 && i < 2) {
            str += ','
          }
        }
        keys.push(this.selections[i].audioClipId)
      }
      str = this.selections.length > 3 ? (str + '等') : str
      this.$confirm('确定要刪除 "' + str + '" 的广播音频吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
        dangerouslyUseHTMLString: true
      }).then(() => {
        // 在此处调用批量删除的接口
        delMutipAudioClip({ 'ids': keys })
          .then(res => {
            let tiptype = 'warning'
            if (res.data.code === '00000') {
              tiptype = 'success'
              /* if (keys.length === this.tableData.length) {
                this.tableData = []
                this.getData()
              } else {
                this.deleteTableData(keys)
              } */
              this.updateList()
            }
            this.$message({
              message: res.data.message,
              type: tiptype
            })
          }).catch(err => {
            console.warn(err)
          })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    /**
     * @description 删除数据成功后，更新列表显示
     * @param Array params 要删除的数据id集合
     */
    deleteTableData: function (params = []) {
      for (let i = 0, len = this.tableData.length; i < len; i++) {
        let k = params.indexOf(this.tableData[i].audioClipId)
        if (k !== -1) {
          params.splice(k, 1)
          this.tableData.splice(i, 1)
          if (params.length === 0) break
          i--
        }
      }
      this.total -= params.length
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="less" scoped>
.clearfix:before,
.clearfix:after {
  content: "";
  display: table;
  clear: both;
}
.clearfix {
  zoom: 1;
}
.container {
  border: 1px solid #ccc;
  width: 100%;
  height: 100%;
  min-height: 800px;
  padding: 15px;
  box-sizing: border-box;
}
.searchBar {
  float: right;
}
.audioSearch {
  width: 200px;
}
.audioTable {
  height: 600px;
  margin-top: 15px;
}
.controlBtn {
  padding: 7px 7px;
  margin-left: 4px;
}
.pageBar {
  padding: 0;
  margin-top: 10px;
  text-align: center;
}
.hbar {
  /deep/.addAudioCon {
    .el-upload--text {
      width: 120px;
      height: 45px;
      border: none;
    }
    .el-upload-list__item-name {
      height: 30px;
      line-height: 30px;
    }
    .el-button--small {
      padding: 15px 25px;
    }
  }
}
</style>

import { getDevicesList } from '@/views/BroadcastApp/apis/index.js'

export function listDeviceList () {
  let params = {
    // 'listDeviceTypeCode': ['2019']
    deviceType: 2019
  }
  let idx = 0
  let subIdx = 0
  let treeD = []
  getDevicesList(Object.assign({}, params))
    .then(res => {
      if (res.data.code === '00000') {
        let devcList = res.data.data.deviceList
        devcList.map(function (item, index, arr) {
          if (item.subDeviceList.length > 0) {
            treeD[idx] = {}
            treeD[idx].label = item.deviceName
            treeD[idx].id = item.deviceID
            treeD[idx].children = []
            item.subDeviceList.map(function (cur, _idx, arr) {
              if (cur.subDeviceInstallAddress !== null && cur.subDeviceInstallAddress !== '') {
                treeD[idx].children[subIdx] = {}
                treeD[idx].children[subIdx].subDeviceInstallAddress = cur.subDeviceInstallAddress
                treeD[idx].children[subIdx].id = cur.subDeviceID
                // treeD[idx].children[subIdx].label = cur.subOrgName
                treeD[idx].children[subIdx].label = cur.subDeviceName
                treeD[idx].children[subIdx].parentId = item.deviceID
                subIdx = subIdx + 1
                if (_idx === arr.length - 1) {
                  subIdx = 0
                }
              } else {
                if (_idx === arr.length - 1) {
                  subIdx = 0
                }
              }
            })
            idx = idx + 1
          }
        })
        this.treeData = treeD
      }
    }).catch(err => {
      console.warn(err)
    })
}

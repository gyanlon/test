/**
 * 验证手机号码
 */
export function phoneVerification (rule, value, callback) {
  const isMobile = /^1(3|4|5|7|8)\d{9}$/
  if (!isMobile.test(value)) {
    callback(new Error('请输入正确的手机号码!'))
  } else {
    callback()
  }
}
/**
 * 验证 邮箱
 * @param {*} rule
 * @param {*} value
 * @param {*} callback
 */
export function emailValidator (rule, value, callback) {
  if (!/\w[-\w.+]*@([A-Za-z0-9][-A-Za-z0-9]+\.)+[A-Za-z]{2,14}/.test(value)) {
    callback(new Error('请输入正确的邮箱地址!'))
  } else {
    callback()
  }
}

/**
 * 把日期对象转成 yyyy-MM-dd hh:mm:ss 显示格式
 * @param {*} date
 */
export function formatDateTime (date, type = '-') {
  let y = date.getFullYear()
  let m = date.getMonth() + 1
  m = m < 10 ? '0' + m : m
  let d = date.getDate()
  d = d < 10 ? '0' + d : d
  let h = date.getHours()
  h = h < 10 ? '0' + h : h
  let minute = date.getMinutes()
  minute = minute < 10 ? '0' + minute : minute
  let second = date.getSeconds()
  second = second < 10 ? '0' + second : second
  return y + type + m + type + d + ' ' + h + ':' + minute + ':' + second
}
/**
 * 把日期对象转成 yyyy-MM-dd 显示格式
 * @param {*} date
 */
export function formatDate (date, type = '-') {
  let y = date.getFullYear()
  let m = date.getMonth() + 1
  m = m < 10 ? '0' + m : m
  let d = date.getDate()
  d = d < 10 ? '0' + d : d
  return y + type + m + type + d + ''
}
/**
 * 把时间对象转成 hh:mm:ss 显示格式
 * @param {*} date
 */
export function formatTime (date) {
  let h = date.getHours()
  h = h < 10 ? '0' + h : h
  let minute = date.getMinutes()
  minute = minute < 10 ? '0' + minute : minute
  let second = date.getSeconds()
  second = second < 10 ? '0' + second : second
  return h + ':' + minute + ':' + second
}
/**
 * 验证正整数
 */

export function validPositiveInt (value) {
  let g = /^[1-9]*[1-9][0-9]*$/
  return g.test(value)
}
/**
 * 验证任务名称
 */
export function validTaskName (value) {
  let g = value.indexOf(' ') >= 0 || value == null
  return !g
}

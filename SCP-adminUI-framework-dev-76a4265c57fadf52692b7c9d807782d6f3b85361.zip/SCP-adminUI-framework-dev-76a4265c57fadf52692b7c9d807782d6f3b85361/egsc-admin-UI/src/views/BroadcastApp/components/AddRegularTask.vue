<template>
  <el-dialog :visible.sync="dialogFormVisible" width="950px">
    <div slot="title">
      <span class="pull-left pl10">定时任务添加</span>
    </div>
    <el-form ref="taskForm" :model="taskForm" :rules="rules" label-width="90px">
      <el-row>
        <el-col :span="10">
          <el-form-item label="任务名称" prop="broadcastName">
            <el-input v-model="taskForm.broadcastName" auto-complete="off" :maxlength="20"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="5">
          <el-form-item label="重复次数" prop="repetitions">
            <el-input v-model="taskForm.repetitions" auto-complete="off" :maxlength="10"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="9">
          <el-form-item label="任务等级" prop="taskLevel">
            <el-input v-model="taskForm.taskLevel" auto-complete="off" :maxlength="2" placeholder="请输入1~20,数字越小代表等级越高"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <!-- 中间媒体选择区域 -->
      <el-row>
        <div class="ca-container clearfix">
          <div class="left-con">
            <el-tree ref="tree" node-key="id" :data="treeData" @check-change="handleCheckChange" :props="defaultProps" default-expand-all :expand-on-click-node="true" show-checkbox>
            </el-tree>
          </div>
          <div class="right-con">
            <el-table ref="multipleTable" :data="sceneList" tooltip-effect="dark" max-height="200" @selection-change="handleSelectionChange">
              <el-table-column type="selection" width="55">
              </el-table-column>
              <el-table-column label="场景名称" width="140" prop="sceneName">
                <template slot-scope="scope">{{ scope.row.sceneName }}</template>
              </el-table-column>
              <el-table-column label="创建日期" width="190" prop="createTime">
                <template slot-scope="scope">{{ scope.row.createTime }}</template>
              </el-table-column>
            </el-table>
          </div>
        </div>
      </el-row>
      <el-row>
        <el-col :span="10" v-show="false">
          <el-form-item label="结束日期" prop="endTime">
            <!-- <el-date-picker class="datepick" v-model="taskForm.endTime" :editable="false" :picker-options="endPickerOption" @change="endTimeChange" type="date" format="yyyy-MM-dd" value-format="yyyy-MM-dd" placeholder="选择结束日期">
            </el-date-picker> -->
          </el-form-item>
        </el-col>
        <el-col :span="10">
          <el-form-item label="启动时间" prop="dailyStartTime">
            <el-time-picker class="datepick" v-model="taskForm.dailyStartTime" :editable="false" placeholder="选择启动时间" value-format="HH:mm:ss">
            </el-time-picker>
          </el-form-item>
        </el-col>
        <el-col :span="10">
          <el-form-item label="终止时间" prop="dailyEndTime">
            <el-time-picker class="datepick" v-model="taskForm.dailyEndTime" :editable="false" placeholder="选择终止时间" value-format="HH:mm:ss">
            </el-time-picker>
          </el-form-item>
        </el-col>
        <el-col :span="20" v-show="false">
          <el-form-item label="单次播放" prop="startupTime">
            <!-- <el-date-picker @blur="startupTimeBlur" @change="startupTimeChange" :disabled="startupTimeDisable" class="datepick" v-model="taskForm.startupTime" :editable="false" :picker-options="startPickerOption" type="date" format="yyyy-MM-dd" value-format="yyyy-MM-dd" placeholder="选择开始日期">
            </el-date-picker> -->
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-form-item label="重复周期" prop="duplicate">
          <el-checkbox-group v-model="taskForm.duplicate" @change="duplicateChange" :disabled="checkboxGroupDisable">
            <el-checkbox label="0" name="type" ref="everyday" :checked="everyDayChecked" @change="handleEvdchange">每天</el-checkbox>
            <el-checkbox label="7" name="type" :disabled="weekDaydisabled">星期日</el-checkbox>
            <el-checkbox label="1" name="type" :disabled="weekDaydisabled">星期一</el-checkbox>
            <el-checkbox label="2" name="type" :disabled="weekDaydisabled">星期二</el-checkbox>
            <el-checkbox label="3" name="type" :disabled="weekDaydisabled">星期三</el-checkbox>
            <el-checkbox label="4" name="type" :disabled="weekDaydisabled">星期四</el-checkbox>
            <el-checkbox label="5" name="type" :disabled="weekDaydisabled">星期五</el-checkbox>
            <el-checkbox label="6" name="type" :disabled="weekDaydisabled">星期六</el-checkbox>
          </el-checkbox-group>
        </el-form-item>
      </el-row>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button type="primary" @click="save">保 存</el-button>
      <el-button @click="cancel">取 消</el-button>
    </div>
  </el-dialog>
</template>
<script>

// import { addVisitorInfoTest } from '@/views/VisitorApp/apis/index.js'
import { addTimingTask, getSceneList } from '@/views/BroadcastApp/apis/index.js'
import { formatDateTime, formatTime, formatDate, validPositiveInt, validTaskName } from '@/views/BroadcastApp/assets/js/validate.js'
import { listDeviceList } from '@/views/BroadcastApp/assets/js/listDevices.js'
export default {
  mounted: function () {
    this.getSceneData()
    this.getDeviList()
  },
  data () {
    let taskLevelPass = (rule, value, callback) => {
      if (value === '' || value === null) {
        callback(new Error('请输入等级数字'))
      } else {
        if (!validPositiveInt(value)) {
          callback(new Error('请输入正整数'))
        } else if (value > 20) {
          callback(new Error('等级不能大于20'))
        } else {
          callback()
        }
      }
    }
    let repetitionsPass = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请输入重复次数'))
      } else {
        if (!validPositiveInt(value)) {
          callback(new Error('请输入正整数'))
        } else {
          callback()
        }
      }
    }
    let broadcastNamePass = (rule, value, callback) => {
      if (!validTaskName(value)) {
        callback(new Error('请输入正确的任务名称'))
      } else {
        callback()
      }
    }
    let that = this
    return {
      pageSize: 10,
      currentPage: 1,
      taskForm: {
        broadcastName: '',
        repetitions: '',
        taskLevel: '',
        broadcastType: 1,
        startupTime: '',
        endTime: '',
        dailyStartTime: '',
        dailyEndTime: '',
        duplicate: [],
        sceneIds: [],
        playAreaIds: [],
        recovery: 1,
        createUser: 'xxx'
      },
      searchKey: '',
      loadable: true,
      defaultOpenKeys: [1, 2],
      startupTimeDisable: false,
      checkboxGroupDisable: false,
      /* treeData: [
        {
          id: 0,
          label: '恒大智慧小区',
          children: [
            {
              id: 1,
              label: '设备一',
              children: [
                {
                  id: 5,
                  label: '楼盘1 1-1'
                }, {
                  id: 6,
                  label: '楼盘2 1-2'
                },
                {
                  id: 7,
                  label: '楼盘3 1-3'
                }
              ]
            },
            {
              id: 2,
              label: '设备二',
              children: [
                {
                  id: 8,
                  label: '楼盘1 1-1'
                },
                {
                  id: 9,
                  label: '楼盘2 1-2'
                }
              ]
            },
            {
              id: 3,
              label: '设备三',
              children: [
                {
                  id: 10,
                  label: '楼盘1 1-1'
                }
              ]
            },
            {
              id: 4,
              label: '设备四',
              children: [
                {
                  id: 11,
                  label: '楼盘1 1-1'
                }
              ]
            }
          ]
        }
      ], */
      treeData: [],
      defaultProps: {
        id: 'id',
        children: 'children',
        label: 'label'
      },
      chooseScene: [],
      sceneList: [
      ],
      sceneTotal: 10,
      dialogFormVisible: false,
      rules: {
        broadcastName: [
          { required: true, message: '请输入任务名称', trigger: 'blur' },
          { min: 2, max: 20, message: '长度在 2 到 20 个字符', trigger: 'blur' },
          { validator: broadcastNamePass, trigger: 'blur' }
        ],
        repetitions: [
          { required: true, message: '请输入重复次数', trigger: 'blur' },
          { validator: repetitionsPass, trigger: 'blur' }
        ],
        taskLevel: [
          { required: true, message: '请输入整数1~20 (数字越小代表等级越高)', trigger: 'blur' },
          { validator: taskLevelPass, trigger: 'blur' }
        ],
        /* startupTime: [
          { required: true, message: '请输入开始日期', trigger: 'blur' }
        ],
        endTime: [
          { required: true, message: '请输入结束日期', trigger: 'blur' }
        ], */
        dailyStartTime: [
          { required: true, message: '请输入启动时间', trigger: 'blur' }
        ],
        dailyEndTime: [
          { required: true, message: '请输入终止时间', trigger: 'blur' }
        ],
        duplicate: [
          { required: true, message: '请选择重复周期', trigger: 'blur' }
        ]
      },
      chooseTasks: [],
      taskDatas: [],
      chooseTasks2: [],
      isIndeterminate: true,
      checkAll: false,
      startPickerOption: {
        disabledDate (time) {
          return time.getTime() < (Date.now() - 3600 * 1000 * 24)
        }
      },
      endPickerOption: {
        disabledDate (time) {
          return time.getTime() < (new Date(that.taskForm.startupTime).getTime() - 3600 * 1000 * 24)
        }
      },
      runPickerOption: {
        disabledDate (time) {
          return time.getTime() < (new Date(that.taskForm.startupTime).getTime() - 3600 * 1000 * 24) || time.getTime() > (new Date(that.taskForm.endTime).getTime())
        }
      },
      everyDayChecked: false,
      weekDaydisabled: false
    }
  },
  methods: {
    /* getData: function (params = {}) {
      let that = this
      let condition = {}
      condition.pageNo = this.currentPage
      condition.pageSize = this.pageSize
      condition.searchKey = this.searchKey
      getAudioList(Object.assign({}, condition, params))
        .then(res => {
          // debugger
          let tiptype = 'warning'
          if (res.data.code === '00000') {
            tiptype = 'success'
            let tableD = res.data.data.audioClip
            tableD.map(function (item, index, arr) {
              that.taskDatas.push(item.audioClipName)
              that.taskForm.audioClipIds.push(item.audioClipId)
            }, this)
          }
          this.$message({
            message: res.data.message,
            type: tiptype
          })
        }).catch(err => {
          // debugger
          this.$message({
            type: 'warning',
            message: err
          })
        })
    }, */
    getSceneData: function (params = {}) {
      let condition = {}
      condition.pageNo = this.currentPage
      condition.pageSize = this.pageSize
      condition.searchKey = this.searchKey
      // condition.broadcastType = this.broadcastType
      getSceneList(Object.assign({}, condition, params))
        .then(res => {
          if (res.data.code === '00000') {
            this.total = res.data.data.total
            let tableD = res.data.data.scene
            tableD.map(function (item, index, arr) {
              let d = new Date(item.createTime)
              // item.createTime = d.toLocaleString()
              item.createTime = formatDateTime(d, '-')
            }, this)
            this.sceneList = tableD
          }
        }).catch(err => {
          /* this.$message({
            type: 'warning',
            message: err
          }) */
          console.warn(err)
        })
    },
    scrollLoad: function () {
      let altAudio = document.getElementById('alternativeAudio')
      if (this.loadable && altAudio.scrollHeight - altAudio.clientHeight === altAudio.scrollTop) {
        this.loadable = false
        this.currentPage++
        // console.log(this.currentPage)
        this.getData()
        this.loadable = true
      }
    },
    openDialog: function () {
      // let startd = new Date()
      // let endd = new Date()
      // endd.setTime(startd.getTime() + 3600 * 1000 * 1)// 默认'终止时间'='开始时间'+1小时
      // this.taskForm.startupTime = startd
      // this.taskForm.endTime = endd
      // this.taskForm.dailyStartTime = startd
      this.dialogFormVisible = true
    },
    closeDialog: function () {
      // 重置form并关闭对话
      this.weekDaydisabled = false
      this.everyDayChecked = false
      this.$refs['taskForm'].resetFields()
      this.$refs['tree'].setCheckedNodes([])
      this.$refs['multipleTable'].clearSelection()
      this.dialogFormVisible = false
    },
    /* 获取设备列表 */
    getDeviList: listDeviceList,
    resetChecked: function () {
      this.$refs.tree.setCheckedKeys([])
    },
    handleSelectionChange (val) {
      this.multipleSelection = val
      // console.log(val)
      this.chooseScene = val
    },
    /* 验证日期合理性 */
    /* validDate: function () {
      if (new Date(this.taskForm.startupTime) > new Date(this.taskForm.endTime)) {
        this.$message({
          message: '开始日期不能大于终止日期',
          type: 'warning'
        })
        return false
      } else {
        return true
      }
    }, */
    /* 验证时间合理性 */
    validDailyTime: function () {
      let dailyStartTime = new Date('January 20,2018' + ' ' + this.taskForm.dailyStartTime).getTime()
      let dailyEndTime = new Date('January 20,2018' + ' ' + this.taskForm.dailyEndTime).getTime()
      if (dailyEndTime - dailyStartTime < 60000 * 5) { // 时间差至少5分钟
        this.$message({
          message: '终止时间必须大于启动时间5分钟以上',
          type: 'warning'
        })
        return false
      } else {
        return true
      }
    },
    handleCheckChange: function () {
      // console.log('change')
    },
    save: function () {
      // console.log(this.$refs['tree'].getCheckedNodes())
      let treeChecked = [].concat(this.$refs['tree'].getCheckedNodes(true))
      // console.log(treeChecked)
      /*       let newPlayAreaIds = []
            let parentIds = []
            let deciIdx = 0
            treeChecked.map(function (item, index, arr) {
              if (parentIds.indexOf(item.parentId) === -1) {
                if (parentIds.length === 0) {
                  deciIdx = 0
                } else {
                  deciIdx = deciIdx + 1
                }
                newPlayAreaIds[deciIdx] = {}
                newPlayAreaIds[deciIdx].deviceID = item.parentId
                newPlayAreaIds[deciIdx].playAreaIds = []
                newPlayAreaIds[deciIdx].playAreaIds.push(item.subDeviceInstallAddress)
                parentIds.push(item.parentId)
              } else {
                newPlayAreaIds[deciIdx].playAreaIds.push(item.subDeviceInstallAddress)
              }
            })
        */
      // console.log(newPlayAreaIds)
      let treeCheckedaddIds = []
      treeChecked.forEach(function (item, index) {
        treeCheckedaddIds.push(item.subDeviceInstallAddress)
      })
      // console.log(treeCheckedaddIds)
      this.taskForm.playAreaIds = treeCheckedaddIds
      // console.log(this.taskForm.playAreaIds)
      this.$refs['taskForm'].validate((valid) => {
        if (valid) {
          if (treeChecked.length < 1) {
            this.$message({
              type: 'warning',
              message: '请选择播放区域'
            })
            return false
          } else if (!this.validDailyTime()) {
            return false
          } else if (this.taskForm.duplicate.length < 1) {
            this.$message({
              type: 'warning',
              message: '请选择重复周期'
            })
            return false
          } else {
            let chooseScene = this.chooseScene
            if (chooseScene.length < 1) {
              this.$message({
                type: 'warning',
                message: '请选择场景'
              })
              return false
            } else {
              /* if (typeof this.taskForm.startupTime === 'object' && this.taskForm.startupTime !== '' && this.taskForm.startupTime !== null) {
                this.taskForm.startupTime = formatDate(this.taskForm.startupTime, '-')
              } */
              /* if (typeof this.taskForm.endTime === 'object') {
                this.taskForm.endTime = formatDate(this.taskForm.endTime, '-')
              } */
              // let params = this.taskForm
              let params = Object.assign({}, this.taskForm)
              let dateT = formatDate(new Date())
              // let dateT = '2018-01-24'
              if (typeof params.dailyStartTime === 'object') {
                params.dailyStartTime = formatTime(params.dailyStartTime)
              }
              if (typeof params.dailyEndTime === 'object') {
                params.dailyEndTime = formatTime(params.dailyEndTime)
              }
              if (params.dailyStartTime.length < 10) {
                // params.dailyStartTime = dateT + ' ' + params.dailyStartTime
                params.dailyStartTime = dateT + ' ' + params.dailyStartTime
                // this.taskForm.dailyEndTime = this.taskForm.endTime + ' ' + this.taskForm.dailyEndTime
              }
              if (params.dailyEndTime.length < 10) {
                // params.dailyEndTime = dateT + ' ' + params.dailyEndTime
                params.dailyEndTime = dateT + ' ' + params.dailyEndTime
              }
              params.endTime = dateT
              params.startupTime = dateT
              /* if (this.taskForm.startupTime === null) {
                this.taskForm.startupTime = ''
              } */
              chooseScene.map(function (item, index, arr) {
                params.sceneIds.push(item.sceneId)
              }, this)
              params.repetitions = parseInt(this.taskForm.repetitions)
              params.taskLevel = parseInt(this.taskForm.taskLevel)
              if (params.duplicate[0] === '0') {
                params.duplicate = ['1', '2', '3', '4', '5', '6', '7']
              }
              // this.$refs['taskForm'].resetFields()
              addTimingTask(Object.assign({}, params)).then(res => {
                if (res.data.code === '00000') {
                  this.$emit('reflushData')
                  this.$message({
                    message: res.data.message,
                    type: 'success'
                  })
                  this.closeDialog()
                } else {
                  this.$message({
                    message: res.data.message,
                    type: 'warning'
                  })
                  this.closeDialog()
                }
              }).catch(err => {
                console.warn(err.response.data.message)
                // this.closeDialog()
              })
              // 添加完后转为string以通过下次添加的校验
              /* this.taskForm.repetitions = this.taskForm.repetitions + ''
              this.taskForm.taskLevel = this.taskForm.repetitions + ''
              this.taskForm.duplicate = ['0'] */
              // 逐条查询设备
              /* let par = this.taskForm
              const deviceCodes = par.deviceCodes
              let subDeviCount = deviceCodes.length
              let iterator = function (len) {
                if (len < subDeviCount) {
                  getDevice({ deviceCode: deviceCodes[len] }).then((res) => {
                    if (res.data.attributeList) {
                      let attributeValue = res.data.attributeList[0].attributeValue
                      console.log(attributeValue)
                      par.playAreaIds.push(attributeValue)
                      iterator(len + 1)
                    }
                  })
                } else if (len === subDeviCount) {
                  console.log('end')
                  addTimingTask(Object.assign({}, par)).then(res => {
                    if (res.data.deviceCode.length > 0) {
                      console.log('设备查询成功')
                      this.dialogFormVisible = false
                    } else {
                      this.$message({
                        message: res.data.message,
                        type: 'warning'
                      })
                    }
                  }).catch(err => {
                    that.$message({
                      message: err,
                      type: 'warning'
                    })
                    that.dialogFormVisible = false
                  })
                  that.dialogFormVisible = false
                  return false
                }
              }
              iterator(0) */
              // console.log(par.playAreaIds)
            }
          }
        } else {
          this.$message({
            message: '内容未填写完整',
            type: 'warning'
          })
          return false
        }
      })
    },
    cancel: function () {
      this.dialogFormVisible = false
    },
    // 触发file类型的input的默认事件
    uploadFacePic: function () {
      // this.$refs.uploadFacePicInput.click()
    },
    // 读取上传图片的base64编码
    readFacePic: function () {
      const file = this.$refs.uploadFacePicInput.files[0]
      const self = this
      var reader = new FileReader()
      reader.readAsDataURL(file)
      reader.onload = function (e) {
        const base64Code = this.result
        self.form.facePic = base64Code
      }
    },
    /** 复选框  全选 */
    checkAllChange: function (val) {
      this.chooseTasks = val ? this.taskDatas : []
      this.isIndeterminate = false
    },
    /** 复选框 选项更改 */
    checkTaskItemChange: function (val) {
      let nowCount = val.length
      this.checkAll = nowCount === this.taskDatas.length
      this.isIndeterminate = nowCount > 0 && nowCount < this.taskDatas.length
    },

    endTimeChange: function (params) {
      // console.log('终止时间: ' + params)
      this.taskForm.endTime = params
    },
    /* 选择每天或者星期几 */
    handleEvdchange: function () {
      this.taskForm.duplicate = []
      this.everyDayChecked = !this.everyDayChecked
    },
    /* 重复周期选项发生变化 */
    duplicateChange: function () {
      if (this.everyDayChecked === true) {
        this.weekDaydisabled = true
        this.taskForm.duplicate = ['0']
      } else {
        this.weekDaydisabled = false
      }
    }
    /*     startupTimeBlur: function () {
          if (this.taskForm.startupTime === null || this.taskForm.startupTime === '') {
            this.checkboxGroupDisable = false
          } else {
            this.checkboxGroupDisable = true
            this.taskForm.duplicate = []
          }
        },
        startupTimeChange: function () {
          this.startupTimeBlur()
        } */
  }
}
</script>
<style scoped>
.clearfix:before,
.clearfix:after {
  content: "";
  display: table;
  clear: both;
}
.clearfix {
  zoom: 1;
}
ul {
  list-style: none;
}
.fl {
  float: left;
}
.fr {
  float: right;
}
.ca-container {
  position: relative;
  width: 100%;
  height: 100%;
  margin-bottom: 20px;
  padding: 10px;
  box-sizing: border-box;
  border: 1px solid #dddee1;
}
.st-container {
  padding-top: 15px;
}
.left-con {
  float: left;
  width: 50%;
  height: 230px;
  display: flex;
  flex-flow: column;
  overflow-y: auto;
  border-right: 1px solid #dddee1;
}
.right-con {
  display: flex;
  flex-flow: column;
  float: right;
  width: 46%;
  height: 196px;
  overflow-y: auto;
  box-sizing: border-box;
  border: 1px solid #dddee1;
  margin-top: 14px;
}
.task-search {
  margin: 10px;
  width: 60%;
  float: left;
}
.reset-icon {
  width: 20%;
  float: right;
}
.choose-con {
  width: 45%;
  padding: 10px;
}
.list-con {
  display: flex;
  flex-flow: column;
  border: 1px solid #dddee1;
  padding: 10px;
  margin-top: 10px;
  /* height: 100%; */
  height: 180px;
  overflow-y: auto;
  box-sizing: border-box;
}
.datepick {
  width: 210px;
}
.ck-item {
  margin-left: 0px;
}
</style>



<template>
  <el-dialog :visible.sync="dialogFormVisible" width="950px">
    <div slot="title">
      <span class="pull-left pl10">即时任务添加</span>
    </div>
    <el-form ref="taskForm" :model="taskForm" :rules="rules" label-width="90px">
      <el-row>
        <el-col :span="10">
          <el-form-item label="任务名称" prop="broadcastName">
            <el-input v-model="taskForm.broadcastName" :maxlength="20"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="5">
          <el-form-item label="重复次数" prop="repetitions">
            <el-input v-model="taskForm.repetitions" auto-complete="off" :maxlength="10"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="9">
          <el-form-item label="任务等级" prop="taskLevel">
            <el-input v-model="taskForm.taskLevel" auto-complete="off" :maxlength="2" placeholder="请输入1~20,数字越小代表等级越高"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <!-- 中间媒体选择区域 -->
      <el-row>
        <div class="ca-container clearfix">
          <div class="left-con">
            <div class="choose-con">
              <span>备选媒体</span>
              <el-checkbox class="fr" :indeterminate="isIndeterminate" v-model="checkAll" @change="checkAllChange" size="mini">全选
              </el-checkbox>
              <el-checkbox-group class="list-con" v-model="chooseTasks" @change="checkTaskItemChange" ref="alternativeAudio" @scroll.native="scrollLoad" id="alternativeAudio">
                <el-checkbox class="ck-item" v-for="item in taskDatas" :label="item" :key="item.audioClipName">{{item.audioClipName}}</el-checkbox>
              </el-checkbox-group>
            </div>
            <el-button class="controlBtn" type="primary" icon="el-icon-arrow-right" size="mini" @click="selectTasks"></el-button>
            <div class="choose-con">
              <span>已选媒体</span>
              <div class="con-button fr">
                <el-button type="primary" size="mini" @click="deleteItems">删除</el-button>
                <el-button type="primary" size="mini" @click="clearAll">重置</el-button>
              </div>
              <el-checkbox-group class="list-con" v-model="chooseTasks2" @change="checkTaskItemChange">
                <el-checkbox class="ck-item" v-for="item in taskForm.chooseTaskData" :label="item" :key="item.audioClipName">{{item.audioClipName}}</el-checkbox>
              </el-checkbox-group>
            </div>
          </div>
          <div class="right-con">
            <el-tree ref="tree" :data="treeData" :props="defaultProps" show-checkbox node-key="id" :default-expand-all="true" :expand-on-click-node="false">
            </el-tree>
          </div>
        </div>
      </el-row>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button type="primary" @click="save">保 存</el-button>
      <el-button @click="cancel">取 消</el-button>
    </div>
  </el-dialog>
</template>
<script>

// import { addVisitorInfoTest } from '@/views/VisitorApp/apis/index.js'
import { getAudioList, addRealtimeTask, getDevice } from '@/views/BroadcastApp/apis/index.js'
import { validPositiveInt, validTaskName } from '@/views/BroadcastApp/assets/js/validate.js'
import { listDeviceList } from '@/views/BroadcastApp/assets/js/listDevices.js'
export default {
  mounted: function () {
    this.getData()
    this.getDeviList()
  },
  data () {
    let taskLevelPass = (rule, value, callback) => {
      if (value === '' || value === null) {
        callback(new Error('请输入等级数字'))
      } else {
        if (!validPositiveInt(value)) {
          callback(new Error('请输入正整数'))
        } else if (value > 20) {
          callback(new Error('等级不能大于20'))
        } else {
          callback()
        }
      }
    }
    let repetitionsPass = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请输入重复次数'))
      } else {
        if (!validPositiveInt(value)) {
          callback(new Error('请输入正整数'))
        } else {
          callback()
        }
      }
    }
    let broadcastNamePass = (rule, value, callback) => {
      if (!validTaskName(value)) {
        callback(new Error('请输入正确的任务名称'))
      } else {
        callback()
      }
    }
    return {
      currentPage: 1,
      pageSize: 10,
      flagScrollH: 0,
      taskForm: {
        broadcastName: '',
        repetitions: '',
        taskLevel: '',
        broadcastType: 0,
        chooseTaskData: [],
        audioClipIds: [],
        recovery: 1,
        createUser: 'XXX',
        playAreaIds: []
      },
      searchKey: '',
      defaultOpenKeys: [1, 2],
      /* treeData: [
        {
          id: 0,
          label: '恒大智慧小区',
          children: [
            {
              id: 1,
              label: '设备一',
              children: [
                {
                  id: 5,
                  label: '楼盘1 1-1'
                }, {
                  id: 6,
                  label: '楼盘2 1-2'
                },
                {
                  id: 7,
                  label: '楼盘3 1-3'
                }
              ]
            },
            {
              id: 2,
              label: '设备二',
              children: [
                {
                  id: 8,
                  label: '楼盘1 1-1'
                },
                {
                  id: 9,
                  label: '楼盘2 1-2'
                }
              ]
            },
            {
              id: 3,
              label: '设备三',
              children: [
                {
                  id: 10,
                  label: '楼盘1 1-1'
                }
              ]
            },
            {
              id: 4,
              label: '设备四',
              children: [
                {
                  id: 11,
                  label: '楼盘1 1-1'
                }
              ]
            }
          ]
        }
      ], */
      treeData: [],
      chooseTreeData: [],
      defaultProps: {
        id: 'id',
        children: 'children',
        label: 'label'
      },
      dialogFormVisible: false,
      rules: {
        broadcastName: [
          { required: true, message: '请输入任务名称', trigger: 'blur' },
          { min: 2, max: 20, message: '长度在 2 到 20 个字符', trigger: 'blur' },
          { validator: broadcastNamePass, trigger: 'blur' }
        ],
        repetitions: [
          { required: true, message: '请输入重复次数', trigger: 'blur' },
          { validator: repetitionsPass, trigger: 'blur' }
        ],
        taskLevel: [
          { required: true, message: '请输入整数1~20 (数字越大代表等级越高)', trigger: 'blur' },
          { validator: taskLevelPass, trigger: 'blur' }
        ]
      },
      // chooseTasks: ['小苹果', '逆战', '凉凉'],
      // taskDatas: ['突然好想你', '小苹果', '逆战', '凉凉', 'my heart will go on', 'yesterdate noce more',
      //   '逆战2', '凉凉2', 'my heart will go on2', 'yesterdate noce more2', '生如夏花之绚烂'
      // ],
      chooseTasks: [],
      taskDatas: [],
      chooseTasks2: [],
      isIndeterminate: true,
      checkAll: false
    }
  },
  methods: {
    getData: function (params = {}) {
      let that = this
      let condition = {}
      condition.pageNo = this.currentPage
      condition.pageSize = this.pageSize
      condition.searchKey = this.searchKey
      getAudioList(Object.assign({}, condition, params))
        .then(res => {
          if (res.data.code === '00000') {
            let tableD = res.data.data.audioClip
            tableD.map(function (item, index, arr) {
              that.taskDatas.push(item)
            }, this)
            // this.tableData = tableD
            // this.total = res.data.data.total
          }
          /* this.$message({
            message: res.data.message,
            type: 'success'
          }) */
        }).catch(err => {
          console.warn(err)
        })
    },
    scrollLoad: function () {
      let altAudio = document.getElementById('alternativeAudio')
      if (altAudio.scrollHeight - altAudio.clientHeight === altAudio.scrollTop && altAudio.scrollTop > this.flagScrollH) {
        this.flagScrollH = altAudio.scrollTop
        this.currentPage++
        this.getData()
      }
    },
    openDialog: function () {
      // this.getDeviceMsg()
      this.dialogFormVisible = true
    },
    /* 获取设备列表 */
    /* getDeviList: function () {
      let params = {
        // 'listDeviceTypeCode': ['2019']
        deviceType: 2019
      }
      let idx = 0
      let subIdx = 0
      getDevicesList(Object.assign({}, params))
        .then(res => {
          if (res.data.code === '00000') {
            let devcList = res.data.data.deviceList
            let treeD = []
            // 多个设备控制器时启用
            devcList.map(function (item, index, arr) {
              if (item.subDeviceList.length > 0) {
                // console.log(item)
                treeD[idx] = {}
                treeD[idx].label = item.deviceName
                treeD[idx].id = item.deviceID
                treeD[idx].children = []
                item.subDeviceList.map(function (cur, _idx, arr) {
                  if (cur.subDeviceInstallAddress !== null && cur.subDeviceInstallAddress !== '') {
                    treeD[idx].children[subIdx] = {}
                    treeD[idx].children[subIdx].subDeviceInstallAddress = cur.subDeviceInstallAddress
                    treeD[idx].children[subIdx].id = cur.subDeviceID
                    treeD[idx].children[subIdx].label = cur.subOrgName
                    subIdx = subIdx + 1
                    if (subIdx === arr.length) {
                      subIdx = 0
                    }
                  }
                })
                idx = idx + 1
              }
            }, this)
            this.treeData = treeD
            // console.log(this.treeData)
          }
        }).catch(err => {
          this.$message({
            message: err,
            type: 'warning'
          })
        })
    }, */
    getDeviList: listDeviceList,
    getDeviceMsg: function () {
      /* 获取分区信息 */
      // let chooseSubDeviceID = this.$refs['tree'].getCheckedKeys
      let params = {
        'deviceCode': '3022000BAB62AFF40007'
      }
      getDevice(Object.assign({}, params)).then(res => {
        if (res.status === 200) {
          console.log(res)
        }
      }).catch(err => {
        console.warn(err)
      })
    },
    closeDialog: function () {
      this.dialogFormVisible = false
      this.taskForm.chooseTaskData = []
      this.$refs['tree'].setCheckedNodes([])
      this.$refs['taskForm'].resetFields()
    },
    save: function () {
      // console.log(this.$refs['tree'].getCheckedKeys(true))
      let treeChecked = this.$refs['tree'].getCheckedNodes(true)
      let treeCheckedaddIds = []
      treeChecked.forEach(function (item, index) {
        treeCheckedaddIds.push(item.subDeviceInstallAddress)
      })
      // console.log(treeCheckedaddIds)
      this.taskForm.playAreaIds = treeCheckedaddIds
      this.$refs['taskForm'].validate((valid) => {
        if (valid && this.taskForm.chooseTaskData.length !== 0) {
          let dataT = this.taskForm.chooseTaskData
          dataT.map(function (item, index, arr) {
            this.taskForm.audioClipIds.push(item.audioClipId)
          }, this)
          if (treeChecked.length < 1) {
            this.$message({
              type: 'warning',
              message: '请选择播放区域'
            })
            return false
          } else if (this.taskForm.chooseTaskData.length === 0) {
            this.$message({
              message: '请至少添加一个播放媒体',
              type: 'warning'
            })
            return false
          } else {
            let params = this.taskForm
            params.repetitions = parseInt(this.taskForm.repetitions)
            params.taskLevel = parseInt(this.taskForm.taskLevel)
            addRealtimeTask(Object.assign({}, params)).then(res => {
              if (res.data.code === '00000') {
                this.$message({
                  message: res.data.message,
                  type: 'success'
                })
                this.$emit('reflushData')
                this.closeDialog()
              } else {
                this.$message({
                  message: res.data.message,
                  type: 'warning'
                })
              }
            }).catch(err => {
              console.warn(err)
              /* that.$message({
                message: err,
                type: 'warning'
              }) */
              // this.closeDialog()
            })
            // 添加完后转为string以通过下次添加的校验
            // this.taskForm.repetitions = this.taskForm.repetitions + ''
            // this.taskForm.taskLevel = this.taskForm.repetitions + ''
            /* let iterator = function (len) {
              if (len < subDeviCount) {
                getDevice({ deviceCode: deviceCodes[len] }).then((res) => {
                  if (res.data.attributeList) {
                    let attributeValue = res.data.attributeList[0].attributeValue
                    console.log(attributeValue)
                    par.playAreaIds.push(attributeValue)
                    iterator(len + 1)
                  }
                })
              } else if (len === subDeviCount) {
                console.log('end')
                addRealtimeTask(Object.assign({}, par)).then(res => {
                  if (res.data.deviceCode.length > 0) {
                    console.log('设备查询成功')
                    this.dialogFormVisible = false
                  } else {
                    // console.log('err1')
                    this.$message({
                      message: res.data.message,
                      type: 'warning'
                    })
                  }
                }).catch(err => {
                  // console.log('err2')
                  that.$message({
                    message: err,
                    type: 'warning'
                  })
                  that.dialogFormVisible = false
                })
                that.dialogFormVisible = false
                return false
              }
            }
            iterator(0) */
          }
          // this.dialogFormVisible = false
        } else {
          this.$message({
            message: '内容未填写完整',
            type: 'warning'
          })
          return false
        }
      })
    },
    cancel: function () {
      this.dialogFormVisible = false
    },
    /** 复选框  全选 */
    checkAllChange: function (val) {
      this.chooseTasks = val ? this.taskDatas : []
      this.isIndeterminate = false
    },
    /** 复选框 选项更改 */
    checkTaskItemChange: function (val) {
      let nowCount = val.length
      this.checkAll = nowCount === this.taskDatas.length
      this.isIndeterminate = nowCount > 0 && nowCount < this.taskDatas.length
    },
    /** 从‘备选媒体’中选择任务到‘已选媒体’里 */
    selectTasks: function () {
      // let that = this
      if (this.chooseTasks.length < 1) {
        this.$message({
          message: '至少选择一个要添加任务',
          type: 'warning'
        })
        return false
      } else if (this.taskForm.chooseTaskData.length === 0) {
        // this.taskForm.chooseTaskData = this.chooseTasks
        this.taskForm.chooseTaskData = [].concat(this.chooseTasks)
        this.chooseTasks2 = []
        this.chooseTasks = []
        this.isIndeterminate = true
      } else {
        for (let i = 0, len = this.chooseTasks.length; i < len; i++) {
          if (this.taskForm.chooseTaskData.indexOf(this.chooseTasks[i]) === -1) {
            this.taskForm.chooseTaskData.push(this.chooseTasks[i])
          }
        }
        this.chooseTasks2 = []
        this.chooseTasks = []
        this.isIndeterminate = true
      }
    },
    /** 取消 */
    alterCancel: function () {

    },
    /** 删除 */
    deleteItems: function () {
      if (this.chooseTasks2.length === 0) {
        this.$message({
          message: '至少选择一个要删除任务',
          type: 'warning'
        })
        return false
      }
      for (let val in this.chooseTasks2) {
        let idx = this.taskForm.chooseTaskData.indexOf(this.chooseTasks2[val])
        if (idx !== -1) {
          this.taskForm.chooseTaskData.splice(idx, 1)
        }
      }
    },
    /** 清空 */
    clearAll: function () {
      this.taskForm.chooseTaskData = []
    }
  }
}
</script>
<style scoped>
.clearfix:before,
.clearfix:after {
  content: "";
  display: table;
  clear: both;
}
.clearfix {
  zoom: 1;
}
ul {
  list-style: none;
}
.fl {
  float: left;
}
.fr {
  float: right;
}
.ca-container {
  position: relative;
  width: 100%;
  height: 100%;
  margin-bottom: 20px;
  padding: 10px;
  box-sizing: border-box;
  border: 1px solid #dddee1;
}
.st-container {
  padding-top: 15px;
}
.left-con {
  float: left;
  width: 60%;
  height: 230px;
  display: flex;
  flex-flow: row;
  align-items: center;
  border-right: 1px solid #dddee1;
}
.right-con {
  display: flex;
  flex-flow: column;
  float: right;
  width: 35%;
  height: 230px;
  overflow-y: auto;
  box-sizing: border-box;
  border: 1px solid #dddee1;
}
.task-search {
  margin: 10px;
  width: 80%;
}
.choose-con {
  width: 45%;
  padding: 10px;
}
.list-con {
  display: flex;
  flex-flow: column;
  border: 1px solid #dddee1;
  padding: 10px;
  margin-top: 10px;
  /* height: 100%; */
  height: 180px;
  overflow-y: auto;
  box-sizing: border-box;
}
.datepick {
  width: 210px;
}
.ck-item {
  margin-left: 0px;
}
</style>



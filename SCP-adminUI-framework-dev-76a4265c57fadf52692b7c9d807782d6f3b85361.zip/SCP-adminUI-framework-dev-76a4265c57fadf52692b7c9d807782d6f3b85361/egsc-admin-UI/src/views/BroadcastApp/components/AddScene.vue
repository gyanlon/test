<template>
  <el-dialog :visible.sync="dialogFormVisible" width="950px">
    <div slot="title">
      <span class="pull-left pl10">添加场景</span>
    </div>
    <el-form ref="taskForm" :model="taskForm" :rules="rules" label-width="90px">
      <el-row>
        <el-col :span="10">
          <el-form-item label="场景名称" prop="sceneName">
            <el-input v-model="taskForm.sceneName" auto-complete="off" :maxlength="20"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <!-- 中间媒体选择区域 -->
      <el-row>
        <div class="ca-container clearfix">
          <div class="left-con">
            <div class="choose-con">
              <span>备选媒体</span>
              <el-checkbox class="fr" :indeterminate="isIndeterminate" v-model="checkAll" @change="checkAllChange" size="mini">全选
              </el-checkbox>
              <el-checkbox-group class="list-con" v-model="chooseTasks" @change="checkTaskItemChange" id="alternativeAudio" ref="alternativeAudio" @scroll.native="scrollLoad">
                <el-checkbox class="ck-item" v-for="item in taskDatas" :key="item.audioClipName" :label="item">{{item.audioClipName}}</el-checkbox>
              </el-checkbox-group>
            </div>
            <el-button class="controlBtn" type="primary" icon="el-icon-arrow-right" size="mini" @click="selectTasks"></el-button>
            <div class="choose-con">
              <span>已选媒体</span>
              <div class="con-button fr">
                <el-button type="primary" size="mini" @click="deleteItems">删除</el-button>
                <el-button type="primary" size="mini" @click="clearAll">重置</el-button>
              </div>
              <el-checkbox-group class="list-con" v-model="chooseTasks2">
                <el-checkbox class="ck-item" v-for="item in taskForm.chooseTaskData" :key="item.audioClipName" :label="item">{{item.audioClipName}}</el-checkbox>
              </el-checkbox-group>
            </div>
          </div>
        </div>
      </el-row>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button type="primary" @click="save">保 存</el-button>
      <el-button @click="cancel">取 消</el-button>
    </div>
  </el-dialog>
</template>
<script>

import { getAudioList, addScene } from '@/views/BroadcastApp/apis/index.js'
import { validTaskName } from '@/views/BroadcastApp/assets/js/validate.js'
export default {
  mounted: function () {
    this.getData()
  },
  data () {
    let sceneNamePass = (rule, value, callback) => {
      if (!validTaskName(value)) {
        callback(new Error('请输入正确的场景名称'))
      } else {
        callback()
      }
    }
    return {
      pageSize: 10,
      currentPage: 1,
      flagScrollH: 0,
      taskForm: {
        sceneName: '',
        chooseTaskData: [],
        audioClipIds: []
      },
      searchKey: '',
      defaultOpenKeys: [1, 2],
      audioClipIdsAll: [],
      defaultProps: {
        id: 'id',
        children: 'children',
        label: 'label'
      },
      dialogFormVisible: false,
      rules: {
        sceneName: [
          { required: true, message: '请输入场景名称', trigger: 'blur' },
          { min: 2, max: 20, message: '长度在 2 到 20 个字符', trigger: 'blur' },
          { validator: sceneNamePass, trigger: 'blur' }
        ]
      },
      chooseTasks: [],
      chooseTasks2: [],
      taskDatas: [],
      audioIds: [],
      isIndeterminate: true,
      checkAll: false
    }
  },
  methods: {
    getData: function (params = {}) {
      let that = this
      let condition = {}
      condition.pageNo = this.currentPage
      condition.pageSize = this.pageSize
      condition.searchKey = this.searchKey
      getAudioList(Object.assign({}, condition, params))
        .then(res => {
          if (res.data.code === '00000') {
            let tableD = res.data.data.audioClip
            tableD.map(function (item, index, arr) {
              that.taskDatas.push(item)
              // that.audioIds.push(item.audioClipId)
            }, this)
          }
          /* this.$message({
            message: res.data.message,
            type: 'success'
          }) */
        }).catch(err => {
          console.warn(err)
        })
    },
    scrollLoad: function () {
      let altAudio = document.getElementById('alternativeAudio')
      if (altAudio.scrollHeight - altAudio.clientHeight === altAudio.scrollTop && altAudio.scrollTop > this.flagScrollH) {
        this.flagScrollH = altAudio.scrollTop
        this.currentPage++
        this.getData()
      }
    },
    openDialog: function () {
      this.dialogFormVisible = true
    },
    closeDialog: function () {
      this.$refs['taskForm'].resetFields()
      this.chooseTasks = []
      this.chooseTasks2 = []
      this.taskForm.chooseTaskData = []
      this.dialogFormVisible = false
    },
    save: function () {
      this.$refs['taskForm'].validate((valid) => {
        // console.log('save')
        if (valid) {
          if (this.taskForm.chooseTaskData.length === 0) {
            this.$message({
              message: '请至少添加一个播放媒体',
              type: 'warning'
            })
            return false
          } else {
            let dataD = this.taskForm.chooseTaskData
            dataD.map(function (item, index, arr) {
              this.taskForm.audioClipIds.push(item.audioClipId)
            }, this)
            let params = Object.assign({}, { audioClipIds: this.taskForm.audioClipIds, sceneName: this.taskForm.sceneName })
            addScene(params).then(res => {
              if (res.data.code === '00000') {
                this.$emit('reflushData')
                this.$message({
                  message: res.data.message,
                  type: 'success'
                })
                this.closeDialog()
              } else {
                this.$message({
                  message: res.data.message,
                  type: 'warning'
                })
                this.closeDialog()
              }
            }).catch(err => {
              console.warn(err)
              // this.closeDialog()
            })
          }
        } else {
          this.$message({
            message: '内容未填写完整',
            type: 'warning'
          })
          return false
        }
      })
    },
    cancel: function () {
      this.dialogFormVisible = false
    },
    // 触发file类型的input的默认事件
    uploadFacePic: function () {
      // this.$refs.uploadFacePicInput.click()
    },
    // 读取上传图片的base64编码
    readFacePic: function () {
      const file = this.$refs.uploadFacePicInput.files[0]
      const self = this
      var reader = new FileReader()
      reader.readAsDataURL(file)
      reader.onload = function (e) {
        const base64Code = this.result
        self.form.facePic = base64Code
      }
    },
    /** 复选框  全选 */
    checkAllChange: function (val) {
      // let taskD = this.taskDatas
      this.chooseTasks = val ? this.taskDatas : []
      this.isIndeterminate = false
    },
    /** 复选框 选项更改 */
    checkTaskItemChange: function (val) {
      let nowCount = val.length
      this.checkAll = nowCount === this.taskDatas.length
      this.isIndeterminate = nowCount > 0 && nowCount < this.taskDatas.length
    },
    /** 从‘备选媒体’中选择任务到‘已选媒体’里 */
    selectTasks: function () {
      // let that = this
      if (this.chooseTasks.length < 1) {
        this.$message({
          message: '至少选择一个要添加任务',
          type: 'warning'
        })
        return false
      } else if (this.taskForm.chooseTaskData.length === 0) {
        // this.taskForm.chooseTaskData = this.chooseTasks
        this.taskForm.chooseTaskData = [].concat(this.chooseTasks)
        this.chooseTasks2 = []
        this.chooseTasks = []
        this.isIndeterminate = true
      } else {
        for (let i = 0, len = this.chooseTasks.length; i < len; i++) {
          if (this.taskForm.chooseTaskData.indexOf(this.chooseTasks[i]) === -1) {
            this.taskForm.chooseTaskData.push(this.chooseTasks[i])
          }
        }
        this.chooseTasks2 = []
        this.chooseTasks = []
        this.isIndeterminate = true
      }
    },
    /** 取消 */
    alterCancel: function () {

    },
    /** 删除 */
    deleteItems: function () {
      if (this.chooseTasks2.length === 0) {
        this.$message({
          message: '至少选择一个要删除的音频',
          type: 'warning'
        })
        return false
      } else {
        for (let val in this.chooseTasks2) {
          let idx = this.taskForm.chooseTaskData.indexOf(this.chooseTasks2[val])
          if (idx !== -1) {
            this.taskForm.chooseTaskData.splice(idx, 1)
          }
        }
      }
    },
    /** 清空 */
    clearAll: function () {
      this.taskForm.chooseTaskData = []
    },
    endTimeChange: function (params) {
      // console.log('终止时间: ' + params)
      this.taskForm.endTime = params
    }
  }
}
</script>
<style scoped>
.clearfix:before,
.clearfix:after {
  content: "";
  display: table;
  clear: both;
}
.clearfix {
  zoom: 1;
}
ul {
  list-style: none;
}
.fl {
  float: left;
}
.fr {
  float: right;
}
.ca-container {
  position: relative;
  width: 100%;
  height: 100%;
  margin-bottom: 20px;
  padding: 10px;
  box-sizing: border-box;
  border: 1px solid #dddee1;
}
.st-container {
  padding-top: 15px;
}
.left-con {
  float: left;
  width: 100%;
  height: 230px;
  display: flex;
  flex-flow: row;
  align-items: center;
}
.right-con {
  display: flex;
  flex-flow: column;
  float: right;
  width: 35%;
  height: 230px;
  overflow-y: auto;
  box-sizing: border-box;
  border: 1px solid #dddee1;
}
.task-search {
  margin: 10px;
  width: 80%;
}
.choose-con {
  width: 45%;
  padding: 10px;
}
.list-con {
  display: flex;
  flex-flow: column;
  border: 1px solid #dddee1;
  padding: 10px;
  margin-top: 10px;
  /* height: 100%; */
  height: 180px;
  overflow-y: auto;
  box-sizing: border-box;
}
.datepick {
  width: 210px;
}
.ck-item {
  margin-left: 0px;
}
</style>



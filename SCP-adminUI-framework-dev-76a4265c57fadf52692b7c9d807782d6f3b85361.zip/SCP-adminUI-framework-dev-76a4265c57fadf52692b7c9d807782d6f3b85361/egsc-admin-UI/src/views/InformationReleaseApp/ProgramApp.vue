<template>

  <div>
    <div class="add-button">
      <el-button @click="showAdd" type="primary">添加节目</el-button>
    </div>
    <el-col :span="24" class="toolbar" style="padding-bottom: 0px;">
      <el-form :inline="true" :model="filters">
        <el-form-item label="节目名称">
          <el-input v-model.trim="filters.name" placeholder="字符长度不能超过32个" :maxlength="32"></el-input>
        </el-form-item>
        <el-form-item label="状态">
          <el-select clearable v-model="filters.state" placeholder="请选择状态">
            <el-option label="添加成功" value="0"></el-option>
            <el-option label="添加中" value="1"></el-option>
            <el-option label="修改成功" value="2"></el-option>
            <el-option label="修改中" value="3"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="创建时间">
          <el-date-picker v-model="filters.createTime" :editable='false' value-format="yyyy-MM-dd HH:mm:ss" type="datetimerange" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期">
          </el-date-picker>
        </el-form-item>
        <el-form-item label="创建人">
          <el-input v-model.trim="filters.creater" placeholder="字符长度不能超过32个" :maxlength="32"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" v-on:click="addtionMaterial">查询</el-button>
        </el-form-item>
      </el-form>
    </el-col>
    <div class="content">
      <el-table :data="data" border style="width: 100%">
        <el-table-column type="index" label="序号" width="100">
        </el-table-column>
        <el-table-column prop="programName" label="节目名称">
        </el-table-column>
        <el-table-column prop="playTime" label="播放时间(单位/s)">
        </el-table-column>
        <el-table-column prop="status" label="状态">
        </el-table-column>
        <el-table-column prop="createTime" label="创建时间">
        </el-table-column>
        <el-table-column prop="createUser" label="创建人">
        </el-table-column>
        <el-table-column fixed="right" label="操作" width="100">
          <template slot-scope="scope">
            <el-button type="text" @click="delProgram(scope.$index,scope.row)" size="small">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class='page-bar' v-show="data&&data.length">
        <el-pagination style="text-align:center;margin-top:15px" small @size-change="handleSizeChange" @current-change="handleCurrentChange" :page-sizes="[10]" :current-page.sync="pageData.pageNo" :page-size="pageData.pageSize" layout="total, sizes,prev, pager, next, jumper" :total="pageData.total">
        </el-pagination>
      </div>
    </div>
    <add :show="showaddDialog" @showstate='showstate' @closeDialog="closeDialog"></add>
  </div>
</template>
<script>
import { pagingquery, itemdelete } from './apis/index'// programList//pagingquery//editorItem
import add from './dialogs/Add'
export default {
  name: 'material',
  components: { add },
  data () {
    return {
      filters: {
        name: '',
        state: '',
        createTime: '',
        creater: ''
      },
      data: [],
      showaddDialog: false,
      pageData: {
        pageSize: 10,
        pageNo: 1,
        total: 0
      }
    }
  },
  created () {
  },
  mounted () {
    this.addtionMaterial()
  },
  methods: {
    addtionMaterial () { // 加载节目菜单//查询按钮
      if (this.filters.createTime === null) {
        this.filters.createTime = ''
      }
      let param = {
        itemName: this.filters.name,
        pageNo: this.pageData.pageNo,
        pageSize: this.pageData.pageSize,
        startTime: this.filters.createTime[0],
        endTime: this.filters.createTime[1],
        creater: this.filters.creater,
        status: this.filters.state
      }
      pagingquery(param).then(rs => {
        if (rs.data.code === '00000') {
          if (rs.data.data.datas && rs.data.data.datas.length) {
            this.data = rs.data.data.datas
            this.pageData.total = rs.data.data.total
          } else {
            this.data = []
            this.pageData.total = 0
            this.$message({
              showClose: true,
              message: '暂无数据',
              type: 'error'
            })
          }
        } else {
          this.data = []
          this.pageData.total = 0
          this.$message({
            showClose: true,
            message: '数据加载失败',
            type: 'error'
          })
        }
      })
        .catch(err => {
          console.log(err)
        })
    },
    delProgram (index, rowData) { // 删除节目
      this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        itemdelete({ id: rowData.id }).then(rs => {
          if (rs.data.code === '00000') {
            this.addtionMaterial()
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
          } else {
            this.$message({
              type: 'error',
              message: rs.data.message ? rs.data.message : '删除失败!'
            })
          }
        }).catch(err => {
          console.log(err)
        })
      }).catch(() => {
        this.$message({
          type: 'error',
          message: '已取消删除'
        })
      })
    },
    showAdd () { // 添加节目触发弹窗
      this.showaddDialog = true
    },
    closeDialog (mstate) {
      this.showaddDialog = false
    },
    handleSizeChange (val) {
      // console.log(`每页 ${val} 条`)
      this.addtionMaterial()
      this.pageData.pageSize = val
    },
    handleCurrentChange (val) {
      // console.log(`当前页: ${val}`)
      this.addtionMaterial()
      this.pageData.pageNo = val
    },
    showstate (mstate) {
      // console.log('成功调取一级页面接口')
      this.filters.name = ''
      this.filters.creater = ''
      this.filters.createTime = ''
      this.pageData.pageNo = 1
      this.addtionMaterial()
    }
  },
  updated () {
  }
}
</script>
<style lang="less" scoped>
.add-button {
  margin-bottom: 20px;
}
</style>

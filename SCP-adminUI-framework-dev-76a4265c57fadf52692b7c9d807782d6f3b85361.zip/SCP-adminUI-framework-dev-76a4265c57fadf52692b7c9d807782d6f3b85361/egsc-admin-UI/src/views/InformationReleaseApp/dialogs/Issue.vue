<template>
  <el-dialog class="issue-table" title="选择设备" :visible="show" @close="closeEvent(false)" width="80%">
    <el-row class="dialog-row" style="margin-top:-30px;">
      <el-col class="dialog-left">
        <el-table class="table" height="500" :border="true" :data="allData" style="margin-top:10px;width: 100%" :default-expand-all="true">
          <el-table-column type="expand">
            <template slot-scope="scope" v-if="scope.row.subDevice && scope.row.subDevice.length">
              <el-table :data="scope.row.subDevice" class="deviceNametable" style="width: 100%" :show-header="false">
                <el-table-column type="index" label="设备序号" align="center">
                </el-table-column>
                <el-table-column label="设备名称" prop="subDeviceName" align="center">
                </el-table-column>
                <el-table-column label="设备描述" prop="subDeviceDesc" align="center">
                </el-table-column>
                <el-table-column label="组织信息" prop="subOrgName" align="center">
                </el-table-column>
                <el-table-column label="安装位置" prop="subDeviceInstallAddress" align="center">
                </el-table-column>
                <el-table-column prop="creatTime" label="操作" align="center" style="border:none;">
                  <template slot-scope="scope">
                    <template v-if="!scope.row.subDevice || !scope.row.subDevice.length">
                      <el-button type="text" @click="handleSelectClick(scope.$index,scope.row)">
                        添加
                      </el-button>
                    </template>
                    <template v-else>
                      <el-button type="text" @click="handleAllSelectClick(scope.$index,scope.row)">
                        添加全部
                      </el-button>
                    </template>
                  </template>
                </el-table-column>
              </el-table>
            </template>
          </el-table-column>
          <el-table-column label="设备名称" prop="deviceName" align="center">
          </el-table-column>
          <el-table-column label="设备描述" prop="deviceDesc" align="center">
          </el-table-column>
          <el-table-column label="组织名称" prop="orgName" align="center">
          </el-table-column>
          <el-table-column label="安装位置" prop="installAddress" align="center">
          </el-table-column>
          <el-table-column prop="creatTime" label="操作" align="center">
            <template slot-scope="scope">
              <template v-if="!scope.row.subDevice || !scope.row.subDevice.length">
                <el-button type="text" @click="handleSelectClick(scope.$index,scope.row)">
                  <!-- 添加 -->
                </el-button>
              </template>
              <template v-else>
                <el-button type="text" @click="handleAllSelectClick(scope.$index,scope.row)">
                  添加全部
                </el-button>
              </template>
            </template>
          </el-table-column>
        </el-table>
      </el-col>
      <el-col class="dialog-right" style="margin-left:10px;">
        <el-table class="selectTable" height="400" :data="selectDate" :border="true" style="margin-top:10px;width: 100%">
          <el-table-column fixed prop="subDeviceName" label="设备名称" align="center"></el-table-column>
          <el-table-column fixed prop="subDeviceDesc" label="设备描述" align="center"></el-table-column>
          <el-table-column fixed prop="subOrgName" label="组织名称" align="center"></el-table-column>
          <el-table-column fixed prop="subDeviceInstallAddress" label="安装位置" align="center"></el-table-column>
          <el-table-column fixed prop="creatTime" label="操作" align="center">
            <template slot-scope="scope">
              <el-button type="text" @click.native.prevent="deleteRow(scope.$index, selectDate)">
                删除
              </el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-col>
    </el-row>
    <span slot="footer" class="dialog-footer">
      <el-button @click="closeEvent(false)">取 消</el-button>
      <el-button type="primary" @click="saveEpuipment(true)">保 存</el-button>
    </span>
  </el-dialog>
</template>
<script>
import { getDeviceList, sendissue } from '../apis/index'
export default {
  props: {
    show: {
      required: true,
      type: Boolean,
      default () {
        return false
      }
    },
    param: {}
  },
  data () {
    return {
      // index_flag: [],
      allData: [],
      selectDate: [],
      value6: ''
      // selection: ''
    }
  },
  watch: {
    show (val) {
      if (val) {
        this.getEquipments()
      }
    }
  },
  mounted () {
    // this.getEquipments()
    this.param.terminalNoList = []
  },
  updated () {
    // console.log('updated', this.selectDate)
    this.param.terminalNoList = []
    this.selectDate.forEach((item) => {
      this.param.terminalNoList.push({ 'terminalNo': item.subDeviceID })
    })
  },
  methods: {
    getEquipments () { // 获取设备信息
      getDeviceList().then(res => {
        if (res.data.code === '00000') {
          // 判断结果是否不为空
          if (res.data) {
            this.allData = res.data.data
          } else {
            this.allData = []
          }
        } else {
          console.log(res.data)
        }
      })
        .catch(err => {
          console.log(err)
        })
    },
    saveEpuipment () { // 保存设备数据
      this.$emit('closeissueDialog')
      let params = this.param
      sendissue(params).then(res => {
        if (res.data.code === '00000') {
          // console.log('发布成功了')
          // this.selectDate = []
          this.$message({
            message: '发布成功',
            type: 'success'
          })
          this.$emit('showstate')
          // deleteRow()
          this.selectDate = []
        } else {
          this.$message.error('发布失败')
          this.selectDate = []
          // console.log(res.data)
        }
      })
        .catch(err => {
          console.log(err)
        })
      // let selectedEpuipments = []
      // // let tempData = this.selectDate
      // if (this.selectDate && this.selectDate.length > 0) {
      //   for (var i = 0; i < this.selectDate.length; i++) {
      //     let tempObj = {}
      //     tempObj.deviceID = this.selectDate[i].deviceID
      //     tempObj.deviceName = this.selectDate[i].deviceName
      //     tempObj.floors = this.selectDate[i].selectFloors.join(',')
      //     selectedEpuipments.push(tempObj)
      //   }
      //   this.$emit('closeissueDialog')
      // } else {
      //   this.$alert('您还没选择设备', {
      //     dangerouslyUseHTMLString: true
      //   })
      // }
    },
    closeEvent () { // 关闭发布对话框
      this.$emit('closeissueDialog')
      this.selectDate = []
    },
    // handleSelectionChange (val) {
    //   this.selection = val
    //   console.log(this.selection)
    // },
    handleSelectClick (index, row) { // 添加单个设备按钮
      if (this.selectDate && this.selectDate.length > 0) {
        var aaa = 0
        for (let i = 0; i < this.selectDate.length; i++) {
          if (this.selectDate[i].subDeviceID === row.subDeviceID) {
            aaa++
          }
        }
        if (aaa === 0) {
          this.selectDate.push(row)
        }
      } else {
        this.selectDate.push(row)
      }
    },
    // handleSelectClick (index, row) { // 添加单个设备按钮
    //   console.log(JSON.stringify(row))
    //   var _time = 0
    //   if (this.selectDate.length === 0) {
    //     this.selectDate.push(row)
    //   } else {
    //     this.selectDate.forEach((element) => {
    //       // this.terminalNoList.push({ '"terminalNo"': element.subDeviceID })
    //       // this.param.listId.push({ '"terminalNo"': element.subDeviceID })
    //       console.log(this.param)
    //       if (element.subDeviceID === row.subDeviceID) {
    //         _time++
    //       }
    //     })
    //     console.log(_time)
    //     if (_time === 0) {
    //       this.selectDate.push(row)
    //     }
    //   }
    // },
    // handleAllSelectClick (index, allrow) { // 添加全部按钮
    //   console.log(allrow.deviceID)
    //   // this.allData.forEach((element) => {
    //   //   if (element.deviceID === allrow.deviceID) {
    //   //     this.selectDate.push()
    //   //   }
    //   // })
    //   this.selectDate = allrow.subDevice
    // },
    // handleAllSelectClick (index, allrow) { // 添加全部按钮
    //   var num = 0
    //   this.index_flag.forEach(e => {
    //     if (index === e) {
    //       num++
    //     }
    //   })
    //   if (num > 0) return
    //   this.index_flag.push(index)
    //   var subDevice = allrow.subDevice
    //   subDevice.forEach(e => {
    //     this.selectDate.push(e)
    //   })
    // },
    handleAllSelectClick (index, allrow) { // 添加全部按钮
      var subDevice = allrow.subDevice
      // console.log(this.selectDate)
      subDevice.forEach(e => {
        var time = 0
        if (this.selectDate.length > 0) {
          this.selectDate.forEach(data => {
            if (e.subDeviceID === data.subDeviceID) {
              time++
            }
          })
          if (time === 0) {
            this.selectDate.push(e)
          }
        } else {
          this.selectDate.push(e)
        }
      })
    },
    deleteRow (index, rows) { // 删除发布对话框中右侧的设备信息
      // console.log(rows)
      rows.splice(index, 1)
    }
  }
}
</script>
<style lang="less" scoped>
.dialog-row {
  display: flex;
  width: 100%;
  margin-top: 30px;
  .dialog-left {
    flex: 1;
    padding: 0 39px 0 40px;
  }
  .dialog-right {
    flex: 1;
    padding: 0px 40px 0 40px;
    border-left: 1px solid #ddd;
  }
}
</style>
<style lang="less">
.issue-table {
  .el-table__expanded-cell {
    padding: 0;
  }
}
</style>
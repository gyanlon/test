<template>
  <div>
    <el-dialog title="添加节目" :visible="show" width="60%" center @close="closeEvent()">
      <div>
        <el-form :model="ruleFormadd" :rules="rulesadd" ref="ruleFormadd" label-width="100px" class="demo-ruleForm">
          <el-form-item style='display:inline-block;margin-left:42px' label=" 节目名称 " prop="itemName">
            <el-input style="width:300px " v-model.trim="ruleFormadd.itemName" placeholder="字符长度不能超过32个" :maxlength="32"></el-input>
          </el-form-item>
          <el-form-item style='display:inline-block' label="播放时间/s " prop="itemTime">
            <el-input style="width:300px " v-model.number="ruleFormadd.itemTime" placeholder="播放时间必须在一分钟到一周的范围内" :maxlength="32"></el-input>
          </el-form-item>

          <p class="form-tip">提示信息:同一个节目不能添加多个音频、视频
          </p>

          <template>
            <div style="overflow:hidden;text-align: center ">
              <div class="content ">
                <div class="littlebox " @click="showCustom(item) " v-for='(item,index) in backStage' :key="index " :style="{ 'width': item.width/xRate+ 'px', 'height': item.height/yRate+ 'px', 'left': item.positionX/xRate+ 'px', 'top': item.positionY/yRate+ 'px'} ">
                  <p class="itembox " v-if="item.isShowText">
                    {{item.childWords}}
                  </p>
                  <p class="itembox " v-if="!item.isShowText">
                    点击添加节目
                  </p>
                </div>
              </div>
            </div>
          </template>
          <el-form-item class="item-button">
            <el-button style="margin-right:20px" type="primary " @click="submitForm('ruleFormadd')">确定</el-button>
            <el-button @click="resetForm('ruleFormadd')">重置</el-button>
          </el-form-item>
        </el-form>

      </div>
      <!-- <span slot="footer " class="dialog-footer ">
        <el-button @click="closeEvent(false) ">取 消</el-button>
        <el-button type="primary " @click="closeEvent(true) ">确 定</el-button>
      </span> -->
    </el-dialog>
    <custom :show="showaddDialog " @closeDialog2="closeCustom " @showdioalogmessage="showdioalogmessage " @showmessage="showmessage "></custom>
  </div>
</template>
<script>
import { getscreenconfig, itemadd } from '../apis/index' // programScreenConfig//getscreenconfig
import custom from './Custom'
export default {
  name: 'material',
  components: { custom },
  props: {
    show: {
      type: Boolean,
      required: true,
      default () {
        return false
      }
    }
  },
  data () {
    return {
      // storagedata: {},
      xRate: 1920 / 960,
      yRate: 1920 / 540,
      ruleFormadd: {
        itemName: '',
        itemTime: ''
      },
      rulesadd: {
        itemName: [
          { required: true, message: '请输入节目名称', trigger: 'change' }
        ],
        itemTime: [
          { required: true, validator: this.checkPlayTime, trigger: 'blur' }
        ]
      },
      currentObj: '',
      backStage: [],
      showaddDialog: false,
      activeItemId: ''
    }
  },
  watch: {
    show (val) {
      if (val) {
        this.queryData()
      }
    }
  },
  methods: {
    queryData () { // 生成屏幕配置样式
      getscreenconfig({
      }).then(res => {
        if (res.data.code === '00000') {
          if (res.data.data && res.data.data.length) {
            this.backStage = res.data.data
          } else {
            this.backStage = []
            this.$message({
              showClose: true,
              message: '暂无数据',
              type: 'error'
            })
          }
        } else {
          this.backStage = []
          this.$message({
            showClose: true,
            message: '数据加载失败',
            type: 'error'
          })
        }
      })
        .catch(err => {
          console.log(err)
        })
    },
    resetForm (formNameadd) { // 重置按钮
      this.$refs[formNameadd].resetFields()
      this.backStage.forEach(element => {
        this.$set(element, 'isShowText', false)
      })
      // console.log(this.backStage)
    },
    submitForm (formName) { // 提交按钮
      this.$refs[formName].validate((valid) => {
        if (valid) {
          let times = 0
          this.backStage.forEach(el => {
            if (el.isShowText) {
              times++
            }
          })
          if (times === this.backStage.length) {
            this.additem()
          } else {
            this.$message({
              showClose: true,
              message: '添加节目不能为空',
              type: 'error'
            })
          }
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    additem () { // 节目添加
      let param = {
        programName: this.ruleFormadd.itemName,
        page: {
          playTime: this.ruleFormadd.itemTime,
          windowsList: this.backStage
        }
      }
      itemadd(param).then(res => {
        if (res.data.code === '00000') {
          this.$emit('showstate')
          this.$message({
            showClose: true,
            message: '添加成功',
            type: 'success'
          })
          this.$emit('closeDialog')
          this.resetForm('ruleFormadd')
        } else {
          this.$message({
            showClose: true,
            message: res.data.message ? res.data.message : '添加失败',
            type: 'error'
          })
        }
      })
        .catch(err => {
          console.log(err)
        })
    },
    // changeValue (value) {
    //   let obj = {}
    //   obj = this.alldata.find((item) => {
    //     return item.value === value
    //   })
    //   // console.log(obj.id)
    //   this.black = this.alldata[obj.id - 1]
    // },
    closeEvent () { // 关闭按钮
      this.$emit('closeDialog')
      this.resetForm('ruleFormadd')
    },
    showCustom (item) { // 点击添加节目
      this.currentObj = item
      this.activeItemId = item.id
      this.showaddDialog = true
    },
    closeCustom () { // 接收来自子组件的关闭命令
      this.activeItemId = ''
      this.showaddDialog = false
    },
    // storagemessage (storagedata) {
    //   this.storagedata = storagedata
    //   console.log(JSON.stringify(storagedata)) :pullData="storagedata" @storagemessage="storagemessage"
    // },
    showmessage (mdata) { // 把子组件的下拉素材选中信息放在当前点击添加节目区域里
      this.backStage.forEach(e => {
        if (e.id === this.currentObj.id) {
          e['childWords'] = mdata
          this.$set(e, 'isShowText', true)
        }
      })
    },
    // showinputmessage (inputdata) { // 把子组件的自定义文本信息放在当前点击添加节目区域里
    //   this.backStage.forEach(e => {
    //     if (e.id === this.currentObj.id) {
    //       e['childWords'] = inputdata
    //       this.$set(e, 'isShowText', true)
    //     }
    //   })
    // },
    showdioalogmessage (dioalogdata) { // 接收来自子组件页面中的post参数
      this.backStage.forEach((item, index) => {
        if (item.id === this.activeItemId) {
          this.backStage[index] = Object.assign(this.backStage[index], dioalogdata)
        }
      })
      this.activeItemId = ''
      this.showaddDialog = false
    },
    checkPlayTime (rule, value, callback) { // 字体大小
      if (value === '') {
        return callback(new Error('播放时间不能为空'))
      }
      setTimeout(() => {
        if (!Number.isInteger(value)) {
          callback(new Error('请输入数字值'))
        } else {
          if (value >= 60 && value <= 604800) {
            callback()
          } else {
            callback(new Error('播放时间必须在一分钟到一周的范围内'))
          }
        }
      }, 100)
    }
  },
  updated () {
  }
}
</script>
<style lang="less" scoped>
.form-tip {
  display: inline-block;
  margin-left: 62px;
  color: #f56c6c;
}
.content {
  display: inline-block;
  width: 960px;
  height: 540px;
  margin-top: 20px;
  border: 1px solid gray;
  position: relative;
  .littlebox {
    position: absolute;
    border: 1px solid #409eff;
    text-align: center;
    top: 0;
    left: 0;
    width: 100px;
    height: 100px;
    display: flex;
    align-items: center;
    justify-content: center;
    .itembox {
      width: 100px;
      height: auto;
      display: inline-block;
    }
  }
}
.item-button {
  text-align: center;
  margin-left: -100px;
  margin-top: 15px;
}
</style>

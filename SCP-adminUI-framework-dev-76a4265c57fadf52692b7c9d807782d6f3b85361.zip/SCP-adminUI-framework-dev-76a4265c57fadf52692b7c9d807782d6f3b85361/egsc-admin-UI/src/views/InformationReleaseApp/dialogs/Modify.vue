<template>
  <div>
    <el-dialog :visible="show" width="40%" center @close="closeEvent(false)" class="dialog">
      <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
        <el-row :gutter="20">
          <el-col :span="3">
            <div class="grid-content" style="min-height:10px"></div>
          </el-col>
          <el-col :span="21">
            <div class="grid-content">
              <el-form-item label="日程名称">
                <el-input style="width:300px" v-model="ruleForm.scheduleName"></el-input>
              </el-form-item>
            </div>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="3">
            <div class="grid-content" style="min-height:10px"></div>
          </el-col>
          <el-col :span="21">
            <div class="grid-content">
              <el-form-item label="节目列表">
                <el-select v-model="ruleForm.region" placeholder="请选择节目列表">
                  <el-option v-for="item in alldata" :key="item.id" :label="item.name" :value="item.id"></el-option>
                </el-select>
              </el-form-item>
            </div>
          </el-col>
        </el-row>
        <template>
          <div style="text-align:center">
            <el-button v-for='(it,index) in buttontype' @click='opendate(index)' :key="index" :class="{'button':ind===index}" type="info">{{it.name}}</el-button>
          </div>
          <div v-show="showday" class="time-picker" style="text-align:center">
            <!-- <el-time-picker value-format='HH:mm:ss' type="time" @change="getTime" is-range v-model="value4" range-separator="至" start-placeholder="开始时间" end-placeholder="结束时间" placeholder="选择时间范围">
            </el-time-picker> -->
            <el-date-picker v-model="value3" value-format='yyyy-MM-dd HH:mm:ss' type="datetimerange" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期">
            </el-date-picker>
          </div>
          <div v-show="showweek" class="week-content">
            <div class="week-all">
              <div class="week-picker" v-for='(pro,index) in blankbox' :key="index">
                <span style="margin-right:15px" :weekId="index+1">{{pro.dayOfWeek}}</span>
                <el-time-picker :editable='false' value-format='HH:mm:ss' type="time" v-model="pro.value1" is-range range-separator="至" start-placeholder="开始时间" end-placeholder="结束时间" placeholder="选择时间范围">
                </el-time-picker>
              </div>
            </div>
          </div>
        </template>
        <el-form-item style="text-align:center;margin-left:-100px">
          <el-button type="primary" @click="submitForm('ruleForm')">添加</el-button>
          <el-button @click="resetForm('ruleForm')">重置</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>
  </div>
</template>
<script>
import { getItemList, getScheduleById } from '../apis/index'
export default {
  props: {
    show: {
      type: Boolean,
      required: true,
      default () {
        return false
      }
    },
    modifyParam: {}
  },
  data () {
    return {
      scheduleName: '',
      id: '',
      alldata: [],
      ruleForm: {},
      rules: {
        name: [
          { required: true, message: '请输入日程名称', trigger: 'blur' }
        ],
        item: [
          { required: true, message: '请选择节目列表', trigger: 'change' }
        ]
      },
      weekId: '',
      dayOfWeek: '',
      begintime: '',
      endtime: '',
      input10: '',
      time: '',
      type: 'daily',
      ind: 0,
      showweek: false,
      showday: true,
      array: [],
      currentObj: '',
      value: '',
      blankbox: [{
        dayOfWeek: 'monday',
        id: '1',
        childWords: '',
        value1: []
      }, {
        dayOfWeek: 'tuesday',
        id: '2',
        childWords: '',
        value1: []
      }, {
        dayOfWeek: 'wednesday',
        id: '3',
        childWords: '',
        value1: []
      }, {
        dayOfWeek: 'thursday',
        id: '4',
        childWords: '',
        value1: []
      }, {
        dayOfWeek: 'friday',
        id: '5',
        childWords: '',
        value1: []
      }, {
        dayOfWeek: 'saturday',
        id: '6',
        childWords: '',
        value1: []
      }, {
        dayOfWeek: 'sunday',
        id: '7',
        childWords: '',
        value1: []
      }],
      buttontype: [{
        name: '按日期选择',
        id: '1'
      }, {
        name: '按周选择',
        id: '2'
      }],
      timedata: [{
        name: '星期一',
        id: '1'
      }, {
        name: '星期二',
        id: '2'
      }, {
        name: '星期三',
        id: '3'
      }, {
        name: '星期四',
        id: '4'
      }, {
        name: '星期五',
        id: '5'
      }, {
        name: '星期六',
        id: '6'
      }, {
        name: '星期日',
        id: '7'
      }],
      value3: ''
    }
  },
  watch: {
    show (val) {
      if (val) {
        this.getScheduleEdit()
      }
    }
  },
  mounted () {
    this.getItemLists()
  },
  methods: {
    closeEvent () {
      this.$emit('closemodifyDialog')
    },
    getItemLists () {
      getItemList({})
        .then(res => {
          this.alldata = res.data.data
        }).catch(res => {
          console.log(res)
        })
    },
    getScheduleEdit () {
      let params = this.modifyParam
      getScheduleById(params).then(rs => {
        if (rs.data.code === '00000') {
          // 判断结果是否不为空
          this.ruleForm = rs.data.data
          console.log(rs)
        } else {
          console.log(rs.data)
        }
      })
    },
    opendate (index) {
      // console.log('当前位置' + index)
      this.ind = index
      if (index === 0) {
        this.type = 'daily'
        this.showday = true
        this.showweek = false
      } else {
        this.type = 'weekly'
        this.showweek = true
        this.showday = false
      }
    }
  }
}
</script>

<style lang="less" scoped>
.content {
  // text-align: center;
  overflow: hidden;
  height: 300px;
  .typetitle {
    text-align: left;
    margin-bottom: 30px;
  }
}
.time-picker {
  margin-top: 25px;
  margin-bottom: 25px;
  text-align: center;
  // margin-left: -50%;
}
.button {
  background-color: #409eff;
}
.week-content {
  margin-top: 15px;
  text-align: center;
  // overflow: hidden;
  .week-all {
    // display: inline-block;
    // width: 880px;
    height: auto;
    .week-picker {
      // padding: 0 14px;
      margin-bottom: 15px;
      // display: inline-block;
      // float: left;
    }
  }
}
.buttontag1 {
  margin-right: 110px;
  cursor: pointer;
}
.buttontag {
  width: 153px;
  height: auto;
  display: inline-block;
  margin-right: 15px;
}
</style>
<template>
  <div>
    <el-dialog :visible="show" width="40%" center @close="closeEvent(false)" class="dialog">
      <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
        <el-row :gutter="20">
          <el-col :span="3">
            <div class="grid-content" style="min-height:10px"></div>
          </el-col>
          <el-col :span="21">
            <div class="grid-content">
              <el-form-item label="日程名称" prop="name">
                <el-input style="width:300px" v-model.trim="ruleForm.name" placeholder="字符长度不能超过32个" :maxlength="32"></el-input>
              </el-form-item>
            </div>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="3">
            <div class="grid-content" style="min-height:10px"></div>
          </el-col>
          <el-col :span="21">
            <div class="grid-content">
              <el-form-item label="节目列表" prop="item">
                <el-select v-model="ruleForm.item" @change="handleChangeitem" placeholder="请选择节目列表">
                  <el-option v-for="item in alldata" :key="item.id" :label="item.name" :value="item.id"></el-option>
                </el-select>
              </el-form-item>
            </div>
          </el-col>
        </el-row>
        <template>
          <div style="text-align:center">
            <el-button v-for='(it,index) in buttontype' @click='opendate(index)' :key="index" :class="{'button':ind===index}" type="info">{{it.name}}</el-button>
          </div>
          <div v-show="showday" class="time-picker" style="text-align:center">
            <el-form-item prop="date1">
              <el-date-picker v-model="value3" :editable='false' value-format='yyyy-MM-dd HH:mm:ss' type="datetimerange" @change="getTime1" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期">
              </el-date-picker>
              <!-- <el-time-picker is-range arrow-control v-model="value3" value-format='HH:mm:ss' @change="getTime1" range-separator="至" start-placeholder="开始时间" end-placeholder="结束时间" placeholder="选择时间范围">
              </el-time-picker> -->
            </el-form-item>
          </div>
          <div v-show="showweek" class="week-content">
            <div class="week-all">
              <el-form-item prop="date2" ref="date2Item">
                <div class="week-picker" v-for='(pro,index) in blankbox' :key="index">
                  <el-form-item>
                    <span style="margin-right:15px;" :weekId="index+1">{{pro.dayOfWeek}}</span>
                    <el-time-picker value-format='HH:mm:ss' v-model="pro.value1" @change="getTime2" :editable='false' is-range range-separator="至" start-placeholder="开始时间" end-placeholder="结束时间" placeholder="选择时间范围">
                    </el-time-picker>
                  </el-form-item>
                </div>
              </el-form-item>
            </div>
          </div>
        </template>
        <el-form-item style="text-align:center;margin-left:-100px">
          <el-button type="primary" @click="submitForm('ruleForm')">添加</el-button>
          <el-button @click="resetForm('ruleForm')">重置</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>
  </div>
</template>
<script>
import { getItemList, addSchedule } from '../apis/index'
export default {
  name: 'material',
  props: {
    show: {
      type: Boolean,
      required: true,
      default () {
        return false
      }
    }
  },
  data () {
    return {
      value88: [],
      alldata: [],
      ruleForm: {
        name: '',
        item: '',
        date1: '',
        date2: ''
      },
      rules: {
        name: [
          { required: true, message: '请输入日程名称', trigger: 'blur' }
        ],
        item: [
          { required: true, message: '请选择节目列表', trigger: 'change' }
        ],
        date1: [
          { validator: this.validFormDate1, trigger: 'change' }
        ],
        date2: [
          { validator: this.validFormDate2, trigger: 'change' }
        ]
      },
      weekId: '',
      dayOfWeek: '',
      begintime: '',
      endtime: '',
      input10: '',
      time: '',
      type: 'daily',
      ind: 0,
      showweek: false,
      showday: true,
      array: [],
      currentObj: '',
      value: '',
      blankbox: [{
        dayOfWeek: 'monday',
        id: '1',
        childWords: '',
        value1: null
      }, {
        dayOfWeek: 'tuesday',
        id: '2',
        childWords: '',
        value1: null
      }, {
        dayOfWeek: 'wednesday',
        id: '3',
        childWords: '',
        value1: null
      }, {
        dayOfWeek: 'thursday',
        id: '4',
        childWords: '',
        value1: null
      }, {
        dayOfWeek: 'friday',
        id: '5',
        childWords: '',
        value1: null
      }, {
        dayOfWeek: 'saturday',
        id: '6',
        childWords: '',
        value1: null
      }, {
        dayOfWeek: 'sunday',
        id: '7',
        childWords: '',
        value1: null
      }],
      buttontype: [{
        name: '按日期选择',
        id: '1'
      }, {
        name: '按周选择',
        id: '2'
      }],
      timedata: [{
        name: '星期一',
        id: '1'
      }, {
        name: '星期二',
        id: '2'
      }, {
        name: '星期三',
        id: '3'
      }, {
        name: '星期四',
        id: '4'
      }, {
        name: '星期五',
        id: '5'
      }, {
        name: '星期六',
        id: '6'
      }, {
        name: '星期日',
        id: '7'
      }],
      value3: []
    }
  },
  watch: {
    show (val) {
      if (val) {
        this.getItemLists()
      }
    }
  },
  methods: {
    handleChangeitem (value) { // 选择节目列表
      // console.log(value)
      this.ruleForm.item = value
    },
    getItemLists () { // 获取节目列表信息
      getItemList({})
        .then(res => {
          this.alldata = res.data.data
        }).catch(res => {
          // console.log(res)
        })
    },
    submitForm (formName) { // 添加日程(表单提交)
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.addSche()
          // this.$emit('closeDialog')
        } else {
          return false
        }
      })
    },
    resetForm (formName) { // 重置按钮
      this.$refs[formName].resetFields()
      this.value3 = []
      this.blankbox.forEach((ele) => {
        ele.value1 = null
      })
      this.ruleForm.date1 = ''
      this.ruleForm.date2 = ''
      this.ruleForm.dateArr = []
    },
    addSche () { // 添加日程
      let param = {
        scheduleName: this.ruleForm.name,
        scheduleType: this.type,
        createUser: 'admin',
        programNo: this.ruleForm.item,
        dailySchedule: {
          platspan: this.value3
        },
        weekSchedule: this.blankbox
      }
      addSchedule(param).then(res => {
        this.$emit('showstate')
        // this.resetForm('ruleForm')
        if (res.data.code === '00000') {
          this.resetForm('ruleForm')
          this.value3 = []
          this.blankbox.forEach(ele => {
            ele.value1 = null
          })
          // this.$emit('closeDialog')
          this.$message({
            message: '添加日程成功',
            type: 'success'
          })
          this.$emit('closeDialog')
        } else {
          this.$message.error('添加日程失败')
        }
      })
    },
    // handleChange (val) {
    //   // console.log(val)
    //   this.ruleForm.name = val
    // },
    closeEvent (parameter) { // 点×关闭对话框
      if (!parameter) {
        this.$emit('closeDialog')
        this.resetForm('ruleForm')
      }
      // else {
      //   // console.log(1)

      //   console.log(22222221)
      //   this.blankbox.forEach(e => {
      //     if (e.childWords !== '') {
      //       this.array.push(e.name + ':')
      //       this.array.push(e.childWords)
      //     }
      //   })
      //   console.log('返回的时间' + this.array)
      // }
    },
    getTime1 (time) { // 获取按日播放时间
      this.ruleForm.date1 = time
      let startTime = []
      let endTime = []
      // startTime = time[0].split(' ')
      // endTime = time[1].split(' ')
      if (time && time.length !== 0) {
        startTime = time[0].split(' ')
        endTime = time[1].split(' ')
        if (this.ruleForm.date1[0] >= this.ruleForm.date1[1]) {
          this.ruleForm.date1 = ''
          this.value3 = []
          this.$message({
            message: '开始时间不能大于或等于结束时间',
            type: 'error'
          })
        } else if (startTime[0] !== endTime[0]) {
          this.ruleForm.date1 = ''
          this.value3 = []
          this.$message({
            message: '开始时间必须和结束时间在同一天内',
            type: 'error'
          })
        } else {
          this.ruleForm.date1 = time
        }
      }
    },
    getTime2 (time) { // 获取按周播放时间
      let aaa = 0
      this.blankbox.forEach(el => {
        if (el.value1 === null) {
          aaa++
        }
      })
      if (aaa === 7) {
        this.ruleForm.date2 = ''
      }
      if (!time) return
      this.ruleForm.date2 = time
      if (this.ruleForm.date2[0] >= this.ruleForm.date2[1]) {
        this.blankbox.forEach(el => {
          if (el.value1 === this.ruleForm.date2) {
            el.value1 = null
          }
        })
        this.$message({
          message: '开始时间不能大于结束时间',
          type: 'error'
        })
      } else {
        this.ruleForm.date2 = time
      }
      this.$refs.date2Item.onFieldChange()
    },
    // choosetime ($this) {
    //   this.currentObj = $this
    // },
    opendate (index) { // 显示和隐藏按日或按周播放按钮
      // console.log('当前位置' + index)
      this.ind = index
      if (index === 0) {
        this.type = 'daily'
        this.showday = true
        this.showweek = false
      } else {
        this.type = 'weekly'
        this.showweek = true
        this.showday = false
      }
    },
    validFormDate1 (rule, value, callback) { // 提交添加日程时的自定义属性,让按日播放的时间不能为空
      if (this.ind === 0) {
        if (value) callback()
        else callback(new Error('请选择日期'))
      } else callback()
    },
    validFormDate2 (rule, value, callback) { // 提交添加日程时的自定义属性,让按周播放的时间不能为空
      if (this.ind === 1) {
        if (value) callback()
        else callback(new Error('请至少选择一个日期'))
      } else callback()
    }
  }
}
</script>
<style lang="less" scoped>
.content {
  // text-align: center;
  overflow: hidden;
  height: 300px;
  .typetitle {
    text-align: left;
    margin-bottom: 30px;
  }
}
.time-picker {
  margin-top: 25px;
  margin-bottom: 25px;
  text-align: center;
  // margin-left: -50%;
}
.button {
  background-color: #409eff;
}
.week-content {
  margin-top: 15px;
  text-align: center;
  // overflow: hidden;
  .week-all {
    // display: inline-block;
    // width: 880px;
    height: auto;
    .week-picker {
      // padding: 0 14px;
      margin-bottom: 15px;
      width: 75%;
      text-align: right;
      // display: inline-block;
      // float: left;
    }
  }
}
.buttontag1 {
  margin-right: 110px;
  cursor: pointer;
}
.buttontag {
  width: 153px;
  height: auto;
  display: inline-block;
  margin-right: 15px;
}
</style>

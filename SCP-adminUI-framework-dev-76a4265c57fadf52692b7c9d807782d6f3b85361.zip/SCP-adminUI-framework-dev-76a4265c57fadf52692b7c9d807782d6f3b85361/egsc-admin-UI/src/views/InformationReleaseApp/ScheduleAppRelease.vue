<template>
  <div>
    <el-col :span="24" class="toolbar" style="padding-bottom: 0px;">
      <el-form :inline="true" :model="filters">
        <el-form-item label="日程名称">
          <el-input style="width:180px" v-model.trim="filters.name" placeholder="字符长度不能超过32个" :maxlength="32"></el-input>
        </el-form-item>
        <el-form-item label="信息屏名称">
          <el-input style="width:180px" v-model.trim="filters.screenName" placeholder="字符长度不能超过32个" :maxlength="32"></el-input>
        </el-form-item>
        <el-form-item label="发布人">
          <el-input style="width:180px" v-model.trim="filters.creater" placeholder="字符长度不能超过32个" :maxlength="32"></el-input>
        </el-form-item>
        <el-form-item label="发布状态">
          <el-select style="width:180px" v-model="filters.publishState" placeholder="请选择发布状态">
            <el-option label="全部" value=""></el-option>
            <el-option label="未发布" value="unpublish"></el-option>
            <el-option label="已发布" value="success"></el-option>
            <el-option label="发布中" value="publishing"></el-option>
            <el-option label="发布失败" value="fail"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="创建时间">
          <el-date-picker v-model="filters.createTime" :editable='false' value-format="yyyy-MM-dd HH:mm:ss" type="datetimerange" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期">
          </el-date-picker>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" v-on:click="queryData">查询</el-button>
        </el-form-item>
      </el-form>
    </el-col>
    <el-table :data="data" border style="width: 100%">
      <el-table-column type="index" label="序号" width="100">
      </el-table-column>
      <el-table-column prop="scheduleName" label="日程名称" width="200">
      </el-table-column>
      <!-- <el-table-column prop="weekySchedule || dailySchedule" label="播放时间">
        <template slot-scope="props">
          <p v-if="props.row.weekySchedule">
            {{props.row.weekySchedule}}
          </p>
          <p v-else-if="props.row.dailySchedule">
            {{props.row.dailySchedule}}
          </p>
        </template>
      </el-table-column> -->
      <el-table-column prop="deviceName" label="设备">
      </el-table-column>
      <el-table-column prop="createUser" label="发布人">
      </el-table-column>
      <el-table-column prop="publishState" label="发布状态">
      </el-table-column>
      <el-table-column prop="createTime" label="创建时间">
      </el-table-column>
    </el-table>
    <div class='page-bar' v-show="data&&data.length">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page.sync="pageData.pageNo" :page-sizes="[10]" :page-size="pageData.pageSize" layout=" total, sizes,prev, pager, next, jumper" :total="pageData.total">
      </el-pagination>
    </div>
  </div>
</template>
<script>
import { scheduleReleasesQueries } from './apis/index'
export default {
  name: 'material',
  data () {
    return {
      // listLoading: false,
      filters: {
        name: '',
        screenName: '',
        creater: '',
        publishState: '',
        createTime: ''
      },
      data: [],
      pageData: {
        pageSize: 10,
        pageNo: 1,
        total: 0
      }
    }
  },
  mounted () {
    this.queryData()
  },
  methods: {
    queryData () { // 加载素材列表//查询按钮
      if (this.filters.createTime === null) {
        this.filters.createTime = ''
      }
      let param = {
        pageSize: this.pageData.pageSize,
        pageNo: this.pageData.pageNo,
        scheduleName: this.filters.name,
        createUser: this.filters.creater,
        startTime: this.filters.createTime[0],
        endTime: this.filters.createTime[1],
        deviceName: this.filters.screenName,
        publishState: this.filters.publishState
      }
      // this.listLoading = true
      scheduleReleasesQueries(param).then(res => {
        // this.listLoading = false
        if (res.data.code === '00000') {
          if (res.data.data.datas && res.data.data.datas.length) {
            this.data = res.data.data.datas
            this.pageData.total = res.data.data.total
          } else {
            this.data = []
            this.pageData.total = 0
            this.$message({
              showClose: true,
              message: '暂无数据',
              type: 'error'
            })
          }
        } else {
          this.data = []
          this.pageData.total = 0
          this.$message({
            showClose: true,
            message: '数据加载失败',
            type: 'error'
          })
        }
      }).catch(err => {
        console.log(err)
      })
    },
    handleSizeChange (val) {
      this.pageData.pageSize = val
      this.queryData()
    },
    handleCurrentChange (val) {
      this.pageData.pageNo = val
      this.queryData()
    }
  }
}
</script>
<style scoped>
.page-bar {
  margin-top: 10px;
  text-align: center;
}
.handle-control {
  margin-bottom: 15px;
}
</style>

// 定义路由路径数组列表
export default [
  {
    path: '/infoappindex/materialapp',
    name: 'MaterialApp',
    component: resolve => require(['@/views/InformationReleaseApp/MaterialApp.vue'], resolve)
  },
  {
    path: '/infoappindex/programapp',
    name: 'ProgramApp',
    component: resolve => require(['@/views/InformationReleaseApp/ProgramApp.vue'], resolve)
  },
  {
    path: '/infoappindex/scheduleapp',
    name: 'ScheduleApp',
    component: resolve => require(['@/views/InformationReleaseApp/ScheduleApp.vue'], resolve)
  }
  // {
  //   path: '/infoappindex/scheduleapprelease',
  //   name: 'ScheduleAppRelease',
  //   component: resolve => require(['@/views/InformationReleaseApp/ScheduleAppRelease.vue'], resolve)
  // }
]

<template>
  <div>
    <div class="handle-control">
      <el-row>
        <el-button @click="showUpload" type="primary" icon="el-icon-upload">上传素材</el-button>
      </el-row>
    </div>
    <el-col :span="24" class="toolbar" style="padding-bottom: 0px;">
      <el-form :inline="true" :model="filters">
        <el-form-item label="素材名称">
          <el-input v-model.trim="filters.name" placeholder="字符长度不能超过32个" :maxlength="32"></el-input>
        </el-form-item>
        <el-form-item label="素材类型">
          <el-select clearable v-model="filters.materialType" placeholder="素材类型">
            <el-option label="文本" value="0"></el-option>
            <el-option label="图片" value="1"></el-option>
            <el-option label="音频" value="2"></el-option>
            <el-option label="视频" value="3"></el-option>
            <el-option label="PDF文件" value="4"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="创建人">
          <el-input v-model.trim="filters.creater" placeholder="字符长度不能超过32个" :maxlength="32"></el-input>
        </el-form-item>
        <el-form-item label="创建时间">
          <el-date-picker v-model="filters.createTime" :editable='false' value-format="yyyy-MM-dd HH:mm:ss" type="datetimerange" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期">
          </el-date-picker>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" v-on:click="queryData">查询</el-button>
        </el-form-item>
      </el-form>
    </el-col>
    <el-table :data="data" border style="width: 100%">
      <el-table-column type="index" label="序号" width="100">
      </el-table-column>
      <el-table-column prop="mediaName" label="素材名称" width="200">
      </el-table-column>
      <el-table-column prop="meidaTypeDescription" label="素材类型">
      </el-table-column>
      <el-table-column prop="size" label="大小">
      </el-table-column>
      <el-table-column prop="duration" label="时长(单位/s)">
      </el-table-column>
      <el-table-column prop="mediaUrl" label="素材地址">
        <template slot-scope="scope">
          <a :href="scope.row.mediaUrl" :download="scope.row.mediaUrl">点击查看</a>
        </template>
      </el-table-column>
      <el-table-column prop="createUser" label="创建人">
      </el-table-column>
      <!-- <el-table-column prop="updateUser" label="修改人">
      </el-table-column> -->
      <el-table-column prop="createTime" label="创建时间">
      </el-table-column>
      <el-table-column fixed="right" label="操作" width="100">
        <template slot-scope="scope">
          <el-button @click="delMaterial(scope.$index,scope.row)" type="text" size="small">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class='page-bar' v-show="data&&data.length">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page.sync="pageData.pageNo" :page-sizes="[10]" :page-size="pageData.pageSize" layout=" total, sizes,prev, pager, next, jumper" :total="pageData.total">
      </el-pagination>
    </div>
    <materialUpload :show="showUploadDialog" @closeDialog="closeDialog" @showmaterialapp="showmaterialapp"></materialUpload>
  </div>
</template>
<script>
import { materialdelete, getMaterials } from './apis/index' // materialList//getMaterials
import materialUpload from './dialogs/MaterialUpload'
export default {
  name: 'material',
  components: { materialUpload },
  data () {
    return {
      // listLoading: false,
      filters: {
        name: '',
        materialType: '',
        creater: '',
        createTime: ''
      },
      data: [],
      pageData: {
        pageSize: 10,
        pageNo: 1,
        total: 0
      },
      showUploadDialog: false
    }
  },
  mounted () {
    this.queryData()
  },
  methods: {
    queryData () {
      if (this.filters.createTime === null) { // 查询素材列表
        this.filters.createTime = ''
      }
      let param = {
        mediaName: this.filters.name,
        pageNo: this.pageData.pageNo,
        pageSize: this.pageData.pageSize,
        startTime: this.filters.createTime[0],
        endTime: this.filters.createTime[1],
        type: this.filters.materialType,
        creater: this.filters.creater
      }
      // this.listLoading = true
      getMaterials(param).then(res => {
        // this.listLoading = false
        if (res.data.code === '00000') {
          if (res.data.data.datas && res.data.data.datas.length) {
            this.data = res.data.data.datas
            this.pageData.total = res.data.data.total
          } else {
            this.data = []
            this.pageData.total = 0
            this.$message({
              showClose: true,
              message: '暂无数据',
              type: 'error'
            })
          }
        } else {
          this.data = []
          this.pageData.total = 0
          this.$message({
            showClose: true,
            message: '数据加载失败',
            type: 'error'
          })
        }
      }).catch(err => {
        console.log(err)
      })
    },
    showUpload () {
      this.showUploadDialog = true
    },
    closeDialog () {
      this.showUploadDialog = false
    },
    showmaterialapp () {
      this.queryData()
      this.showUploadDialog = false
    },
    delMaterial (index, rowData) {
      this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        materialdelete({ mediaId: rowData.materialId }).then(rs => {
          if (rs.data.code === '00000') {
            this.queryData()
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
          } else {
            this.$message({
              type: 'error',
              message: rs.data.message ? rs.data.message : '删除失败!'
            })
          }
        })
          .catch(err => {
            console.log(err)
          })
      }).catch(() => {
        this.$message({
          type: 'error',
          message: '已取消删除'
        })
      })
    },
    handleSizeChange (val) {
      this.pageData.pageSize = val
      this.queryData()
    },
    handleCurrentChange (val) {
      this.pageData.pageNo = val
      this.queryData()
    }
  }
}
</script>
<style scoped>
.page-bar {
  margin-top: 10px;
  text-align: center;
}
.handle-control {
  margin-bottom: 15px;
}
</style>

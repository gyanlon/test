<template>
  <div>
    <div class="time-button">
      <el-button @click="customtime" type="primary">添加日程</el-button>
    </div>
    <el-col :span="24" class="toolbar" style="padding-bottom: 0px;">
      <el-form :inline="true" :model="filters">
        <el-form-item label="日程名称">
          <el-input style="width:180px" v-model.trim="filters.scheduleName" placeholder="字符长度不能超过32个" :maxlength="32"></el-input>
        </el-form-item>
        <el-form-item label="播放类型">
          <el-select style="width:180px" v-model="filters.scheduleType" placeholder="请选择播放类型">
            <el-option label="全部" value=""></el-option>
            <el-option label="按日播放" value="daily"></el-option>
            <el-option label="按周播放" value="weekly"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="创建人">
          <el-input style="width:180px" v-model.trim="filters.createUser" placeholder="字符长度不能超过32个" :maxlength="32"></el-input>
        </el-form-item>
        <el-form-item label="发布状态">
          <el-select style="width:180px" v-model="filters.publishState" placeholder="请选择发布状态">
            <el-option label="全部" value=""></el-option>
            <el-option label="未发布" value="unpublish"></el-option>
            <el-option label="已发布" value="success"></el-option>
            <el-option label="发布中" value="publishing"></el-option>
            <el-option label="发布失败" value="fail"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-form-item label="创建时间">
            <el-date-picker v-model="filters.createTime" value-format="yyyy-MM-dd HH:mm:ss" :editable="false" type="datetimerange" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期">
            </el-date-picker>
          </el-form-item>
        </el-form-item>
        <el-form-item>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" v-on:click="timeMaterial">查询</el-button>
        </el-form-item>
      </el-form>
    </el-col>
    <div class="content">
      <el-table :data="data" border style="width: 100%">
        <el-table-column type="index" label="序号" align="center" width="50">
        </el-table-column>
        <el-table-column prop="scheduleName" label="日程名称" align="center" min-width="180">
        </el-table-column>
        <el-table-column prop="weekySchedule || dailySchedule" label="播放时间" align="center" min-width="200">
          <template slot-scope="props">
            <p v-if="props.row.weekySchedule">
              {{props.row.weekySchedule}}
            </p>
            <p v-else-if="props.row.dailySchedule">
              {{props.row.dailySchedule}}
            </p>
          </template>
        </el-table-column>
        <el-table-column prop="typeDescription" label="播放类型" align="center" min-width="180">
        </el-table-column>
        <el-table-column prop="createTime" label="创建时间" align="center" min-width="180">
        </el-table-column>
        <el-table-column prop="createUser" label="创建人" align="center" min-width="180">
        </el-table-column>
        <el-table-column prop="publishState" label="发布状态" align="center" min-width="180">
        </el-table-column>
        <el-table-column label="操作" align="center" min-width="100">
          <template slot-scope="scope">
            <el-button @click="handleModify(scope.$index,scope.row)" type="text" size="small" style="display:none">编辑</el-button>
            <el-button type="text" size="small" @click="IssueDialog(scope.$index,scope.row)">发布</el-button>
            <el-button type="text" @click="deleteSche(scope.$index,scope.row)" size="small">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class='page-bar' v-show="data&&data.length" style="margin-top:15px">
        <el-pagination style="text-align:center" small @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="pageData.pageNo" :page-sizes="[5, 10, 15]" :page-size="pageData.pageSize" layout="total, sizes, prev, pager, next, jumper" :total="pageData.total">
        </el-pagination>
      </div>
    </div>
    <customtime :show="showaddDialog" @showstate='showstate' @closeDialog="closeDialog" ref="customtime"></customtime>
    <issueDialog :show="showissueDialog" :param="param" @closeissueDialog="closeissueDialog" @showstate='showstate'></issueDialog>
    <!-- <modifyDialog :show="showmodifyDialog" :modifyParam="modifyParam" @closemodifyDialog="closemodifyDialog"></modifyDialog> -->
  </div>
</template>
<script>
import { getSchedulePage, deleteSchedule } from './apis/index'
import customtime from './dialogs/CustomTime'
import issueDialog from './dialogs/Issue'
// import modifyDialog from './dialogs/Modify'
export default {
  name: 'materialFather',
  components: { customtime, issueDialog },
  data () {
    return {
      param: {
        scheduleId: '',
        createUser: '',
        scheduleName: '',
        releaseType: 'byTerminal'
      },
      modifyParam: {
        id: ''
      },
      filters: {
        scheduleName: '',
        createUser: '',
        scheduleType: '',
        publishState: '',
        createTime: ''
      },
      data: [],
      showaddDialog: false,
      showissueDialog: false,
      showmodifyDialog: false,
      pageData: {
        pageSize: 10,
        pageNo: 1,
        total: 0
      }
    }
  },
  mounted () {
    this.timeMaterial()
  },
  methods: {
    IssueDialog (index, rowData) { // 点击发布按钮scheduleName
      this.showissueDialog = true
      this.param.scheduleId = rowData.id
      this.param.createUser = rowData.createUser
      this.param.releaseType = 'byTerminal'
      this.param.scheduleName = rowData.scheduleName
    },
    closeissueDialog () { // 关闭发布对话框
      this.showissueDialog = false
    },
    closemodifyDialog () { // 关闭编辑对话框(暂时还没写)
      this.showmodifyDialog = false
    },
    deleteSche (index, rowData) { // 删除日程
      this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        deleteSchedule({ id: rowData.id }).then(rs => {
          if (rs.data.code === '00000') {
            this.timeMaterial()
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
          } else {
            this.$message({
              type: 'error',
              message: rs.data.message ? rs.data.message : '删除失败!'
            })
          }
        })
          .catch(err => {
            console.log(err)
          })
      }).catch(() => {
        this.$message({
          type: 'error',
          message: '已取消删除'
        })
      })
    },
    timeMaterial () { // 获取日程列表
      if (this.filters.createTime === null) {
        this.filters.createTime = ''
      }
      let param = {
        pageSize: this.pageData.pageSize,
        pageNo: this.pageData.pageNo,
        scheduleName: this.filters.scheduleName,
        createUser: this.filters.createUser,
        startTime: this.filters.createTime[0],
        endTime: this.filters.createTime[1],
        scheduleType: this.filters.scheduleType,
        publishState: this.filters.publishState
      }
      getSchedulePage(param).then(res => {
        // this.data = res.data.data.datas
        // this.pageData.pageSize = res.data.data.pageSize
        // this.pageData.pageNo = res.data.data.pageNo
        // this.pageData.total = res.data.data.total
        if (res.data.code === '00000') {
          if (res.data.data.datas && res.data.data.datas.length) {
            this.data = res.data.data.datas
            this.pageData.total = res.data.data.total
          } else {
            this.data = []
            this.pageData.total = 0
            this.$message({
              showClose: true,
              message: '暂无数据',
              type: 'error'
            })
          }
        } else {
          this.data = []
          this.pageData.total = 0
          this.$message({
            showClose: true,
            message: '数据加载失败',
            type: 'error'
          })
        }
      }).catch((err) => {
        console.log(err)
      })
    },
    customtime () { // 点击添加日程出现对话框
      this.showaddDialog = true
      // this.$refs.customtime.resetForm('ruleForm')
    },
    closeDialog () { // 关闭添加日程对话框
      this.showaddDialog = false
    },
    handleModify (index, row) { // 编辑按钮(暂时还没写)
      this.showmodifyDialog = true
      console.log(row.id)
      this.modifyParam.id = row.id
    },
    handleSizeChange (val) { // 点击分页按钮 pageSize改变时出发
      this.pageData.pageSize = val
      this.timeMaterial()
    },
    handleCurrentChange (val) { // currentPage 改变时会触发
      this.pageData.pageNo = val
      this.timeMaterial()
    },
    showstate (mstate) { // 父子传值 重新调取分页列表
      // console.log('成功调取一级页面接口')git
      this.timeMaterial()
    }
  }
}
</script>
<style lang="less" scoped>
.time-button {
  margin-bottom: 20px;
}
.content {
  width: 100%;
  height: auto;
}
</style>

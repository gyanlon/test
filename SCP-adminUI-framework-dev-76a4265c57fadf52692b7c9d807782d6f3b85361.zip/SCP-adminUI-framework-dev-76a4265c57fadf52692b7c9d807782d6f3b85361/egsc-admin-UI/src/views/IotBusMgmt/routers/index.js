// 引用pages
import appMgmt from '@/views/IotBusMgmt/components/AppMgmt'
import eventGroupMgmt from '@/views/IotBusMgmt/components/EventGroupMgmt'
// import argMgmt from '@/views/IotBusMgmt/components/ArgMgmt'
// import busMonitor from '@/views/IotBusMgmt/components/BusMonitor'
// import eventMgmt from '@/views/IotBusMgmt/components/EventMgmt'
import subMgmt from '@/views/IotBusMgmt/components/SubMgmt'

// 定义路由路径数组列表
export default[
  {
    path: '/iotbusmgmt/appmgmt',
    name: 'appMgmt',
    component: appMgmt
  },
  {
    path: '/iotbusmgmt/eventgroupmgmt',
    name: 'eventGroupMgmt',
    component: eventGroupMgmt
  },
  // {
  //   path: '/iotbusmgmt/argMgmt',
  //   name: 'argMgmt',
  //   component: argMgmt
  // },
  // {
  //   path: '/iotbusmgmt/busMonitor',
  //   name: 'busMonitor',
  //   component: busMonitor
  // },
  // {
  //   path: '/iotbusmgmt/eventMgmt',
  //   name: 'eventMgmt',
  //   component: eventMgmt
  // },
  {
    path: '/iotbusmgmt/subMgmt',
    name: 'subMgmt',
    component: subMgmt
  }
]

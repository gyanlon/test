export const MOCK_API_URL = '/iotbusconsoleapp'
export const BASE_PATH = '/scp-iotbusconsoleapp'
// export const BASE_PATH = '/api'

import Axios from '@/assets/js/AxiosPlugin'
// import {BASE_PATH} from '../assets/js/common'
import {MOCK_API_URL} from '../assets/js/common'
// const BASE_PATH = '/scp-iotbusconsoleapp'

// 监控指标实时数据
export const getTimelyData = (data) => {
  return Axios.post(MOCK_API_URL + '/monitor/list', data).then(res => res.data)
}

// 监控指标图表测试数据
export const getTestData = (data) => {
  return Axios.post(MOCK_API_URL + '/monitor/busConnections', data).then(res => res.data)
}

import Axios from '@/assets/js/AxiosPlugin'
import {BASE_PATH} from '../assets/js/common'

// const BASE_PATH = '/scp-iotbusconsoleapp'

// 获取IOT应用信息列表分页
export const getAppList = params => {
  return Axios.get(BASE_PATH + '/app/list').then(res => res.data)
}

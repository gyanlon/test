<template>
  <div id='app' class = "ui-common">
    <!--创建一个echarts的容器-->
    
    <div id=tableStyle>
      <div class='inlineDiv'>
        <div class="monitor-title"><i class="el-icon-news"></i> 实时监控数据</div>
        <el-table :data="timelyData" style='width: 700px;' height="233" border>
          <el-table-column prop="argName" label="参数类型">
          </el-table-column>
          <el-table-column prop="realtimeData" label="当前实时数据">
          </el-table-column>
          <el-table-column prop="currentTime" label="数据获取时间">
          </el-table-column>
          <!-- <el-table-column prop="warnValue" label="阀值">
          </el-table-column>
          <el-table-column prop="warnStatus" label="告警状态">
          </el-table-column> -->
        </el-table>
        <div class='inlineDiv button-align'>
          <el-form :inline="true" class="demo-form-inline">
            <el-form-item label="应用：" prop="appItem">
              <el-select v-model="selectAppValue" filterable placeholder="请选择应用名称">
                <el-option
                v-for="item in selectOptions"
                :key="item.appCode"
                :label="item.appName"
                :value="item.appCode">
                </el-option>
              </el-select>
            </el-form-item>
            <el-button class = "search-btn" type="primary" @click="onSearchAppSubmit(selectAppValue)" >查看实时监控</el-button>
          </el-form>
        </div>
      </div>
      <div class='inlineDiv'>
        <div class="monitor-title"><i class="el-icon-news"></i> 告警信息列表</div>
        <el-table :data="warnList" style="width: 700px;" height="290" border>
          <el-table-column prop="warnTime" label="告警时间">
          </el-table-column>
          <el-table-column prop="warnType" label="告警类型">
          </el-table-column>
          <el-table-column prop="argValue" label="阀值">
          </el-table-column>
          <el-table-column prop="warnValue" label="告警值">
            <template slot-scope="scope">
              <span class="warnText">{{ scope.row.warnValue }}</span>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </div>
    <el-row>
        <el-col :span="12"><div id='echartContainer' style='width: 100%; height: 320px'></div></el-col>
        <el-col :span="12"><div id='echartContainer1' style='width: 100%; height: 320px'></div></el-col>
      </el-row>
      <el-row class="button-align monitorApp-dialog">
        <el-col :span="12"><div id='echartContainer2' style='width: 100%; height: 320px'></div></el-col>
        <el-col :span="12"><div id='echartContainer3' style='width: 100%; height: 320px'></div></el-col>
      </el-row>

    <!-- AppRealTimeChart -->
    <el-dialog title="APP实时监控图" :visible.sync="appRealTimeMonitorChartVisible" :before-close="handleClose" style='width: 100%; height: 100%'>
      <el-row class="button-align appMonitorTable">
        <el-col :span="24">
          <el-table :data="appMonitorTableData" style="width: 100%">
            <el-table-column prop="argName" label="参数类型"></el-table-column> 
            <el-table-column prop="realtimeData" label="当前实时数据"></el-table-column>
          </el-table> 
        </el-col>
      </el-row>
      <el-row class="button-align monitorApp-dialog">
        <el-col :span="12"><div id='echartAppChartContainer1' ref="echartAppChartContainer1" style='width: 100%; height: 220px'></div></el-col>
        <el-col :span="12"><div id='echartAppChartContainer2' ref="echartAppChartContainer2" style='width: 100%; height: 220px'></div></el-col>
      </el-row>
      <el-row class="button-align monitorApp-dialog">
        <el-col :span="12"><div id='echartAppChartContainer3' ref="echartAppChartContainer3" style='width: 100%; height: 220px'></div></el-col>
        <el-col :span="12"><div id='echartAppChartContainer4' ref="echartAppChartContainer4" style='width: 100%; height: 220px'></div></el-col>
      </el-row>
    </el-dialog>
  </div>
</template>

<style scoped>
.monitor-title {
    padding: 0 0 10px 10px;
    /* border-bottom: 1px solid #cccccc; */
    /* margin-bottom: 20px; */
    font-size: 17px;
    color: #666666;
    font-weight: bold;
}
.warnText{
  color: red;
  font-weight: bold;
}
.inlineDiv{
  display: inline-block;
  margin: 30px 15px;
}
.monitorApp-dialog{
  margin-top: 15px;
}
.appMonitorTable{
  margin-top: -30px;
}
</style>

<script>
import echarts from 'echarts'
import {getTimelyData, getTestData} from '@/views/IotBusMgmt/apis/iotbus_monitor_api'
import {getAppList} from '@/views/IotBusMgmt/apis/iotbus_busmonitor_api'
import {getArgItems} from '@/views/IotBusMgmt/apis/iotbus_arg_api'

// import {Loading} from 'element-ui'

export default {
  name: 'iotBusMonitor',
  data () {
    return {
      appRealTimeMonitorChartVisible: false,
      selectOptions: [],
      selectAppValue: '',
      appMonitorTableData: [],
      timelyData: [],
      warnList: [],
      iotBusArgList: [],
      testDataX: [],
      testDataY: [],
      //   {
      //     warnId: 1,
      //     warnTime: '2018-01-26 12:05:34',
      //     warnType: '连接数',
      //     warnValue: '1200(阀值1000)'
      //   },
      //   {
      //     warnId: 2,
      //     warnTime: '2018-01-26 12:07:21',
      //     warnType: '响应时间',
      //     warnValue: '2200(阀值1000ms)'
      //   }
      // ],
      option11: {
        title: {
          text: '测试图表'
        },
        tooltip: {
          trigger: 'axis'
        },
        xAxis: {
          // data: this.testDataX.map(function (item) {
          //   return item[1]
          // })
          // data: this.testDataX
          data: [10, 20, 30, 40, 50, 60]
          // data: []
          // data: this.getTestData()
        },
        yAxis: {
          splitLine: {
            show: false
          }
        },
        toolbox: {
          left: 'center',
          feature: {
            dataZoom: {
              yAxisIndex: 'none'
            },
            restore: {},
            saveAsImage: {}
          }
        },
        dataZoom: [{
          // startValue: '2018-1-31 08:30:45'
        }, {
          type: 'inside'
        }],
        visualMap: {
          top: 10,
          right: 10,
          pieces: [{
            gt: 0,
            lte: 15,
            color: '#096'
          }, {
            gt: 15,
            color: '#cc0033'
          }],
          outOfRange: {
            color: '#999'
          }
        },
        series: {
          name: '总线测试数据',
          type: 'line',
          // data: this.testDataX.map(function (item) {
          //   return item[0]
          // }),
          // data: this.testDataY,
          data: [12, 13, 14, 15, 16, 17],
          markLine: {
            silent: true,
            data: [{
              yAxis: 10
            }, {
              yAxis: 15
            }]
          }
        }
      },
      option: {
        title: {
          text: '总线连接数'
        },
        legend: {
          data: ['模拟数据']
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            // animation: false
            type: 'cross',
            label: {
              backgroundColor: '#283b56'
            }
          }
        },
        xAxis: {
          // type: 'time',
          // splitLine: {
          //   show: false
          // }
          type: 'category',
          boundaryGap: true,
          data: (function () {
            var now = new Date()
            var res = []
            var len = 8
            while (len--) {
              res.unshift(now.toLocaleTimeString().replace(/^\D*/, ''))
              now = new Date(now - 1000)
            }
            return res
          })()
        },
        yAxis: {
          type: 'value',
          boundaryGap: [0, '100%'],
          splitLine: {
            show: false
          }
        },
        series: [{
          name: '模拟数据',
          type: 'line',
          showSymbol: false,
          hoverAnimation: false,
          markline: {
            data: [
              [
                {name: 'b1', value: 1000, x: -1, y: 1000},
                {name: 'b2', x: 5, y: 1000}
              ]
            ]
          },
          data: (function () {
            var res = []
            var len = 12
            while (len--) {
              res.push(Math.round(Math.random() * 1000))
            }
            return res
          })()
        }]
      },
      option1: {
        title: {
          text: '队列深度'
        },
        legend: {
          data: ['模拟数据1']
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            // animation: false
            type: 'cross',
            label: {
              backgroundColor: '#283b56'
            }
          }
        },
        xAxis: {
          // type: 'time',
          // splitLine: {
          //   show: false
          // }
          type: 'category',
          boundaryGap: true,
          data: (function () {
            var now = new Date()
            var res = []
            var len = 8
            while (len--) {
              res.unshift(now.toLocaleTimeString().replace(/^\D*/, ''))
              now = new Date(now - 1000)
            }
            return res
          })()
        },
        yAxis: {
          type: 'value',
          boundaryGap: [0, '100%'],
          splitLine: {
            show: false
          }
        },
        series: [{
          name: '模拟数据1',
          type: 'line',
          showSymbol: false,
          hoverAnimation: false,
          markline: {
            data: [
              [
                {name: 'b1', value: 1000, x: -1, y: 1000},
                {name: 'b2', x: 5, y: 1000}
              ]
            ]
          },
          data: (function () {
            var res = []
            var len = 12
            while (len--) {
              res.push(Math.round(Math.random() * 1000))
            }
            return res
          })()
        }]
      },
      option2: {
        title: {
          text: '吞吐量'
        },
        legend: {
          data: ['模拟数据2']
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            // animation: false
            type: 'cross',
            label: {
              backgroundColor: '#283b56'
            }
          }
        },
        xAxis: {
          // type: 'time',
          // splitLine: {
          //   show: false
          // }
          type: 'category',
          boundaryGap: true,
          data: (function () {
            var now = new Date()
            var res = []
            var len = 8
            while (len--) {
              res.unshift(now.toLocaleTimeString().replace(/^\D*/, ''))
              now = new Date(now - 1000)
            }
            return res
          })()
        },
        yAxis: {
          type: 'value',
          boundaryGap: [0, '100%'],
          splitLine: {
            show: false
          }
        },
        series: [{
          name: '模拟数据2',
          type: 'line',
          showSymbol: false,
          hoverAnimation: false,
          markline: {
            data: [
              [
                {name: 'b1', value: 1000, x: -1, y: 1000},
                {name: 'b2', x: 5, y: 1000}
              ]
            ]
          },
          data: (function () {
            var res = []
            var len = 12
            while (len--) {
              res.push(Math.round(Math.random() * 1000))
            }
            return res
          })()
        }]
      },
      option3: {
        title: {
          text: '响应时间'
        },
        legend: {
          data: ['模拟数据3']
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            // animation: false
            type: 'cross',
            label: {
              backgroundColor: '#283b56'
            }
          }
        },
        xAxis: {
          // type: 'time',
          // splitLine: {
          //   show: false
          // }
          type: 'category',
          boundaryGap: true,
          data: (function () {
            var now = new Date()
            var res = []
            var len = 8
            while (len--) {
              res.unshift(now.toLocaleTimeString().replace(/^\D*/, ''))
              now = new Date(now - 1000)
            }
            return res
          })()
        },
        yAxis: {
          type: 'value',
          boundaryGap: [0, '100%'],
          splitLine: {
            show: false
          }
        },
        series: [{
          name: '模拟数据3',
          type: 'line',
          showSymbol: false,
          hoverAnimation: false,
          markline: {
            data: [
              [
                {name: 'b1', value: 1000, x: -1, y: 1000},
                {name: 'b2', x: 5, y: 1000}
              ]
            ]
          },
          data: (function () {
            var res = []
            var len = 12
            while (len--) {
              res.push(Math.round(Math.random() * 1000))
            }
            return res
          })()
        }]
      }
    }
  },
  methods: {
    loadArgData () {
      getArgItems()
        .then(
          function (result) {
            this.iotBusArgList = result.data
            // console.log('iotBusArgList' + this.iotBusArgList)
          }.bind(this)
        )
        .catch(
          function (error) {
            // this.$message.error('服务器请求超时，无法获取数据！')
            console.info(error)
          }
        )
    },
    loadTestData () {
      // console.log('数据类型0' + this.testDataX.constructor)
      getTestData()
        .then(
          function (result) {
            // this.testDataX = result.data
            result.data.forEach((item) => {
              this.testDataX.push(item.currentTime)
            })
            // this.testDataX = result.data
            console.log('x列表：' + this.testDataX)
            // result.data.forEach((item) => {
            //   this.testDataY.push(item.connections)
            // })
            // console.log('y列表：' + this.testDataY)
            return this.testDataX
          }.bind(this)
        )
        .catch(
          function (error) {
            // this.$message.error('服务器请求超时，无法获取数据！')
            console.info(error)
          }
        )
    },
    loadWarnList () {
      // let alertConnections = this.iotBusArgList[0]
      // let alertQueueDepth = this.iotBusArgList[1]
      // let alertCapacity = this.iotBusArgList[2]
      // let alertResponseTime = this.iotBusArgList[3]
      // var item = {}
      // console.log('________________________')
      for (var i = 0; i < 4; i++) {
        // console.log('i为：' + i)
        // console.log(i + 'i1为：' + this.timelyData[i].realtimeData)
        if (this.timelyData[i].realtimeData >= this.iotBusArgList[i].thresholdMax) {
          // console.log('i2为：' + 'haha')
          var item = {}
          item.warnType = this.timelyData[i].argName
          item.warnValue = this.timelyData[i].realtimeData
          item.warnTime = this.timelyData[i].currentTime
          item.argValue = this.iotBusArgList[i].warnValue
          this.warnList.push(item)
          // console.log('我是' + i)
          // console.log(item)
        }
      }
      // this.warnList.shift()
      // console.log('warnList' + this.warnList)
    },
    loadData () {
      getTimelyData()
        .then(function (result) {
          this.timelyData = result.data
          let num = Math.random() * 700 + 800
          num = parseInt(num, 10)
          let num1 = Math.random() * 200 + 100
          num1 = parseInt(num1, 10)
          let num2 = Math.random() * 900 + 100
          num2 = parseInt(num2, 10)
          let num3 = Math.random() * 2500 + 100
          num3 = parseInt(num3, 10)
          this.timelyData[0].realtimeData = num
          this.timelyData[1].realtimeData = num1
          this.timelyData[2].realtimeData = num2
          this.timelyData[3].realtimeData = num3
          // this.timelyData.forEach((item) => console.log('我是timelyData' + item.realtimeData))
        }.bind(this)).catch(
          function (error) {
            // this.$message.error('服务器请求超时，无法获取数据！')
            console.info(error)
          }
        )
    },
    refreshData () {
      this.intervalID = setInterval(() => {
        this.loadData()
        this.loadArgData()
        this.loadWarnList()
        this.loadAppMonitorRTData()
      }, 10100)
    },
    doIt () {
      var myChart = echarts.init(document.getElementById('echartContainer'))
      var myChart1 = echarts.init(document.getElementById('echartContainer1'))
      var myChart2 = echarts.init(document.getElementById('echartContainer2'))
      var myChart3 = echarts.init(document.getElementById('echartContainer3'))
      // var axisData = (new Date()).toLocaleTimeString().replace(/^\D*/, '')
      // var timeData = this.option.series[0].data
      // timeData.shift()
      // timeData.push(Math.round(Math.random() * 1000))
      // var connectData = this.option.xAxis.data
      // connectData.shift()
      // connectData.push(axisData)
      myChart.setOption(this.option11)
      myChart1.setOption(this.option1)
      myChart2.setOption(this.option2)
      myChart3.setOption(this.option3)
    },
    loadSelectAppData () {
      getAppList().then(function (result) {
        this.selectOptions = result.data
      }.bind(this)).catch(function (error) {
        console.log(error)
      })
    },
    loadAppMonitorRTData () {
      getTimelyData()
        .then(function (result) {
          this.appMonitorTableData = result.data
          let num = Math.random() * 700 + 800
          num = parseInt(num, 10)
          let num1 = Math.random() * 200 + 100
          num1 = parseInt(num1, 10)
          let num2 = Math.random() * 900 + 100
          num2 = parseInt(num2, 10)
          let num3 = Math.random() * 2500 + 100
          num3 = parseInt(num3, 10)
          this.appMonitorTableData[0].realtimeData = num
          this.appMonitorTableData[1].realtimeData = num1
          this.appMonitorTableData[2].realtimeData = num2
          this.appMonitorTableData[3].realtimeData = num3
        }.bind(this)).catch(
          function (error) {
            console.info(error)
          }
        )
    },
    onSearchAppSubmit (item) {
      if (item === '') {
        this.appRealTimeMonitorChartVisible = false
      } else {
        this.appRealTimeMonitorChartVisible = true
        this.showAppRTChart()
      }
    },
    showAppRTChart () {
      this.$nextTick(() => {
        this.loadAppMonitorRTData()
        var AppChartContainer1 = echarts.init(document.getElementById(this.$refs.echartAppChartContainer1.id))
        var AppChartContainer2 = echarts.init(document.getElementById(this.$refs.echartAppChartContainer2.id))
        var AppChartContainer3 = echarts.init(document.getElementById(this.$refs.echartAppChartContainer3.id))
        var AppChartContainer4 = echarts.init(document.getElementById(this.$refs.echartAppChartContainer4.id))
        var axisData = (new Date()).toLocaleTimeString().replace(/^\D*/, '')
        var timeData = this.option.series[0].data
        timeData.shift()
        timeData.push(Math.round(Math.random() * 1000))
        var connectData = this.option.xAxis.data
        connectData.shift()
        connectData.push(axisData)
        AppChartContainer1.setOption(this.option)
        AppChartContainer2.setOption(this.option1)
        AppChartContainer3.setOption(this.option2)
        AppChartContainer4.setOption(this.option3)
      })
    },
    handleClose (done) {
      this.appRealTimeMonitorChartVisible = false
    }
  },
  mounted () {
    // this.loadTestData()
    console.log('wos' + this.testDataX)
    this.doIt()
    // this.$nextTick(function () {
    //   this.loadData()
    // })
    this.loadData()
    this.loadArgData()
    // this.loadWarnList()
    this.refreshData()
    this.loadSelectAppData()
    // setInterval(this.loadData(), 2000)
  },
  beforeDestroy () {
    clearInterval(this.intervalID)
  }
}
</script>

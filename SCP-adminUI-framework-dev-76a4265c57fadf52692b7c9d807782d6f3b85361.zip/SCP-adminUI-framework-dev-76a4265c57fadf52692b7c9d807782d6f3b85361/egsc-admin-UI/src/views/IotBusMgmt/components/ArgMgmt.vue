<template>
<div class = "ui-common">
  
  <!-- 主布局 Start -->
<div class="arg-title"><i class="el-icon-news"></i> 监控指标列表</div>
<!-- <div class="border-divide"></div> -->
  <!-- List显示区 -->   
  <div class="flex-1">
    <el-table :data="iotBusArgList" style="width: 100%">
      <!-- <el-table-column type="index"></el-table-column>     -->
      <el-table-column label="监控指标类型" prop="indexName"></el-table-column>
      <el-table-column label="告警阀值" prop="thresholdMax"></el-table-column>
      <!-- <el-table-column label="启用状态" prop="enableFlag" :formatter="enableFlag"></el-table-column> -->
      <!-- <el-table-column label="更新人" prop="updateUser"></el-table-column> -->
      <el-table-column label="最后更新时间" prop="updateTime" :formatter="dateFormat"></el-table-column>
            
      <el-table-column fixed="right" label="操作" width="170" align="center">
          <template slot-scope="scope">            
            <el-button  icon="el-icon-edit" type="text" size="small"  @click="handleEdit(scope.$index, scope.row)">更新阈值</el-button>               
          </template>
      </el-table-column>
    </el-table>
  </div>

 
  <!-- 主布局 End -->


  <!-- 编辑IOT订阅对话框 -->
  <el-dialog
    title="更新监控指标"
    :close-on-click-modal=false
    :close-on-press-escape=false
    :visible.sync="editIotArgDialogVisible"
    width="25%"
    :before-close="handleClose">

    <el-form :model="editIotArg" :rules="rules" ref="updateIotArg" label-width="110px" class="demo-ruleForm">
      <el-form-item label="监控指标类型：" prop="indexName">
        <el-input size="small" v-model="editIotArg.indexName" disabled></el-input>
        <!-- <span>{{ editIotArg.indexName }}</span> -->
      </el-form-item>
      <el-form-item label="告警阀值：" prop="thresholdMax">
        <el-input size="small" v-model="editIotArg.thresholdMax"></el-input>
      </el-form-item>
      <!-- <el-form-item label="是否启用" prop="enableFlag">
        <el-switch v-model="editIotArg.enableStatus">
        </el-switch>
      </el-form-item> -->

      <el-form-item class="text-right add-IotArg-button">
        <el-button type="primary" @click="submitEditForm('updateIotArg')">保存</el-button>
        <el-button @click="handleClose">取消</el-button>
      </el-form-item>
    </el-form>
  </el-dialog>

</div>
</template>


<style scoped>
.arg-title {
    padding: 5px 0 10px 10px;
    border-bottom: 1px solid #cccccc;
    margin-bottom: 20px;
    font-size: 18px;
    color: #666666;
  }
.demo-table-expand {
  font-size: 0;
}
.demo-table-expand label {
  width: 110px;
  color: #99a9bf;
}
.demo-table-expand .el-form-item {
  margin-right: 0;
  margin-bottom: 0;
  width: 50%;
}

.el-table .unenable-row {
  background: oldlace;
}
.el-table .enable-row {
  background: rgb(175, 215, 255); 
}
</style>

<script>
import {getArgItems, updateArgItem} from '@/views/IotBusMgmt/apis/iotbus_arg_api'
import { formatDate } from '../assets/js/tool.js'

export default {
  name: 'iotBusArgList',
  components: {
  },
  data () {
    return {
      editIotArgDialogVisible: false,
      iotBusArgList: [],
      editIotArg: {},
      rules: {
        thresholdMax: [
          // {required: true, message: '不能为空'},
          {required: true, pattern: /^[1-9]\d{0,5}$/, message: '请输入1-6位非零正整数'}
        ]
      }
    }
  },
  methods: {
    // 时间格式化
    dateFormat (row, column) {
      var time = row[column.property]
      // var timeS = time.replace(/(\d{4})-(\d{2})-(\d{2})T(.*)?\.(.*)/, '$1/$2/$3 $4')
      var date = new Date(time)
      return formatDate(date, 'yyyy-MM-dd hh:mm:ss')
    },
    // enableText (row, column) {
    //   var enableKey = row[column.property]
    //   return enableKey ? '启用' : '禁用'
    // },
    loadData () {
      getArgItems()
        .then(
          function (result) {
            this.iotBusArgList = result.data
            // console.log('hello' + this.iotBusArgList)
          }.bind(this)
        )
        .catch(
          function (error) {
            // this.$message.error('服务器请求超时，无法获取数据！')
            console.info(error)
          }
        )
    },
    resetForm (formName) {
      if (this.$refs[formName] !== undefined) {
        this.$refs[formName].resetFields()
      }
    },
    confirmEditIotArg () {
      // this.loadingEditStep = true
      var params = this.editIotArg
      // console.log(params)
      updateArgItem(params)
        .then(
          function (result) {
            // console.log(result)
            // this.loadingEditStep = false
            this.editIotArgDialogVisible = false
            this.iotBusArgList = []
            this.loadData()
          }.bind(this)
        )
        .catch(
          function (error) {
            // this.loadingEditStep = false
            // this.$message.error('发生错误，更新失败！')
            console.info(error)
          }
        )
    },
    submitEditForm (formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.confirmEditIotArg()
        } else {
          console.log('error submit Edit!!')
          return false
        }
      })
    },
    handleClose (done) {
      this.editIotArgDialogVisible = false
      this.resetForm('updateIotArg')
    },
    handleEdit (index, item) {
      // console.info(item)
      this.editIotArg = JSON.parse(JSON.stringify(item))
      // this.editIotArg = item
      this.editIotArgDialogVisible = true
    }
  },
  mounted () {
    this.loadData()
  }
}
</script>
// 引用pages
import deviceParamConfig from '@/views/deviceManagement/paramConfig/index'

// 定义路由路径数组列表
export default[
  {
    path: '/devicemgmt/deviceparamconfig',
    name: 'deviceParamConfig',
    component: deviceParamConfig
  }
]

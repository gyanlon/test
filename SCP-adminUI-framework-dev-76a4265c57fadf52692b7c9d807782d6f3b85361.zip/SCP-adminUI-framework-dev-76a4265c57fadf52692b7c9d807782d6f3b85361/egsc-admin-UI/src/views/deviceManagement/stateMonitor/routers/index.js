// 引用pages
import deviceStateMonitor from '@/views/deviceManagement/stateMonitor/index'

// 定义路由路径数组列表
export default[
  {
    path: '/devicemgmt/devicestatusmonitor',
    name: 'deviceStateMonitor',
    component: deviceStateMonitor
  }
]

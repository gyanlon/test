// 引用pages
import deviceRegister from '@/views/deviceManagement/register/index'

// 定义路由路径数组列表
export default[
  {
    path: '/devicemgmt/deviceregister',
    name: 'deviceRegister',
    component: deviceRegister
  }
]

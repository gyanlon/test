<template>
    <div>
      <el-row :gutter="60">
        <el-col :span="7">
          <div class="grid-content bg-purple">
            <select-box title="设备类型"
                        code="deviceType"
                        :options="deviceType"
                        :disabled="selectDisable"
                        @listenToInput="_saveDeviceData"
                        ref="deviceTypeDesc">
            </select-box>
          </div>
        </el-col>
        <el-col :span="7">
          <div class="grid-content bg-purple">
            <inputBox title="设备编码"
                      code="deviceCode"
                      ref="deviceCode"
                      :disabled="inputDisable"
                      @listenToInput="_saveDeviceData"
                      :maxlength=128>
            </inputBox>
          </div>
        </el-col>
      </el-row>
      <el-row :gutter="60">
        <el-col :span="7">
          <div class="grid-content bg-purple">
            <input-box style="margin-right: 20px"
                       title="固件名称"
                       code="fileName"
                       :value="selectedVaue.fileName"
                       :disabled="true"
                       ref="fileName">
            </input-box>
            <el-button plain @click="_selectFirmware">选择固件</el-button>
            <el-dialog
              title="选择固件"
              :visible.sync="showDialog"
              @close="_close"
              :modal="false"
              :modal-append-to-body="true"
              width="35%">
              <firmware-table-list ref="firmwareTableList" @listenToRowSelected="_selectedResult" :tableData="firmwareUpdateList"></firmware-table-list>
            </el-dialog>
          </div>
        </el-col>
        <el-col :span="7">
          <div class="grid-content bg-purple">
            <input-box title="固件版本"
                       code="firmwareVersion"
                       :value="selectedVaue.firmwareVersion"
                       :disabled="true"
                       @listenToInput="_saveDeviceData"
                       ref="firmwareVersion">
            </input-box>
          </div>
        </el-col>
        <el-col :span="7">
          <div class="grid-content bg-purple">
            <input-box title="固件大小"
                       code="fileSize"
                       :disabled="true"
                       ref="fileSize"
                       :value="selectedVaue.fileSize"
                       append="MB"
                       @listenToInput="_saveDeviceData">
            </input-box>
          </div>
        </el-col>
      </el-row>
      <div class="action-container">
        <el-button type="primary" :disabled="!selectedVaue.fileName" @click="_sendFirmwareUpdate">请求固件升级</el-button>
      </div>
    </div>
</template>

<script>
  import inputBox from '../../register/components/inputBox'
  import selectBox from '../../register/components/selectBox'
  import firmwareTableList from './firmwareTableList'
  import {getDeviceTypeList} from '../../register/apis/index'
  import {getFotaFileList, getFotaFileSelectList, fotaUpgradeRequest} from '../apis/index'

  export default {
    data () {
      return {
        deviceType: [{value: '', label: ''}],
        deviceUpdateData: {},
        showDialog: false,
        selectedVaue: {},
        deviceTypeList: [],
        selectDisable: false,
        inputDisable: false,
        firmwareUpdateList: []
      }
    },
    components: {
      inputBox,
      selectBox,
      firmwareTableList
    },
    methods: {
      _loadDeviceTypeList () {
        getDeviceTypeList()
          .then(
            function (result) {
              this.deviceTypeList = result.deviceCategoryList
              for (let i = 0; i < this.deviceTypeList.length; i++) {
                this.deviceType.push({
                  value: this.deviceTypeList[i].type,
                  label: this.deviceTypeList[i].typeDesc
                })
              }
            }.bind(this)
          )
          .catch()
      },
      _saveDeviceData (data) {
        for (var key in data) {
          this.deviceUpdateData[key] = data[key]
          if (key === 'deviceType') {
            this.selectedVaue = {}
            if (this.$refs.fileSize) {
              this.$refs.fileSize.clearBox()
              this.$refs.firmwareVersion.clearBox()
              this.$refs.fileName.clearBox()
            }
          }
          if (key === 'deviceCode') {
            this.selectedVaue = {}
            if (this.$refs.fileSize) {
              this.$refs.fileSize.clearBox()
              this.$refs.firmwareVersion.clearBox()
              this.$refs.fileName.clearBox()
            }
          }
          if (key === 'deviceType' && data[key] !== undefined && data[key] !== '') {
            this.inputDisable = true
          }
          if (key === 'deviceType' && (data[key] === undefined || data[key] === '')) {
            this.inputDisable = false
          }
          if (key === 'deviceCode' && data[key] !== undefined && data[key] !== '') {
            this.selectDisable = true
          }
          if (key === 'deviceCode' && (data[key] === undefined || data[key] === '')) {
            this.selectDisable = false
          }
        }
      },
      _close () {
      },
      _selectFirmware () {
        if ((this.deviceUpdateData.deviceType !== undefined && this.deviceUpdateData.deviceType !== '') || (this.deviceUpdateData.deviceCode !== undefined && this.deviceUpdateData.deviceCode !== '')) {
          // 请求固件升级文件列表
          getFotaFileSelectList(this.deviceUpdateData)
            .then((result) => {
              if (result.listDmFotaFile.length > 0) {
                this.firmwareUpdateList = result.listDmFotaFile
                this.showDialog = true
                if (this.$refs.firmwareTableList) {
                  this.$refs.firmwareTableList.loadFirmwareTableList(result.listDmFotaFile)
                }
              } else {
                this.$message({
                  message: result.message,
                  type: 'warning'
                })
              }
            })
            .catch()
        } else {
          this.$message({
            message: '请先选择设备类型或输入设备编码',
            type: 'warning'
          })
        }
      },
      _selectedResult (data) {
        this.selectedVaue = data
        this.showDialog = false
        this.deviceUpdateData = Object.assign(this.deviceUpdateData, data)
      },
      _sendFirmwareUpdate () {
        // 发送升级请求
        fotaUpgradeRequest(this.deviceUpdateData)
          .then((result) => {
            this.$message({
              message: '固件升级请求发送成功',
              type: 'success'
            })
          })
          .catch()
      },
      _loadNotify () {
        getFotaFileList()
          .then((result) => {
            var list = result.listDmFotaFile
            var messageFile = ''
            list.forEach(value => {
              messageFile += value.fileName + '/'
            })
            const h = this.$createElement
            var message = '新的固件升级文件' + messageFile + '已上传，请安排升级'
            this.$notify({
              title: '通知',
              dangerouslyUseHTMLString: true,
              message: h('i', {style: 'color: teal'}, message),
              offset: 60
            })
          })
          .catch()
      }
    },
    mounted () {
      this._loadDeviceTypeList()
      this._loadNotify()
    }
  }
</script>


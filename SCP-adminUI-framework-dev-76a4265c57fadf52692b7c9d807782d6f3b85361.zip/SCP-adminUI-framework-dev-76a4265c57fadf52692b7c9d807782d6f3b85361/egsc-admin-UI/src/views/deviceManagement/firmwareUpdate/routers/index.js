// 引用pages
import deviceFirmwareUpdate from '@/views/deviceManagement/firmwareUpdate/index'

// 定义路由路径数组列表
export default[
  {
    path: '/devicemgmt/devicefirmwareupdate',
    name: 'deviceFirmwareUpdate',
    component: deviceFirmwareUpdate
  }
]

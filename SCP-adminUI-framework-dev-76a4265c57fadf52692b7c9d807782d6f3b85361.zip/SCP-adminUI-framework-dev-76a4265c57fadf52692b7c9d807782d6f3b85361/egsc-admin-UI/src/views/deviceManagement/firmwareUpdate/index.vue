<template>
<div class="ui-common">
  <firmware-update></firmware-update>
  <update-history></update-history>
</div>
</template>

<script>
  import firmwareUpdate from './components/firmwareUpdate'
  import updateHistory from './components/updateHistory'

  export default {
    components: {
      firmwareUpdate,
      updateHistory
    }
  }
</script>

<style>
  @import "../register/assets/css/devicemgmt.less";
</style>

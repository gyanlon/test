<template>
  <div>
    <el-form :inline="true" ref="authForm" :model="authForm">
      <el-form-item class="mt30">
        <template slot-scope="scope">
          <el-button type="primary" @click.native.prevent="authAddClick">添加权限</el-button>
          <el-button type="primary" @click="deletePermisson(data)">删除权限</el-button>
          <!-- <el-button type="primary">删除全部权限</el-button> -->
          <el-button type="primary" @click="downloadAuth(data)">权限下载</el-button>
        </template>
      </el-form-item>
      <div class="mt10">
        <el-form-item label="姓名：" prop="personName">
          <el-input v-model.trim="authForm.personName" placeholder="输入内容不能超过20个字符" :maxlength="20"></el-input>
        </el-form-item>
        <el-form-item label="梯控设备：" prop="elevatorName">
          <el-input v-model.trim="authForm.elevatorName" placeholder="输入内容不能超过20个字符" :maxlength="20"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="searchAuth">查询</el-button>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="resetAuthForm('authForm')">重置</el-button>
        </el-form-item>
      </div>
    </el-form>
    <el-table :data="data" :border="true" class="authTable" tooltip-effect="light" @selection-change="handleSelectionChange" ref="hasSelected">
      <el-table-column type="selection" width="55" align="center">
      </el-table-column>
      <el-table-column type="index" label="序号" width="80" align="center"></el-table-column>
      <el-table-column prop="personName" label="姓名" show-overflow-tooltip width="100" align="center"></el-table-column>
      <el-table-column prop="elevatorName" label="电梯" show-overflow-tooltip align="center"></el-table-column>
      <el-table-column prop="floorNo" label="关联楼层号" show-overflow-tooltip align="center"></el-table-column>
      <el-table-column prop="cardId" label="卡号" show-overflow-tooltip align="center"></el-table-column>
      <el-table-column prop="startTime" label="开始时间" show-overflow-tooltip align="center"></el-table-column>
      <el-table-column prop="expireTime" label="结束时间" show-overflow-tooltip align="center"></el-table-column>
      <el-table-column prop="createTime" label="创建时间" show-overflow-tooltip align="center"></el-table-column>
      <el-table-column prop="creator" label="创建人" width="100" align="center"></el-table-column>
      <el-table-column prop="statues" label="状态" width="100" align="center">
        <template slot-scope="scope">
          <el-col v-if="scope.row.statues ===0">未下载</el-col>
          <el-col v-else style="color:#409eff;">已下载</el-col>
        </template>
      </el-table-column>
      <!-- <el-table-column prop="modify" label="操作" width="100" align="center">
        <template slot-scope="scope">
          <el-button @click="handleClick(scope.row)" type="text" size="small">修改</el-button>
        </template>
      </el-table-column> -->
    </el-table>
    <div class="mt20" v-show="data&&data.length">
      <el-pagination small @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="pageData.currentPage" :page-sizes="[10, 15, 30, 50]" :page-size="pageData.pageSize" layout="total, sizes, prev, pager, next, jumper" :total="pageData.totalCount">
      </el-pagination>
    </div>
    <add-permissions :show="showDialog" @addpermissions="closePermission" @closeDialog="closeDialog"></add-permissions>
  </div>
</template>
<script>
import AddPermissions from './component/AddPermissions'
import { getAuthList, downloadAuthById, deletePermissions } from './apis/index'
const ERR_OK = '00000'
export default {
  components: {
    AddPermissions
  },
  data () {
    return {
      data: [],
      hasSelected: [],
      id: [],
      downloadId: [],
      authForm: {
        personName: '',
        elevatorName: ''
      },
      pageData: {
        pageSize: 10,
        currentPage: 1,
        totalCount: 0
      },
      showDialog: false
    }
  },
  mounted () {
    this.addtionAuth()
  },
  methods: {
    addtionAuth () {
      getAuthList({
        personName: this.authForm.personName ? this.authForm.personName : '',
        elevatorName: this.authForm.elevatorName ? this.authForm.elevatorName : '',
        currentPage: this.pageData.currentPage,
        pageSize: this.pageData.pageSize
      }).then((res) => {
        if (res.data.code === ERR_OK) {
          if (res.data.data.permissionList && res.data.data.permissionList.length) {
            this.pageData.totalCount = res.data.data.totalCount
            this.data = res.data.data.permissionList
          } else {
            this.pageData.totalCount = 0
            this.data = []
            this.$message({
              message: '暂无数据',
              type: 'info'
            })
          }
        } else {
          this.data = []
          this.$message({
            message: res.data.message ? res.data.message : '请求数据失败',
            type: 'error'
          })
        }
      })
        .catch(err => {
          console.log(err)
        })
    },
    // 修改
    // handleClick (row) {
    //   console.log(row)
    // },
    // 删除权限
    deletePermisson (rows) {
      if (this.hasSelected && this.hasSelected.length) {
        this.$confirm('确定删除该权限吗?', '提示', {
          type: 'warning'
        }).then(() => {
          this.hasSelected.forEach((select, index) => {
            this.id.push(select.id)
          })
          deletePermissions({
            ids: this.id.join(',')
          }).then((res) => {
            if (res.data.code === ERR_OK) {
              this.hasSelected = []
              this.id = []
              this.addtionAuth()
              this.$refs.hasSelected.clearSelection()
              this.$message({
                message: '删除成功',
                type: 'success'
              })
            } else {
              this.$refs.hasSelected.clearSelection()
              this.hasSelected = []
              this.id = []
              this.$message({
                message: '删除失败',
                type: 'error'
              })
            }
          })
        }).catch(() => {
          this.$message({
            type: 'warning',
            message: '已取消删除'
          })
        })
      } else {
        this.$message({
          message: '您还没选中删除权限',
          type: 'warning'
        })
      }
    },
    // 关闭窗口
    closePermission (removeData) {
      this.showDialog = false
      this.authForm.personName = ''
      this.authForm.elevatorName = ''
      this.pageData.currentPage = 1
      this.addtionAuth()
    },
    handleSizeChange (val) {
      this.pageData.pageSize = val
      this.addtionAuth()
    },
    handleCurrentChange (val) {
      this.pageData.currentPage = val
      this.addtionAuth()
    },
    authAddClick () {
      this.showDialog = true
    },
    closeDialog () {
      this.showDialog = false
    },
    handleSelectionChange (val) {
      this.hasSelected = val
    },
    // 搜索
    searchAuth () {
      if (this.authForm.personName.trim().length > 20) {
        this.$message({
          message: '输入姓名不能超多20个字符',
          type: 'warning'
        })
      } else if (this.authForm.personName.trim() && !/^[\u4e00-\u9fa50-9A-Za-z]+$/.test(this.authForm.personName.trim())) {
        this.$message({
          message: '输入姓名只能为中文、英文和数字',
          type: 'warning'
        })
      } else if (this.authForm.elevatorName.trim().length > 20) {
        this.$message({
          message: '输入梯控设备不能超多20个字符',
          type: 'warning'
        })
      } else if (this.authForm.elevatorName.trim() && !/^[\u4e00-\u9fa5_0-9a-zA-Z]+$/.test(this.authForm.elevatorName.trim())) {
        this.$message({
          message: '输入梯控设备只能为中文、英文、数字和下划线',
          type: 'warning'
        })
      } else {
        this.pageData.currentPage = 1
        this.addtionAuth()
      }
    },
    // 重置
    resetAuthForm (formName) {
      this.$refs[formName].resetFields()
      this.data = []
      this.pageData.currentPage = 1
      this.pageData.pageSize = 10
      this.addtionAuth()
    },
    // 下载
    downloadAuth (permissionList) {
      if (this.hasSelected && this.hasSelected.length) {
        this.$confirm('确定下载该权限吗?', '提示', {
          type: 'warning'
        }).then(() => {
          this.hasSelected.forEach((select, index) => {
            this.downloadId.push(select.id)
          })
          downloadAuthById({
            ids: this.downloadId.join(',')
          }).then(res => {
            if (res.data.code === ERR_OK) {
              this.hasSelected = []
              this.downloadId = []
              this.addtionAuth()
              this.$refs.hasSelected.clearSelection()
              this.$message({
                message: '下载成功',
                type: 'success'
              })
            } else {
              this.hasSelected = []
              this.downloadId = []
              this.$refs.hasSelected.clearSelection()
              this.$message({
                message: '下载失败',
                type: 'error'
              })
            }
          })
        }).catch(() => {
          this.$message({
            type: 'warning',
            message: '已取消下载'
          })
        })
      } else {
        this.$message({
          message: '您还没选中下载权限',
          type: 'warning'
        })
      }
    }
  }
}
</script>
<style lang='less' scoped>
.mt30 {
  margin-top: 30px;
}
.mt10 {
  margin-top: 10px;
}
.mt20 {
  margin-top: 20px;
  text-align: center;
}
.authTable {
  margin-top: 10px;
  width: 100%;
}
</style>

<template>
  <div>
    <div class="eventContent">
      <div style="width:100%;height:100%;margin-top:30px;">
        <el-form ref="form1" :model="form1" label-width="80px" style="overflow:hidden;">
          <el-row>
            <el-form-item label="事件类型" prop="eventType" style="float:left;width:25%;">
              <el-select v-model="form1.eventType" placeholder="请选择事件类型">
                <el-option label="刷卡事件" value="3"></el-option>
                <el-option label="呼梯事件" value="4"></el-option>
                <el-option label="异常事件" value="5"></el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="卡号" prop="cardId" style="float:left;width:25% ">
              <el-input v-model.trim="form1.cardId" style="width:220px;" :maxlength="32" placeholder="输入内容不能超过20个字符"></el-input>
            </el-form-item>
            <!-- <el-form-item label="持卡人" prop="name" style="float:left;width:25% ">
              <el-input v-model="form1.name" style="width:220px;"></el-input>
            </el-form-item> -->
            <el-form-item label="梯控设备" prop="machineName" style="float:left;width:25% ">
              <el-input v-model.trim="form1.machineName" style="width:220px;" placeholder="输入内容不能超过20个字符" :maxlength="20"></el-input>
            </el-form-item>
            <el-form-item style="float:left;width:25% ">
              <el-button type="primary " @click.stop="submitForm('form1')">查询</el-button>
            </el-form-item>
          </el-row>
          <el-row>
            <el-form-item label="开始时间 " prop="createTime" style="float:left;width:25% ">
              <el-date-picker v-model="form1.createTime" :editable="false" type="datetime" placeholder="选择日期时间">
              </el-date-picker>
            </el-form-item>
            <el-form-item label="结束时间 " prop="stopTime" style="float:left;width:25% ">
              <el-date-picker v-model="form1.stopTime" :editable="false" type="datetime" placeholder="选择日期时间">
              </el-date-picker>
            </el-form-item>
            <el-form-item style="float:left;width:25%;visibility:hidden;">
              <el-input style="width:220px;visibility:hidden;"></el-input>
            </el-form-item>
            <el-form-item style="float:left;width:25% ">
              <el-button type="primary " @click="resetForm('form1')">重置</el-button>
            </el-form-item>
          </el-row>
        </el-form>
      </div>
      <!-- <div class="ex-data">
        <el-button @click="submit">导出数据</el-button>
      </div> -->
      <el-table style="width: 100%;" :data="tableData" tooltip-effect="light" border>
        <el-table-column type="index" label="序号" width="50" align="center">
        </el-table-column>
        <el-table-column prop="eventType" label="事件类型" width="120" :formatter="formatEventType" align="center">
        </el-table-column>
        <el-table-column prop="createTime" label="开始时间" show-overflow-tooltip align="center">
        </el-table-column>
        <el-table-column prop="stopTime" label="结束时间" show-overflow-tooltip align="center">
        </el-table-column>
        <el-table-column prop="cardId" label="卡号" show-overflow-tooltip align="center">
        </el-table-column>
        <el-table-column prop="holderName" label="持卡人" show-overflow-tooltip align="center">
        </el-table-column>
        <el-table-column prop="machineName" label="梯控设备名称" show-overflow-tooltip align="center">
        </el-table-column>
        <el-table-column prop="entranceName" label="门禁设备名称" show-overflow-tooltip align="center">
        </el-table-column>
      </el-table>
      <div class='page-bar' v-show="tableData && tableData.length">
        <el-pagination class="el-page" @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page.sync="pageNo" :page-sizes="[10, 15, 30, 50]" :page-size="pageSize" layout="total, sizes, prev, pager, next, jumper" :total="total">
        </el-pagination>
      </div>
    </div>
  </div>
</template>
<script>
import { queryLadderLog } from './apis/index'
const ERR_OK = '00000'
export default {
  data () {
    return {
      tableData: [],
      form1: {
        eventType: '刷卡事件',
        cardId: '',
        machineName: '',
        createTime: '',
        stopTime: ''
      },
      options: [],
      pageNo: 1,
      pageSize: 10,
      total: 0
    }
  },
  mounted () {
    this.queryList()
  },
  methods: {
    queryList (eventType) {
      queryLadderLog({
        pageNo: this.pageNo,
        pageSize: this.pageSize,
        eventType: eventType ? parseInt(eventType) : 3,
        cardId: this.form1.cardId,
        machineName: this.form1.machineName,
        startTime: this.form1.createTime,
        endTime: this.form1.stopTime
      })
        .then(res => {
          // 判断结果是否不为空
          if (res.data.code === ERR_OK) {
            if (res.data.data) {
              this.tableData = res.data.data.ladderEventLogVos
              this.total = res.data.data.totalCount
            } else {
              this.tableData = []
              this.total = 0
              this.$message({
                message: '暂无数据',
                type: 'info'
              })
            }
          } else {
            this.$message({
              message: res.data.message ? res.data.message : '请求数据失败',
              type: 'error'
            })
            this.tableData = []
          }
        })
        .catch(err => {
          console.log(err)
        })
    },
    // 搜索
    submitForm (formName) {
      if (this.form1.stopTime && (this.form1.createTime > this.form1.stopTime)) {
        this.form1.stopTime = ''
        this.$message({
          message: '开始时间不能大于结束时间',
          type: 'warning'
        })
      } else if (this.form1.machineName.trim().length > 20) {
        this.$message({
          message: '输入梯控设备不能超多20个字符',
          type: 'warning'
        })
      } else if (this.form1.machineName.trim() && !/^[\u4e00-\u9fa5_a-zA-Z0-9]+$/.test(this.form1.machineName.trim())) {
        this.$message({
          message: '输入梯控设备只能为中文、英文、数字和下划线',
          type: 'warning'
        })
      } else if (this.form1.cardId.trim().length > 32) {
        this.$message({
          message: '输入的卡号不能超多32个字符',
          type: 'warning'
        })
      } else if (this.form1.cardId.trim() && !/^[0-9a-zA-Z]+$/.test(this.form1.cardId.trim())) {
        this.$message({
          message: '输入的卡号只能是英文和数字',
          type: 'warning'
        })
      } else {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            let eventType = this.form1.eventType === '刷卡事件' ? 3 : this.form1.eventType
            this.pageNo = 1
            this.queryList(eventType)
          } else {
            return false
          }
        })
      }
    },
    // 事件类型显示转化
    formatEventType (row, column) {
      return row.eventType === 3 ? '刷卡事件' : row.eventType === 4 ? '呼梯事件' : '异常事件'
    },
    // 重置
    resetForm (formName) {
      this.$refs[formName].resetFields()
      this.tableData = []
      let eventType = 3
      this.form1.cardId = ''
      this.form1.machineName = ''
      this.form1.createTime = ''
      this.form1.stopTime = ''
      this.pageNo = 1
      this.pageSize = 10
      this.queryList(eventType)
    },
    handleSizeChange (val) {
      let eventType = this.form1.eventType === '刷卡事件' ? 3 : this.form1.eventType
      this.pageSize = val
      this.queryList(eventType)
    },
    handleCurrentChange (val) {
      let eventType = this.form1.eventType === '刷卡事件' ? 3 : this.form1.eventType
      this.pageNo = val
      this.queryList(eventType)
    }
  }
}
</script>
<style lang="less" scoped>
.ex-data {
  margin: 30px 0 20px 0;
}
.page-bar {
  margin-top: 20px;
  .el-page {
    text-align: center;
  }
}
</style>



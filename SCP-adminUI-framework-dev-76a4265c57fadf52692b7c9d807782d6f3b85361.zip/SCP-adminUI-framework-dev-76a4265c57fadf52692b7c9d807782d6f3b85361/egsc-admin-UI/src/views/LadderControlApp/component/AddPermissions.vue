<template>
  <div>
    <el-dialog title="添加权限" :visible="show" @close="closeEvent('form')" width="560px">
      <el-row class="addPermissionsContent">
        <el-form ref="form" :model="form" label-width="100px" :rules="rules" class="demo-ruleForm addPermissionForm">
          <el-row class="addPermissionsRow">
            <el-form-item label="选择人员:" prop="holder">
              <el-input type="textarea" :rows="2" placeholder="请选择人员" v-model="form.holder" @click.native.prevent="addPerson" :readonly="true" class="addPermissionsInput"></el-input>
            </el-form-item>
          </el-row>
          <el-row class="addPermissionsRow">
            <el-form-item label="选择设备:" prop="org">
              <el-input type="textarea" :rows="2" placeholder="请选择设备" v-model="form.org" @click.native.prevent="addEquiment" :readonly="true" class="addPermissionsInput"></el-input>
            </el-form-item>
          </el-row>
          <el-row class="addPermissionsRow">
            <el-form-item label="开始时间:" prop="startTime">
              <el-date-picker ref="startTime" v-model="form.startTime" :editable="false" type="datetime" class="addPermissionsInput" placeholder="选择日期时间">
              </el-date-picker>
            </el-form-item>
          </el-row>
          <el-row class="addPermissionsRow">
            <el-form-item label="结束时间:" prop="endTime">
              <el-date-picker v-model="form.endTime" :editable="false" type="datetime" class="addPermissionsInput" placeholder="选择日期时间">
              </el-date-picker>
            </el-form-item>
          </el-row>
          <el-row class="addPermissionsRow">
            <el-form-item style="margin-left:-100px;">
              <el-button @click="closeEvent('form')">取消</el-button>
              <el-button type="primary" style="margin-left:20px;" :disabled="disButton" @click="saveEpuipment('form')">提交</el-button>
            </el-form-item>
          </el-row>
        </el-form>
      </el-row>
    </el-dialog>
    <add-equipment :show="showEquipment" :selectedData="selectedData" @selectedEquipments="getEquipments" @closeEquipment="closeEquipment"></add-equipment>
    <choose-person :show="showPerson" :selectPerson='selectPerson' @onSavePerson="doSavePerson" @closePerson="closePerson"></choose-person>
  </div>
</template>
<script>
import AddEquipment from './AddEquipment'
import ChoosePerson from './ChoosePerson'
import { addPermissions } from '../apis/index'
const ERR_OK = '00000'
export default {
  props: {
    show: {
      required: true,
      type: Boolean,
      default () {
        return false
      }
    }
  },
  data () {
    return {
      form: {
        holder: '',
        org: '',
        startTime: new Date(),
        endTime: new Date(new Date().getTime() + 24 * 60 * 60 * 1000)
      },
      rules: {
        holder: [{ required: true, message: '请选择人员', trigger: 'change' }],
        org: [{ required: true, message: '请选择设备', trigger: 'change' }],
        startTime: [{ required: true, message: '请选择开始时间', trigger: 'change' }],
        endTime: [{ required: true, validator: this.checkendTime, trigger: 'change' }]
      },
      deviceIDs: '',
      holderId: [],
      selectedData: [],
      selectPerson: [],
      showEquipment: false,
      showPerson: false,
      disButton: false
    }
  },
  methods: {
    // 获取设备数据
    getEquipments (equipments) {
      let getDeviceName = []
      if (equipments.selectedEquipments && equipments.selectedEquipments.length > 0) {
        for (let i = 0; i < equipments.selectedEquipments.length; i++) {
          getDeviceName.push(equipments.selectedEquipments[i].deviceName)
          delete equipments.selectedEquipments[i].deviceName
        }
      }
      this.form.org = getDeviceName.join('、')
      this.deviceIDs = equipments.selectedEquipments
      this.selectData = equipments.selectedEquipments.selectData
      this.selectedData = equipments.selectData
      this.showEquipment = false
    },
    // 打开添加人员弹框
    addPerson () {
      this.showPerson = true
    },
    addEquiment () {
      this.showEquipment = true
    },
    // 添加权限
    saveEpuipment (fromName) {
      this.$refs[fromName].validate((valid) => {
        if (valid) {
          this.disButton = true
          addPermissions({
            deviceIDs: this.deviceIDs ? this.deviceIDs : null,
            holderId: this.holderId.join(','),
            startTime: this.formatDate(this.form.startTime),
            endTime: this.formatDate(this.form.endTime)
          }).then(res => {
            if (res.data.code === ERR_OK) {
              this.$refs[fromName].resetFields()
              this.disButton = false
              this.selectedData = []
              this.$emit('addpermissions')
              this.$message({
                message: '添加人员权限成功',
                type: 'success'
              })
            } else {
              this.disButton = false
              this.$message({
                message: res.data.message ? res.data.message : '添加权限失败',
                type: 'error'
              })
            }
          }).catch(err => {
            this.disButton = false
            console.log(err)
          })
        } else {
          this.disButton = false
          return false
        }
      })
    },
    checkendTime (rule, value, callback) {
      if (!value) {
        return callback(new Error('结束时间为空'))
      }
      if (this.form.startTime > this.form.endTime) {
        callback(new Error('结束时间不能小于开始时间'))
      } else {
        callback()
      }
    },
    // 获取人员信息
    doSavePerson (chosePerson) {
      this.form.holder = chosePerson.holderNames.join(',')
      this.holderId = chosePerson.uuIds
      this.selectPerson = chosePerson.selectPerson
      this.showPerson = false
    },
    // 关闭设备
    closeEquipment () {
      this.showEquipment = false
    },
    // 关闭人员
    closePerson () {
      this.showPerson = false
    },
    closeEvent (fromName) {
      this.$refs[fromName].resetFields()
      this.selectedData = []
      this.selectPerson = []
      this.$emit('closeDialog')
    },
    // 时间格式化
    formatDate (now) {
      let year = now.getFullYear()
      let month = now.getMonth() + 1
      if (month < 10) {
        month = '0' + month
      }
      let date = now.getDate()
      if (date < 10) {
        date = '0' + date
      }
      let hour = now.getHours()
      if (hour < 10) {
        hour = '0' + hour
      }
      let minute = now.getMinutes()
      if (minute < 10) {
        minute = '0' + minute
      }
      let second = now.getSeconds()
      if (second < 10) {
        second = '0' + second
      }
      return year + '-' + month + '-' + date + ' ' + hour + ':' + minute + ':' + second
    }
  },
  components: {
    AddEquipment,
    ChoosePerson
  }
}
</script>
<style lang="less" scoped>
.addPermissionsContent {
  text-align: center;
  .addPermissionsRow {
    width: 100%;
    margin-bottom: 50px;
    .addPermissionsInput {
      margin-left: -100px;
      width: 300px;
    }
  }
}
</style>
<style lang="less">
.addPermissionsRow {
  .el-form-item {
    margin: 0 auto;
  }
}
</style>


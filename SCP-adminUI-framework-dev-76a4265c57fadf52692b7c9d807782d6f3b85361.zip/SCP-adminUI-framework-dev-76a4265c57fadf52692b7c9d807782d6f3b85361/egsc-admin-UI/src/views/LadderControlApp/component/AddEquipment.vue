<template>
  <el-dialog title="选择设备" class="equipmentContent" :visible="show" @close="closeEvent(false)" width="1500px">
    <el-row class="dialog-row" style="margin-top:-30px;">
      <el-col class="dialog-left">
        <el-table class="table " filter-multiple height="450" border :data="allData" style="margin-top:10px;width: 100%" tooltip-effect="light" :default-expand-all="true" @selection-change="handleSelectionChange">
          <el-table-column type="expand">
            <template slot-scope="scope" v-if="scope.row.childrens && scope.row.childrens.length">
              <el-table :data="scope.row.childrens" filter-multiple class="deviceNametable tableBorder" tooltip-effect="light" style="width: 100%" :show-header="false" @selection-change="handleSelectionChange">
                <el-table-column label="设备" prop="childrenDeviceName" show-overflow-tooltip align="right">
                </el-table-column>
                <el-table-column label="楼幢" show-overflow-tooltip prop="childrenOrgName" align="right">
                </el-table-column>
                <el-table-column label="楼层" align="center" width="180px">
                  <template slot-scope="scope">
                    <template v-if="!scope.row.childrens || !scope.row.childrens.length">
                      <el-select v-model="scope.row.selectFloors" multiple collapse-tags placeholder="请选择" align="center">
                        <el-option v-for="item in getFloorOptions(scope.row)" :key="item.value" :label="item.label" :value="item.value">
                          {{ item.label }}
                        </el-option>
                      </el-select>
                    </template>
                    <template v-else> ---- </template>
                  </template>
                </el-table-column>
                <el-table-column prop="creatTime" label="操作" align="center" style="border:none;">
                  <template slot-scope="scope">
                    <template v-if="!scope.row.childrens || !scope.row.children.length">
                      <el-button type="text" @click="handleSelectClick(scope.$index,scope.row)">
                        添加
                      </el-button>
                    </template>
                    <template v-else> ---- </template>
                  </template>
                </el-table-column>
              </el-table>
            </template>
          </el-table-column>
          <el-table-column label="设备" prop="deviceName" show-overflow-tooltip align="left">
          </el-table-column>
          <el-table-column label="楼幢" prop="orgName" show-overflow-tooltip align="left">
          </el-table-column>
          <el-table-column label="楼层" width="180px" align="left">
            <template slot-scope="scope">
              <template v-if="!scope.row.childrens || !scope.row.childrens.length">
                <el-select v-model="scope.row.selectFloors" multiple collapse-tags placeholder="请选择" align="left">
                  <el-option v-for="item in getFloorOptions(scope.row)" :key="item.value" :label="item.label" :value="item.value">
                    {{ item.label }}
                  </el-option>
                </el-select>
              </template>
              <template v-else> ---- </template>
            </template>
          </el-table-column>
          <el-table-column prop="creatTime" label="操作" align="center">
            <template slot-scope="scope">
              <template v-if="!scope.row.childrens || !scope.row.childrens.length">
                <el-button type="text" @click="handleSelectClick(scope.$index,scope.row)">
                  添加
                </el-button>
              </template>
              <template v-else> ---- </template>
            </template>
          </el-table-column>
        </el-table>
      </el-col>
      <el-col class="dialog-right" style="margin-left:10px;">
        <el-table class="selectTable" height="450" :data="selectData" tooltip-effect="light" :border="true" style="margin-top:10px;width: 100%">
          <el-table-column prop="childrenDeviceName" label="设备" show-overflow-tooltip align="center"></el-table-column>
          <el-table-column prop="childrenOrgName" label="楼幢" show-overflow-tooltip align="center"></el-table-column>
          <el-table-column label="楼层" show-overflow-tooltip align="center">
            <template slot-scope="props">
              <span>[{{props.row.selectFloors.join(',')}}]</span>
            </template>
          </el-table-column>
          <el-table-column prop="creatTime" label="操作" align="center">
            <template slot-scope="scope">
              <el-button type="text" @click.native.prevent="deleteRow(scope.$index, selectData)">
                删除
              </el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-col>
    </el-row>
    <span slot="footer" class="dialog-footer">
      <el-button @click="clearAll">清空</el-button>
      <el-button type="primary" @click="saveEpuipment(true)">保存</el-button>
    </span>
  </el-dialog>
</template>
<script>
import { getEquipment } from '../apis/index'
const ERR_OK = '00000'
export default {
  props: {
    show: {
      required: true,
      type: Boolean,
      default () {
        return false
      }
    },
    selectedData: {
      type: Array,
      default: []
    }
  },
  data () {
    return {
      allData: [],
      selectData: [],
      selection: ''
    }
  },
  watch: {
    show (val) {
      if (val) {
        this.getEquipments()
        this.selectData = this.selectedData.length ? this.selectedData : []
      }
    }
  },
  methods: {
    getEquipments () {
      getEquipment().then(res => {
        if (res.data.code === ERR_OK) {
          // 判断结果是否不为空
          if (res.data.data && res.data.data.length) {
            this.allData = res.data.data
          } else {
            this.allData = []
            this.$message({
              message: '暂无数据',
              type: 'info'
            })
          }
        } else {
          this.allData = []
          this.$message({
            message: res.data.message ? res.data.message : '请求数据失败',
            type: 'error'
          })
        }
      })
        .catch(err => {
          console.log(err)
        })
    },
    // 保持设备数据
    saveEpuipment () {
      let selectedEquipments = []
      if (this.selectData && this.selectData.length > 0) {
        for (var i = 0; i < this.selectData.length; i++) {
          let tempObj = {}
          tempObj.deviceID = this.selectData[i].childrenDeviceID
          tempObj.deviceName = this.selectData[i].childrenDeviceName
          tempObj.floors = this.selectData[i].selectFloors.join(',')
          selectedEquipments.push(tempObj)
        }
        let equipmentobj = {}
        equipmentobj.selectData = this.selectData
        equipmentobj.selectedEquipments = selectedEquipments
        this.allData = []
        this.selectData = []
        this.$message({
          message: '添加成功',
          type: 'success'
        })
        this.$emit('selectedEquipments', equipmentobj)
      } else {
        this.$message({
          message: '您还没有添加设备',
          type: 'warning'
        })
      }
    },
    closeEvent () {
      this.allData = []
      this.$emit('closeEquipment')
    },
    // 清空
    clearAll () {
      this.selectData = []
    },
    handleSelectionChange (val) {
      this.selection = val
    },
    // 添加
    handleSelectClick (index, row) {
      let tempRow = {}
      tempRow.childrens = row.childrens
      tempRow.childrenDeviceID = row.childrenDeviceID ? row.childrenDeviceID : row.deviceID
      tempRow.childrenDeviceName = row.childrenDeviceName ? row.childrenDeviceName : row.deviceName
      tempRow.endFloor = row.endFloor
      tempRow.childrenOrgID = row.childrenOrgID ? row.childrenOrgID : row.orgID
      tempRow.childrenOrgName = row.childrenOrgName ? row.childrenOrgName : row.orgName
      tempRow.selectFloors = this.systemSort(row.selectFloors)
      tempRow.startFloor = row.startFloor
      if (tempRow.selectFloors && tempRow.selectFloors.length > 0) {
        if (this.selectData && this.selectData.length > 0) {
          for (let i = 0; i < this.selectData.length; i++) {
            if (this.selectData[i].childrenDeviceID === tempRow.childrenDeviceID) {
              this.selectData.splice(i, 1)
            }
          }
          this.selectData.push(tempRow)
        } else {
          this.selectData.push(tempRow)
        }
      } else {
        this.$message({
          message: '您还没有选择楼层',
          type: 'warning'
        })
      }
    },
    // 排序
    systemSort (array) {
      return array.sort(function (a, b) { return a - b })
    },
    // 移除
    deleteRow (index, rows) {
      rows.splice(index, 1)
    },
    getFloorOptions (row) {
      let start = parseInt(row.startFloor)
      let end = parseInt(row.endFloor)
      let floorArrs = []
      for (; start < end + 1; start++) {
        if (start === 0) {
          start = 1
        }
        floorArrs.push({ label: start + '楼', value: start })
      }
      return floorArrs
    }
  }
}
</script>
<style lang="less" scoped>
.dialog-row {
  display: flex;
  width: 100%;
  margin-top: 30px;
  .dialog-left {
    flex: 1;
    padding: 0 39px 0 40px;
  }
  .dialog-right {
    flex: 1;
    padding: 0px 40px 0 40px;
    border-left: 1px solid #ddd;
  }
}
.deviceNametable {
  margin: 0px 30px -1px;
}
</style>
<style lang="less">
.table {
  .el-table__expanded-cell[class*="cell"] {
    padding: 0px 30px;
  }
  .deviceNametable {
    td {
      border-right: none;
    }
  }
}
.equipmentContent {
  .el-dialog__footer {
    text-align: center;
  }
}
</style>
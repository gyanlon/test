// 定义路由路径数组列表
export default [
  {
    path: '/ladderappindex/authapp',
    name: 'AuthApp',
    component: resolve => require(['@/views/LadderControlApp/AuthApp.vue'], resolve)
  },
  {
    path: '/ladderappindex/eventapp',
    name: 'EventApp',
    component: resolve => require(['@/views/LadderControlApp/EventApp.vue'], resolve)
  }
]

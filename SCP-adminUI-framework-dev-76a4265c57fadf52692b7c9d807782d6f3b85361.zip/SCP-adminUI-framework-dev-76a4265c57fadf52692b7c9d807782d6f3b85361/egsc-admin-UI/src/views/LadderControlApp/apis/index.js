import Axios from '../../../assets/js/AxiosPlugin'
export const getAuthList = (params) => { return Axios.get('/scp-laddercontrolapp/ladderControl/listPermission', { params: params, headers: { 'Content-Type': 'application/json' } }) }
export const getAuthDio = (params) => { return Axios.get('/scp-laddercontrolapp/ladderControl/listPerson', { params: params, headers: { 'Content-Type': 'application/json' } }) }
// 获取设备数据
export const getEquipment = (params) => { return Axios.get('/scp-laddercontrolapp/ladderControl/listDevice', { params: params, headers: { 'Content-Type': 'application/json' } }) }
// 添加梯控设备权限
export const addPermissions = (params) => { return Axios.post('/scp-laddercontrolapp/ladderControl/insertPermission', params, { headers: { 'Content-Type': 'application/json' } }) }
// 删除权限
export const deletePermissions = (params) => { return Axios.post('/scp-laddercontrolapp/ladderControl/deletePermission', params, { headers: { 'Content-Type': 'application/json' } }) }
// 下载权限
export const downloadAuthById = (params) => { return Axios.post('/scp-laddercontrolapp/ladderControl/download', params, { headers: { 'Content-Type': 'application/json' } }) }
// 梯控事件查询
export const queryLadderLog = (params) => { return Axios.post('/scp-laddercontrolapp/ladderControl/listLadderLog', params, { headers: { 'Content-Type': 'application/json' } }) }

<template>
  <el-row>
    <el-col :span="24">数据同步管理</el-col>
  </el-row>
</template>

<script>
  export default {
    name: 'data-sync-mgmt-component'
  }
</script>

<style scoped>

</style>

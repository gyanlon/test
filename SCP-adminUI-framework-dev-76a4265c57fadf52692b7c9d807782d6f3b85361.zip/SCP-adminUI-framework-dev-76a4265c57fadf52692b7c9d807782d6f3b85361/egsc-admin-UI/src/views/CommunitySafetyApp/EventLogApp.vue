<template>
  <div>
    <div class="event-form">
      <el-form ref="eventLog" :model="eventLog" label-width="80px">
        <el-row :gutter="10">
          <el-col :xs="8" :sm="8" :md="8" :lg="8" :xl="8">
            <el-form-item label="事件类型" prop="name">
              <!-- <el-select v-model="typeResult" clearable placeholder="请选择事件类型" @visible-change="handleChange">
                <el-option v-for="item in typeResult" :key="item.id" :label="item.name" :value="item.code"></el-option>
              </el-select> -->
              <el-select v-model="eventLog.name" clearable placeholder="选择事件">
                <el-option v-for="item in eventTypeResult" :key="item.id" :label="item.name" :value="item.code"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <!-- <el-col :xs="6" :sm="7" :md="8" :lg="7" :xl="6">
            <el-form-item label="事件内容" prop="contain">
              <el-input v-model="form1.contain"></el-input>
            </el-form-item>
          </el-col> -->
          <el-col :xs="8" :sm="8" :md="8" :lg="8" :xl="8">
            <el-form-item label="事件状态" prop="state">
              <el-select v-model="eventLog.state" clearable placeholder="请选择事件状态">
                <el-option label="事件开始" value="0"></el-option>
                <el-option label="事件进行中" value="1"></el-option>
                <el-option label="事件结束" value="2"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :xs="8" :sm="8" :md="8" :lg="8" :xl="8">
            <el-form-item>
              <el-button type="primary" @click="submitForm('eventLog')">查询</el-button>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <!-- <el-col :xs="6" :sm="4" :md="4" :lg="5" :xl="6">
            <el-form-item label="设备" prop="device">
                <TreeComponent></TreeComponent>
            </el-form-item>
          </el-col> -->
          <el-col :xs="8" :sm="8" :md="8" :lg="8" :xl="8">
            <el-form-item label="开始时间" prop="startTime">
              <el-date-picker v-model="eventLog.startTime" :picker-options="pickerOptions0" type="datetime" placeholder="选择日期时间" value-format="yyyy-MM-dd HH:mm:ss" :editable="false"></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :xs="8" :sm="8" :md="8" :lg="8" :xl="8">
            <el-form-item label="结束时间" prop="endTime">
              <el-date-picker v-model="eventLog.endTime" :picker-options="pickerOptions1" type="datetime" placeholder="选择日期时间" value-format="yyyy-MM-dd HH:mm:ss" :editable="false" @change="getEndTime"></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :xs="8" :sm="8" :md="8" :lg="8" :xl="8">
            <el-form-item>
              <el-button type="primary" @click="resetForm('eventLog')">重置</el-button>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>
    <div class="event-table">
      <el-table :data="eventResult" :row-key="getRowKeys" :expand-row-keys="expands" border @expand-change="handleExpandChange" type="expand">
        <el-table-column prop="eventLogId" label="事件日志ID"></el-table-column>
        <el-table-column prop="eventTypeName" label="事件类型"></el-table-column>
        <el-table-column prop="startTime" label="开始时间"></el-table-column>
        <el-table-column prop="endTime" label="结束时间"></el-table-column>
        <el-table-column prop="content" label="事件内容"></el-table-column>
        <el-table-column prop="deviceName" label="设备名称"></el-table-column>
        <el-table-column prop="deviceCode" label="设备编号"></el-table-column>
        <el-table-column prop="statusMessage" label="事件状态"></el-table-column>
        <el-table-column type="expand">
          <template slot-scope="props">
            <el-row :gutter="10">
              <div class="text-center" v-if="resultPic">{{resultPic}}</div>
              <!-- <el-form v-model="result2" class="demo-form-inline"> -->
              <!-- <el-col :span="4">
                    <div class="grid-content bg-purple">
                      姓名:&nbsp;&nbsp;<span>{{result2.personName}}</span>
                    </div>
                  </el-col>
                  <el-col :span="3">
                    <div class="grid-content bg-purple">
                      性别:&nbsp;&nbsp;<span>{{result2.Sex}}</span>
                    </div>
                  </el-col>
                  <el-col :span="4">
                    <div class="grid-content bg-purple">
                      民族:&nbsp;&nbsp;<span>{{result2.params}}</span>
                    </div>
                  </el-col>
                  <el-col :span="4">
                    <div class="grid-content bg-purple">
                      户籍:&nbsp;&nbsp;<span>{{result2.IDType}}</span>
                    </div>
                  </el-col>
                  <el-col :span="5">
                    <div class="grid-content bg-purple">
                      身份证:&nbsp;&nbsp;<span>{{result2.IDNumber}}</span>
                    </div>
                  </el-col>
                  <el-col :span="4">
                    <div class="grid-content bg-purple">
                      来访次数:&nbsp;&nbsp;<span>{{result2.vcount}}</span>
                    </div>
                  </el-col> -->
              <!-- </el-form> -->
              <!-- <el-col :xs="8" :sm="8" :md="8" :lg="8" :xl="8">
                  <el-form v-model="result2">
                    <el-form-item label="姓名">
                      <span>{{props.row.personName}}</span>
                    </el-form-item>
                    <el-form-item label="性别">
                      <span>{{props.row.Sex}}</span>
                    </el-form-item>
                    <el-form-item label="民族">
                      <span>{{props.row.params}}</span>
                    </el-form-item>
                    <el-form-item label="户籍">
                      <span>{{props.row.IDType}}</span>
                    </el-form-item>
                    <el-form-item label="身份证">
                      <span>{{props.row.extend.IDNumber}}</span>
                    </el-form-item>
                    <el-form-item label="来访次数">
                      <span>{{props.row.extend.vcount}}</span>
                    </el-form-item>
                  </el-form>
                </el-col> -->
              <el-col :xs="8" :sm="8" :md="8" :lg="8" :xl="8">
                <div v-if="props.row.extend &&  props.row.extend.imgUrl || ''">
                  <img :src="props.row.extend.imgUrl" style="width:100%">
                </div>
                <!-- 判断当前行是否有数据 -->
              </el-col>
              <!-- <el-col :xs="8" :sm="8" :md="8" :lg="8" :xl="8">
                  <p>全景图片</p>
                  <img src="" alt="全景图片">
                </el-col> -->
            </el-row>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination class="el-page" @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page.sync="pageNo" :page-size="pageSize" :page-sizes="[10, 20, 50, 100]" layout="total, sizes, prev, pager, next, jumper" :total="total" v-show="showTable">
      </el-pagination>
    </div>
  </div>
</template>

<script>
import { getEventLog, getEventLogById, getEventLogByType, getEventTypeList } from './apis/index'
export default {
  data () {
    return {
      pickerOptions0: {
        disabledDate (time) {
          return time.getTime() > Date.now() - 8.64e6
        }
      },
      pickerOptions1: {
        disabledDate (time) {
          return time.getTime() > Date.now() - 8.64e6
        }
      },
      eventResult: [],
      resultPic: {},
      eventTypeResult: [],
      radio2: 3,
      activeName: 'first',
      centerDialogVisible: false,
      showTable: false,
      pageNo: 1,
      pageSize: 10,
      eventLogId: '',
      type: '',
      imgUrl: '',
      total: 0,
      eventLog: {
        name: '',
        contain: '',
        state: '',
        startTime: '',
        endTime: ''
      },
      // 获取row的key值
      getRowKeys (row) {
        return row.eventLogId
      },
      form: {},
      // 要展开的行，数值的元素是row的key值
      expands: []
    }
  },
  mounted () {
    this.getData()
    this.getEventType()
  },
  methods: {
    // 向后端发送请求获取事件类型
    handleChange (flag) {
      if (flag === true) {
        getEventLogByType({

        }).then(res => {
          this.typeResult = res.data.data
        })
          .catch(err => {
            console.log(err)
          })
      } else {
        console.log(1)
      }
    },
    // 获取事件类型
    getEventType () {
      getEventTypeList()
        .then(res => {
          this.eventTypeResult = res.data.data.eventType
        })
        .catch(err => {
          console.log(err)
        })
    },
    // 向后端发送请求获取数据
    getData () {
      getEventLog({
        pageNo: this.pageNo,
        pageSize: this.pageSize,
        eventType: this.eventLog.name,
        status: this.eventLog.state,
        startTime: this.eventLog.startTime,
        endTime: this.eventLog.endTime
      })
        .then(res => {
          // 判断结果是否不为空
          if (res.data.data == null) {
            this.eventResult = []
            this.showTable = false
          } else {
            this.eventResult = res.data.data.rows
            this.total = res.data.data.total
            this.showTable = true
          }
        })
        .catch(err => {
          console.log(err)
        })
    },
    // 通过传递参数ID发送请求得到相关数据
    getDataById (eventLogId) {
      console.log('getDataById', eventLogId)
      getEventLogById({
        eventLogId: eventLogId
      })
        .then(res => {
          // 判断结果是否不为空
          if (res.data.data == null) {
            this.resultPic = ''
          } else {
            this.resultPic = res.data.data
          }
        })
        .catch(err => {
          console.log(err)
        })
    },
    // 获取结束时间并判断
    getEndTime (val) {
      if (this.eventLog.startTime > val) {
        this.$message({
          message: '开始时间不能大于结束时间，请重新选择',
          type: 'warning'
        })
        // this.clearEndTime()
        // this.clearStartTime()
        this.eventLog.endTime = ''
        this.eventLog.startTime = ''
      }
    },
    // 通过每页的条数向后端获取数据
    handleSizeChange (val) {
      this.pageSize = val
      this.pageNo = 1
      this.getData()
      console.log(`每页 ${val} 条`)
    },
    handleCurrentChange (val) {
      // 显示当前页数
      this.pageNo = val
      this.getData()
      console.log(`当前页: ${val}`)
    },
    handleExpandChange (row) {
      this.resultPic = ''
      if (this.expands[0] === row.eventLogId) {
        // 关闭当前行
        this.expands = []
      } else if (row.eventLogId) {
        this.expands = []
        this.expands.push(row.eventLogId)
        this.getDataById(row.eventLogId)
      }
    },
    onSubmit () {
      console.log('submit!')
    },
    // 查询所有数据
    submitForm (formName) {
      this.$refs['eventLog'].validate((valid) => {
        if (valid) {
          this.pageNo = 1
          this.getData()
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    resetForm (formName) {
      this.$refs['eventLog'].resetFields()
      this.eventResult = []
      this.pageNo = 1
      this.getData()
    },
    handleNodeClick (data) {
      // console.log(data)
    },
    handleClose (done) {
      this.$confirm('确认关闭？')
        .then(() => {
          done()
        })
        .catch(() => { })
    }
  }

}
</script>
<style scoped>
.demo-table-expand {
  font-size: 0;
}
.demo-table-expand label {
  width: 90px;
  color: #99a9bf;
}
.demo-table-expand .el-form-item {
  margin-right: 0;
  margin-bottom: 0;
  width: 50%;
}
.event-form {
  width: 100%;
  margin-top: 30px;
}
.event-table {
  width: 100%;
}
.event-table .el-table {
  width: 100%;
}
.el-page {
  text-align: center;
}
.text-center {
  text-align: center;
}
</style>

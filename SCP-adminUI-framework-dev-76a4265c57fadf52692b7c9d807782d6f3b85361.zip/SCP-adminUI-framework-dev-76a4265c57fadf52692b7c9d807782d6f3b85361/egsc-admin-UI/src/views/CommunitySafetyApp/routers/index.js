// 定义路由路径数组列表
export default [
  {
    path: '/safetyappindex/eventlogapp',
    name: 'EventLogApp',
    component: resolve => require(['@/views/CommunitySafetyApp/EventLogApp.vue'], resolve)
  },
  {
    path: '/safetyappindex/linkageruleapp',
    name: 'LinkageRuleApp',
    component: resolve => require(['@/views/CommunitySafetyApp/LinkageRuleApp.vue'], resolve)
  },
  {
    path: '/safetyappindex/linkageresultapp',
    name: 'LinkageResultApp',
    component: resolve => require(['@/views/CommunitySafetyApp/LinkageResultApp.vue'], resolve)
  }
]

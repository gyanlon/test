<template>
  <div>
    <div class="event-form">
      <el-form ref="form1" :model="form1" label-width="80px">
        <el-row :gutter="10">
          <el-col :xs="6" :sm="4" :md="4" :lg="5" :xl="6">
            <el-form-item label="事件方式" prop="name">
              <el-select v-model="form1.name" clearable placeholder="选择事件">
                <!-- <el-option label="呼梯" value="呼梯"></el-option>
                <el-option label="区域二" value="beijing"></el-option> -->
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :xs="6" :sm="7" :md="8" :lg="7" :xl="6">
            <el-form-item label="开始时间" prop="value1">
              <el-date-picker v-model="form1.value1" type="datetime" placeholder="选择日期时间" value-format="yyyy-MM-dd HH:mm:ss"></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :xs="6" :sm="7" :md="8" :lg="7" :xl="6">
            <el-form-item label="结束时间" prop="value2">
              <el-date-picker v-model="form1.value2" type="datetime" placeholder="选择日期时间" value-format="yyyy-MM-dd HH:mm:ss"></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :xs="6" :sm="4" :md="4" :lg="5" :xl="6">
            <el-form-item>
              <el-button type="primary" @click="submitForm('form1')">查询</el-button>
            </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="resetForm('form1')">重置</el-button>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>
    <div class="event-table">
      <el-table :data="result" border>
        <el-table-column prop="id" label="ID"></el-table-column>
        <el-table-column prop="eventLogId" label="联动日志编号"></el-table-column>
        <el-table-column prop="triggerLogId" label="事件日志编号"></el-table-column>
        <el-table-column prop="triggerType" label="联动方式"></el-table-column>
        <el-table-column prop="triggerResult" label="联动结果">
          <template slot-scope="scope">
            <el-button @click="handleClick(scope.row.triggerResult)">result</el-button>
          </template>
        </el-table-column>
        <el-table-column prop="order" label="联动顺序"></el-table-column>
        <el-table-column prop="triggerTime" label="联动时间"></el-table-column>
        <el-table-column prop="retryCount" label="重复次数"></el-table-column>
      </el-table>
      <el-pagination class="el-page" @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page.sync="currentPage3" :page-size="pageSize" layout="prev, pager, next, jumper" :total="total" v-show="showTable">
      </el-pagination>
      <el-dialog title="联动结果" :visible.sync="centerDialogVisible" width="70%" :before-close="handleClose" center>
        <el-table :data="tableData5" border>
          <el-table-column label="cardType" prop="cardType"></el-table-column>
          <el-table-column label="buildCode" prop="buildCode"></el-table-column>
          <el-table-column label="ownerCode" prop="ownerCode"></el-table-column>
          <el-table-column label="estateCode" prop="estateCode"></el-table-column>
          <el-table-column label="flag" prop="flag"></el-table-column>
        </el-table>
        <span slot="footer" class="dialog-footer">
          <el-button @click="centerDialogVisible = false">取 消</el-button>
          <el-button type="primary" @click="centerDialogVisible = false">确 定</el-button>
        </span>
      </el-dialog>
    </div>
  </div>
</template>

<script>
import { getLinkageResult } from './apis/index'
export default {
  data () {
    return {
      result: [],
      centerDialogVisible: false,
      currentPage3: 0,
      showTable: false,
      pageNo: 1,
      pageSize: 10,
      total: 0,
      form1: {
        name: '',
        value1: '',
        value2: ''
      },
      tableData5: []
    }
  },
  // mounted () {
  //   this.getData()
  // },
  methods: {
    // 发送请求
    getData () {
      /*  this.$http({
         method: 'post',
         url: '/scp-commonitysafetyapp/trigger/result/list',
         headers: {'Content-Type': 'application/json'},
         params: JSON.stringify({
           pageNo: this.pageNo,
           pageSize: this.pageSize,
           triggerType: this.form1.name,
           triggerStartTime: this.form1.value1,
           triggerEndTime: this.form1.value2
         })
       }) */
      getLinkageResult({
        pageNo: this.pageNo,
        pageSize: this.pageSize,
        triggerType: this.form1.name,
        triggerStartTime: this.form1.value1,
        triggerEndTime: this.form1.value2
      }).then(res => {
        this.result = res.data.data.rows
        this.total = res.data.data.total
        if (this.result !== null) {
          this.showTable = true
        }
      })
        .catch(err => {
          console.log(err)
        })
    },
    // 每页显示条数
    handleSizeChange (val) {
      this.pageSize = val
      this.getData()
      console.log(`每页 ${val} 条`)
    },
    // 当前页
    handleCurrentChange (val) {
      this.pageNo = val
      this.getData()
      console.log(`当前页: ${val}`)
    },
    // 触发事件结果
    handleClick (data) {
      this.centerDialogVisible = true
      console.log(data)
      this.tableData5 = [data]
    },
    onSubmit () {
      console.log('submit!')
    },
    // 触发查询结果
    submitForm (formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.getData()
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    // 重置查询结果
    resetForm (formName) {
      this.$refs[formName].resetFields()
      this.result = []
      if (this.pageNo !== 1) {
        this.pageNo = ''
      }
      this.getData()
      this.pageNo = 1
    },
    handleClose (done) {
      this.$confirm('确认关闭？')
        .then(() => {
          done()
        })
        .catch(() => { })
    }
  }
}
</script>
<style scoped>
.event-form {
  width: 100%;
  margin-top: 30px;
}
.event-table {
  width: 100%;
}
.event-table .el-table {
  width: 100%;
}
.el-page {
  text-align: center;
}
</style>

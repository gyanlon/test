<template>
  <el-dialog title="联动规则配置" :visible="show" @close="closeDialog" width="70%">
    <el-form ref="ruleForm" :model="ruleForm" :rules="ruleFormRules" :show-message="true" label-width="80px">
      <el-row :gutter="10">
        <el-col :xs="6" :sm="6" :md="6" :lg="6" :xl="6">
          <el-form-item label="设备分类" prop="deviceType">
            <el-select v-model="ruleForm.deviceType" clearable placeholder="请选择设备" @change="getEvent" :disabled="isDisabled" @clear="clear">
              <el-option v-for="item in deviceTypes" :key="item.id" :label="item.name" :value="item.code"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :xs="6" :sm="6" :md="6" :lg="6" :xl="6">
          <el-form-item label="事件类型" prop="eventType">
            <el-select v-if="isDisabled" v-model="ruleForm.eventTypeName" clearable placeholder="请选择事件" :disabled="isDisabled">
            </el-select>
            <el-select v-else v-model="ruleForm.eventType" clearable placeholder="请选择事件">
              <el-option v-for="item in eventOptions" :key="item.id" :label="item.name" :value="item.code"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :xs="6" :sm="6" :md="6" :lg="6" :xl="6">
          <el-form-item label="设备资源" prop="eventSourceCode">
            <template v-if="isDisabled">
              <el-input placeholder="选择资源" v-model="deviceName" :disabled="true">
              </el-input>
            </template>
            <template v-else>
              <!-- <select class="hidden-rule" name="" id="hidden-sel" v-model="deviceName" @change="changeTrigger"></select> -->
              <TreeComponent :editTitle="deviceName" :data="treeResult" :code="code" @onNodeClick="handleNodeClick" ref="tree"></TreeComponent>
            </template>
          </el-form-item>
        </el-col>
        <el-col :xs="6" :sm="6" :md="6" :lg="6" :xl="6">
          <el-form-item label="是否有序" prop="isSequential">
            <el-select v-model="ruleForm.isSequential" clearable placeholder="请选择顺序" :disabled="isDisabled">
              <el-option label="是" :value="true">是</el-option>
              <el-option label="否" :value="false">否</el-option>
            </el-select>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <div class="linkage-rule">
      <el-row :gutter="10">
        <el-col :xs="6" :sm="6" :md="6" :lg="6" :xl="6">
          <div class="linkage-method">
            <h3>联动方式</h3>
            <div>
              <ul class="event-list">
                <li v-for="(item, index) of linkageList" :key="item.id" :class="{'active': linkageActiveIndex===index}" @click="onSelectLinkageType(index)">
                  <span>{{item.name}}</span>
                  <div class="linkage-type-switch">
                    <el-switch v-model="linkageOpenIndexs[index]" :index="index" @change="handleSwitchChange" active-color="#13ce66" inactive-color="#ff4949"> </el-switch>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </el-col>
        <el-col :xs="18" :sm="18" :md="18" :lg="18" :xl="18">
          <div class="resource-table-content">
            <component :sourceTableData="sourceTableData" :modifyData="this.triggers[linkageActiveIndex] || []" :is="componentViewsMap[linkageList.length ? linkageList[linkageActiveIndex].value : 'FAC_CALLING']" @onUpdateData="handleUpdateData" :code="linkageList.length ? linkageList[linkageActiveIndex].code : ''">
            </component>
          </div>
        </el-col>
      </el-row>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button type="primary" @click="handleSave">保 存</el-button>
      <el-button @click="closeInnerDialog">取 消</el-button>
    </div>
  </el-dialog>
</template>
<script>
import TreeComponent from './Tree.vue'
import ImageLinkage from './ImageLinkage.vue'
import VideoLinkage from './VideoLinkage.vue'
import DoorLinkage from './DoorLinkage.vue'
import AudioLinkage from './AudioLinkage.vue'
import { getLinkageRuleDevice, getLinkageRuleByCode, getSourceTree, getLinkageMode, getLinkageRuleSave, getLinkageRuleInfo, getLinkageRuleUpdate } from '../apis/index'
export default {
  name: 'ruleDialog',
  props: {
    show: {
      required: true,
      type: Boolean,
      default () {
        return false
      }
    },
    id: {
      type: String,
      defautl () {
        return ''
      }
    }
  },
  components: {
    TreeComponent,
    ImageLinkage,
    VideoLinkage,
    DoorLinkage,
    AudioLinkage
  },
  data () {
    /*
    var checkTree = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请选择设备'))
      } else {
        if (this.ruleForm.eventSourceCode !== '') {
          return this.ruleForm.validateField('eventSourceCode')
        }
      }
    }
    */
    return {
      ruleFormRules: {
        eventType: [{ required: true, message: '请选择事件类型', trigger: 'change' }],
        deviceType: [{ required: true, message: '请选择设备', trigger: 'change' }],
        // deviceName: [{ validator: this.checkTree, trigger: 'change' }],
        isSequential: [{ required: true, message: '请选择顺序', trigger: 'change' }]
      },
      showMsg: true,
      // ['ImageLinkage', 'VideoLinkage', 'DoorLinkage', 'AudioLinkage']
      componentViewsMap: {
        'FAC_CALLING': 'DoorLinkage',
        'CATCH_CALLING': 'DoorLinkage'
      },
      isDisabled: false,
      treeSelect: [],
      treeResult: [],
      eventList: [],
      showTable: false, // 控制分页是否显示
      deviceTypes: [],
      eventOptions: [],
      innerDialogVisible: false,
      ruleForm: {
        deviceType: '',
        triggerId: '',
        isSequential: false,
        eventType: '',
        eventSourceCode: ''
      },
      sourceTableData: [],
      linkageList: [],
      linkageActiveIndex: 0,
      linkageOpenIndexs: [],
      triggers: [],
      ruleParams: {
        triggers: []
      },
      deviceName: '',
      disabled: true,
      code: ''
    }
  },
  watch: {
    show (val) {
      if (val) {
        this.initData()
      }
    }
  },
  // updated () {
  //   if (this.deviceName === '') {
  //     this.showMsg = true
  //   } else {
  //     this.checkTree()
  //   }
  // },
  computed: {
    username () {
      let username = localStorage.getItem('login_username')
      return username || this.name || 'admin'
    }
  },
  methods: {
    // 验证规则
    // checkTree (rule, value, callback) {
    //   console.log('tree value----', this.deviceName)
    //   if (this.deviceName === '') {
    //     callback(new Error('请选择设备'))
    //   } else {
    //     this.showMsg = false
    //   }
    // },
    // 触发change
    // changeTrigger () {
    //   this.checkTree()
    // },
    // 初始化数据
    initData () {
      getLinkageMode().then(rs => {
        this.linkageList = rs.data.data || []
        this.triggers.length = this.linkageOpenIndexs.length = this.linkageList.length
        getLinkageRuleDevice().then(res => {
          this.deviceTypes = res.data.data
          if (this.id) {
            let params = { triggerId: this.id }
            getLinkageRuleInfo(params).then(rs => {
              this.ruleParams = rs.data.data
              let ruleParams = this.ruleParams
              let triggers = ruleParams.triggers || []
              this.isDisabled = true
              this.getEvent(ruleParams.deviceType, ruleParams)
              this.$nextTick(() => {
                this.deviceName = ruleParams.deviceName
                this.ruleForm = {
                  eventTypeName: ruleParams.eventTypeName,
                  eventType: ruleParams.eventType,
                  eventSourceCode: ruleParams.eventSourceCode,
                  isSequential: ruleParams.isSequential,
                  deviceType: ruleParams.deviceType,
                  triggerRuleId: this.id
                }
                this.linkageList.forEach((item, index) => {
                  triggers.forEach(subItem => {
                    if (item.value === subItem.method) {
                      this.linkageOpenIndexs[index] = true
                      this.triggers[index] = JSON.parse(subItem.params.sourceLists)
                    }
                  })
                })
              })
            })
          }
        })
      })
    },
    handleUpdateData (data) {
      let linkageActiveIndex = this.linkageActiveIndex
      this.triggers[linkageActiveIndex] = data
    },
    // 树节点点击事件
    handleNodeClick (data) {
      this.ruleForm.eventSourceCode = data.deviceId
      this.deviceName = data.label
    },
    // 树节点多选事件
    // onCheckChange (data) {
    //   this.ruleForm.eventSourceCode = data.map((item) => { return item.deviceId }).join(',')
    //   this.deviceName = data.label
    // },
    // 联动方式开关状态切换
    handleSwitchChange (state) {
      console.log(arguments)
      // this.linkageOpenIndexs[index]
    },
    // 传递设备获取事件类型
    getEvent (value, editData) {
      if (this.ruleForm.deviceType) {
        this.treeResult = []
        this.eventOptions = []
        this.ruleForm.eventType = ''
        this.releForm.eventSourceCode = ''
        // this.$refs.tree.onCheckChange([])
        this.$refs.tree.clear()
        this.code = value
        getLinkageRuleByCode({ code: value }).then(res => {
          this.eventOptions = res.data.data
          this.$nextTick(() => {
            if (editData) this.ruleForm.eventType = editData.eventType
          })
        }).catch(err => {
          console.log(err)
        })
        getSourceTree().then(res => {
          this.treeResult = [res.data.data]
          this.$nextTick(() => {
            if (this.$refs.tree && editData) {
              this.$refs.tree.setCurrentKey(editData.eventSourceCode)
            }
          })
        }).catch(err => {
          console.log(err)
        })
      }
    },
    // 清空选中
    clearSelect () {
      this.ruleForm.deviceType = ''
      this.ruleForm.eventType = ''
      this.isDisabled = false
      this.triggers = []
      this.treeResult = []
      this.deviceName = ''
      this.ruleForm.eventSourceCode = ''
    },
    // 切换联动规则
    onSelectLinkageType (index) {
      this.linkageActiveIndex = index
    },
    handleSave () {
      if (!this.isDisabled) {
        this.$refs['ruleForm'].validate((valid) => {
          if (valid) {
            let params = Object.assign({}, this.ruleForm)
            let triggers = []
            this.linkageList.forEach((item, index) => {
              let trigger = this.triggers[index] || []
              this.linkageOpenIndexs[index] && triggers.push({
                method: item.value,
                to: item.to,
                params: {
                  deviceId: trigger.map(rs => { return rs.deviceId }).join(','),
                  sourceLists: JSON.stringify(trigger)
                }
              })
            })
            let creator = this.username
            params.creator = creator
            params.triggers = triggers
            getLinkageRuleSave(params).then(res => {
              this.closeInnerDialog()
              this.$message({
                message: '新增联动规则成功',
                type: 'success'
              })
              this.clear()
            }).catch(() => {

            })
          } else {
            console.log('error submit!!')
            return false
          }
        })
      } else {
        let params = Object.assign({}, this.ruleForm)
        let triggers = []
        this.linkageList.forEach((item, index) => {
          let trigger = this.triggers[index] || []
          if (trigger) {
            this.linkageOpenIndexs[index] && triggers.push({
              method: item.value,
              to: item.to,
              params: {
                deviceId: trigger.map(rs => { return rs.deviceId }).join(','),
                sourceLists: JSON.stringify(trigger)
              }
            })
          } else {
            this.linkageOpenIndexs[index] = false
          }
        })
        params.triggers = triggers
        getLinkageRuleUpdate(params).then(res => {
          this.$message({
            message: '修改联动规则成功',
            type: 'success'
          })
          this.closeInnerDialog()
        }).catch(() => {

        })
      }
    },
    clear () {
      this.treeResult = []
      this.eventOptions = []
      this.$refs.tree.onCheckChange([])
      this.$refs.tree.clear()
      this.$refs['ruleForm'].resetFields()
      this.ruleForm.eventSourceCode = ''
    },
    closeDialog () {
      this.$emit('closeDialog')
      this.$refs['ruleForm'].resetFields()
      this.clearSelect()
      if (!this.isDisabled) {
        if (this.$refs.tree) {
          this.$refs.tree.clear()
        }
      }
    },
    closeInnerDialog () {
      if (!this.isDisabled) {
        this.$refs.tree.clear()
      }
      this.clearSelect()
      this.closeDialog()
      this.$refs['ruleForm'].resetFields()
    }
  }
}
</script>
<style scoped lang='less'>
ul {
  list-style-type: none;
  padding: 0;
}
.linkage-rule {
  border: 1px solid #999;
  .linkage-method {
    height: 420px;
    margin: 8px;
    border: 1px solid #999;
    h3 {
      text-align: center;
      line-height: 42px;
      font-size: 20px;
      color: #666;
      font-weight: normal;
    }
    .event-list {
      display: block;
      margin: 0 10px 5px 10px;
      li {
        cursor: pointer;
        text-align: center;
        height: 40px;
        line-height: 38px;
        margin-bottom: 1px;
        font-size: 14px;
        letter-spacing: 3px;
        padding: 0 50px;
        position: relative;
        background: #ccc;
        box-sizing: border-box;
        &:hover,
        &.active {
          background: #409eff;
          color: #fff;
        }
        &:hover {
          background: #2c85dd;
        }
      }
    }
    .linkage-type-switch {
      display: block;
      position: absolute;
      right: 10px;
      top: 0;
    }
  }
  .resource-table-content {
    height: 420px;
    margin: 8px 8px 8px 0;
    border: 1px solid #999;
  }
}
.hidden-rule {
  height: 1px;
  width: 100px;
  position: absolute;
  top: 0;
  left: 0;
  // border: 1px solid red;
  // border: none;
}
</style>
<template>
  <el-row style="height:300px">
    <div>
      <div class="event-btn">
        <span type="info" @click="openDialog">＋ 添加</span>
        <span type="info" style="margin-left:20px" @click="handleClickDelete(addResult)">× 删除</span>
      </div>
      <el-dialog title="添加" :visible="dialogVisible" width="30%" @close="dialogVisible = false" :modal="false" :data="data" :code="code">
        <div class="tree-size">
          <tree-component :data="data" @onNodeCheckEvent="doCheckEvent"></tree-component>
        </div>
        <span slot="footer" class="dialog-footer">
          <el-button @click="dialogVisible = false">取 消</el-button>
          <el-button type="primary" @click="dialogVisible = false">确 定</el-button>
        </span>
      </el-dialog>
    </div>
    <el-table :data="addResult" border @selection-change="handleSelectionChange" ref="hasSelected" max-height="280">
      <el-table-column type="selection"></el-table-column>
      <el-table-column prop="eventType" label="资源" align="center"></el-table-column>
      <el-table-column prop="eventType" label="事件名称" align="center"></el-table-column>
      <el-table-column prop="eventType" label="电梯" align="center"></el-table-column>
      <el-table-column prop="eventType" label="区域名称" align="center"></el-table-column>
    </el-table>
  </el-row>
</template>
<script>
import TreeComponent from './Tree.vue'
import { getLinkageRule, getLinkageDoor, getSourceTree } from '../apis/index'
export default {
  props: ['data', 'reviseData', 'code'],
  name: 'item2',
  components: {
    TreeComponent
  },
  data () {
    return {
      value4: '',
      input: '',
      dialogVisible: false,
      tableData5: [],
      addResult: [],
      hasSelected: [],
      deviceId: ''
    }
  },
  computed: {
    handleData () {
      // this.tableData8.push(this.reviseData)
      // console.log('--------------doorlinkage-datatable8-------------')
      // console.log(this.tableData8)
      // return this.reviseData === '' ? this.tableData8 : this.reviseData
    }
  },
  mounted () {
    getLinkageDoor({
      TriggerIds: this.TriggerIds
    })
      .then(res => {
        this.addResult = res.data.addResult
      })
      .catch(err => {
        console.log(err)
      })
    // if (this.reviseData !== '') {
    //   this.tableData8 = this.reviseData
    // }
    this.$nextTick(function () {
      this.addResult.push(this.reviseData)
      console.log('--------------doorlinkage----datatable8----mounted---------')
      console.log(this.addResult)
    })
  },
  methods: {
    getService () {
      getLinkageRule({
        pageNo: this.pageNo,
        pageSize: this.pageSize
      })
        .then(res => {
          this.addResult = res.data.tableData8
          this.total = res.data.total
          if (this.result !== null) {
            this.showTable = true
          }
        })
        .catch(err => {
          console.log(err)
        })
    },
    toggleSelection (rows) {
      if (rows) {
        rows.forEach(row => {
          this.$refs.hasSelected.toggleRowSelection(row)
        })
      } else {
        this.$refs.hasSelected.clearSelection()
      }
    },
    // 删除联动数据
    handleClickDelete (rows) {
      getLinkageDoor({ TriggerIds: this.TriggerIds }).then(res => {
        var temp = this.hasSelected
        // 判断并遍历所有选中行
        if (temp) {
          temp.forEach(t => {
            rows.forEach((row, index) => {
              if (row.id === t.id) {
                rows.splice(index, 1)
              }
            })
          })
          this.hasSelected = []
        }
      }).catch(err => {
        console.log(err)
      })
    },
    openDialog () {
      this.dialogVisible = true
      getSourceTree({ code: this.code }).then(res => {
        console.log(res)
        this.treeData = [res.data.data]
      }).catch(err => {
        console.log(err)
      })
    },
    // 改变选中项
    handleSelectionChange (val) {
      console.log(val)
      this.hasSelected = val
    },
    doCheckEvent (val) {
      if (val !== '') {
        console.log('-----------------------val--11-----------------------')
        console.log(val)
        this.addResult.push(val[0])
        this.deviceId = val[0].deviceId
        console.log(1111)
        console.log(this.deviceId)
        this.$emit('onNodeCheckEvent', this.deviceId)
      } else {
        this.addResult = this.data.treeTableData
      }
    }
  }
}
</script>
<style scoped>
body {
  padding: 0;
  margin: 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
.event-btn {
  background-color: gray;
  text-align: left;
  color: #fff;
}
.event-btn :hover {
  cursor: pointer;
}
.tree-size {
  height: 300px;
}
</style>


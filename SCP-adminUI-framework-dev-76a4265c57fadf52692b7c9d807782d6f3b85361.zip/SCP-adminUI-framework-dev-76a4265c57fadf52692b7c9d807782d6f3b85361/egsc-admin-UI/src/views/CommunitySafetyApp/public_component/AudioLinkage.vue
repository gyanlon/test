<template>
  <el-row :gutter="10">
    <el-col :xs="12" :sm="12" :md="12" :lg="12" :xl="12">
      <el-form-item label="资源">
        3
        <TreeComponent></TreeComponent>
      </el-form-item>
    </el-col>
    <el-col :xs="12" :sm="12" :md="12" :lg="12" :xl="12">
      广播联动
      <!-- <ul style="margin-left:50px">
        <li>
          <p>对讲通道</p>
          <hr>
          <el-checkbox>启动通道告警:</el-checkbox>
          <el-input v-model="value4" size="small" style="width:200px"></el-input>X
        </li>
        <li>
          <p>声音告警</p>
          <hr>
          <el-checkbox>启动声音告警:</el-checkbox>
          <el-input v-model="value4" placeholder="请输入语音文字" size="small" style="width:200px"></el-input>
        </li>
        <li>
          <p>字符叠加</p>
          <hr>
          <el-checkbox>启动字符叠加:</el-checkbox>
          <el-input v-model="value4" placeholder="请输入文字内容" size="small" style="width:200px"></el-input>
        </li>
      </ul>
      <div style="margin-top:30px;text-align:center">
        <p>下个节点:
          <el-select placeholder="请选择" v-model="value4">
            <el-option label="xxx" value="xxx"></el-option>
          </el-select>
        </p>
      </div> -->
    </el-col>
  </el-row>
</template>
<script>
import TreeComponent from './Tree.vue'
import { getLinkageRule } from '../apis/index'
export default {
  name: 'item3',
  components: {
    TreeComponent
  },
  data () {
    return {
      value4: ''
    }
  },
  // mounted () {
  //   this.getData()
  // },
  methods: {
    getService () {
      getLinkageRule({
        pageNo: this.pageNo,
        pageSize: this.pageSize
      })
        .then(res => {
          this.theModel = res.data.data
          this.tableData7 = res.data.tableData7
          this.tableData5 = res.data.tableData5
          this.imgUrl = res.data.imgUrl
          this.total = res.data.total
          if (this.result !== null) {
            this.showTable = true
          }
        })
        .catch(err => {
          console.log(err)
        })
    }
  }
}
</script>
<style scoped>
ul {
  list-style-type: none;
  padding: 0;
}
</style>


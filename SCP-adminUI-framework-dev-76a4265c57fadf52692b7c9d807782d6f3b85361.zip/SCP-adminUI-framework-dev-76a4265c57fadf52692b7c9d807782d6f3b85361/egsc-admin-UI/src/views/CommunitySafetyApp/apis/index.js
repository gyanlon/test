import Axios from '../../../assets/js/AxiosPlugin'
// 获取事件类型结果
export const getEventTypeList = (params) => {
  return Axios.get('/scp-communitysafetyapp/resource/log/eventType/list', params, { headers: { 'Content-Type': 'application/json' } })
}
// 获取联动结果数据
export const getLinkageResult = (params) => {
  return Axios.post('/scp-communitysafetyapp/trigger/result/list', params, { headers: { 'Content-Type': 'application/json' } })
}
// 获取联动日志结果
export const getEventLog = (params) => {
  return Axios.post('/scp-communitysafetyapp/event/log/list', params, { headers: { 'Content-Type': 'application/json' } })
}
// 通过传递当前ID获取联动结果详情
export const getEventLogById = (params) => {
  return Axios.get('/scp-communitysafetyapp/event/log/triggerId/' + params.eventLogId, { headers: { 'Content-Type': 'application/json' } })
}
// 获取事件日志中事件类型
export const getEventLogByType = (params) => {
  return Axios.get('/scp-communitysafetyapp/resource/eventType/0/list', params, { headers: { 'Content-Type': 'application/json' } })
}
// 查询联动规则结果
export const getLinkageRule = (params) => {
  return Axios.post('/scp-communitysafetyapp/trigger/rule/list', params, { headers: { 'Content-Type': 'application/json' } })
}
// 当页面加载时获取联动规则中的设备类型
export const getLinkageRuleDevice = (params) => {
  return Axios.get('/scp-communitysafetyapp/resource/subSystem/list', params, { headers: { 'Content-Type': 'application/json' } })
}
// 通过code获取当前事件类型
export const getLinkageRuleByCode = (params) => {
  return Axios.get('/scp-communitysafetyapp/resource/eventType/' + params.code + '/list', { headers: { 'Content-Type': 'application/json' } })
}
// 通过当前选中的id删除此条内容
export const delLinkageById = (params) => {
  // return Axios.post('/scp-commonitysafetyapp/trigger/rule/delete/?triggerId=' + params.triggerRuleId,
  //   {
  //     headers: { 'Content-Type': 'application/json' }
  //   })
  return Axios.post('/scp-communitysafetyapp/trigger/rule/delete', params, { headers: { 'Content-Type': 'application/json' } })
}
// 获取联动方式列表
export const getLinkageMode = () => {
  return Axios.get('/scp-communitysafetyapp/resource/triggerType/list', { headers: { 'Content-Type': 'application/json' } })
}
// 保存联动规则数据
export const getLinkageRuleSave = (params) => {
  return Axios.post('/scp-communitysafetyapp/trigger/rule/save', params, { headers: { 'Content-Type': 'application/json' } })
}
// 获取联动规则主页面组织树
export const getSourceTree = (params) => {
  return Axios.get('/scp-communitysafetyapp/resource/root/org', params, { headers: { 'Content-Type': 'application/json' } })
  // return Axios.get('/scp-commonitysafetyapp/trigger/rule/tree', { headers: { 'Content-Type': 'application/json' } })
}
// 通过triggerId获取当前行数据
export const getLinkageRuleInfo = (params) => {
  return Axios.get('/scp-communitysafetyapp/trigger/rule/get/' + params.triggerId, { headers: { 'Content-Type': 'application/json' } })
}
// 修改联动规则完成保存
export const getLinkageRuleUpdate = (params) => {
  return Axios.post('/scp-communitysafetyapp/trigger/rule/update', params, { headers: { 'Content-Type': 'application/json' } })
}
// 获取组织树中每个节点的数据
export const getOrgNextLevel = (params) => {
  return Axios.get('/scp-communitysafetyapp/resource/device/tree/', { params: params, headers: { 'Content-Type': 'application/json' } })
}
export const getLinkageRuleByList = (params) => {
  return Axios.get('/scp-communitysafetyapp/resource/Orgs', { params: params, headers: { 'Content-Type': 'application/json' } })
}
export const getLinkageDoor = (params) => {
  return Axios.get('/CommunitySafetyApp/list/', params, { headers: { 'Content-Type': 'application/json' } })
}

<template>
  <div class="visitor-container el-container">
    <div class="tree-container">
      <el-input placeholder="模糊查询组织" prefix-icon="el-icon-search" v-model="searchKey" class="visitor-search">
      </el-input>
      <el-tree :data="treeData" ref="tree" :props="defaultProps" node-key="uuid" :default-expanded-keys="defaultExpandKeys" :filter-node-method="filterNode" :expand-on-click-node="true" @node-click="handleNodeClick" @node-expand="nodeExpand"></el-tree>
    </div>
    <div class="view-content">
      <el-button type="primary" @click="visitorEdit">访客录入</el-button>
      <visitor-edit ref="visitorEdit" @openAuthority="openAu"></visitor-edit>
      <authority-edit ref="authorityEdit" :message="visitorEditForm" @refData="getVisitorTableData"></authority-edit>
      <el-button type="primary" @click="downLoad">导出</el-button>
      <div class="visitor-con clearfix">
        <el-form :model="visitorForm" :rules="rules" ref="visitorForm" class="visitor-form" label-width="100px">
          <el-form-item prop="name" label="访客姓名" class="form-item">
            <el-input v-model="visitorForm.name"></el-input>
          </el-form-item>
          <el-form-item prop="phone" label="联系方式" class="form-item">
            <el-input v-model="visitorForm.phone"></el-input>
          </el-form-item>
          <el-form-item prop="idenNum" label="证件号码" class="form-item">
            <el-input v-model="visitorForm.idenNum"></el-input>
          </el-form-item>
          <el-form-item prop="personName" label="被访者姓名" class="form-item">
            <el-input v-model="visitorForm.personName"></el-input>
          </el-form-item>
        </el-form>
        <div class="btnbar">
          <el-button type="primary" @click="searchVisitor">查询</el-button>
          <el-button type="primary" @click="resetSearchKey">重置</el-button>
        </div>
      </div>

      <div class="table-con">
        <pager-table class="visit-pb" ref="pagerTable" :visitor-data="visitorData" :total="total" @turnPage="getVisitorTableData" @selection-change="selectionChange" hasSelect>
          <template slot="table-column">
            <el-table-column label="访客姓名" prop="name">
            </el-table-column>
            <el-table-column label="访者单位" prop="company">
            </el-table-column>
            <el-table-column label="被访者姓名" prop="personName">
            </el-table-column>
            <el-table-column label="证件号码" prop="idenNum">
            </el-table-column>
            <el-table-column label="被访房屋地址" prop="houseAddr">
            </el-table-column>
            <el-table-column label="联系方式" prop="phone">
            </el-table-column>
            <el-table-column label="拜访人数" prop="visitorCnt">
            </el-table-column>
            <el-table-column fixed="right" label="操作" width="150">
              <template slot-scope="scope">
                <el-button @click="visitorEdit(scope.row)" size="mini">查看</el-button>
                <!-- v-if="scope.row.showCode" -->
                <el-button size="mini" @click="authorityEdit(scope.row)">授权</el-button>
                <!-- <el-dialog title="提示" :visible.sync="centerDialogVisible" width="30%" center :modal-append-to-body="false">
                  <div class="qrCode">
                    <template>
                      <div id='code'>{{qrCode}}</div>
                      <canvas id="canvas"></canvas>
                    </template>
                  </div>
                  <span slot="footer" class="dialog-footer">
                    <el-button @click="centerDialogVisible = false">取 消</el-button>
                    <el-button type="primary" @click="centerDialogVisible = false">确 定</el-button>
                  </span>
                </el-dialog> -->
              </template>
            </el-table-column>
          </template>
        </pager-table>
      </div>
    </div>
  </div>
</template>
<script>
// import Vue from 'vue'
import PagerTable from '@/views/VisitorApp/components/PagerTable'
import VisitorEdit from '@/views/VisitorApp/components/VisitorEdit'
import AuthorityEdit from '@/views/VisitorApp/components/AuthorityEdit'
import { getVisitor, getOrgNextLevel } from '@/views/VisitorApp/apis/index.js'
// import QRCode from 'qrcode'
// Vue.use(QRCode)
// import { phoneVerification } from '@/views/BroadcastApp/utils/validate.js'

export default {
  components: {
    PagerTable,
    VisitorEdit,
    AuthorityEdit
  },
  data () {
    // let that = this
    //  校验证件号是否输入正确
    // var validatePassport = (rule, value, callback) => {
    //   if (that.visitorForm.idenType === '') callback()
    //   if (value === '') {
    //     callback(new Error('请输入证件号码'))
    //   } else if (that.visitorForm.idenType === 0) {
    //     // 身份证验证
    //     if (!/\d{17}[\d|x]|\d{15}/.test(value)) {
    //       callback(new Error('请输入正确的身份证号码!'))
    //     } else {
    //       callback()
    //     }
    //   } else if (that.visitorForm.idenType === 1) {
    //     // 护照验证
    //     if (
    //       !/^1[45][0-9]{7}|([P|p|S|s]\d{7})|([S|s|G|g]\d{8})|([Gg|Tt|Ss|Ll|Qq|Dd|Aa|Ff]\d{8})|([H|h|M|m]\d{8，10})$/.test(
    //         value
    //       )
    //     ) {
    //       callback(new Error('请输入正确的护照号码!'))
    //     } else {
    //       callback()
    //     }
    //   }
    // }
    return {
      visitorForm: {
        name: '',
        personName: '',
        idenNum: '',
        phone: ''
      },
      visitorEditForm: '',
      centerDialogVisible: false,
      selections: [],
      rules: {
        name: [
          // { required: true, message: '请输入访客姓名', trigger: 'blur' },
          { min: 1, max: 15, message: '长度在 1 到 15 个字符', trigger: 'blur' }
        ],
        personName: [
          // { required: true, message: '请输入被访者姓名', trigger: 'blur' },
          { min: 1, max: 15, message: '长度在 1 到 15 个字符', trigger: 'blur' }
        ],
        idenNum: [
          { message: '请输入证件号码', trigger: 'blur' },
          { min: 1, max: 18, message: '长度在 1 到 18 个字符', trigger: 'blur' }
        ],
        phone: [
          { message: '请输入手机号码', trigger: 'blur' },
          { min: 1, max: 11, message: '长度在 1 到 11 个字符', trigger: 'blur' }
        ]
      },
      searchKey: '',
      treeData: [],
      defaultProps: {
        uuid: 'uuid',
        children: 'children',
        label: 'name'
      },
      orgData: {},
      defaultExpandKeys: [],
      visitorData: [],
      total: 0,
      currentPage: 1,
      pageSize: 10,
      orgId: '',
      houseId: '',
      qrCode: ''
    }
  },
  watch: {                        // 模糊查询
    searchKey (val) {
      this.$refs.tree.filter(val)
      if (val === '') {
        getOrgNextLevel().then(res => {           // 组织树根节点数据
          // console.log(res.data)
          this.treeData.push(res.data.data[0])
          this.defaultExpandKeys.push(res.data.data[0].uuid)
          this.formatTree(res.data.data[0].children)
          this.loading = false
        }).catch(err => {
          console.warn({
            message: err,
            type: 'warning'
          })
        })
      }
    }
  },
  mounted: function () {
    this.getVisitorTableData({ 'currentPage': this.currentPage, 'pageSize': this.pageSize, 'orgId': this.orgId, 'houseId': this.houseId })
    getOrgNextLevel().then(res => {           // 组织树根节点数据
      // console.log(res.data)
      this.treeData.push(res.data.data[0])
      // this.exportHouseNode.rootName = res.data.data[0].name
      // this.exportHouseNode.orgUuid = res.data.data[0].uuid
      this.defaultExpandKeys.push(res.data.data[0].uuid)
      this.formatTree(res.data.data[0].children)
      this.loading = false
    }).catch(err => {
      console.warn({
        message: err,
        type: 'warning'
      })
    })
  },
  methods: {
    getVisitorTableData: function (params) {
      // if (params === undefined) {
      //   this.resetSearchKey()
      // }
      getVisitor(Object.assign({ 'orgId': this.orgId, 'houseId': this.houseId }, this.visitorForm, params)).then(res => {           // 访客查询接口
        console.log(params)
        if (res.data.code === '00000') {
          let tableD = res.data.data[0].rows
          tableD.map(function (item, index, arr) {
            if (item.qrCode) {
              item.showCode = true
            } else {
              item.showCode = false
            }
          }, this)
          this.visitorData = tableD
          // console.log(this.visitorData)
          this.currentPage = res.data.data[0].currentPage
          this.total = res.data.data[0].rowCount
        } else {
          this.visitorData = res.data.data[0].rows
          // this.$message({
          //   message: res.data.message ? res.data.message : '查询失败',
          //   type: res.data.message ? 'success' : 'warning'
          // })
        }
      }).catch(err => {
        console.warn({
          message: err,
          type: 'warning'
        })
      })
    },
    filterNode (value, data) {                 // 树节点过滤
      if (!value) return true
      return data.name.indexOf(value) !== -1
    },
    formatTree: function (data) {
      const defaultNode = {
        name: ''
      }
      for (let i = 0; i < data.length; i++) {
        if (data[i].isParent === true) {
          data[i].children = []
          data[i].children.push(defaultNode)
        }
      }
      return data
    },
    nodeExpand: function (data, node) {
      if (data.hasExpanded) {
        return false
      }
      this.orgData = {
        isParent: data.isParent,
        type: data.type,
        uuid: data.uuid
      }
      console.log(this.orgData)
      getOrgNextLevel(this.orgData).then(res => {            // 获取组织树下一个节点数据信息
        console.log(res.data)
        data.children = this.formatTree(res.data.data)
        data.hasExpanded = true
      })
    },
    /** 点击树形结构node */
    handleNodeClick: function (params) {
      console.log(params)
      if (params.type === 'org') {
        this.orgId = params.uuid
        this.houseId = ''
      } else {
        this.orgId = ''
        this.houseId = params.uuid
      }
      this.getVisitorTableData({ 'currentPage': this.currentPage, 'pageSize': this.pageSize, 'orgId': this.orgId, 'houseId': this.houseId })
    },
    searchVisitor: function (options) {
      this.$refs['visitorForm'].validate((valid) => {
        if (valid) {
          this.getVisitorTableData({ 'currentPage': this.currentPage, 'pageSize': this.pageSize, 'orgId': this.orgId, 'houseId': this.houseId })
        }
      })
    },
    resetSearchKey: function () {
      for (let key in this.visitorForm) {
        this.visitorForm[key] = ''
      }
    },
    /**
     * @description 点击table组件复选框触发
     * @param Array val 所有选中行数据
     */
    selectionChange: function (val) {
      this.selections = val
      console.log(val)
    },
    /**
     * 访客录入/编辑访客数据
     */
    visitorEdit: function (visitorInfo = {}) {
      const visitorInfoTmp = Object.assign({}, visitorInfo)
      this.$refs['visitorEdit'].visitorEdit(visitorInfoTmp)
      console.log(visitorInfoTmp)
    },
    // 访客授权
    openAu: function (params) {
      this.visitorEditForm = params
      // console.log(this.visitorEditForm)
      this.authorityEdit()
    },
    authorityEdit: function (authorityInfo = {}) {
      const authorityInfoTmp = Object.assign({}, authorityInfo)
      this.$refs['authorityEdit'].authorityEdit(authorityInfoTmp)
    },
    //  导出功能
    downLoad: function () {
      this.$confirm('导出访客信息, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        window.open('/scp-visitorapp/visitor/exportExcel?name=' + this.visitorForm.name + '&phone=' + this.visitorForm.phone + '&personName=' + this.visitorForm.personName + '&idenNum=' + this.visitorForm.idenNum + '&orgId=' + this.orgId + '&houseId=' + this.houseId)
        this.$message({
          type: 'success',
          message: '导出成功!'
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消导出'
        })
      })
    },
    // 点击查看二维码
    open: function (qrCode) {
      console.log(qrCode)
      this.centerDialogVisible = true
      this.qrCode = qrCode
      // var canvas = document.getElementById('canvas')
      // QRCode.toCanvas(canvas, '58f4315c79b248368f4eb6b38df432ef', function (error) {
      //   console.log(qrCode)
      //   if (error) console.error(error)
      //   console.log('success!')
      // })
    }
  }
}
</script>
<style scoped>
.clearfix:before,
.clearfix:after {
  content: "";
  display: table;
  clear: both;
}
.clearfix {
  zoom: 1;
}
.visitor-container {
  position: relative;
  width: 100%;
  height: 100%;
  min-height: 850px;
  /* padding: 15px 0px 15px -210px; */
  /* padding-left:-210px; */
  padding: 10px;
  border: 1px solid #dddee1;
}
.tree-container {
  display: flex;
  flex-flow: column;
  width: 250px;
  float: left;
  border-right: 1px solid #ccc;
  box-sizing: border-box;
  height: 830px;
  overflow: auto;
  /* margin-left:-10px; */
}
.visitor-search {
  margin: 10px;
  width: 85%;
}
.el-tree {
  width: 900px;
  flex: 1;
}
.view-content {
  position: relative;
  float: left;
  width: 100%;
  height: 100%;
  margin-left: 20px;
  /* box-sizing: border-box; */
}
.visitor-con {
  width: 100%;
  margin-top: 15px;
  padding: 15px;
  padding-bottom: 0px;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

.visitor-form {
  width: 70%;
  float: left;
}
.form-item {
  width: 50%;
  float: left;
}
.btnbar {
  float: right;
}
.table-con {
  position: relative;
  width: 100%;
  height: 75%;
  margin-top: 10px;
}
#canvas {
  width: 200px;
  height: 200px;
}
</style>




<template>
  <el-dialog :visible.sync="dialogFormVisible" width="880px" :before-close="handleClose" :modal-append-to-body="false">
    <div slot="title">
      <span class="pull-left pl10">{{form.code?'物业人员记录查看':'物业人员录入'}}</span>
    </div>
    <el-form ref="form" :model="form" label-width="100px" :rules="rules">
      <el-row>
        <el-col :span="16">
          <el-row>
            <el-col :span="12">
              <el-form-item label="人员姓名" prop="name">
                <el-input v-model="form.name"></el-input>
              </el-form-item>
              <el-form-item label="证件类型" prop="idenType">
                <el-select v-model="form.idenType" placeholder="请选择证件类型">
                  <el-option v-for="item in list.idenType" :key="item.id" :label="item.itemName" :value="item.itemCode"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item label="民族" prop="nation">
                <el-select v-model="form.nation" placeholder="请选择民族">
                  <el-option v-for="item in list.nation" :key="item.id" :label="item.itemName" :value="item.itemCode"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item label="联系方式" prop="phone">
                <el-input v-model="form.phone"></el-input>
              </el-form-item>
              <el-form-item label="邮箱" prop="email">
                <el-input v-model="form.email"></el-input>
              </el-form-item>
              <el-form-item label="公司" prop="company">
                <el-input v-model="form.company"></el-input>
              </el-form-item>
              <el-form-item label="部门" prop="department">
                <el-select v-model="form.department" placeholder="请选择部门" @change="getPosition(form.department, 1)">
                  <el-option v-for="item in list.department" :key="item.id" :label="item.itemName" :value="item.itemCode"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item label="密码" prop="passCode">
                <el-input v-model="form.passCode"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="性别" prop="sex">
                <el-select v-model="form.sex" placeholder="请选择性别">
                  <el-option v-for="item in list.sex" :key="item.id" :label="item.itemName" :value="item.itemCode"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item label="证件号码" prop="idenNum">
                <el-input v-model="form.idenNum"></el-input>
              </el-form-item>
              <el-form-item label="生日" prop="birth">
                <el-date-picker style="width:auto" v-model="form.birth" align="right" type="date" :editable="false" placeholder="选择生日" format="yyyy年MM月dd日" value-format="yyyy-MM-dd" :picker-options="birthPickerOption">
                </el-date-picker>
              </el-form-item>
              <el-form-item label="籍贯" prop="origin">
                <el-input v-model="form.origin"></el-input>
              </el-form-item>
              <el-form-item label="车牌号" prop="plateNum">
                <el-input v-model="form.plateNum"></el-input>
              </el-form-item>
              <el-form-item label="项目" prop="project">
                <el-input v-model="form.project"></el-input>
              </el-form-item>
              <el-form-item label="岗位" prop="position">
                <el-select v-model="form.position" placeholder="请选择岗位">
                  <el-option v-for="item in positionList" :key="item.id" :label="item.itemName" :value="item.itemCode"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item label="确认密码" prop="repassCode">
                <el-input v-model="form.repassCode"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-form-item label="居住地址" prop="address">
              <el-input v-model="form.address"></el-input>
            </el-form-item>
          </el-row>
        </el-col>
        <el-col :span="8">
          <el-form-item prop="facePic" label-width="0">
            <div class="upload-con">
              <div class="facePic-con">
                <async-img width=260 :src="defaultPic"></async-img>
              </div>
              <el-button type="primary" @click="uploadFacePic" style="margin-left:80px;">本地上传</el-button>
              <input @change="readFacePic" class="uploadPicInput" ref="uploadFacePicInput" type="file" accept="image/jpeg,image/png,image/gif">
            </div>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button type="primary" @click="save" :disabled="disabledButton">保 存</el-button>
      <el-button @click="cancel">取 消</el-button>
    </div>
  </el-dialog>
</template>
<script>
import imgurl from '@/views/VisitorApp/assets/images/defaultPicture.png'
import AsyncImg from './AsyncImg'
import { insertProperty, updateProperty, positionList } from '@/views/VisitorApp/apis/index.js'
import { phoneVerification, nameValidator, originValidator, emailValidator, typeValidator, passValidator } from '@/views/VisitorApp/assets/js/validate.js'
export default {
  components: {
    AsyncImg
  },
  props: ['list'],
  data () {
    let that = this // 暂时去掉输入验证
    // 校验证件号是否输入正确
    var validatePassport = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请输入证件号码'))
      } else if (that.form.idenType === '1') {
        // 身份证验证
        if (!/^[1-9]\d{5}(19|20)*[0-99]{2}(0[1-9]{1}|10|11|12)(0[1-9]{1}|1[0-9]|2[0-9]|30|31)(\d{3})([0-9]|X|x)$/.test(value)) {
          callback(new Error('请输入正确的身份证号码!'))
        } else {
          callback()
        }
      } else if (that.form.idenType === '5') {
        // 护照验证
        if (
          !/(^1[45][0-9]{7}$)|(^(P|p|S|s)\d{8}$)|(^(S|s|G|g)\d{8}$)|(^(Gg|Tt|Ss|Ll|Qq|Dd|Aa|Ff)\d{8}$)|(^(H|h|M|m)\d{8,10}$)/.test(
            value
          )
        ) {
          callback(new Error('请输入正确的护照号码!'))
        } else {
          callback()
        }
      } else {
        callback()
      }
    }
    var repassValidate = (rule, value, callback) => {
      if (value !== that.form.passCode) {
        callback(new Error('两次输入密码不一致'))
      } else {
        callback()
      }
    }
    return {
      form: {
        id: '', // 物业人员id
        qrCode: '', // 二维码
        name: '', // 物业人员姓名
        sex: '', // 性别
        plateNum: '', // 物业人员车牌号
        nation: '', // 民族
        phone: '', // 电话
        position: '',
        passCode: '',
        repassCode: '',
        company: '', // 物业单位
        idenType: '', // 证件类型，默认0身份证，1军人证，2护照，3学生证，4工作证件，5其他'
        department: '', // 部门
        idenNum: '', // 证件号码
        origin: '', // 籍贯
        email: '', // 电子邮件
        personType: '', // 人员类型--保安、清洁等
        address: '', // 居住地址
        birth: '', // 生日
        description: '', // 描述
        facePic: '', // 物业人脸信息
        createTime: '', // 创建时间
        cardId: '', // 物业卡号
        fingerPrint: '', // 指纹信息
        starTtime: '', // 授权起始时间
        endTime: '', // 授权结束时间
        status: '', // 状态 1：在岗0：离岗';
        deleteFlag: '' // 逻辑删除标记： 0-已删除 1-未删除'
        // create_user创建用户      update_time更新时间     update_user更新用户
      },
      defaultForm: {
        id: '', // 物业人员id
        qrCode: '', // 二维码
        name: '', // 物业人员姓名
        sex: '', // 性别
        plateNum: '', // 物业人员车牌号
        nation: '', // 民族
        position: '',
        passCode: '',
        repassCode: '',
        phone: '', // 电话
        company: '', // 物业单位
        idenType: '', // 证件类型，默认0身份证，1军人证，2护照，3学生证，4工作证件，5其他'
        department: '', // 部门
        idenNum: '', // 证件号码
        origin: '', // 籍贯
        email: '', // 电子邮件
        personType: '', // 人员类型--保安、清洁等
        address: '', // 居住地址
        birth: '', // 生日
        description: '', // 描述
        facePic: '', // 物业人脸信息
        createTime: '', // 创建时间
        cardId: '', // 物业卡号
        fingerPrint: '', // 指纹信息
        starTtime: '', // 授权起始时间
        endTime: '', // 授权结束时间
        status: '', // 状态 1：在岗0：离岗';
        deleteFlag: '' // 逻辑删除标记： 0-已删除 1-未删除'
        // create_user创建用户      update_time更新时间     update_user更新用户
      },
      dialogFormVisible: false,
      disabledButton: false,
      positionList: '',
      rules: {
        name: [
          { required: true, min: 2, max: 15, message: '长度在 2 到 15 个字符', trigger: 'blur' },
          { validator: nameValidator, message: '姓名格式输入不正确', trigger: 'blur' }
        ],
        company: [
          { required: true, min: 2, max: 32, message: '请输入公司,长度在32个字符内', trigger: 'blur' },
          { validator: typeValidator, message: '不能输入特殊字符', trigger: 'blur' }
        ],
        idenNum: [
          { required: true, min: 2, max: 18, message: '请输入证件号码', trigger: 'blur' },
          { validator: validatePassport, message: '证件号码输入不正确', trigger: 'blur' },
          { validator: typeValidator, message: '不能输入特殊字符', trigger: 'blur' }
        ],
        sex: [
          { required: true, message: '性别不能为空', trigger: 'change' }
        ],
        origin: [
          { required: true, min: 1, max: 15, message: '籍贯不能为空,长度15 个字符内', trigger: 'blur' },
          { validator: originValidator, message: '不能输入特殊字符和数字', trigger: 'blur' }
        ],
        plateNum: [
          { max: 7, message: '长度不超过 7 个字符', trigger: 'blur' }
        ],
        department: [
          { required: true, message: '部门不能为空', trigger: 'change' }
        ],
        nation: [
          { required: true, message: '民族不能为空', trigger: 'change' }
        ],
        idenType: [
          { required: true, message: '证件类型不能为空', trigger: 'change' }
        ],
        email: [
          { validator: emailValidator, message: '邮箱输入不正确', trigger: 'blur' }
        ],
        position: [
          { required: true, message: '岗位不能为空', trigger: 'change' }
        ],
        passCode: [
          { required: true, message: '密码不能为空', trigger: 'change' },
          { validator: passValidator, message: '请输入6位数字密码', trigger: 'blur' }
        ],
        repassCode: [
          { required: true, message: '确认密码不能为空', trigger: 'change' },
          { validator: repassValidate, message: '两次输入密码不一致', trigger: 'blur' }
        ],
        project: [
          { required: true, min: 1, max: 32, message: '请输入项目,长度在32个字符内', trigger: 'blur' },
          { validator: typeValidator, message: '不能输入特殊字符', trigger: 'blur' }
        ],
        address: [
          { required: true, min: 2, max: 32, message: '请输入住址,长度在32个字符内', trigger: 'blur' }
        ],
        phone: [
          { required: true, message: '请输入手机号码', trigger: 'blur' },
          { validator: phoneVerification, message: '请输入手机号码', trigger: 'blur' }
        ],
        facePic: [
          { required: true, message: '请上传物业人员头像', trigger: 'blur' }
        ]
      },
      restaurants: [
      ],
      loading: false,
      birthPickerOption: {
        disabledDate (time) {
          return time.getTime() > Date.now()
        }
      }
    }
  },
  computed: {
    defaultPic: function () {
      return this.form.facePic === '' ? imgurl : this.form.facePic
    }
  },
  methods: {
    propertyEdit: function (personInfo) {
      this.form = Object.assign({}, this.defaultForm, personInfo)
      this.dialogFormVisible = true
      this.disabledButton = false
      // console.log(this.form)
      if (this.form.position) {            // 点击编辑后res.data.position存在调用岗位联动获取岗位
        let params = this.form.department
        this.getPosition(params)
      }
    },
    getPosition: function (params, key) {
      if (key) {
        this.form.position = ''
      }
      positionList(params).then(res => {           // 请求物业部门岗位联动下拉数据
        this.positionList = res.data
        console.log(res.data)
      }).catch(err => {
        console.warn({
          message: err,
          type: 'warning'
        })
      })
    },
    save: function () {
      this.$refs['form'].validate((valid) => {
        if (valid) {
          // console.log(this.form)
          this.disabledButton = true
          if (this.form.uuid) {
            updateProperty(Object.assign({}, this.form)).then(res => {       // 更新物业
              console.log(res.data)
              if (res.data.code === '00000') {
                this.$emit('reflushData') // 保存数据成功后，用事件通知父组件，刷新访客数据表格
                this.dialogFormVisible = false
              }
              this.$message({
                message: '保存成功',
                type: 'success'
              })
            }).catch(err => {
              console.warn({
                message: err,
                type: 'warning'
              })
            })
          } else {
            console.log(2222)
            insertProperty(Object.assign({}, this.form)).then(res => {     // 新增物业
              console.log(1111)
              console.log(res.data)
              if (res.data.code === '00000') {
                this.$emit('reflushData') // 保存数据成功后，用事件通知父组件，刷新访客数据表格
                this.dialogFormVisible = false
              }
              this.$message({
                message: res.data.message,
                type: 'success'
              })
            }).catch(err => {
              console.warn({
                message: err,
                type: 'warning'
              })
            })
          }
        } else {
          this.$message({
            message: '内容未填写完整',
            type: 'warning'
          })
          return false
        }
      })
    },
    cancel: function () {                     // 点击取消重置表单
      this.dialogFormVisible = false
      this.$refs['form'].resetFields()
      this.$refs.uploadFacePicInput.value = ''
    },
    handleClose: function () {
      this.dialogFormVisible = false
      this.$refs['form'].resetFields()
      this.$refs.uploadFacePicInput.value = ''
    },
    // 触发file类型的input的默认事件
    uploadFacePic: function () {
      this.$refs.uploadFacePicInput.click()
    },
    // 读取上传图片的base64编码
    readFacePic: function () {
      const file = this.$refs.uploadFacePicInput.files[0]
      console.log(file)
      if (file.size <= 204800) {
        if (file.type === 'image/jpeg') {
          const self = this
          var reader = new FileReader()
          reader.readAsDataURL(file)
          reader.onload = function (e) {
            const base64Code = this.result
            self.form.fileName = file.name
            self.form.facePic = base64Code
          }
        } else {
          this.$message({
            message: '图片格式只能为jpg',
            type: 'warning'
          })
          return false
        }
      } else {
        this.$message({
          message: '照片不能大于200kb',
          type: 'warning'
        })
        return false
      }
    }
  }
}
</script>
<style lang="less" scoped>
.house-select-popover {
  height: 150px;
  overflow: auto;
}
.uploadPicInput {
  display: none;
}
.upload-con {
  margin-left: 20px;
  .facePic-con {
    width: 260px;
    height: 240px;
    overflow: hidden;
    margin-bottom: 10px;
  }
}
.my-autocomplete {
  li {
    height: 60px;
    line-height: normal;
    padding: 7px;
    .name {
      text-overflow: ellipsis;
      overflow: hidden;
      line-height: 25px;
    }
    .addr {
      font-size: 13px;
      color: #b4b4b4;
      text-overflow: ellipsis;
      overflow: hidden;
    }
    .highlighted .addr {
      color: #ddd;
    }
  }
}
</style>

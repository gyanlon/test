<template>
  <el-dialog :visible.sync="dialogVisible" width="880px" :before-close="handleClose" :modal-append-to-body="false" title="授权信息">
    <el-form ref="form" :model="form" label-width="100px" :rules="rules">
      <el-row>
        <el-col :span="8">
          <el-form-item label="被访者姓名" prop="personName">
            <el-select v-model="form.personName" popper-class="my-autocomplete" @change="handleSelect" filterable remote reserve-keyword placeholder="请输入被访者姓名" :remote-method="remoteMethod" :loading="loading">
              <el-option v-for="item in restaurants" :key="item.uuid" :label="item.name" :value="item">
                <span class="name">{{ item.name }}</span>
                <div class="addr">{{ item.houseName }}</div>
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="16">
          <el-form-item label="被访房屋地址" prop="houseAddr">
            <el-input :offset="23" v-model="form.houseAddr" readonly></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="8">
          <el-form-item label="拜访原由" prop="reasonType">
            <el-input v-model="form.reasonType" :readonly="isCan"></el-input>
          </el-form-item>
          <el-form-item label="人员类型" prop="visitorType">
            <el-select v-model="form.visitorType" placeholder="请选择人员类型">
              <el-option v-for="item in list.visitorType" :key="item.id" :label="item.itemName" :value="item.itemCode"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="来访车牌" prop="plateNum">
            <el-input v-model="form.plateNum" :readonly="isCan"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="拜访人数" prop="visitorCnt">
            <el-input v-model="form.visitorCnt" :readonly="isCan"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row style="height:20px;"><hr/></el-row>
      <el-row>
        <el-col :span="18" :offset="2">
          <el-form-item label="有效日期">
            <el-date-picker style="width:100%" v-model="effectDate" @change="changeDate" :readonly="isCan" value-format="yyyy-MM-dd HH:mm:ss" align="center" type="datetimerange" :editable="false" start-placeholder="开始日期" end-placeholder="结束日期" format="yyyy-MM-dd HH:mm:ss" :picker-options="birthPickerOption">
            </el-date-picker>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="8" :offset="2">授权方式:</el-col>
      </el-row>
      <el-row class="authorityRow">
        <el-col :span="2" :offset="4">
          <el-checkbox v-model="form.card" true-label="1">刷卡</el-checkbox>
        </el-col>
        <el-col :span="5">
          <el-input v-model="form.cardId" placeholder="请输入卡号" prop="cardId"></el-input>
        </el-col>
        <el-col :span="12" :offset="1">
          <div v-if="cardId">
            <el-button size="mini" type="success">成功</el-button>
            <el-button size="mini" type="danger">退卡</el-button>
          </div>
          <div v-else>
            <el-button size="mini" type="warning">失败</el-button>
            <el-button size="mini" type="primary" @click="getCard(form.card)">重新授权</el-button>
          </div>
        </el-col>
      </el-row>
      <el-row class="authorityRow">
        <el-col :span="8" :offset="4">
          <el-checkbox v-model="form.currentFacePic" true-label="1">人脸</el-checkbox>
        </el-col>
        <el-col :span="12">
          <el-button size="mini" type="success" v-if="currentFacePic">成功</el-button>
          <div v-else>
            <el-button size="mini" type="warning">失败</el-button>
            <el-button size="mini" type="primary" @click="getFace(form.currentFacePic)">重新授权</el-button>
          </div>
        </el-col>
      </el-row>
      <el-row class="authorityRow">
        <el-col :span="8" :offset="4">
          <el-checkbox v-model="form.qrType" true-label="1">二维码</el-checkbox>
        </el-col>
        <el-col :span="12">
          <div v-if="qrCode">
            <el-button size="mini" type="success">成功</el-button>
            <el-button size="mini" type="success" @click="openQrCode">查看</el-button>
            <span style="margin-left:10px;" v-show="flag">{{qrCode}}</span>
          </div>
          <div v-else>
            <el-button size="mini" type="warning">失败</el-button>
            <el-button size="mini" type="primary" @click="getQrCode(form.qrType)">重新授权</el-button>
          </div>
        </el-col>
      </el-row>
      <!-- <el-row class="authorityRow">
        <el-col :span="8" :offset="4">
          <el-checkbox v-model="checked">密码</el-checkbox>
        </el-col>
        <el-col :span="12">
          <el-button size="mini" type="success">成功</el-button>
          <el-button size="mini" type="warning">失败</el-button>
          <el-button size="mini" type="primary">重新授权</el-button>
        </el-col>
      </el-row>
      <el-row class="authorityRow">
        <el-col :span="8" :offset="4">
          <el-checkbox v-model="checked">指纹</el-checkbox>
        </el-col>
        <el-col :span="12">
          <el-button size="mini" type="success">成功</el-button>
          <el-button size="mini" type="warning">失败</el-button>
          <el-button size="mini" type="primary">重新授权</el-button>
        </el-col>
      </el-row> -->
    </el-form>
    <div slot="footer">
      <el-button type="primary" :disabled="disabledButton" @click="authority">一键授权</el-button>
      <el-button @click="cancel">取 消</el-button>
    </div>
  </el-dialog>
</template>
<script>
import { searchVisitorInfo, grant, getTypeNodeMap } from '@/views/VisitorApp/apis/index.js'
import { typeValidator } from '@/views/VisitorApp/assets/js/validate.js'
export default {
  props: ['message'],
  data () {
    // var validateCard = (rule, value, callback) => {
    // }
    return {
      form: {
        reasonType: '',
        visitorCnt: 1,
        plateNum: '',
        personName: '',
        status: 0,
        houseAddr: '',
        uuid: '',
        personId: '',
        houseId: '',
        startTime: '',
        endTime: '',
        cardId: '',
        qrType: '',
        currentFacePic: '',
        card: '',
        visitorType: ''
      },
      defaultForm: {
        reasonType: '',
        visitorCnt: 1,
        plateNum: '',
        personName: '',
        status: 0,
        houseAddr: '',
        uuid: '',
        personId: '',
        houseId: '',
        startTime: '',
        endTime: '',
        cardId: '',
        qrType: '',
        currentFacePic: '',
        card: '',
        visitorType: ''
      },
      cardId: '',
      qrCode: '',
      currentFacePic: '',
      effectDate: [],
      flag: false,
      dialogVisible: false,
      disabledButton: false,
      list: '',
      checked: '',
      rules: {
        personName: [
          { required: true, message: '请输入被访者姓名', trigger: 'blur' }
          // { min: 2, max: 5, message: '长度在 2 到 5 个字符', trigger: 'blur' }
        ],
        reasonType: [
          { required: true, min: 1, max: 32, message: '原由不能为空,不超过32个字符', trigger: 'blur' },
          { validator: typeValidator, message: '不能输入特殊字符', trigger: 'blur' }
        ],
        plateNum: [
          { max: 7, message: '长度不超过 7 个字符', trigger: 'blur' }
        ],
        cardId: [
          { max: 15, message: '长度不超过 15 个字符', trigger: 'blur' }
        ]
      },
      birthPickerOption: {
        disabledDate (time) {
          return time.getTime() < Date.now() - 3600 * 1000 * 24
        }
      },
      isCan: true,
      restaurants: [
      ],
      loading: false
    }
  },
  watch: {
  },
  methods: {
    authorityEdit: function (personInfo) {
      this.dialogVisible = true
      this.isCan = Boolean(personInfo.name)
      this.disabledButton = false
      getTypeNodeMap(Object.assign({}, personInfo)).then(res => {           // 请求访客下拉数据
        this.list = res.data
        console.log(this.list)
      }).catch(err => {
        console.warn({
          message: err,
          type: 'warning'
        })
      })
      this.form = Object.assign({}, this.defaultForm, personInfo)
      this.currentFacePic = personInfo.currentFacePic             // 服务器端返回的多选框的值  存在显示成功  不存在显示失败
      this.qrCode = personInfo.qrCode
      this.cardId = personInfo.cardId
      /** 设置默认时间 */
      if (personInfo.startTime === undefined || (personInfo.startTime === '' && personInfo.endTime === '')) {
        let startd = new Date()
        let endd = new Date()
        endd.setTime(startd.getTime() + 3600 * 1000 * 24)
        this.effectDate = [startd, endd]
      }
      if (personInfo.startTime !== '' && personInfo.startTime !== undefined) {
        this.effectDate = [personInfo.startTime, personInfo.endTime]
      } else {
        this.form.startTime = this.formatDateTime(this.effectDate[0])
        this.form.endTime = this.formatDateTime(this.effectDate[1])
      }
    },
    cancel: function () {                          // 点击取消重置表单
      this.dialogVisible = false
      this.$refs['form'].resetFields()
      this.flag = false
    },
    handleClose: function () {
      this.dialogVisible = false
      this.$refs['form'].resetFields()
      this.flag = false
    },
    changeDate: function (date) {           // 有效日期改变时的事件
      this.form.startTime = this.effectDate[0]
      this.form.endTime = this.effectDate[1]
    },
    /**
     * 输入被访者姓名时，查询与此被访者相关的信息：房屋地址、房屋id
     */
    querySearch (queryString, cb) {
      searchVisitorInfo({ 'personName': this.form.personName })
        .then(res => {
          this.restaurants = res.data.data
          var restaurants = this.restaurants
          var results = queryString ? restaurants.filter(this.createFilter(queryString)) : restaurants
          // 调用 callback 返回建议列表的数据
          cb(results)
        })
        .catch(err => {
          console.warn({
            message: err,
            type: 'warning'
          })
        })
    },
    createFilter (queryString) {
      console.log(queryString)
      return (restaurant) => {
        return (restaurant.name.toLowerCase().indexOf(queryString.toLowerCase()) === 0)
      }
    },
    handleSelect (item) {
      this.form.personName = item.name
      this.form.houseAddr = item.houseName
      this.form.personId = item.uuid
      this.form.houseId = item.houseUuid
      this.form.personType = item.personType
    },
    remoteMethod (queryString) {
      if (this.isCan) return false // 查看状态下，不做远程搜索
      if (queryString !== '') {
        this.loading = true
        searchVisitorInfo({ 'personName': queryString })
          .then(res => {
            this.restaurants = res.data.data
            this.loading = false
          })
          .catch(err => {
            console.warn({
              message: err,
              type: 'warning'
            })
          })
      } else {
        this.restaurants = []
      }
    },
    formatDateTime: function (date) {
      let y = date.getFullYear()
      let m = date.getMonth() + 1
      m = m < 10 ? ('0' + m) : m
      let d = date.getDate()
      d = d < 10 ? ('0' + d) : d
      let h = date.getHours()
      h = h < 10 ? ('0' + h) : h
      let minute = date.getMinutes()
      minute = minute < 10 ? ('0' + minute) : minute
      let second = date.getSeconds()
      second = second < 10 ? ('0' + second) : second
      return y + '-' + m + '-' + d + ' ' + h + ':' + minute + ':' + second
    },
    // 一键授权
    authority: function () {
      this.$refs['form'].validate((valid) => {
        if (valid) {
          // this.disabledButton = true
          grant(Object.assign({}, this.form, this.message)).then(res => {
            console.log(res.data)
            this.qrCode = res.data.data[0].qrCode
            this.currentFacePic = res.data.data[0].currentFacePic
            this.cardId = res.data.data[0].cardId
            this.form.uuid = res.data.data[0].uuid
            if (res.data.code === '00000') {
              this.$emit('refData') // 保存数据成功后，用事件通知父组件刷新页面
              this.dialogVisible = false
              this.qrCode = ''               // 让多选框值都为空
              this.currentFacePic = ''
              this.cardId = ''
              this.$message({
                message: '授权成功',
                type: 'success'
              })
            } else {
              this.$message({
                message: res.data.message,
                type: 'success'
              })
            }
          }).catch(err => {
            console.warn({
              message: err,
              type: 'warning'
            })
          })
        } else {
          this.$message({
            message: '内容未填写完整',
            type: 'warning'
          })
          return false
        }
      })
    },
    // 单独授权
    getFace: function (val) {
      grant(Object.assign({}, this.form, this.message)).then(res => {
        console.log(res.data)
        this.currentFacePic = res.data.data[0].currentFacePic
        this.form.uuid = res.data.data[0].uuid
        if (res.data.code === '00000') {
          this.form.currentFacePic = ''
          this.$message({
            message: '授权成功',
            type: 'success'
          })
        } else {
          this.$message({
            message: res.data.message,
            type: 'success'
          })
        }
      }).catch(err => {
        console.warn({
          message: err,
          type: 'warning'
        })
      })
    },
    getQrCode: function (val) {
      grant(Object.assign({}, this.form, this.message)).then(res => {
        console.log(res.data)
        this.qrCode = res.data.data[0].qrCode
        this.form.uuid = res.data.data[0].uuid
        if (res.data.code === '00000') {
          this.form.qrType = ''
          this.$message({
            message: '授权成功',
            type: 'success'
          })
        } else {
          this.$message({
            message: res.data.message,
            type: 'success'
          })
        }
      }).catch(err => {
        console.warn({
          message: err,
          type: 'warning'
        })
      })
    },
    getCard: function (val) {
      grant(Object.assign({}, this.form, this.message)).then(res => {
        console.log(res.data)
        this.cardId = res.data.data[0].cardId
        this.form.uuid = res.data.data[0].uuid
        if (res.data.code === '00000') {
          this.form.card = ''
          this.$message({
            message: '授权成功',
            type: 'success'
          })
        } else {
          this.$message({
            message: res.data.message,
            type: 'success'
          })
        }
      }).catch(err => {
        console.warn({
          message: err,
          type: 'warning'
        })
      })
    },
    openQrCode: function () {
      this.flag = true
    }
  }
}
</script>
<style lang="less" scoped>
.authorityRow {
  height: 40px;
}
.my-autocomplete {
  li {
    height: 60px;
    line-height: normal;
    padding: 7px;
    .name {
      text-overflow: ellipsis;
      overflow: hidden;
      line-height: 25px;
    }
    .addr {
      font-size: 13px;
      color: #b4b4b4;
      text-overflow: ellipsis;
      overflow: hidden;
    }

    .highlighted .addr {
      color: #ddd;
    }
  }
}
</style>
<template>
  <el-dialog :visible.sync="dialogFormVisible" width="880px" :before-close="handleClose" :modal-append-to-body="false">
    <div slot="title">
      <span class="pull-left pl10">{{form.uuid?'访客记录查看':'访客录入'}}</span>
    </div>
    <el-form ref="form" :model="form" label-width="100px" :rules="rules">
      <el-row>
        <el-col :span="16">
          <el-row>
            <el-col :span="12">
              <el-form-item label="访客姓名" prop="name">
                <el-autocomplete v-model="form.name" :fetch-suggestions="querySearchAsync" placeholder="请输入内容" @select="handleSelect"></el-autocomplete>
              </el-form-item>
              <!-- <el-form-item label="人员类型" prop="visitorType">
                <el-select v-model="form.visitorType" placeholder="请选择人员类型">
                  <el-option v-for="item in list.visitorType" :key="item.id" :label="item.itemName" :value="item.itemCode"></el-option>
                </el-select>
              </el-form-item> -->
              <el-form-item label="证件类型" prop="idenType">
                <el-select v-model="form.idenType" placeholder="请选择证件类型">
                  <el-option v-for="item in list.idenType" :key="item.id" :label="item.itemName" :value="item.itemCode"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item label="访客单位" prop="company">
                <el-input v-model="form.company" :readonly="isCan"></el-input>
              </el-form-item>
              <el-form-item label="重点关注人员" prop="focusOnPersonel">
                <el-select v-model="form.focusOnPersonel" placeholder="请选择">
                  <el-option v-for="item in list.focusOnPersonel" :key="item.id" :label="item.itemName" :value="item.itemCode"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="性别" prop="sex">
                <el-select v-model="form.sex" placeholder="请选择性别">
                  <el-option v-for="item in list.sex" :key="item.id" :label="item.itemName" :value="item.itemCode"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item label="联系方式" prop="phone">
                <el-input v-model="form.phone" :readonly="isCan"></el-input>
              </el-form-item>
              <el-form-item label="证件号码" prop="idenNum">
                <el-input v-model="form.idenNum" :readonly="isCan"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-col>
        <el-col :span="8">
          <el-form-item prop="facePic" label-width="0">
            <div class="upload-con">
              <div class="facePic-con">
                <async-img width=260 :src="defaultPic"></async-img>
              </div>
              <el-button type="primary" @click="uploadFacePic" v-show="isShow" style="margin-left:80px;">选择文件</el-button>
              <input @change="readFacePic" class="uploadPicInput" ref="uploadFacePicInput" type="file" accept="image/jpeg,image/png,image/gif">
            </div>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button type="primary" @click="save" v-show="isShow" :disabled="disabledButton">保 存</el-button>
      <el-button @click="cancel">取 消</el-button>
    </div>
  </el-dialog>
</template>
<script>
import imgurl from '@/views/VisitorApp/assets/images/defaultPicture.png'
import AsyncImg from './AsyncImg'
import AuthorityEdit from './AuthorityEdit'
// addVisitorInfoTest, searchVisitorInfo,
import { getTypeNodeMap, addVisitorInfoTest, listByName } from '@/views/VisitorApp/apis/index.js'
import { phoneVerification, nameValidator, typeValidator } from '@/views/VisitorApp/assets/js/validate.js'
export default {
  components: {
    AsyncImg,
    AuthorityEdit
  },
  data () {
    let that = this // 暂时去掉输入验证
    // 校验证件号是否输入正确
    var validatePassport = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请输入证件号码'))
      } else if (that.form.idenType === '1') {
        // 身份证验证
        // \d{6}
        if (!/^[1-9]\d{5}(19|20)*[0-99]{2}(0[1-9]{1}|10|11|12)(0[1-9]{1}|1[0-9]|2[0-9]|30|31)(\d{3})([0-9]|X|x)$/.test(value)) {
          callback(new Error('请输入正确的身份证号码!'))
        } else {
          callback()
        }
      } else if (that.form.idenType === '5') {
        // 护照验证
        if (
          !/(^1[45][0-9]{7}$)|(^(P|p|S|s)\d{8}$)|(^(S|s|G|g)\d{8}$)|(^(Gg|Tt|Ss|Ll|Qq|Dd|Aa|Ff)\d{8}$)|(^(H|h|M|m)\d{8,10}$)/.test(
            value
          )
        ) {
          callback(new Error('请输入正确的护照号码!'))
        } else {
          callback()
        }
      } else {
        callback()
      }
    }
    return {
      form: {
        name: '',
        company: '',
        sex: '',
        idenType: '',
        focusOnPersonel: '',
        phone: '',
        idenNum: '',
        visitorUuid: '',
        facePic: ''
      },
      defaultForm: {
        name: '',
        company: '',
        sex: '',
        idenType: '',
        focusOnPersonel: '',
        phone: '',
        idenNum: '',
        visitorUuid: '',
        facePic: ''
      },
      effectDate: [],
      dialogFormVisible: false,
      disabledButton: false,
      list: '',
      rules: {
        name: [
          { required: true, min: 2, max: 15, message: '长度在 2 到 15 个字符', trigger: 'blur' },
          { validator: nameValidator, message: '姓名格式输入不正确', trigger: 'blur' }
        ],
        idenNum: [
          { required: true, min: 2, max: 18, message: '请输入证件号码', trigger: 'blur' },
          { validator: validatePassport, message: '证件号码输入不正确', trigger: 'blur' },
          { validator: typeValidator, message: '不能输入特殊字符', trigger: 'blur' }
        ],
        phone: [
          { required: true, message: '请输入手机号码', trigger: 'blur' },
          { validator: phoneVerification, message: '手机号码输入不正确', trigger: 'blur' }
        ],
        visitorType: [
          { required: true, message: '访客类型不能为空', trigger: 'change' }
        ],
        idenType: [
          { required: true, message: '证件类型不能为空', trigger: 'change' }
        ],
        company: [
          { max: 32, message: '长度不超过 32 个字符', trigger: 'blur' }
        ],
        facePic: [
          { required: true, message: '请上传访客头像', trigger: 'blur' }
        ]
      },
      isCan: true,
      isShow: true,
      restaurants: []
    }
  },
  computed: {
    defaultPic: function () {
      return this.form.facePic === '' ? imgurl : this.form.facePic
    }
  },
  methods: {
    visitorEdit: function (personInfo) {
      this.isCan = Boolean(personInfo.name)
      this.isShow = Boolean(!personInfo.name)
      this.disabledButton = false
      /** 设置默认时间 */
      // if (personInfo.startTime === undefined || (personInfo.startTime === '' && personInfo.endTime === '')) {
      //   let startd = new Date()
      //   let endd = new Date()
      //   endd.setTime(startd.getTime() + 3600 * 1000 * 24)
      //   this.effectDate = [startd, endd]
      // }
      this.form = Object.assign({}, this.defaultForm, personInfo)
      // if (personInfo.startTime !== '' && personInfo.startTime !== undefined) {
      //   this.effectDate = [personInfo.startTime, personInfo.endTime]
      // } else {
      //   this.form.startTime = this.formatDateTime(this.effectDate[0])
      //   this.form.endTime = this.formatDateTime(this.effectDate[1])
      // }
      this.dialogFormVisible = true
      getTypeNodeMap(Object.assign({}, personInfo)).then(res => {           // 请求访客下拉数据
        this.list = res.data
        console.log(this.list)
      }).catch(err => {
        console.warn({
          message: err,
          type: 'warning'
        })
      })
    },
    save: function () {
      // this.$emit('openAuthority', this.form) // 保存数据成功后，用事件通知父组件，调用授权页面
      // this.dialogFormVisible = false
      this.$refs['form'].validate((valid) => {
        if (valid) {
          this.disabledButton = true
          addVisitorInfoTest(Object.assign({}, this.form)).then(res => {
            this.form.visitorUuid = res.data.data[0].uuid
            this.form.facePic = res.data.data[0].facePic
            if (res.data.code === '00000') {
              this.$emit('openAuthority', Object.assign({}, this.form)) // 保存数据成功后，用事件通知父组件，调用授权页面
              this.dialogFormVisible = false
              this.$refs.uploadFacePicInput.value = ''
            }
            this.$message({
              message: '保存成功,跳转授权页面',
              type: 'success'
            })
          }).catch(err => {
            console.warn({
              message: err,
              type: 'warning'
            })
          })
        } else {
          this.$message({
            message: '内容未填写完整',
            type: 'warning'
          })
          return false
        }
      })
    },
    cancel: function () {                          // 点击取消重置表单
      this.dialogFormVisible = false
      this.$refs['form'].resetFields()
      this.$refs.uploadFacePicInput.value = ''
    },
    handleClose: function () {
      this.dialogFormVisible = false
      this.$refs['form'].resetFields()
      this.$refs.uploadFacePicInput.value = ''
    },
    // 触发file类型的input的默认事件
    uploadFacePic: function () {
      this.$refs.uploadFacePicInput.click()
    },
    // 读取上传图片的base64编码
    readFacePic: function () {
      const file = this.$refs.uploadFacePicInput.files[0]
      // console.log(file)
      if (file.size <= 204800) {
        if (file.type === 'image/jpeg') {
          const self = this
          var reader = new FileReader()
          reader.readAsDataURL(file)
          reader.onload = function (e) {
            const base64Code = this.result
            self.form.fileName = file.name
            self.form.facePic = base64Code
          }
        } else {
          this.$message({
            message: '图片格式只能为jpg',
            type: 'warning'
          })
          return false
        }
      } else {
        this.$message({
          message: '照片不能大于200kb',
          type: 'warning'
        })
        return false
      }
    },
    /**
     *根据访客名字匹配信息
     */
    querySearchAsync (queryString, cb) {
      listByName({ 'name': queryString }).then(res => {
        console.log(res)
        for (let i of res.data.data) {
          i.value = i.name + i.phone
        }
        this.restaurants = res.data.data
        cb(this.restaurants)
      })
        .catch(err => {
          console.warn({
            message: err,
            type: 'warning'
          })
        })
    },
    handleSelect (item) {
      console.log(item)
      this.form.name = item.name
      this.form.phone = item.phone
      this.form.uuid = item.uuid
      this.form.sex = item.sex
      this.form.idenNum = item.idenNum
      this.form.idenType = item.idenType
      this.form.focusOnPersonel = item.focusOnPersonel
      this.form.company = item.company
      this.form.visitorType = item.visitorType
      this.form.facePic = item.facePic
    }
  }
}
</script>
<style lang="less" scoped>
.uploadPicInput {
  display: none;
}
.upload-con {
  margin-left: 20px;
  .facePic-con {
    width: 260px;
    height: 240px;
    overflow: hidden;
    margin-bottom: 10px;
  }
}
</style>



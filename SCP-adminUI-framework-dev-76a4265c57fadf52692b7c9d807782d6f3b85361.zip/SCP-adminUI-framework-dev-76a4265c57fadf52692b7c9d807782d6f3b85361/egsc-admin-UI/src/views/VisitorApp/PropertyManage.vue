<template>
  <div class="property-container el-container">

    <div class="view-content">
      <el-button type="primary" @click="propertyEdit">添加</el-button>
      <property-edit ref="propertyEdit" @reflushData="getPropertyTableData" :list="typeList"></property-edit>
      <!-- <el-button type="primary" class="button-leading">导入</el-button>
      <el-button type="primary">导出</el-button> -->
      <div class="property-con clearfix">
        <el-form :model="propertyForm" :rules="rules" ref="propertyForm" class="property-form" label-width="100px">
          <el-form-item prop="name" label="人员姓名" class="form-item">
            <el-input v-model="propertyForm.name"></el-input>
          </el-form-item>
          <el-form-item prop="department" label="部门" class="form-item">
            <el-select v-model="propertyForm.department" placeholder="请选择部门" @change="getPosition(propertyForm.department)" size="100px">
              <el-option v-for="item in typeList.department" :key="item.id" :label="item.itemName" :value="item.itemCode"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item prop="idenNum" label="证件号码" class="form-item">
            <el-input v-model="propertyForm.idenNum"></el-input>
          </el-form-item>
          <el-form-item prop="position" label="岗位" class="form-item">
            <el-select v-model="propertyForm.position" placeholder="请选择岗位" size="100px">
              <el-option v-for="item in positionList" :key="item.id" :label="item.itemName" :value="item.itemCode"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item prop="phone" label="电话号码" class="form-item">
            <el-input v-model="propertyForm.phone"></el-input>
          </el-form-item>
          <el-form-item label="人员" class="form-item">
            <el-radio-group v-model="propertyForm.deleteFlag" >
              <el-radio :label="1">在职人员</el-radio>
              <el-radio :label="0">离职人员</el-radio>
            </el-radio-group>
          </el-form-item>
        </el-form>
        <div class="btnbar">
          <el-button type="primary" @click="searchProperty">查询</el-button>
          <el-button type="primary" @click="resetSearchKey">重置</el-button>
        </div>
      </div>
      
      <div class="table-con">
        <pager-table class="visit-pb" ref="pagerTable" :visitor-data="visitorData" :total="total" @turnPage="getPropertyTableData" @selection-change="selectionChange" hasSelect>
          <template slot="table-column">
            <el-table-column label="人员姓名" prop="name" width="130">
            </el-table-column>
            <el-table-column label="性别" prop="sex" :formatter="filtersSex" width="70">
            </el-table-column>
            <el-table-column label="公司" prop="company" width="200">
            </el-table-column>
            <el-table-column label="证件类型" prop="idenType" :formatter="filtersidenType" width="130">
            </el-table-column>
            <el-table-column label="证件号码" prop="idenNum">
            </el-table-column>
            <el-table-column label="居住地址" prop="address">
            </el-table-column>
            <el-table-column label="联系方式" prop="phone" width="150">
            </el-table-column>
            <el-table-column label="创建时间" prop="createTime">
            </el-table-column>
            <el-table-column fixed="right" label="操作" width="150">
              <template slot-scope="scope">
                <el-button type="primary" @click="propertyEdit(scope.row)" size="mini">编辑</el-button>
                <el-button type="danger" @click="remove(scope.row.uuid)" size="mini" style="padding:7px 12px;">删除</el-button>
              </template>
            </el-table-column>
          </template>
        </pager-table>
      </div>
    </div>
  </div>
</template>
<script>

import PagerTable from './components/PagerTable'
import PropertyEdit from './components/PropertyEdit'
import { getProperty, deleteProperty, getTypeNodeMap, positionList } from '@/views/VisitorApp/apis/index.js'

// import { phoneVerification } from '@/views/BroadcastApp/utils/validate.js'
export default {
  components: {
    PagerTable,
    PropertyEdit
  },
  data () {
    // let that = this
    //  校验证件号是否输入正确
    // var validatePassport = (rule, value, callback) => {
    //   if (that.visitorForm.idenType === '') callback()
    //   if (value === '') {
    //     callback(new Error('请输入证件号码'))
    //   } else if (that.visitorForm.idenType === 0) {
    //     // 身份证验证
    //     if (!/\d{17}[\d|x]|\d{15}/.test(value)) {
    //       callback(new Error('请输入正确的身份证号码!'))
    //     } else {
    //       callback()
    //     }
    //   } else if (that.visitorForm.idenType === 1) {
    //     // 护照验证
    //     if (
    //       !/^1[45][0-9]{7}|([P|p|S|s]\d{7})|([S|s|G|g]\d{8})|([Gg|Tt|Ss|Ll|Qq|Dd|Aa|Ff]\d{8})|([H|h|M|m]\d{8，10})$/.test(
    //         value
    //       )
    //     ) {
    //       callback(new Error('请输入正确的护照号码!'))
    //     } else {
    //       callback()
    //     }
    //   }
    // }
    return {
      propertyForm: {
        name: '',
        position: '',
        idenNum: '',
        phone: '',
        department: '',
        deleteFlag: 2
      },
      selections: [],
      rules: {
        name: [
          // { required: true, message: '请输入访客姓名', trigger: 'blur' },
          { min: 1, max: 15, message: '长度在 1 到 15 个字符', trigger: 'blur' }
        ],
        idenNum: [
          { message: '请输入证件号码', trigger: 'blur' },
          { min: 1, max: 18, message: '长度在 1 到 18 个字符', trigger: 'blur' }
        ],
        phone: [
          { message: '请输入手机号码', trigger: 'blur' },
          { min: 1, max: 11, message: '长度在 1 到 11 个字符', trigger: 'blur' }
        ]
      },
      typeList: '',
      positionList: '',
      searchKey: '',
      visitorData: [],
      total: 0,
      currentPage: 1,
      pageSize: 10
    }
  },
  mounted: function (personInfo) {
    this.getPropertyTableData({ 'currentPage': this.currentPage, 'pageSize': this.pageSize })
    getTypeNodeMap(Object.assign({}, personInfo)).then(res => { // 查询时请求物业下拉数据
      this.typeList = res.data
      // console.log(this.typeList.department)
    }).catch(err => {
      console.warn({
        message: err,
        type: 'warning'
      })
    })
  },
  methods: {
    getPropertyTableData: function (params) {
      // if (params === undefined) {
      //   this.resetSearchKey()
      // }
      getProperty(Object.assign({}, this.propertyForm, params)).then(res => {
        console.log(res.data)
        if (res.data.code === '00000') {
          // this.$refs['pagerTable'].getData(res)
          // let that = this
          this.visitorData = res.data.data[0].rows
          console.log(this.visitorData)
          this.currentPage = res.data.data[0].currentPage
          this.total = res.data.data[0].rowCount
        }
        // this.$message({
        //   message: res.data.message ? res.data.message : '查询失败',
        //   type: res.data.message ? 'success' : 'warning'
        // })
      }).catch(err => {
        console.warn({
          message: err,
          type: 'warning'
        })
      })
    },
    getPosition: function (params) {
      if (this.propertyForm.department) {
        this.propertyForm.position = ''
      }
      positionList(params).then(res => {           // 请求物业部门岗位联动下拉数据
        this.positionList = res.data
        // console.log(res.data)
      }).catch(err => {
        console.warn({
          message: err,
          type: 'warning'
        })
      })
    },
    searchProperty: function (options) {
      this.$refs['propertyForm'].validate((valid) => {
        if (valid) {
          this.getPropertyTableData({})
        }
      })
    },
    resetSearchKey: function () {
      for (let key in this.propertyForm) {
        this.propertyForm[key] = ''
      }
    },
    /**
     * @description 点击table组件复选框触发
     * @param Array val 所有选中行数据
     */
    selectionChange: function (val) {
      this.selections = val
      // console.log(val)
    },
    /**
     * 访客录入/编辑访客数据
     */
    propertyEdit: function (propertyInfo = {}) {
      const propertyInfoTmp = Object.assign({}, propertyInfo)
      this.$refs['propertyEdit'].propertyEdit(propertyInfoTmp)
      // console.log(propertyInfoTmp)
    },
    // 数据删除
    remove: function (data) {
      // console.log(data)
      deleteProperty({ uuid: data }).then(res => {
        // console.log(res.data)
        if (res.data.code === '00000') {
          this.$confirm('确定要删除该条信息吗, 是否继续?', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() => {
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
            this.getPropertyTableData({ 'currentPage': this.currentPage, 'pageSize': this.pageSize })
          }).catch(() => {
            this.$message({
              type: 'info',
              message: '已取消删除'
            })
          })
        }
      }).catch(err => {
        console.warn({
          message: err,
          type: 'warning'
        })
      })
    },
    // 人员性别格式化
    filtersSex: function (row, column) {
      // console.log(row.sex)
      var fingerFace = row.sex
      return fingerFace === '1' ? '男' : '女'
    },
    // 证件类型格式化
    filtersidenType: function (row, column) {
      // console.log(row.idenType)
      var fingerFace = row.idenType
      switch (fingerFace) {
        case '1':
          return '身份证'
        case '2':
          return '驾驶证'
        case '3':
          return '学生证'
        case '4':
          return '军官证'
        case '5':
          return '护照'
      }
    }
  }
}
</script>
<style scoped>
.clearfix:before,
.clearfix:after {
  content: "";
  display: table;
  clear: both;
}
.clearfix {
  zoom: 1;
}
.property-container {
  position: relative;
  width: 100%;
  height: 100%;
  min-height: 850px;
  /* padding: 15px 0px 15px -210px; */
  /* padding-left:-210px; */
  padding: 10px;
  border: 1px solid #dddee1;
}
.view-content {
  position: relative;
  float: left;
  width: 100%;
  height: 100%;
  margin-left: 20px;
  /* box-sizing: border-box; */
}
.button-leading {
  margin-left: 10px;
}
.property-con {
  width: 100%;
  margin-top: 15px;
  padding: 15px;
  padding-bottom: 0px;
  border: 1px solid #ccc;
  box-sizing: border-box;
}
.property-form {
  width: 70%;
  float: left;
}
.form-item {
  width: 50%;
  float: left;
}
.btnbar {
  float: right;
}
.table-con {
  position: relative;
  width: 100%;
  height: 65%;
  margin-top: 10px;
}
</style>
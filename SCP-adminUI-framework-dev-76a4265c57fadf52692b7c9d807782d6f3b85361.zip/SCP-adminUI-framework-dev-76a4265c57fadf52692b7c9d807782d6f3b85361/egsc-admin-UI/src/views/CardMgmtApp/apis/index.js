import Axios from '@/assets/js/AxiosPlugin'

// 分页查询二维码
export const getUserListByPage = (listQuery) => {
  return Axios.post('/scp-cardmgmtapp/cardMgmt/queryQrCodeByPage', listQuery).then(res => res.data)
}

// 查询卡片列表
export const queryCardList = (listQuery) => {
  return Axios.post('/scp-cardmgmtapp/cardMgmt/queryCardPage', listQuery).then(res => res.data)
}

// 卡片入库
export const storeCards = condition => {
  console.log(JSON.stringify(condition))
  return Axios.post('/scp-cardmgmtapp/cardMgmt/addCard', condition).then(res => res.data)
}

// 住户查询
export const queryUsers = (userCondition) => {
  console.log(JSON.stringify(userCondition))
  return Axios.post('/scp-cardmgmtapp/cardMgmt/queryUsers', userCondition).then(res => res.data)
}

// 物业人员查询
export const queryManagersByName = (userCondition) => {
  console.log(JSON.stringify(userCondition))
  return Axios.post('/scp-cardmgmtapp/cardMgmt/queryManagersByName', userCondition).then(res => res.data)
}

// 查询卡务流水
export const queryCardOperateList = (listQuery) => {
  return Axios.post('/scp-cardmgmtapp/cardMgmt/queryCardOperatePage', listQuery).then(res => res.data)
}

// 查询挂失卡片信息
export const queryCardBindInfo = (condition) => {
  return Axios.post('/scp-cardmgmtapp/cardMgmt/getUserInfo', condition).then(res => res.data)
}

// 卡片挂失
export const handleCardLost = (condition) => {
  return Axios.post('/scp-cardmgmtapp/cardMgmt/reportCardLost', condition).then(res => res.data)
}

// 卡片解挂
export const handleRecovery = (condition) => {
  return Axios.post('/scp-cardmgmtapp/cardMgmt/reportCardFinded', condition).then(res => res.data)
}

// 卡片注销
export const handleCancellation = (condition) => {
  return Axios.post('/scp-cardmgmtapp/cardMgmt/reportCancelledCard', condition).then(res => res.data)
}

// 卡片退卡
export const handleBackCard = (condition) => {
  return Axios.post('/scp-cardmgmtapp/cardMgmt/reportCardReturned', condition).then(res => res.data)
}

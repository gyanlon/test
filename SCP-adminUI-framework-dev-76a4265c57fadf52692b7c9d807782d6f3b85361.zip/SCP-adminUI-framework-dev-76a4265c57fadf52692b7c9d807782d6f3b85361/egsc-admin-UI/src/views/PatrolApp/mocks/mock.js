import Mock from 'mockjs'
Mock.mock('/PatrolApp/CrewPlan', 'get', {
  'errMsg': null,
  'success': 'true',
  'data': {
    'total': 100,
    'pageNo': 1,
    'rows|90': [
      {
        'date|+1': 1,
        'planName|+1': ['王小虎', '王大虎', '王老虎', '虎不虎', '还是虎', '王小虎'],
        'paramId|+1': ['上海市普陀区金沙江路 1518 弄', '上海市普陀区金沙江路 1519 弄'],
        'startTime|+1': ['2016-05-03', '2016-05-06'],
        'beginTime|+1': ['2017-05-03', '2017-05-06']
      }
    ]
  }
})

Mock.mock('/PatrolApp/HistoryTask', 'get', {
  'errMsg': null,
  'success': 'true',
  'data': {
    'total': 100,
    'pageNo': 1,
    'rows|90': [
      {
        'date|+1': 1,
        'startPlanTime|+1': ['2016-05-03', '2016-05-06', '2016-05-06', '2016-05-06', '2017-05-06', '2017-05-03'],
        'paramsId|+1': ['巡查参数1', '巡查参数2'],
        'deviceId|+1': ['单兵1', '单兵2'],
        'userId|+1': ['张三', '李四'],
        'taskStatus|+1': ['正常', '异常']
      }
    ]
  }
})

Mock.mock('/PatrolApp/PlanInfo', 'get', {
  'errMsg': null,
  'success': 'true',
  'data': {
    'total': 100,
    'pageNo': 1,
    'rows|90': [
      {
        'date|+1': 1,
        'startTime|+1': ['2016-05-03', '2016-05-06', '2016-05-06', '2016-05-06', '2017-05-06', '2017-05-03'],
        'parameter|+1': ['巡查参数1', '巡查参数2'],
        'requipments|+1': ['单兵1', '单兵2']
      }
    ]
  }
})

Mock.mock('/PatrolApp/PatrolParamApp', 'get', {
  'errMsg': null,
  'success': 'true',
  'data': {
    'rows|6': [
      {
        'order|+1': 1,
        'parameterName|+1': ['Wulian720p摄像头', '中兴Memo', '微软 LifeCam HD', '罗技Pro C920'],
        'equipment|+1': ['中兴1号', '中兴2号'],
        'startTime|+1': ['8:00', '8:20', '8:40', '8:50', '9:00']
      }
    ]
  }
})

Mock.mock('/PatrolApp/ParameterSave', 'get', {
  'errMsg': null,
  'success': 'true',
  'data': {
    'rows|5': [
      {
        'date|+1': 1,
        'name|+1': ['小虎1', '小虎2', '小虎3', '小虎4', '小虎5', '小虎6'],
        'address|+1': ['普陀区金沙江路1', '普陀区金沙江路2']
      }
    ]
  }
})

Mock.mock('/PatrolApp/PatrolChoose', 'get', {
  'errMsg': null,
  'success': 'true',
  'data': {
    'rows': [
      { 'uuid': '0101011', 'pointId': '001', 'interval': '15', 'paramId': '00110011', 'pointName': '巡查点1' },
      { 'uuid': '0101022', 'pointId': '002', 'interval': '12', 'paramId': '00110012', 'pointName': '巡查点2' },
      { 'uuid': '0101033', 'pointId': '003', 'interval': '10', 'paramId': '00110013', 'pointName': '巡查点3' },
      { 'uuid': '0101044', 'pointId': '004', 'interval': '18', 'paramId': '00110014', 'pointName': '巡查点4' },
      { 'uuid': '0101045', 'pointId': '004', 'interval': '18', 'paramId': '00110014', 'pointName': '巡查点5' },
      { 'uuid': '0101046', 'pointId': '004', 'interval': '18', 'paramId': '00110014', 'pointName': '巡查点6' },
      { 'uuid': '0101047', 'pointId': '004', 'interval': '18', 'paramId': '00110014', 'pointName': '巡查点7' }
    ]
  }
})

Mock.mock('/PatrolApp/PatrolPointApp', 'get', {
  'errMsg': null,
  'success': 'true',
  'data': {
    'rows|10': [
      {
        'pointName|+1': ['巡更点名称1', '巡更点名称2'],
        'remark|+1': ['abc12345', 'abc']
      }
    ]
  }
})

Mock.mock('/PatrolApp/components/dialogs/CheckResult', 'get', {
  'errMsg': null,
  'success': 'true',
  'data': {
    'date|+1': 1,
    'resultname|+1': ['2016-05-03', '2016-05-06', '2016-05-06', '2016-05-06', '2017-05-06', '2017-05-03'],
    'pointtime|+1': ['2016-05-03', '2016-05-06', '2016-05-06'],
    'result|+1': ['异常', '正常'],
    'reason|+1': ['母鸡', '正常']
  }
})

// Mock.mock('/PatrolApp/TimeoutAlarmEvent', 'get', {
//   'errMsg': null,
//   'success': 'true',
//   'data': {
//     'rows': [
//       {
//         'date|+1': 1,
//         'startTime|+1': ['2016-05-03', '2016-05-06', '2016-05-06', '2016-05-06', '2017-05-06', '2017-05-03'],
//         'parameter|+1': ['超时报警'],
//         'descrlbe|+1': ['西南角越界'],
//         'state|+1': ['已处理', '未处理']
//       }
//     ]
//   }
// })

<template>
  <div class="container patro-param">
    <el-row :gutter="20" class="row-box">
      <el-form label-width="80px " class="form-one">
        <el-col :span="6">
          <el-form-item label="参数名称：" label-width="100px" class="plan-name">
            <el-input v-model="paramName" auto-complete="off"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="设备：">
            <el-select placeholder="请选择" v-model="queryDevice">
              <el-option v-for="item in deviceList" :key="item.deviceID" :label="item.deviceDesc || item.deviceName" :value="item.deviceID"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
      </el-form>
      <el-col :span="2">
        <div class="grid-content bg-purple">
          <el-button class="el-button el-button--primary" @click="queryList">查询</el-button>
        </div>
      </el-col>
      <el-col :span="2">
        <div class="grid-content bg-purple">
          <el-button class="el-button el-button--primary" @click="resetForm">重置</el-button>
        </div>
      </el-col>
    </el-row>

    <el-row :gutter="20" class="row-box table-btn">
      <el-col :span="2">
        <div class="grid-content bg-purple">
          <el-button class="el-button-add el-button--primary" type="button" @click="addPatrolPram">添加</el-button>
        </div>
      </el-col>
      <el-col :span="2">
        <div class="grid-content bg-purple">
          <el-button class="el-button-add el-button--primary" @click="deleteRow">删除</el-button>
        </div>
      </el-col>
    </el-row>
    <el-row class="row-box patrolParam-table">
      <!-- <el-table :data="patrolParmData.slice((pageData.pageNo-1)*pageData.pageSize,pageData.pageNo*pageData.pageSize)" border @selection-change="handleSelectionChange" align="center"> -->
      <el-table :data="patrolParmData" border @selection-change="handleSelectionChange" align="center">
        <el-table-column label="" type="selection" class="el-table-column-all" header-align="center"></el-table-column>
        <el-table-column label="序号" type="index" header-align="center" width="100px"></el-table-column>
        <el-table-column label="参数名称" prop="paramName" header-align="center"></el-table-column>
        <el-table-column label="设备" prop="deviceName" header-align="center"> </el-table-column>
        <el-table-column label="时长" prop="timeLong" header-align="center"></el-table-column>
        <el-table-column label="操作" prop="scope" header-align="center">
          <template slot-scope="scope">
            <el-button size="mini" @click="handleEdit(scope.$index, scope.row)">更新</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="block pagination-box">
        <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="pageData.pageNo" :page-sizes="[2, 5, 10, 20, 30]" :page-size="pageData.pageSize" layout="total, sizes, prev, pager, next, jumper" :total="pageData.total">
        </el-pagination>
      </div>
    </el-row>
    <parameter-save ref="paramSave" :infoId="infoId" :show="show" :deviceList="deviceList" @closeDialog="closeSave" :refresh="refresh"></parameter-save>
  </div>
</template>
<script>
import ParameterSave from './components/dialogs/ParameterSave'
import { PatrolParamApp, DelParam, getDviceList } from './apis/index'
export default {
  data () {
    return {
      patrolParmData: [],
      show: false,
      showstate: false,
      dialogTableVisible: false,
      dialogFormVisible: false,
      form: {
        name: '',
        region: '',
        date1: '',
        date2: '',
        delivery: false,
        type: [],
        resource: '',
        desc: ''
      },
      // 设备列表
      deviceList: [],
      formLabelWidth: '120px',
      paramName: '',
      queryDevice: '',
      multipleSelection: [],
      pageData: {
        pageNo: 1,
        pageSize: 10,
        total: 0
      },
      flag: 'add',
      infoId: '',
      paramInfo: {}
    }
  },
  mounted () {
    this.getPatrolParamList()
    this.getDvicesList()
  },
  methods: {
    refresh () {
      this.queryList()
    },
    // 添加巡查参数配置
    addPatrolPram () {
      // 清空添加页面表单
      this.$refs.paramSave.clearData()
      this.infoId = ''
      this.show = true
      this.flag = 'add'
    },
    closeSave () {
      this.show = false
      this.infoId = ''
    },
    // 重置
    resetForm () {
      this.paramName = ''
      this.queryDevice = ''
      this.pageData.pageNo = 1
      this.pageData.pageSize = 10
    },
    // 获取设备列表
    getDvicesList () {
      getDviceList().then(res => {
        if (res.data.code === '0') {
          this.deviceList = res.data.data
        } else {
          this.$message.error('获取设备列表失败')
        }
      }).catch(err => {
        console.log(err)
      })
    },
    // 获取巡查参数list
    getPatrolParamList () {
      let param = {
        pageNo: this.pageData.pageNo,
        pageSize: this.pageData.pageSize,
        paramName: this.paramName,
        deviceId: this.queryDevice
      }
      PatrolParamApp(param).then((rs) => {
        if (rs.data.code === '0') {
          this.patrolParmData = rs.data.data.patrolParamDto
          this.pageData.total = rs.data.data.pageCount
        } else {
          this.patrolParmData = []
          this.$message.error('获取数据失败')
        }
      })
    },
    // 查询
    queryList () {
      this.getPatrolParamList()
    },
    // 删除
    deleteRow () {
      let param = {}
      param.patrolParamIds = this.multipleSelection

      // 发送请求删除选中项
      DelParam(param).then(res => {
        if (res.data.code === '0') {
          this.$message({
            message: '删除成功',
            type: 'success'
          })
          // 请求最新列表
          this.getPatrolParamList()
        } else {
          this.$message.error('删除失败')
        }
      }).catch(err => {
        console.log(err)
      })
    },
    // 更新
    handleEdit (index, row) {
      this.show = true
      this.flag = 'modify'
      this.infoId = row.uuid
    },
    // 表格选中项
    handleSelectionChange (val) {
      this.multipleSelection = []
      val.forEach(i => {
        this.multipleSelection.push(i.uuid)
      })
    },
    handleSizeChange (val) {
      console.log(`每页 ${val} 条`)
      this.pageData.pageSize = val
      this.getPatrolParamList()
    },
    handleCurrentChange (val) {
      console.log(`当前页: ${val}`)
      this.pageData.pageNo = val
      this.getPatrolParamList()
    }
  },
  components: { ParameterSave }
}
</script>
<style scoped lang="less">
.patro-param {
  margin: 10px;
  .row-box {
    margin: 10px 0;
    .pagination-box {
      text-align: center;
      padding: 20px 0;
    }
  }
  .table-btn {
    margin-top: 25px;
  }
  .el-input {
    width: 150px;
    margin: 0 100px 0 15px;
  }
  .el-select {
    width: 200px;
    margin: 0 100px 0 15px;
  }
  .el-button-add {
    margin-right: 50px;
  }
  .patrolParam-table {
    width: 100%;
    .el-table {
      width: 100%;
      margin-top: 10px;
      th,
      td {
        .cell {
          text-align: center;
        }
      }
    }
  }
}
</style>
<style lang="less">
.patro-param {
  .el-dialog {
    width: 800px;
  }
  .el-table--border td,
  .el-table--border th {
    text-align: center;
  }
}
</style>



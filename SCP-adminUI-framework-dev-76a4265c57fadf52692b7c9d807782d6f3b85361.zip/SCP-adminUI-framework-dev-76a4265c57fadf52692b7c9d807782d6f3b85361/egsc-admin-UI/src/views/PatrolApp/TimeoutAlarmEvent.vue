<template>
  <div>
    <!-- 横线 + 上半 -->
    <div>
      <el-form :inline="true" :model="TimeoutQuery" class="demo-form-inline">
        <!-- 第一行 -->
        <el-row style="margin-top:30px;margin-bottom:20px">
          <!-- 第一列 -->
          <el-col :xs="7" :sm="7" :md="7" :lg="7" :xl="7">
            <el-form-item label="人 员" label-width="70px">
              <el-select placeholder="请选择查找人姓名" v-model="TimeoutQuery.userId" @focus="addGetName">
                <el-option v-for="item in personList" :key="item.uuid" :label="item.name" :value="item.name"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <!-- 第二列 -->
          <el-col :xs="9" :sm="9" :md="9" :lg="9" :xl="9">
            <el-form-item label="任 务" label-width="70px">
              <el-input v-model="TimeoutQuery.taskName" placeholder="请输入任务名"></el-input>
            </el-form-item>
          </el-col>
          <!-- 第三列 -->
          <el-col :xs="3" :sm="3" :md="3" :lg="3" :xl="3">
            <el-form-item>
              <el-button type="primary" @click="getDate">查 询</el-button>
            </el-form-item>
          </el-col>
        </el-row>
        <!-- 第二行 -->
        <el-row style="margin-top:20px;margin-bottom:20px">
          <!-- 第一列 -->
          <el-col :xs="7" :sm="7" :md="7" :lg="7" :xl="7">
            <el-form-item label="设 备" label-width="70px">
              <el-select placeholder="请选择查找设备" v-model="TimeoutQuery.deviceId" @focus="addTaskName">
                <el-option v-for="item in taskList" :key="item.deviceID" :label="item.deviceName" :value="item.deviceID"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <!-- 第二列 -->
          <el-col :xs="9" :sm="9" :md="9" :lg="9" :xl="9">
            <el-form-item label="时 段" label-width="70px">
              <el-date-picker v-model="TimeoutQuery.beginDate" type="daterange" align="right" unlink-panels range-separator="至" start-placeholder="开始日期" value-format="yyyy-MM-dd" end-placeholder="结束日期" :picker-options="pickerOptions2">
              </el-date-picker>
            </el-form-item>
          </el-col>
          <!-- 第三列 -->
          <el-col :xs="3" :sm="3" :md="3" :lg="3" :xl="3">
            <el-form-item>
              <el-button type="primary" @click="closeQuery">重 置</el-button>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>
    <!-- END -->

    <!-- 表格 -->
    <div>
      <el-table ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%" @selection-change="handleSelectionChange" border>
        <el-table-column label="序号" prop="index" type="index" align="center" header-align="center" width="50"></el-table-column>
        <el-table-column label="开始时间" prop="createTime" align="center" header-align="center"></el-table-column>
        <el-table-column label="人员" prop="userId" align="center" header-align="center"> </el-table-column>
        <el-table-column label="设备" prop="deviceId" align="center" header-align="center"> </el-table-column>
        <el-table-column label="任务" prop="taskName" align="center" header-align="center"></el-table-column>
        <el-table-column label="原因" prop="lateReason" align="center" show-overflow-tooltip header-align="center"></el-table-column>
        <el-table-column label="预警" align="center" header-align="center" type="text">
          <template slot-scope="scope">
            <span :class="getPoinStatusClass(scope.$index, scope.row)" @click="statusClick(scope.$index, scope.row)">
              {{formatStatus(scope.$index, scope.row)}}
            </span>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页 -->
      <el-pagination @size-change="handleSizeChange" background @current-change="handleCurrentChange" align='center' :current-page="current.pageNo" :page-sizes="[10,20,30,40,50,60]" :page-size="current.pageSize" layout="total, sizes, prev, pager, next, jumper" :total="current.total" style="margin-top:15px"></el-pagination>
      <!-- 分页 END -->
    </div>
    <!-- 弹框 -->
    <describe :visible="showaddDialog" v-on:child-say="listenToMyBoy" :child-msg="msg" :times='time' :deviceId='deviceId' :person='person' :diffserv='diffserv' :uuid='uuid' @closeDialog="closeDialog"></describe>
    <!-- END 弹框 -->
    <!-- END -->
  </div>
</template>


<script>
import { TimeoutAlarmEvent, getName, taskName } from './apis/index.js'
import describe from './components/dialogs/BoundaryViolationAlarm.vue'

export default {
  components: {
    describe
  },
  data () {
    return {
      msg: '',
      time: '',
      person: '',
      deviceId: '',
      diffserv: '',
      uuid: '',
      showaddDialog: false,
      TimeoutQuery: {
        taskName: '',
        userId: '',
        beginDate: '',
        endDate: '',
        deviceId: ''
      },
      current: {
        pageNo: 1,
        pageSize: 10,
        total: 0
      },
      pickerOptions2: {
        shortcuts: [{
          text: '最近一周',
          onClick (picker) {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
            picker.$emit('pick', [start, end])
          }
        }, {
          text: '最近一个月',
          onClick (picker) {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
            picker.$emit('pick', [start, end])
          }
        }, {
          text: '最近三个月',
          onClick (picker) {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
            picker.$emit('pick', [start, end])
          }
        }, {
          text: '最近六个月',
          onClick (picker) {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 180)
            picker.$emit('pick', [start, end])
          }
        }, {
          text: '最近一年',
          onClick (picker) {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 365)
            picker.$emit('pick', [start, end])
          }
        }]
      },
      multipleSelection: [],
      tableData: [],
      timeoutAlarmEvent: 'timeoutAlarmEvent',
      personList: [],
      taskList: []
    }
  },
  mounted () {
    this.getDate()
  },
  methods: {
    // timeTransform (time) {
    //   var year = getFullYear(time)
    //   var month =
    // },
    // // 时间转化方法
    // format (shijianchuo) {
    //   var time = new Date(shijianchuo)
    //   var y = time.getFullYear()
    //   var m = time.getMonth() + 1
    //   var d = time.getDate()
    //   var h = time.getHours()
    //   var mm = time.getMinutes()
    //   var s = time.getSeconds()
    //   return y + '-' + (m < 10 ? '0' + m : m) + '-' + (d < 10 ? '0' + d : d) + ' ' + (h < 10 ? '0' + h : h) + ':' + (mm < 10 ? '0' + mm : mm) + ':' + (s < 10 ? '0' + s : s)
    // },
    /*
     * ajax 初始请求
     */
    getDate () {
      // console.log(this.TimeoutQuery.beginDate)
      if (this.TimeoutQuery.beginDate != null) {
        for (var i = 0; i < this.TimeoutQuery.beginDate.length; i++) {
          var strBegin = this.TimeoutQuery.beginDate[0]
          var strEnd = this.TimeoutQuery.beginDate[1]
        }
      }
      // 传入的参数
      let params = {
        'pageSize': this.current.pageSize,
        'pageNo': this.current.pageNo,
        'taskName': this.TimeoutQuery.taskName,
        'userId': this.TimeoutQuery.userId,
        'beginDate': strBegin,
        'endDate': strEnd,
        'deviceId': this.TimeoutQuery.deviceId
      }
      TimeoutAlarmEvent(params).then(rs => {
        console.log(rs)
        if (rs.status === 200) {
          this.tableData = rs.data.data.rows
          this.current.total = rs.data.data.total
          console.log(this.current.total)
          console.log('请求成功')
        } else {
          this.data = []
        }
      })
    },
    // 人员姓名下拉框
    addGetName () {
      getName().then(rs => {
        console.log(rs)
        if (rs.data.code === '0') {
          this.personList = rs.data.data
          console.log(this.personList)
          console.log('请求成功')
        } else {
          this.data = []
        }
      })
    },
    // 设备选择下拉框
    addTaskName () {
      taskName().then(rs => {
        console.log(rs)
        if (rs.data.code === '0') {
          this.taskList = rs.data.data
          console.log(this.taskList)
          console.log('请求成功')
        } else {
          this.data = []
        }
      })
    },
    // 预警项条件内的变色
    getPoinStatusClass (index, row) { // row, column, rowIndex, columnIndex
      let status = row.historyPointStatus
      if ((status === '3' || status === '4') && (row.lateReason === undefined || row.lateReason === null || row.lateReason === '')) {
        console.log('当前样式----')
        return 'clickStyle'
      }
    },
    // 预警点击事件
    statusClick (index, row) {
      let status = row.historyPointStatus
      console.log('当前状态：-----', this.status)
      if ((status === '3' || status === '4') && (row.lateReason === undefined || row.lateReason === null || row.lateReason === '')) {
        this.showaddDialog = true
        this.msg = row.taskName
        this.time = row.createTime
        this.person = row.userId
        this.diffserv = this.timeoutAlarmEvent
        this.uuid = row.uuid
        this.deviceId = row.deviceId
      }
    },
    formatStatus (index, row) {
      let statusText = ['未查巡', '已查巡', '超时未查巡', '超时已查巡', '超时预警中', '超时预警已解除']
      return statusText[parseInt(row.historyPointStatus)]
    },
    /*
     * list
     */
    toggleSelection (rows) {
      if (rows) {
        rows.forEach(row => {
          this.$refs.multipleTable.toggleRowSelection(row)
        })
      } else {
        this.$refs.multipleTable.clearSelection()
      }
    },
    /*
     * 分页
     */
    handleSizeChange (val) {
      /*
       *每页显示几条
       */
      console.log(`每页 ${val} 条`)
      this.current.pageSize = val
      this.getDate()
    },
    /*
     *当前页数
     */
    handleCurrentChange (val) {
      console.log(`当前页: ${val}`)
      this.current.pageNo = val
      this.getDate()
    },
    handleSelectionChange (val) {
      this.multipleSelection = val
    },
    // 组件--弹框开启
    dialogFormVisible () {
      console.log('点击')
      this.showaddDialog = true
    },
    // 组件-弹框关闭
    closeDialog () {
      this.showaddDialog = false
    },
    /*
     *  重置按钮
     */
    closeQuery () {
      this.TimeoutQuery.taskName = ''
      this.TimeoutQuery.userId = ''
      this.TimeoutQuery.beginDate = ''
      this.TimeoutQuery.deviceId = ''
      this.getDate()
    },
    // 子组件反馈信息
    listenToMyBoy: function (somedata, ros) {
      for (var i = 0; i < this.current.total; i++) {
        let uu = this.tableData[i].uuid
        if (uu === ros) {
          this.tableData[i].lateReason = somedata
          console.log(somedata)
          this.tableData[i].historyPointStatus = 5
        }
      }
    }
  }
}
</script>

<style lang="less" scoped>
// /* el-form */
// .demo-form-inline {
//   margin-bottom: 34px;
//   padding-bottom: 20px;
//   margin-top: 44px;
// }
// /* 查询按钮 */
// .el-form-item__content {
//   width: 50%;
// }
// .el-form-item__content .el-button--primary {
//   // margin-left: 900%;
//   width: 100px;
//   height: 44px;
// }
// .el-button--text {
//   color: #5050dd;
// }
.clickStyle {
  color: blue;
  cursor: pointer;
}
</style>
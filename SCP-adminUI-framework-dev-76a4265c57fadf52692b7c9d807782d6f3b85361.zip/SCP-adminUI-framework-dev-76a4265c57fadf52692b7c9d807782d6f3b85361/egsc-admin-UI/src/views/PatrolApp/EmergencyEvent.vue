<template>
  <div>
    <!-- 横线 + 上半 -->
    <div>
      <el-form :inline="true" :model="EmergencyQuery" class="demo-form-inline">
        <!-- 第一行 -->
        <el-row style="margin-top:30px;margin-bottom:20px">
          <!-- 第一列 -->
          <el-col :xs="7" :sm="7" :md="7" :lg="7" :xl="7">
            <el-form-item label="处理人" label-width="70px">
              <el-select placeholder="请选择查找人姓名" v-model="EmergencyQuery.userId" @focus="addGetName">
                <el-option v-for="item in personList" :key="item.uuid" :label="item.name" :value="item.name"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <!-- 第二列 -->
          <el-col :xs="9" :sm="9" :md="9" :lg="9" :xl="9">
            <el-form-item label="任 务" label-width="70px">
              <el-input v-model="EmergencyQuery.taskName" placeholder="请输入任务名"></el-input>
            </el-form-item>
          </el-col>
          <!-- 第三列 -->
          <el-col :xs="3" :sm="3" :md="3" :lg="3" :xl="3">
            <el-form-item>
              <el-button type="primary" @click="addEmergencyEvent">查询</el-button>
            </el-form-item>
          </el-col>
        </el-row>
        <!-- 第二行 -->
        <el-row style="margin-top:20px;margin-bottom:20px">
          <!-- 第一列 -->
          <el-col :xs="7" :sm="7" :md="7" :lg="7" :xl="7">
            <el-form-item label="设 备" label-width="70px">
              <el-select placeholder="请选择查找设备" v-model="EmergencyQuery.deviceId" @focus="addTaskName">
                <el-option v-for="item in taskList" :key="item.deviceID" :label="item.deviceName" :value="item.deviceID"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <!-- 第二列 -->
          <el-col :xs="9" :sm="9" :md="9" :lg="9" :xl="9">
            <el-form-item label="时 段" label-width="70px">
              <el-date-picker v-model="EmergencyQuery.beginDate" type="daterange" align="right" unlink-panels range-separator="至" start-placeholder="开始日期" value-format="yyyy-MM-dd" end-placeholder="结束日期" :picker-options="pickerOptions2">
              </el-date-picker>
            </el-form-item>
          </el-col>
          <!-- 第三列 -->
          <el-col :xs="3" :sm="3" :md="3" :lg="3" :xl="3">
            <el-form-item>
              <el-button type="primary" @click="closeQuery">重 置</el-button>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>
    <!-- END -->
    <!-- 表格 -->
    <div>
      <el-table ref="multipleTable" :data="EmergencyData" tooltip-effect="dark" style="width: 100%" @selection-change="handleSelectionChange" border>
        <!-- <el-table-column type="selection" width="80" align="center" header-align="center"></el-table-column> -->
        <el-table-column label="序号" prop="index" type="index" align="center" header-align="center" width="50"></el-table-column>
        <el-table-column label="事发时间" prop="eventTime" align="center" header-align="center"></el-table-column>
        <el-table-column label="事发地点" prop="place" align="center" header-align="center"></el-table-column>
        <el-table-column label="事件类型" prop="emergencyType" align="center" header-align="center"></el-table-column>
        <el-table-column label="处理人" prop="userId" align="center" header-align="center"> </el-table-column>
        <el-table-column label="设备" prop="deviceId" align="center" header-align="center"> </el-table-column>
        <el-table-column label="任务" prop="taskName" align="center" header-align="center"> </el-table-column>
        <el-table-column label="描述" align="center" show-overflow-tooltip header-align="center">
          <span slot-scope="scope" @click="dialogFormVisible(scope.$index, scope.row)" type="text" style="color:blue;cursor:pointer">
            {{ scope.row.description }}
          </span>
        </el-table-column>
        <el-table-column label="更新时间" prop="updateTime" align="center" header-align="center"></el-table-column>
        <!-- <el-table-column label="处理状态" prop="status" align="center" header-align="center" type="text"></el-table-column> -->
      </el-table>

      <!-- 分页 -->
      <el-pagination @size-change="handleSizeChange" background @current-change="handleCurrentChange" align='center' :current-page="current.pageNo" :page-sizes="[10,20,30,40,50,60]" :page-size="current.pageSize" layout="total, sizes, prev, pager, next, jumper" :total="current.total" style="margin-top:15px"></el-pagination>
      <!-- 分页 END -->
    </div>
    <!-- 弹框 -->
    <describe :show="showaddDialog" :child="photo" :video='video' @closeDialog="closeDialog"></describe>
    <!-- END 弹框 -->
    <!-- END -->
  </div>
</template>

<script>
import { EmergencyEvent, getName, taskName } from './apis/index'
import describe from './components/dialogs/GustyEventDescribe.vue'

export default {
  components: {
    describe
  },
  data () {
    return {
      pickerOptions2: {
        shortcuts: [{
          text: '最近一周',
          onClick (picker) {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
            picker.$emit('pick', [start, end])
          }
        }, {
          text: '最近一个月',
          onClick (picker) {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
            picker.$emit('pick', [start, end])
          }
        }, {
          text: '最近三个月',
          onClick (picker) {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
            picker.$emit('pick', [start, end])
          }
        }, {
          text: '最近六个月',
          onClick (picker) {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 180)
            picker.$emit('pick', [start, end])
          }
        }, {
          text: '最近一年',
          onClick (picker) {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 365)
            picker.$emit('pick', [start, end])
          }
        }]
      },
      showaddDialog: false,
      photo: '',
      video: '',
      EmergencyQuery: {
        userId: '',
        deviceId: '',
        beginDate: '',
        taskName: ''
      },
      current: {
        pageNo: 1,
        pageSize: 10,
        total: 0
      },
      multipleSelection: [],
      EmergencyData: [],
      personList: [],
      taskList: []
    }
  },
  mounted () {
    this.addEmergencyEvent()
  },
  methods: {
    /*
    *数据加载
    */
    addEmergencyEvent () {
      console.log(this.EmergencyQuery.userId)
      if (this.EmergencyQuery.beginDate != null) {
        var strBegin = this.EmergencyQuery.beginDate[0]
        var strEnd = this.EmergencyQuery.beginDate[1]
      }
      // 传送数据
      let params = {
        'pageSize': this.current.pageSize,
        'pageNo': this.current.pageNo,
        'userId': this.EmergencyQuery.userId,
        'beginDate': strBegin,
        'endDate': strEnd,
        'deviceId': this.EmergencyQuery.deviceId,
        'taskName': this.EmergencyQuery.taskName
      }
      EmergencyEvent(params).then(rs => {
        console.log(rs)
        if (rs.data.code === '0') {
          this.EmergencyData = rs.data.data.rows
          console.log(rs.data.data.rows.picUrl)
          this.current.total = rs.data.data.total
          console.log(rs.data.data.rows)
        } else {
          this.data = []
        }
      })
    },
    /*
    * 分页
    */
    handleSizeChange (val) {
      /*
       *每页显示几条
       */
      console.log(`每页 ${val} 条`)
      this.current.pageSize = val
      this.addEmergencyEvent()
    },
    /*
     *当前页数
     */
    handleCurrentChange (val) {
      console.log(`当前页: ${val}`)
      this.current.pageNo = val
      this.addEmergencyEvent()
    },
    toggleSelection (rows) {
      if (rows) {
        rows.forEach(row => {
          this.$refs.multipleTable.toggleRowSelection(row)
        })
      } else {
        this.$refs.multipleTable.clearSelection()
      }
    },
    handleSelectionChange (val) {
      this.multipleSelection = val
    },
    /*
     *点击描述 -- 弹框弹出
     */
    dialogFormVisible (index, row) {
      console.log('点击')
      this.showaddDialog = true
      this.photo = row.picUrl
      console.log(this.photo)
      this.video = row.videoUrl
    },
    /*
  *  重置按钮
  */
    closeQuery () {
      this.EmergencyQuery.userId = ''
      this.EmergencyQuery.beginDate = ''
      this.EmergencyQuery.deviceId = ''
      this.EmergencyQuery.taskName = ''
      this.addEmergencyEvent()
    },
    // 人员姓名下拉框
    addGetName () {
      getName().then(rs => {
        console.log(rs)
        if (rs.data.code === '0') {
          this.personList = rs.data.data
          console.log(this.personList)
          this.current.total = rs.data.data.total
          console.log(this.current.total)
          console.log('请求成功')
        } else {
          this.data = []
        }
      })
    },
    // 设备选择下拉框
    addTaskName () {
      taskName().then(rs => {
        console.log(rs)
        if (rs.data.code === '0') {
          this.taskList = rs.data.data
          console.log(this.taskList)
          console.log('请求成功')
        } else {
          this.data = []
        }
      })
    },
    /*
     *关闭弹框
     */
    closeDialog () {
      this.showaddDialog = false
    }
  }
}
</script>

 <style lang="less" scoped>
// /* el-form */
// .demo-form-inline {
//   margin-bottom: 34px;
//   padding-bottom: 20px;
//   margin-top: 44px;
// }
// /* 查询按钮 */
// .el-button--primary {
//   margin-left: 1000px;
//   width: 100px;
//   height: 44px;
//   background: none;
//   color: gray;
// }
.el-table el-table-column .cell {
  color: blue;
}
</style>
<template>
  <div>
    <el-dialog title='' :visible='show' width='50%' @close='closeEvent' class='add-one'>
      <el-form :model='detailInfo'>
        <el-form-item label='计划名称' label-width='100px' class='plan-name-one' id='plan-one'>
          <el-input v-model='detailInfo.planName' auto-complete='off'></el-input>
        </el-form-item>
        <el-form-item label='巡查参数' label-width='100px' class='plan-name-two'>
          <el-select placeholder='请选择巡查区域' v-model='paramName' @change='getValue'>
            <el-option v-for='item in partolParams' :key='item.uuid' :label='item.paramName' :value='item.uuid' class='item.timeLong'></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label='开始时间' label-width='100px' class='plan-name-three'>
          <el-date-picker v-model='detailInfo.startTime' value-format='yyyy-MM-dd' type='date' placeholder='选择日期' :editable="false">
          </el-date-picker>
        </el-form-item>
        <el-form-item label='结束时间' label-width='100px' class='plan-name-four'>
          <el-date-picker v-model='detailInfo.endTime' value-format='yyyy-MM-dd' type='date' placeholder='选择日期' :editable="false">
          </el-date-picker>
        </el-form-item>
        <el-form-item label='巡更周期' label-width='100px'>
          <el-checkbox :indeterminate='isIndeterminate' v-model='detailInfo.checkAll' @change="handleCheckAllChange">全选</el-checkbox>
          <div style='margin: 15px 0;'></div>
          <el-checkbox-group v-model='detailInfo.repeat' @change='handleCheckedWeeksChange'>
            <el-checkbox v-for='Week in Weeks' :label='Week' :key='Week'>{{Week}}</el-checkbox>
          </el-checkbox-group>
        </el-form-item>
      </el-form>
      <h4 class='Period'>巡查时段 </h4>
      <span>(开始时间早于当前时间的巡查班次将不会被生成)</span>
      <div class='checkPeriod'>
        <el-button type='primary' @click.native.prevent='addRows' class='secondAdd'>添加</el-button>
        <el-button type='primary' @click.native.prevent='handleClickDelete'>清除</el-button>
        <div style='margin-top: 20px' class=''>
          <el-table ref='singleTable' :data='group' highlight-current-row style='width: 100%' :border='true'>
            <el-table-column type='index' label='序号' width='50'>
            </el-table-column>
            <el-table-column label='开始时间' show-overflow-tooltip align='center' prop='startTime'>
              <template slot-scope='scope'>
                <el-time-select placeholder='起始时间' v-model='scope.row.startTime' :picker-options='beginOption' @change='getStartTime(scope.row.startTime,scope.index,scope.row)'>
                </el-time-select>
              </template>
            </el-table-column>
            <el-table-column label='结束时间' show-overflow-tooltip align='center' prop='endTime'>
              <template slot-scope='scope'>
                <el-time-select placeholder='结束时间' value-format='hh-ss' :picker-options='endOption' v-model='scope.row.endTime'></el-time-select>
              </template>
            </el-table-column>
            <el-table-column fixed='right' label='操作' width='120' align='center'>
              <template slot-scope='scope'>
                <el-button @click.native.prevent='deleteRow(scope.$index, scope.row)' type='text' size='small'>
                  移除
                </el-button>
              </template>
            </el-table-column>
          </el-table>
        </div>
      </div>
      <div slot='footer' class='dialog-footer'>
        <el-button type='primary' @click='saveEvent' class='savePlan'>保存</el-button>
        <el-button @click='closeEvent'>取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import { patrolPiontId, personPlan, renewPlan } from '../../apis/index'
const WeekOptions = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31']
export default {
  props: {
    show: {
      type: Boolean,
      required: true,
      default () {
        return false
      }
    },
    selectMessege: {
      type: String,
      default: ''
    }
  },
  data () {
    return {
      timeLong: '',
      optionValue: '',
      courtUuid: '',
      uuid: '',
      name: '',
      value1: '',
      value2: '',
      paramName: '',
      finishtime: '',
      checkAll: false,
      isIndeterminate: true,
      Weeks: WeekOptions,
      dialogTableVisible: false,
      dialogFormVisible: false,
      detailInfo: {
        planName: '',
        paramName: '',
        startTime: '',
        endTime: '',
        checkAll: ['']
      },
      partolParams: [],
      optionlist: [],
      tableData: [],
      pickerOptions2: {
        shortcuts: [{
          text: '最近一周',
          onClick (picker) {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
            picker.$emit('pick', [start, end])
          }
        }, {
          text: '最近一个月',
          onClick (picker) {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
            picker.$emit('pick', [start, end])
          }
        }, {
          text: '最近三个月',
          onClick (picker) {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
            picker.$emit('pick', [start, end])
          }
        }]
      },
      beginOption: {
        start: '00:00',
        step: '00:30',
        end: '24:00'
      },
      endOption: {
        start: '00:00',
        step: '00:30',
        end: '24:00',
        minTime: '',
        maxTime: ''
      },
      group: [],
      selectList: [],
      startTime: '',
      timeTotal: '',
      Hours: '',
      minutes: '',
      RealTimelong: '',
      changeHours: '',
      changeMinutes: '',
      endTime: '',
      startSecond: '',
      checkStart: ''
    }
  },
  watch: {
    show (val) {
      if (val) {
        this.uuid = this.selectMessege ? this.selectMessege : ''
        if (this.uuid) {
          this.queryMessege()
        }
      }
    }
  },
  mounted () {
    this.pointId()
  },
  methods: {
    getValue (value) {
      this.optionValue = value
      this.partolParams.forEach(value => {
        // 获取巡查参数的时间段
        if (this.optionValue === value.uuid) {
          this.timeLong = value.timeLong
          console.log(this.timeLong)
        }
      })
    },
    // 获取添加开始时间和开始时间拼接
    getStartTime (val) {
      this.startSecond = val
      console.log('this.timeLong====', this.timeLong)
      let Temps = val.split(':')
      console.log('temps---', Temps)
      let all = 60 * Number(Temps[0]) + Number(Temps[1]) + this.timeLong + 30
      let min = (all % 60)
      let h = Math.floor(all / 60)
      h = h > 10 ? h.toString() : '0' + h.toString()
      min = min > 10 ? min.toString() : '0' + min.toString()
      this.endOption.maxTime = h + ':' + min
      this.endOption.minTime = val
      console.log('--.maxTime--', this.endOption.maxTime)
    },
    // 获取个人排班信息详情
    queryMessege () {
      personPlan({ id: this.uuid }).then(rs => {
        if (rs.data.code === '0') {
          this.detailInfo = rs.data.data
          this.selectList = rs.data.data.repeat.split(',')
          this.detailInfo.repeat = rs.data.data.repeat.split(',')
        } else {
          this.detailInfo = {}
        }
      }).catch(res => {
      })
    },
    // 添加、修改 保存
    saveEvent () {
      let patrolPlanTimes = this.group
      let repeat = this.selectList.join(',')
      console.log('111', patrolPlanTimes)
      let param = {
        'paramId': this.paramName,
        'patrolPlanTimes': this.group,
        'planName': this.detailInfo.planName,
        'startTime': this.detailInfo.startTime,
        'endTime': this.detailInfo.endTime,
        'repeat': repeat,
        'uuid': this.uuid
      }
      // 修改
      renewPlan(param).then(res => {
        if (res.data.code === '0') {
          this.$message({
            message: '修改成功',
            type: 'success'
          })
        } else {
          this.$message.error('修改失败')
        }
      })
      this.$emit('closePlan')
      this.cleanContent()
    },
    // 取消
    closeEvent () {
      this.$emit('closePlan')
      this.cleanContent()
    },
    // 关闭后清除
    cleanContent () {
      this.group = []
      this.detailInfo.planName = ''
      this.detailInfo.startTime = ''
      this.detailInfo.endTime = ''
      this.detailInfo.checkedWeeks = []
    },
    // 增加时间段
    addRows () {
      this.group.push({ 'startTime': '', 'endTime': '' })
    },
    // 清除
    handleClickDelete () {
      this.group = []
    },
    // 删除行
    deleteRow (index, row) {
      this.group.splice(index, 1)
    },
    // 全选
    handleCheckAllChange (val) {
      if (val) {
        this.selectList = this.Weeks
      }
      this.detailInfo.repeat = val ? WeekOptions : []
      this.isIndeterminate = false
    },
    // 选择
    handleCheckedWeeksChange (value) {
      if (value.length === 0) {
        this.selectList = []
      } else {
        this.selectList = value
      }
      let checkedCount = value.length
      this.checkAll = checkedCount === this.Weeks.length
      this.isIndeterminate = checkedCount > 0 && checkedCount < this.Weeks.length
    },
    // 巡查点参数
    pointId () {
      let params = {
        'paramName': ''
      }
      patrolPiontId(params).then(res => {
        this.partolParams = res.data.data.partolParams
      })
    }
  }
}
</script>
<style scoped land='less'>
.add-one {
  height: 100%;
}
.plan-name {
  width: 35%;
}
.plan-name-one {
  display: inline-block;
  margin-right: 10%;
}
.plan-name-two {
  display: inline-block;
}
.plan-name-three {
  display: inline-block;
  margin-right: 8%;
}
.plan-name-four {
  display: inline-block;
}
.dialog-footer {
  text-align: center;
}
.Period {
  padding-left: 3.5%;
  float: left;
  padding-right: 1.5%;
}
.el-button el-button--primary {
  float: right;
  padding-right: 5%;
}
.secondAdd {
  margin-left: 75%;
}
.checkPeriod {
  max-height: 40%;
}
</style>



<template>
  <div>
    <el-dialog title="" :visible="show" width="50%" @close="closeEvent">
      <el-table ref="checkResultForm" :data="checkResultForm" tooltip-effect="dark" style="width: 100%" @selection-change="handleSelectionChange" :border="true">
        <el-table-column type="selection" width="55">
        </el-table-column>
        <el-table-column type="index" prop="date" label="序号" width="120" align="center">
        </el-table-column>
        <el-table-column prop="resultname" label="名称" show-overflow-tooltip align="center">
        </el-table-column>
        <el-table-column prop="pointtime" label="打点时间" show-overflow-tooltip align="center">
        </el-table-column>
        <el-table-column prop="result" label="结果" show-overflow-tooltip align="center">
        </el-table-column>
        <el-table-column prop="reason" label="原因" show-overflow-tooltip align="center">
        </el-table-column>
      </el-table>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="closeEvent" class="savePlan">保存</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import { Result } from '../../apis/index.js'
export default {
  props: {
    show: {
      type: Boolean,
      required: true,
      default () {
        return false
      },
      dialogtext: {}
    }
  },
  data () {
    return {
      checkResultForm: []
    }
  },
  mounted () {
    this.chenckResult()
  },
  methods: {
    closeEvent () {
      this.$emit('closePlan')
    },
    handleSelectionChange () {
    },
    chenckResult () {
      Result().then((rs) => {
        // console.log('测试')
        if (rs.data.success === 'true') {
          this.data = rs.data.data
        } else {
          this.data = []
        }
      })
    }
  }
}
</script>
<style scoped land='less'>
.dialog-footer {
  text-align: center;
}
</style>


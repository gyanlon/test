<template>
  <div class="paramter-save-dailog">
    <el-dialog :visible="show" @close="closeDialog">
      <el-form :model="patrolParam" :rules="rules" ref="patrolParam" class="demo-ruleForm">
        <el-form-item label="参数名称" :label-width="formLabelWidth" prop="paramName">
          <el-input size="small" v-model="patrolParam.paramName" clearable></el-input>
        </el-form-item>
        <el-form-item label="设备" :label-width="formLabelWidth" prop="deviceId">
          <el-select size="small" v-model="patrolParam.deviceId" placeholder="请选择设备">
            <el-option v-for="item in deviceList" :key="item.deviceID" :label="item.deviceDesc || item.deviceName" :value="item.deviceID"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="时长(分钟)" :label-width="formLabelWidth" prop="timeLong">
          <el-input size="small" v-model.number="patrolParam.timeLong"></el-input>
        </el-form-item>
        <el-form-item label="备注" :label-width="formLabelWidth">
          <el-input type="textarea" v-model="patrolParam.remark" auto-complete="off"></el-input>
        </el-form-item>
      </el-form>

      <el-row :gutter="20" class="row-box">
        <el-col :span="3">
          <span>巡查点：</span>
        </el-col>
        <el-col :span="4">
          <div class="grid-content bg-purple">
            <el-button class="el-button--primary" size="small" type="button" @click="openChoose">选择</el-button>
          </div>
        </el-col>
        <el-col :span="4">
          <div class="grid-content bg-purple">
            <el-button class="el-button--primary" size="small" type="button" @click="delTable">删除</el-button>
          </div>
        </el-col>
      </el-row>

      <!-- table -->
      <el-table class="table-box" :data="list" border ref="multipleTable" @selection-change="handleSelectionChange" tooltip-effect="dark" style="width: 100%" height="300">
        <el-table-column width="80" label="" type="selection" header-align="center"></el-table-column>
        <el-table-column width="100" label="次序" type="index" prop="index" header-align="center"></el-table-column>
        <el-table-column label="名称" prop="pointName" header-align="center"></el-table-column>
        <el-table-column label="间隔时间(min)" prop="interval" header-align="center">
          <template slot-scope="scope">
            <el-input type="text" size="small" v-model="scope.row.interval" placeholder="请输入间隔时间(min)"></el-input>
          </template>
        </el-table-column>
      </el-table>

      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm('patrolParam')">保 存</el-button>
        <el-button @click="closeDialog">取 消</el-button>
      </div>
    </el-dialog>
    <patrol-choose :show="show" :innerDialog="innerDialog" @closeDialog="closeChoose" @patrolChooseSave="patrolChooseSave"></patrol-choose>
  </div>
</template>
<script>

import PatrolChoose from './PatrolChoose.vue'
import { modifyParam, addParam, getInfo } from '../../apis/index'

export default {
  props: {
    refresh: {
      type: Function,
      default: null
    },
    show: {
      required: true,
      type: Boolean,
      default () {
        return false
      }
    },
    infoId: '',
    deviceList: ''
  },
  components: {
    PatrolChoose
  },
  data () {
    return {
      paramData: [],
      dialogTableVisible: false,
      dialogFormVisible: false,
      formLabelWidth: '120px',
      innerDialog: false,
      tableSelection: [],
      value: '',
      // 添加、修改接口参数
      patrolParam: {
        paramId: '',
        paramName: '',
        deviceId: '',
        remark: '',
        timeLong: '',
        courtUuid: ''
      },
      list: [
        {
          uuid: '',
          pointId: '',
          paramId: '',
          interval: '',
          orderNo: '',
          courtUuid: ''
        }
      ],
      rules: {
        paramName: [
          { required: true, message: '请输入参数名称', trigger: 'blur' }
        ],
        deviceId: [
          { required: true, message: '请选择设备', trigger: 'change' }
        ],
        timeLong: [
          { required: true, message: '请填写时长', trigger: 'blur' },
          { type: 'number', message: '时长必须为整数' }
        ]
      },
      paramInfo: {}
    }
  },
  watch: {
    show (val) {
      if (val) {
        if (this.infoId) {
          this.getDetailInfo()
        }
      }
    }
  },
  methods: {
    refreshList () {
      if (this.refresh) {
        this.refresh()
      }
    },
    // 请求详情 & 赋值
    getDetailInfo () {
      getInfo(this.infoId).then(res => {
        if (res.data.code === '0') {
          this.paramInfo = res.data.data.info
          this.patrolParam.paramId = this.paramInfo.uuid
          this.patrolParam.paramName = this.paramInfo.paramName
          this.patrolParam.deviceId = this.paramInfo.deviceId
          this.patrolParam.timeLong = this.paramInfo.timeLong
          this.patrolParam.remark = this.paramInfo.remark
          this.patrolParam.courtUuid = this.paramInfo.courtUuid
          this.patrolParam.remark = this.paramInfo.remark

          let pointInfo = {}
          // 处理巡查点信息
          this.paramInfo.relationExtList.forEach(i => {
            pointInfo.uuid = i.uuid
            pointInfo.pointId = i.pointId
            pointInfo.interval = i.interval
            pointInfo.orderNo = i.orderNo
            pointInfo.paramId = i.paramId
            pointInfo.pointName = i.pointName
            this.list = []
            this.list.push(pointInfo)
          })
        } else {
          this.paramInfo = {}
        }
      }).catch(err => {
        console.log(err)
      })
    },
    // 清空表单和table
    clearData () {
      // this.$refs['patrolParam'].resetFields()
      this.patrolParam.paramId = ''
      this.patrolParam.paramName = ''
      this.patrolParam.deviceId = ''
      this.patrolParam.timeLong = ''
      this.patrolParam.remark = ''
      this.patrolParam.courtUuid = ''
      this.patrolParam.remark = ''
      this.list = []
      this.infoId = ''
      this.paramInfo = {}
    },
    // 提交更改 & 表单验证
    submitForm (patrolParam) {
      this.$refs['patrolParam'].validate((valid) => {
        if (valid) {
          this.ParameterSave()
          this.list = []
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    // 保存添加或更新
    ParameterSave () {
      // 判空提示
      if (this.list.length === 0) {
        this.$message.error('请选择巡查点！')
        return false
      } else {
        this.$emit('closeDialog')
      }

      // 处理list
      let resobj = {}
      let forList = this.list
      forList.forEach((i, index) => {
        resobj.pointId = i.pointId
        resobj.paramId = i.paramId
        resobj.interval = i.interval
        resobj.courtUuid = '000'
        resobj.orderNo = index
        // 更新
        if (this.paramInfo.uuid) {
          resobj.uuid = i.uuid
        }
        this.list = []
        this.list.push(resobj)
      })

      // 处理param
      let param = {}
      param.list = this.list
      param.patrolParam = {
        uuid: this.patrolParam.paramId,
        paramName: this.patrolParam.paramName,
        deviceId: this.patrolParam.deviceId,
        remark: this.patrolParam.remark,
        timeLong: this.patrolParam.timeLong,
        courtUuid: '000'
      }

      if (this.paramInfo.uuid === undefined) {
        // 请求添加接口
        addParam(param).then(res => {
          if (res.data.code === '0') {
            this.$message({
              message: '添加成功',
              type: 'success'
            })
            this.clearData()
          } else {
            this.$message.error('添加失败')
          }
        })
      } else {
        // 请求更新接口
        modifyParam(param).then((rs) => {
          if (rs.data.code === '0') {
            this.$message({
              message: '更新成功',
              type: 'success'
            })
            this.clearData()
          } else {
            this.$message.error('更新失败')
          }
        })
      }
    },
    // 关闭弹窗
    closeDialog () {
      this.$emit('closeDialog')
      this.clearData()
      this.list = []
    },
    sel () {
      self.$emit('change')
    },
    // 打开选择弹窗
    openChoose () {
      this.innerDialog = true
      this.show = true
      this.prevPages = 1
    },
    // 关闭选中弹窗
    closeChoose () {
      this.innerDialog = false
    },
    // 表格选中
    handleSelectionChange (val) {
      this.tableSelection = val
    },
    // 删除表格项目
    delTable () {
      // 从form的list里面截取掉对应位置的项目
      this.tableSelection.forEach(j => {
        let list = this.list
        this.list.forEach((i, index) => {
          if (j.uuid === i.uuid) {
            list.splice(index, 1)
          }
        })
      })
      this.$message({
        message: '删除成功',
        type: 'success'
      })
    },
    // 接收子组件传递的值
    patrolChooseSave (select) {
      this.list = this.list.concat(select)
    }
  }
}
</script>
<style lang="less">
.paramter-save-dailog {
  .el-dialog {
    margin-top: 10vh !important;
  }
}
</style>

<style lang="less" scoped>
.paramter-save-dailog {
  .table-btn {
    margin: 10px 0;
  }
  .el-table {
    text-align: center;
    tbody {
      max-height: 100px;
      overflow-y: auto;
    }
  }
  .el-button {
    margin-left: 20px;
  }
  .el-select {
    width: 100%;
  }
  .el-table-btn {
    width: 80%;
  }
  .patrolPointBtn {
    margin-top: 20px;
  }
  .el-table-up,
  .el-table-down {
    position: absolute;
    width: 10px;
    height: 60px;
    white-space: pre-wrap;
  }
  .el-table-up {
    bottom: 300px;
    right: 20px;
  }
  .el-table-down {
    bottom: 200px;
    right: 20px;
  }
  .row-box {
    margin-bottom: 20px;
  }
}
</style>



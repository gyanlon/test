<template>
  <div class="PlanInfo">
    <div class="PlanInfo-one">
      <el-form label-width="80px " class="form-one">
        <el-form-item label="参数">
          <!-- <el-select v-model="planData.ParamName" placeholder="请选择参数"  @focus="pointId">
            <el-option v-for="item in pointList" :key="item.uuid" :label="item.label" :value="item.uuid">
            </el-option>
          </el-select> -->
          <el-select placeholder="请选择巡查区域" v-model="paramName" @change='getValue'>
            <el-option v-for="item in partolParams" :key="item.uuid" :label="item.paramName" :value="item.uuid" class="item.timeLong"></el-option>
          </el-select>
        </el-form-item>
      </el-form>
    </div>
    <div class="PlanInfo-two">
      <el-form label-width="80px " class="form-four">
        <el-form-item label="从 ">
          <el-date-picker v-model="beginDate" value-format="yyyy-MM-dd" type="date" placeholder="选择日期" :editable="false">
          </el-date-picker>
        </el-form-item>
      </el-form>
      <el-form label-width="80px " class="form-five">
        <el-form-item label="到 ">
          <el-date-picker v-model="endDate" value-format="yyyy-MM-dd" type="date" placeholder="选择日期" :editable="false">
          </el-date-picker>
        </el-form-item>
      </el-form>
      <el-button type="primary" class="button-one" @click="queryList">搜索</el-button>
    </div>
    <div class="PlanInfo-three">
      <el-table ref="multipleTable" :data="data" tooltip-effect="dark" class="table" :border="true" @selection-change="handleSelectionChange">
        <!-- <el-table-column type="selection" width="55">
        </el-table-column> -->
        <el-table-column type="index" prop="date" label="序号" width="120" align="center">
        </el-table-column>
        <el-table-column prop="startTime" label="开始时间" show-overflow-tooltip align="center">
        </el-table-column>
        <el-table-column prop="patrolParam.paramName" label="参数" show-overflow-tooltip align="center">
        </el-table-column>
        <el-table-column prop="deviceName" label="设备" show-overflow-tooltip align="center">
        </el-table-column>
        <el-table-column prop="taskName" label="任务名称" show-overflow-tooltip align="center">
        </el-table-column>
      </el-table>
    </div>
    <div class='pages-crew' v-show="data.length">
      <el-pagination small @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="pageData.pageNo" :page-sizes="[10]" :page-size="pageData.pageSize" layout="total, sizes, prev, pager, next, jumper" :total="pageData.total">
      </el-pagination>
    </div>
  </div>
</template> 
<script>
import { taskPlan, patrolPiontId } from './apis/index'
export default {
  data () {
    return {
      data: [],
      optionValue: '',
      paramName: '',
      pageData: {
        pageSize: 10,
        pageNo: 1,
        total: ''
      },
      planData: [],
      pointList: [],
      partolParams: [],
      paramId: '',
      Id: '',
      userId: '',
      beginDate: '',
      endDate: '',
      deviceName: '',
      pickerOptions1: {
        disabledDate (time) {
          return time.getTime() > Date.now()
        },
        shortcuts: [{
          text: '今天',
          onClick (picker) {
            picker.$emit('pick', new Date())
          }
        }, {
          text: '昨天',
          onClick (picker) {
            const date = new Date()
            date.setTime(date.getTime() - 3600 * 1000 * 24)
            picker.$emit('pick', date)
          }
        }, {
          text: '一周前',
          onClick (picker) {
            const date = new Date()
            date.setTime(date.getTime() - 3600 * 1000 * 24 * 7)
            picker.$emit('pick', date)
          }
        }]
      }
    }
  },
  created () {
  },
  mounted () {
    this.queryList()
    this.pointId()
  },
  methods: {
    getValue (value) {
      this.optionValue = value
      this.partolParams.forEach(value => {
        // 获取巡查参数的时间段
        if (this.optionValue === value.uuid) {
          this.timeLong = value.timeLong
          console.log(this.timeLong)
        }
      })
    },
    queryList () {
      let params = {
        'pageNo': this.pageData.pageNo,
        'pageSize': this.pageData.pageSize,
        'taskStatus': this.taskStatus,
        'planName': '',
        'beginDate': this.beginDate,
        'endDate': this.endDate,
        'paramId': this.paramName,
        'userId': this.userId,
        'startTime': this.startTime,
        'deviceName': this.deviceName
      }
      taskPlan(params).then(rs => {
        if (rs.data.code === '0') {
          console.log(rs.data.code)
          this.data = rs.data.data.rows
          this.pageData.total = rs.data.data.total
        } else {
          this.data = []
        }
      })
    },
    // 巡查点参数
    pointId () {
      let params = {
        'paramName': ''
      }
      patrolPiontId(params).then(res => {
        if (res.data.code === '0') {
          this.partolParams = res.data.data.partolParams
        }
      }).catch(err => {
        console.log(err)
      })
    },
    handleSelectionChange (val) {
      this.multipleSelection = val
    },
    handleSizeChange (val) {
      this.pageData.pageSize = val
      this.queryList()
      this.pointId()
      console.log('测试' + this.data)
    },
    handleCurrentChange (val) {
      this.pageData.pageNo = val
      this.queryList()
      this.pointId()
    },
    showstate (mstate) {
    },
    updated () {
    }
  }
}
</script>
<style>
.PlanInfo {
  margin-left: 50px;
  margin-top: 20px;
  padding-bottom: 30px;
}
.form-one {
  display: inline-block;
  margin-right: 20%;
}
.form-four {
  display: inline-block;
  margin-right: 20%;
}
.form-five {
  display: inline-block;
  margin-right: 20%;
}
.PlanInfo-two {
  border-bottom: 1px solid #aaaaaa;
  padding-bottom: 30px;
}
.PlanInfo-three {
  margin-top: 3%;
}
</style>
<style lang='less'>
@import url("./assets/css/common.less");
</style>
 


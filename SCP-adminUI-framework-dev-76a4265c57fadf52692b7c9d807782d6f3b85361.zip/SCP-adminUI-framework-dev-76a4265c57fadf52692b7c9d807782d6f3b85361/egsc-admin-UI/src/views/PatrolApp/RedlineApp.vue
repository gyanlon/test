<template>
  <div>
    红线彻底
  </div>
</template>
<script>
export default {
  name: 'PatrolPointApp'
}
</script>
<style scoped land='less'>

</style>
<style lang='less'>
@import url("./assets/css/common.less");
</style>

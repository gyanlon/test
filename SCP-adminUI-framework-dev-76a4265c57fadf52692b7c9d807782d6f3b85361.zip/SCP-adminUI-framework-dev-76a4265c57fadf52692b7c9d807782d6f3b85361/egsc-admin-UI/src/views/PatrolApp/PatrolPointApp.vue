<template>
  <div>
    <!-- 功能项 -->
    <el-row :gutter="20">
      <el-col :span="3">
        <el-input v-model="pointName" size="medium" placeholder="请输入pointName"></el-input>
      </el-col>
      <el-col :span="3">
        <el-button type="primary" size="medium" @click="queryList">查 询</el-button>
      </el-col>
      <el-col :span="3">
        <el-button type="primary" size="medium" @click="dialogVisible = true">添 加</el-button>
      </el-col>
      <el-col :span="3">
        <el-button type="primary" size="medium" @click="delData">删 除</el-button>
      </el-col>
    </el-row>
    <!-- 列表项 -->
    <el-table class="table-box" :data="patrolTable" style="width: 90%" @selection-change="handleSelectionChange" border>
      <el-table-column width="180" type="selection" align="center">
      </el-table-column>
      <el-table-column prop="index" type="index" label="序号" width="180" align="center">
      </el-table-column>
      <el-table-column label="名称" width="180" align="center">
        <span slot-scope="scope" @click="amend(scope.$index, scope.row)" type="text" style="color:blue;cursor:pointer">
          {{ scope.row.pointName }}
        </span>
      </el-table-column>
      <el-table-column prop="remark" label="备注" align="center">
      </el-table-column>
      <!-- <el-table-column prop="uuid" label="小区UUID">
      </el-table-column>
      <el-table-column prop="mapId" label="地图ID" width="180">
      </el-table-column> -->
    </el-table>
    <!-- 分页 -->
    <el-pagination class="page-box" @size-change="handleSizeChange" background @current-change="handleCurrentChange" align='center' :current-page="pageData.pageNo" :page-sizes="[10,20,30,40,50]" :page-size="pageData.pageSize" layout="total, sizes, prev, pager, next, jumper" :total="pageData.total"></el-pagination>
    <!-- 弹出框 -->
    <el-dialog :visible.sync="dialogVisible" width="30%" :before-close="handleClose">
      <el-form :model="form">
        <el-form-item label="名称" :label-width="formLabelWidth">
          <el-input v-model="form.name" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="备注" :label-width="formLabelWidth">
          <el-input v-model="form.remark" auto-complete="off"></el-input>
        </el-form-item>
        <!-- <el-form-item label="小区UUID" :label-width="formLabelWidth">
          <el-input v-model="form.uuid" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="地图ID" :label-width="formLabelWidth">
          <el-input v-model="form.mapId" auto-complete="off"></el-input>
        </el-form-item> -->
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="addData">保 存</el-button>
      </span>
    </el-dialog>
    <!-- 点击名称修改 -->
    <el-dialog :visible.sync="dialogAmend">
      <el-form :model="form">
        <el-form-item label="名称" :label-width="formLabelWidth">
          <el-input v-model="chlidName" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="备注" :label-width="formLabelWidth">
          <el-input v-model="chlidMark" auto-complete="off"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogAmend = false">取 消</el-button>
        <el-button type="primary" @click="amend">修 改</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import { getByCriteria, addPatrolPoint, deletePatrolPoint, updatePatrolPoint } from './apis/index'
export default {
  data () {
    return {
      pageData: {
        pageNo: 1,
        pageSize: 10,
        total: 0
      },
      dialogVisible: false,
      dialogTableVisible: false,
      dialogFormVisible: false,
      dialogAmend: false,
      pointer: '',
      form: {
        name: '',
        region: '',
        date1: '',
        date2: '',
        delivery: false,
        type: [],
        resource: '',
        desc: ''
      },
      length: '',
      formLabelWidth: '120px',
      patrolTable: [],
      multipleSelection: [],
      checked: '',
      pointName: '',
      selectList: [],
      chlidName: '',
      chlidMark: ''
    }
  },
  methods: {
    // 小窗确认关闭
    handleClose (done) {
      this.$confirm('确认关闭？')
        .then(_ => {
          done()
        })
        .catch(_ => { })
    },
    // 获取巡查点列表、查询
    queryList () {
      let params = {
        pageNo: this.pageData.pageNo,
        pageSize: this.pageData.pageSize,
        pointName: this.pointName
      }
      getByCriteria(params).then(rs => {
        if (rs.data.code === '0') {
          this.patrolTable = rs.data.data.rows
          this.pageData.total = rs.data.data.total
        }
      })
    },
    // pageSize 改变时会触发Events
    handleSizeChange (val) {
      this.pageData.pageSize = val
      this.queryList()
    },
    // currentPage 改变时会触发Events
    handleCurrentChange (val) {
      this.pageData.pageNo = val
      this.queryList()
    },
    // 点击添加
    addData () {
      if (this.form.name === '') {
        alert('名称不能为空！')
      } else {
        let params = {
          // 请求必须发送的参数courtUuid、mapId
          'courtUuid': 1,
          'mapId': 2,
          'pointName': this.form.name,
          'remark': this.form.remark
        }
        this.patrolTable.push(params)
        this.dialogVisible = false
        this.form.name = ''
        this.form.remark = ''
        this.form.uuid = ''
        this.form.mapId = ''
        addPatrolPoint(params).then(rs => {
          if (rs.status === 200) {
            this.queryList()
          }
        })
      }
    },
    // 当选择项发生变化时触发
    handleSelectionChange (val) {
      this.selectList = []
      let selList = val
      selList.forEach(item => {
        this.selectList.push(item.uuid)
      })
    },
    // 点击删除
    delData () {
      let params = {
        patrolPointId: this.selectList
      }
      deletePatrolPoint(params).then(rs => {
        if (rs.status === 200) {
          this.queryList()
          this.$message({
            message: '删除成功',
            type: 'success'
          })
        }
      })
    },
    // 修改询查点
    amend (index, row) {
      this.dialogAmend = true
      this.pointer = row.pointName
      this.chlidName = row.pointName
      this.chlidMark = row.remark
    },
    promo () {
      console.log(this.pointer)
      console.log(this.chlidName)
      if (this.chlidName === this.pointer || this.chlidName === '') {
        console.log('失败')
        // this.$message({
        //   message: '修改失败',
        //   type: 'success'
        // })
      } else {
        let params = {
          'courtUuid': 1,
          'mapId': 2,
          'pointName': this.form.name,
          'uuid': this.pointName
        }
        updatePatrolPoint(params).then(rs => {
          console.log(rs)
          if (rs.status === 200) {
            this.queryList()
            this.$message({
              message: '修改成功',
              type: 'success'
            })
          }
        })
      }
    }
  },
  init () {
    this.handleSelectionChange()
  },
  mounted () {
    this.queryList()
  }
}
</script>
<style scoped lang='less'>
.table-box {
  margin-top: 20px;
}
.page-box {
  margin: 20px 0;
}
</style>

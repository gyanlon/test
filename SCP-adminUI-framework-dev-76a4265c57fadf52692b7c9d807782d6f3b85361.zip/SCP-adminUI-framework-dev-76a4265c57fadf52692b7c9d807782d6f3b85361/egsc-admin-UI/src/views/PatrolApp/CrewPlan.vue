<template>
  <div class="CrewPlan">
    <div class="CrewPlan-one">
      <el-form label-width="80px " class="form-one">
        <el-form-item label="计划名称" label-width="100px" class="plan-name">
          <el-input v-model="searchName" auto-complete="off"></el-input>
        </el-form-item>
      </el-form>
      <el-button type="primary" class="button-one" @click="addCrewPlan">搜索</el-button>
      <button data-v-654e2d72="" @click="AddPlan" type="button" class="el-button el-button--primary" style="margin:30px">
        <span>添加</span>
      </button>
      <button data-v-654e2d72="" type="button" class="el-button el-button--primary" style="margin-left:100px" @click="removeRows">
        <span>删除</span>
      </button>
    </div>
    <div class="CrewPlan-two">
      <el-table ref="multipleTable" :data="data" tooltip-effect="dark" class="table" :border="true" @selection-change="handleSelectionChange">
        <el-table-column type="selection" width="55">
        </el-table-column>
        <el-table-column type="index" prop="date" label="序号" width="120" align="center">
        </el-table-column>
        <el-table-column prop="planName" label="计划名称" show-overflow-tooltip align="center">
          <template slot-scope="scope">
            <span @click="opendialog(scope.$index,scope.row)" style="color:#409EFF; cursor:pointer">{{scope.row.planName}}</span>
          </template>
        </el-table-column>
        <el-table-column prop="patrolParam.paramName" label="参数" show-overflow-tooltip align="center">
        </el-table-column>
        <el-table-column prop="startTime" label="开始时间" show-overflow-tooltip align="center">
        </el-table-column>
        <el-table-column prop="endTime" label="结束时间" show-overflow-tooltip align="center">
        </el-table-column>
        <el-table-column fixed="right" label="操作" width="100" show-overflow-tooltip align="center">
          <template slot-scope="scope">
            <el-button type="text" @click="opendialog(scope.$index,scope.row)">修改</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class='pages-crew' v-show="data.length">
        <el-pagination small @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="pageData.pageNo" :page-sizes="[10]" :page-size="pageData.pageSize" layout="total, sizes, prev, pager, next, jumper" :total="pageData.total">
        </el-pagination>
      </div>
      <AddPlan :show="showaddDialog" :selectMessege="uuid" :dialogtext="dialogtext" @closePlan='closePlan'></AddPlan>
      <AddPlanRows :show="addRows" :selectMessege="uuid" :dialogtext="dialogtext" @closePlan1='closePlan1'></AddPlanRows>
    </div>
  </div>
</template>

<script>
import { patrol, deletPlan } from './apis/index'
import AddPlan from './components/dialogs/AddPlan'
import AddPlanRows from './components/dialogs/AddPlanRows'
export default {
  name: 'CrewPlan',
  components: { AddPlan, AddPlanRows },
  data () {
    return {
      data: [],
      showaddDialog: false,
      addRows: false,
      pageData: {
        pageSize: 10,
        pageNo: 1,
        total: 0
      },
      dialogtext: {
      },
      searchName: '',
      planIds: [],
      uuid: '',
      multipleSelection: []
    }
  },
  created () {
  },
  mounted () {
    this.addCrewPlan()
  },
  methods: {
    // 页面获取排班信息
    addCrewPlan () {
      console.log(23334)
      let params = { 'pageNo': this.pageData.pageNo, 'pageSize': this.pageData.pageSize, 'planName': this.searchName }
      patrol(params).then(rs => {
        if (rs.data.code === '0') {
          console.log(rs.data.code)
          this.data = rs.data.data.rows
          this.pageData.total = rs.data.data.total
        } else {
          this.data = []
        }
      })
    },
    AddPlan () {
      this.dialogtext = ''
      this.addRows = true
    },
    removeRows () {
      this.planIds = []
      this.multipleSelection.forEach((e) => {
        this.planIds.push(e.uuid)
      })
      deletPlan(this.planIds).then((res) => {
        if (res.data.code === '0') {
          this.$message({
            message: '删除成功',
            type: 'success'
          })
          this.addCrewPlan()
        } else {
          this.$message.error('删除失败')
        }
      }).catch((err) => {
        console.log(err)
      })
    },
    opendialog (index, row) {
      this.uuid = row.uuid
      this.showaddDialog = true
    },
    // 关闭弹窗
    closePlan () {
      this.uuid = ''
      this.showaddDialog = false
    },
    closePlan1 () {
      this.uuid = ''
      this.addRows = false
    },
    handleSelectionChange (val) {
      this.multipleSelection = val
    },
    // closeDialog () {
    //   this.showaddDialog = false
    // },
    handleSizeChange (val) {
      // console.log(`每页 ${val} 条`)
      this.pageData.pageSize = val
      this.addCrewPlan()
      // console.log('测试' + this.pageData.pageSize)
    },
    handleCurrentChange (val) {
      // console.log(`当前页: ${val}`)
      this.pageData.pageNo = val
      this.addCrewPlan()
    },
    showstate (mstate) {
    },
    updated () {
    }
  }
}
</script>

<style scoped land='less'>
.CrewPlan {
  margin-left: 5%;
  margin-top: 20px;
  padding-bottom: 30px;
}
.CrewPlan-two {
  margin-top: 1%;
}
.form-one {
  display: inline-block;
}
.button-one {
  margin-left: 3%;
  margin-right: 35%;
}
.pages-crew {
  text-align: center;
}
</style>
<style lang='less'>
@import url("./assets/css/common.less");
</style>
<template>
  <div>
    <!-- 横线 + 上半 -->
    <div>
      <el-form :inline="true" :model="BoundaryQuery" class="demo-form-inline">
        <!-- 第一行 -->
        <el-row style="margin-top:30px;margin-bottom:20px">
          <!-- 第一列 -->
          <el-col :xs="7" :sm="7" :md="7" :lg="7" :xl="7">
            <el-form-item label="人 员" label-width="70px">
              <el-select placeholder="请选择查找人姓名" v-model="BoundaryQuery.userId" @focus="addGetName">
                <el-option v-for="item in personList" :key="item.uuid" :label="item.name" :value="item.name"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <!-- 第二列 -->
          <el-col :xs="9" :sm="9" :md="9" :lg="9" :xl="9">
            <el-form-item label="任 务" label-width="70px">
              <el-input v-model="BoundaryQuery.taskName" placeholder="请输入任务名"></el-input>
            </el-form-item>
          </el-col>
          <!-- 第三列 -->
          <el-col :xs="3" :sm="3" :md="3" :lg="3" :xl="3">
            <el-form-item>
              <el-button type="primary" @click="addBoundaryAlarmEvent">查 询</el-button>
            </el-form-item>
          </el-col>
        </el-row>
        <!-- 第二行 -->
        <el-row style="margin-top:20px;margin-bottom:20px">
          <!-- 第一列 -->
          <el-col :xs="7" :sm="7" :md="7" :lg="7" :xl="7">
            <el-form-item label="设 备" label-width="70px">
              <el-select placeholder="请选择查找设备" v-model="BoundaryQuery.deviceId" @focus="addTaskName">
                <el-option v-for="item in taskList" :key="item.deviceID" :label="item.deviceName" :value="item.deviceID"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <!-- 第二列 -->
          <el-col :xs="9" :sm="9" :md="9" :lg="9" :xl="9">
            <el-form-item label="时 段" label-width="70px">
              <el-date-picker v-model="BoundaryQuery.beginTime" type="daterange" align="right" unlink-panels range-separator="至" start-placeholder="开始日期" value-format="yyyy-MM-dd" end-placeholder="结束日期" :picker-options="pickerOptions2">
              </el-date-picker>
            </el-form-item>
          </el-col>
          <!-- 第三列 -->
          <el-col :xs="3" :sm="3" :md="3" :lg="3" :xl="3">
            <el-form-item>
              <el-button type="primary" @click="closeQuery">重 置</el-button>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>
    <!-- END -->
    <!-- 表格 -->

    <div>
      <el-table ref="multipleTable" :data="BoundaryData" tooltip-effect="dark" style="width: 100%" @selection-change="handleSelectionChange" border>
        <!-- <el-table-column type="selection" width="80" align="center" header-align="center"></el-table-column> -->
        <el-table-column label="序号" prop="index" type="index" align="center" header-align="center" width="50"></el-table-column>
        <el-table-column label="开始时间" prop="happenTime" align="center" header-align="center"></el-table-column>
        <el-table-column label="人员" prop="userId" align="center" header-align="center"> </el-table-column>
        <el-table-column label="设备" prop="deviceId" align="center" header-align="center"> </el-table-column>
        <el-table-column label="任务" prop="taskName" align="center" header-align="center"></el-table-column>
        <el-table-column label="原因" prop="reason" align="center" show-overflow-tooltip header-align="center"></el-table-column>
        <el-table-column label="预警" align="center" header-align="center" type="text">
          <template slot-scope="scope">
            <span :class="getPoinStatusClass(scope.$index, scope.row)" @click="statusClick(scope.$index, scope.row)">
              {{formatStatus(scope.$index, scope.row)}}
            </span>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页 -->
      <el-pagination @size-change="handleSizeChange" background @current-change="handleCurrentChange" align='center' :current-page="current.pageNo" :page-sizes="[10,20,30,40,50,60]" :page-size="current.pageSize" layout="total, sizes, prev, pager, next, jumper" :total="current.total" style="margin-top:15px"></el-pagination>
      <!-- 分页 END -->
    </div>
    <!-- 弹框 -->
    <describe :visible="showaddDialog" v-on:child="listenToMyBoy" :child-msg="msg" :times='time' :deviceId='deviceId' :person='person' :diffserv='diffserv' :uuidNumber='uuidNumber' @closeDialog="closeDialog"></describe>
    <!-- END 弹框 -->
    <!-- END -->
  </div>
</template>


<script>
import { BoundaryAlarmEvent, getName, taskName } from './apis/index.js'
import describe from './components/dialogs/BoundaryViolationAlarm.vue'

export default {
  components: {
    describe
  },
  data () {
    return {
      pickerOptions2: {
        shortcuts: [{
          text: '最近一周',
          onClick (picker) {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
            picker.$emit('pick', [start, end])
          }
        }, {
          text: '最近一个月',
          onClick (picker) {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
            picker.$emit('pick', [start, end])
          }
        }, {
          text: '最近三个月',
          onClick (picker) {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
            picker.$emit('pick', [start, end])
          }
        }, {
          text: '最近六个月',
          onClick (picker) {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 180)
            picker.$emit('pick', [start, end])
          }
        }, {
          text: '最近一年',
          onClick (picker) {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 365)
            picker.$emit('pick', [start, end])
          }
        }]
      },
      msg: '',
      time: '',
      person: '',
      deviceId: '',
      diffserv: '',
      uuidNumber: '',
      showaddDialog: false,
      personList: [],
      taskList: [],
      BoundaryQuery: {
        taskName: '',
        userId: '',
        beginTime: '',
        endTime: '',
        deviceId: ''
      },
      current: {
        pageNo: 1,
        pageSize: 10,
        total: 0
      },
      multipleSelection: [],
      BoundaryData: [],
      timeoutAlarmEvent: 'boundaryAlermEvent'
    }
  },
  // init () {
  //   this.addBoundaryAlarmEvent()
  // },
  mounted () {
    this.addBoundaryAlarmEvent()
  },
  methods: {
    /*
     * ajax 请求
     */
    addBoundaryAlarmEvent () {
      // console.log(typeof this.BoundaryQuery.beginTime)
      if (this.BoundaryQuery.beginTime != null) {
        for (var i = 0; i < this.BoundaryQuery.beginTime.length; i++) {
          var strBegin = this.BoundaryQuery.beginTime[0]
          var strEnd = this.BoundaryQuery.beginTime[1]
        }
      }
      let params = {
        'pageSize': this.current.pageSize,
        'pageNo': this.current.pageNo,
        'taskName': this.BoundaryQuery.taskName,
        'userId': this.BoundaryQuery.userId,
        'beginDate': strBegin,
        'endDate': strEnd,
        'deviceId': this.BoundaryQuery.deviceId
      }
      BoundaryAlarmEvent(params).then(rs => {
        console.log(rs)
        if (rs.status === 200) {
          this.BoundaryData = rs.data.data.rows
          this.current.total = rs.data.data.total
          console.log(this.current.total)
          console.log('请求成功')
        } else {
          this.data = []
        }
      })
    },
    // 预警项条件内的变色
    getPoinStatusClass (index, row) {
      let status = row.alarmStatus
      if ((status === '3' || status === '4') && (row.reason === null)) {
        return 'clickStyle'
      }
    },
    // 预警点击事件
    statusClick (index, row) {
      let status = row.alarmStatus
      if ((status === '3' || status === '4') && (row.reason === null)) {
        this.showaddDialog = true
        this.msg = row.taskName
        this.time = row.happenTime
        this.person = row.userId
        this.diffserv = this.timeoutAlarmEvent
        this.uuidNumber = row.uuid
        this.deviceId = row.deviceId
        console.log(row.deviceId)
      }
    },
    formatStatus (index, row) {
      let statusText = ['未查巡', '已查巡', '越界未查巡', '越界已查巡', '越界预警中', '越界预警已解除', '', '预警已解除']
      return statusText[parseInt(row.alarmStatus)]
    },
    /*
     * list
     */
    toggleSelection (rows) {
      if (rows) {
        rows.forEach(row => {
          this.$refs.multipleTable.toggleRowSelection(row)
        })
      } else {
        this.$refs.multipleTable.clearSelection()
      }
    },
    /*
     * 分页
     */
    handleSizeChange (val) {
      /*
       *每页显示几条
       */
      console.log(`每页 ${val} 条`)
      this.current.pageSize = val
      this.addBoundaryAlarmEvent()
    },
    /*
     *当前页数
     */
    handleCurrentChange (val) {
      console.log(`当前页: ${val}`)
      this.current.pageNo = val
      this.addBoundaryAlarmEvent()
    },

    handleSelectionChange (val) {
      this.multipleSelection = val
    },

    dialogFormVisible () {
      console.log('点击')
      this.showaddDialog = true
    },
    closeDialog () {
      this.showaddDialog = false
    },
    /*
    *  重置按钮
    */
    closeQuery () {
      this.BoundaryQuery.taskName = ''
      this.BoundaryQuery.userId = ''
      this.BoundaryQuery.beginTime = ''
      this.BoundaryQuery.deviceId = ''
      this.addBoundaryAlarmEvent()
    },
    // 人员姓名下拉框
    addGetName () {
      getName().then(rs => {
        console.log(rs)
        if (rs.data.code === '0') {
          this.personList = rs.data.data
          console.log(this.personList)
          this.current.total = rs.data.data.total
          console.log(this.current.total)
          console.log('请求成功')
        } else {
          this.data = []
        }
      })
    },
    // 设备选择下拉框
    addTaskName () {
      taskName().then(rs => {
        console.log(rs)
        if (rs.data.code === '0') {
          this.taskList = rs.data.data
          console.log(this.taskList)
          console.log('请求成功')
        } else {
          this.data = []
        }
      })
    },
    // 子组件反馈信息
    listenToMyBoy: function (somedata, ros) {
      console.log(somedata)
      console.log(ros)
      for (var i = 0; i < this.current.total; i++) {
        if (this.BoundaryData[i].uuid === ros) {
          this.BoundaryData[i].reason = somedata
          console.log(somedata)
          this.BoundaryData[i].alarmStatus = 7
        }
      }
    }
  }
}
</script>

<style lang="less" scoped>
.clickStyle {
  color: blue;
  cursor: pointer;
}
</style>
import Axios from '@/assets/js/AxiosPlugin'

// 接口地址
// const BASE_PATH = process.env.API_URL
let contextPath = '/scp-broadcastcomponent/broadcast'
/**
 * 获取音频列表数据
 */
export const getAudioList = data => {
  return Axios({
    method: 'get',
    url: contextPath + '/audioClip/getList',
    data
  })
}
/**
 * 添加音频
 * @param {*} data
 */
export const addAudio = data => {
  return Axios({
    method: 'post',
    url: contextPath + '/audioClip/create',
    data
  })
}
/**
 * 删除音频
 * @param {*} data
 */
export const delAudioClip = data => {
  return Axios({
    method: 'post',
    url: contextPath + '/audioClip/del',
    data
  })
}

/**
 * 获取 实时任务 列表数据
 */
export const getRealtimeList = data => {
  return Axios({
    method: 'get',
    url: contextPath + '/realtime/getList',
    data
  })
}
/**
 * 添加实时任务
 * @param {*} data
 */
export const addRealtimeTask = data => {
  return Axios({
    method: 'post',
    url: contextPath + '/task/add',
    data
  })
}
/**
 * 播放 实时任务
 * @param {*} data
 */
export const playRealtimeTask = data => {
  return Axios({
    method: 'post',
    url: contextPath + '/task/play',
    data
  })
}
/**
 * 停止 实时任务
 * @param {*} data
 */
export const pauseRealtimeTask = data => {
  return Axios({
    method: 'post',
    url: contextPath + '/task/pause',
    data
  })
}

/**
 * 删除实时任务
 * @param {*} data
 */
export const delRealtimeTask = data => {
  return Axios({
    method: 'post',
    url: contextPath + '/task/del',
    data
  })
}

/**
 * 获取 定时任务 列表数据
 */
export const getTimingList = data => {
  return Axios({
    method: 'get',
    url: contextPath + '/timing/getList',
    data
  })
}
/**
 * 添加 定时 任务
 * @param {*} data
 */
export const addTimingTask = data => {
  return Axios({
    method: 'post',
    url: contextPath + '/timing/add',
    data
  })
}
/**
 * 添加 定时 任务
 * @param {*} data
 */
export const delTimingTask = data => {
  return Axios({
    method: 'post',
    url: contextPath + '/timing/del',
    data
  })
}
/**
 * 1 排班计划查询页面
 * @param {*} params
 */
export const patrol = (params) => {
  return Axios.get('/scp-patrolapp/scheduleMng/listSchedule', { params: params },
    {
      headers: { 'Content-Type': 'application/json' }
    })
}

/**
 * 2 删除排班计划页面
 * @param {*} params
 */
export const deletPlan = (params) => {
  return Axios.post('/scp-patrolapp/scheduleMng/deleteSchedule', params,
    {
      headers: { 'Content-Type': 'application/json' }
    })
}

/**
 * 3 任务排班页面 历史和信息查询
 * @param {*} params
 */
export const taskPlan = (params) => { return Axios.get('/scp-patrolapp/patrolTaskMng/listScheduleTask', { params: params, headers: { 'Content-Type': 'application/json' } }) }

/**
 * 4 保存排班计划
 * @param {*} params
 */
export const savePlan = (params) => {
  return Axios.post('/scp-patrolapp/scheduleMng/insertSchedule', params,
    {
      headers: { 'Content-Type': 'application/json' }
    })
}

/**
 * 5 安保，保安接口
 * @param {*} params
 */
export const security = (params) => {
  return Axios.get('/scp-patrolapp/patrolTaskMng/listSecurity', { params: params },
    {
      headers: { 'Content-Type': 'application/json' }
    })
}

/**
 * 6 巡更点list参数
 * @param {*} params
 */
export const patrolPiontId = (params) => {
  return Axios.get('/scp-patrolapp/patrolParamMng/queryPatrolParamList', { params: params },
    {
      headers: { 'Content-Type': 'application/json' }
    })
}

/**
 *更新排班计划
 * @param {*} params
 */
export const renewPlan = (params) => {
  return Axios.post('/scp-patrolapp/scheduleMng/updateSchedule', params,
    {
      headers: { 'Content-Type': 'application/json' }
    })
}

/**
 *获取个人排班计划
 * @id {*} id
 */
export const personPlan = (params) => {
  return Axios.get('/scp-patrolapp/scheduleMng/get', { params: params },
    {
      headers: { 'Content-Type': 'application/json' }
    })
}

/**
 * 排班历史查询
 * @param {*} data
 */
export const HistoryTask = data => {
  return Axios({
    method: 'get',
    url: '/PatrolApp/HistoryTask',
    data
  })
}
/**
 * 排班信息查询
 * @param {*} data
 */
export const PlanInfo = data => {
  return Axios({
    method: 'get',
    url: '/PatrolApp/PlanInfo',
    data
  })
}
/**
 * 获取巡查参数配置
 * @param {*}
 */
export const PatrolParamApp = (param) => {
  return Axios.get(`/scp-patrolapp/patrolParamMng/queryPatrolParamList?pageNo=${param.pageNo}&pageSize=${param.pageSize}&deviceId=${param.deviceId}&paramName=${param.paramName}`,
    {
      headers: { 'Content-Type': 'application/json' }
    }
  )
}
/**
 * 根据id获取巡查参数配置详情
 * @id {*}巡查参数配置项id
 */
export const getInfo = id => {
  return Axios.get(`/scp-patrolapp/patrolParamMng/queryPatrolParamById?patrolParamId=${id}`,
    {
      headers: { 'Content-Type': 'application/json' }
    })
}

/**
 * 添加巡查参数配置
 * @param {*}
 */
export const addParam = param => {
  return Axios.post('/scp-patrolapp/patrolParamMng/savePatrolParam', param,
    {
      headers: { 'Content-Type': 'application/json' }
    })
}

/**
 * 更新巡查参数配置
 * @param {*}
 */
export const modifyParam = param => {
  return Axios.post('/scp-patrolapp/patrolParamMng/updatePatrolParam', param,
    {
      headers: { 'Content-Type': 'application/json' }
    })
}

/**
 * 删除巡查参数配置
 * @param {*}
 */
export const DelParam = param => {
  return Axios.post('/scp-patrolapp/patrolParamMng/deletePatrolParam', param,
    {
      headers: { 'Content-Type': 'application/json' }
    })
}

/**
 * 获取设备列表
 * @param {*}
 */
export const getDviceList = param => {
  return Axios.get('/scp-patrolapp/patrolParamMng/getDeviceList', param,
    {
      headers: { 'Content-Type': 'application/json' }
    })
}

/**
 * 获取巡查点列表
 * @param {*} data
 */
export const queryPatrolPointList = param => {
  return Axios.get('/scp-patrolapp/patrolPointManage/queryPatrolPointList', param,
    {
      headers: { 'Content-Type': 'application/json' }
    })
}

/**
 * 巡查点分页
 * @param {*} params
 */
export const getByCriteria = (params) => {
  return Axios.post('/scp-patrolapp/patrolPointManage/getByCriteria', params,
    {
      headers: { 'Content-Type': 'application/json' }
    })
}

/**
 * 巡查点添加
 * @param {*} params
 */
export const addPatrolPoint = (params) => {
  return Axios.post('/scp-patrolapp/patrolPointManage/addPatrolPoint', params,
    {
      headers: { 'Content-Type': 'application/json' }
    })
}

/**
 * 巡查点删除
 * @param {*} params
 */
export const deletePatrolPoint = (params) => {
  return Axios.post('/scp-patrolapp/patrolPointManage/deletePatrolPoint', params,
    {
      headers: { 'Content-Type': 'application/json' }
    })
}

/**
 * 巡查点修改
 * @param {*} params
 */
export const updatePatrolPoint = (params) => {
  return Axios.post('/scp-patrolapp/patrolPointManage/updatePatrolPoint', params,
    {
      headers: { 'Content-Type': 'application/json' }
    })
}

export const Result = data => {
  return Axios({
    method: 'get',
    url: '/PatrolApp/components/dialogs/CheckResult',
    data
  })
}
/**
 * 超时报警
 */
export const TimeoutAlarmEvent = (params) => {
  return Axios.get('/scp-patrolapp/patrolHistoryPoint/list', { params: params },
    {
      headers: { 'Content-Type': 'application/json' }
    })
}
/**
 * 超时报警--查询
 */
export const TimeoutQuery = (params) => {
  return Axios.post('/scp-patrolapp/patrolHistoryPoint/update', params,
    {
      headers: { 'Content-Type': 'application/json' }
    })
}
/**
 *  人员姓名下拉框
 */
export const getName = () => {
  return Axios.get('/scp-patrolapp/patrolTaskMng/listSecurity',
    {
      headers: { 'Content-Type': 'application/json' }
    })
}
/**
 *  设备下拉框
 */
export const taskName = () => {
  return Axios.get('/scp-patrolapp/patrolDevice/listDevice',
    {
      headers: { 'Content-Type': 'application/json' }
    })
}
/**
 *越界报警
 */
export const BoundaryAlarmEvent = (params) => {
  return Axios.get('/scp-patrolapp/patrolAlarm/list', { params: params },
    {
      headers: { 'Content-Type': 'application/json' }
    })
}
/**
 * 越界报警--查询
 */
export const BoundaryQuery = (params) => {
  return Axios.post('/scp-patrolapp/patrolAlarm/update', params,
    {
      headers: { 'Content-Type': 'application/json' }
    })
}
/**
 *应急事件 --列表
 */
export const EmergencyEvent = (params) => {
  return Axios.get('/scp-patrolapp/patrolEmergencyEvent/list', { params: params },
    {
      headers: { 'Content-Type': 'application/json' }
    })
}

<template>
  <div class="person-manager">
    <org-house-tree-view :search="search" :exportHouseNode="exportHouseNode" class="org-view-tree" ref="OrgHouseTreeView"></org-house-tree-view>
    <div class="tree-view-container">
      <div class="operation pb10 clearfix">
        <!-- 操作栏 -->
        <el-col :md="24">
          <el-button type="primary" @click="personEdit">添加</el-button>
          <person-edit ref="personEdit" :search="search" :exportHouseNode="exportHouseNode" :dictItem="dictItem"></person-edit>
          <el-button @click="personUpload">导入</el-button>
          <upload title="人员导入" :search="search" action="/scp-mdmapp/user/uploadUsers" downloadUrl="/scp-mdmapp/templates/personTemplate.xlsx" tips="请选择EXCEL文件！" ref='personUpload' @successUpload="listChange"></upload>
          <el-button @click="download" ref="download">导出</el-button>
          <el-button type="danger" @click="delBatchPerson" class="danger">批量删除</el-button>
        </el-col>
      </div>
      <!-- 查询操作 -->
      <el-form :model="personSearch" ref="personSearch" label-width="70px" class="demo-form-inline" style="min-width:1200px">
        <el-col :md="5" :lg="4">
          <div class="grid-content bg-purple">
            <el-form-item label="姓名" prop="name">
              <el-input v-model="personSearch.name" placeholder="请输入姓名" @change="nameCheck"></el-input>
            </el-form-item>
          </div>
        </el-col>
        <el-col :md="8" :lg="6">
          <el-form-item label="性别">
            <el-select clearable v-model="personSearch.sex" placeholder="请选择性别">
              <el-option v-for="item in dictItem.sexList" :key="item.id" :label="item.itemName" :value="item.itemCode"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :md="8" :lg="6">
          <div class="grid-content bg-purple">
            <el-form-item label="人员类型">
              <el-select clearable v-model="personSearch.userType" placeholder="请选择人员类型">
                <el-option v-for="item in dictItem.userTypeList" :key="item.id" :label="item.itemName" :value="item.itemCode"></el-option>
              </el-select>
            </el-form-item>
          </div>
        </el-col>
        <el-col :md="6" :lg="6">
          <div class="grid-content bg-purple query">
            <el-button class="primary" type="primary" @click="query">查询</el-button>
            <el-button class="primary" type="primary" @click="reset">重置</el-button>
          </div>
        </el-col>
      </el-form>
      <div class="person-list" height="400" style="min-width:1200px">
        <!-- 带分页表格 -->
        <el-table :data="tableData" stripe height="640" @selection-change="handleSelectionChange">
          <el-table-column fixed="left" type="selection" width="55">
          </el-table-column>
          <el-table-column label="姓名" prop="name">
          </el-table-column>
          <el-table-column label="人员类型" prop="userType" :formatter="filtersUserType">
          </el-table-column>
          <el-table-column label="性别" prop="sex" :formatter="filtersSex">
          </el-table-column>
          <el-table-column label="年龄" prop="age">
          </el-table-column>
          <el-table-column label="证件类型" prop="idenType" :formatter="filtersIdenType">
          </el-table-column>
          <el-table-column label="证件号码" prop="idenNum" width="200">
          </el-table-column>
          <el-table-column label="房屋地址" prop="houseName" width="200" :show-overflow-tooltip="true">
          </el-table-column>
          <el-table-column label="电话号码" prop="phone" width="120">
          </el-table-column>
          <el-table-column fixed="right" label="操作" width="150">
            <template slot-scope="scope">
              <el-button @click="personEdit(scope.row)" size="mini">
                编辑</el-button>
              <el-button @click="delPerson(scope.row)" size="mini" type="danger" class="danger">
                删除</el-button>
            </template>
          </el-table-column>
        </el-table>
        <el-pagination class="table-pager" :current-page="currentPage" :page-sizes="[10, 20, 50, 100]" :page-size="pageSize" layout="total, sizes, prev, pager, next, jumper" :total="total" @size-change="sizeChange" @current-change="currentChange">
        </el-pagination>
      </div>
    </div>
  </div>
</template>
<script>
import OrgHouseTreeView from './OrgHouseTreeView'
import PersonEdit from './PersonEdit'
import Upload from '../../components/Upload'
import { getPersonList, deletePerson, batchDeletePerson, getUser, getDictItem } from '../../apis/personManager'
export default {
  data () {
    return {
      exportHouseNode: {
        // rootName: '',                    // 新增人员显示使用
        houseUuid: '',                      // 搜索关键词
        orgUuid: ''                         // 搜索关键词
      },
      dictItem: {
        userTypeList: [],                   // 业主类型
        sexList: [],                        // 性别字典
        idenTypeList: [],                   // 证件类型
        nationList: [],                     // 名族字典
        focusOnPersonnelList: []            // 重点关注字典
      },
      personSearch: {
        name: '',
        userType: '',
        idenType: '',
        sex: '',
        houseUuid: '',
        uuid: '',
        orgUuid: '',
        facePic: ''
      },
      selections: [],
      total: 1,                           // 数据总量
      currentPage: 1,                     // 当前页
      pageSize: 10,                       // 当前页展示数据量
      tableData: [],
      age: 0,
      orgUuid: '',
      loading: false
    }
  },
  components: {
    OrgHouseTreeView,
    Upload,
    PersonEdit
  },
  methods: {
    nameCheck: function () {
      if (this.personSearch.name !== '') {
        if (!/^[\u4e00-\u9fa5A-Za-z0-9·]+$/.test(this.personSearch.name)) {
          this.personSearch.name = ''
          this.$message({
            message: '请输入正确中英文姓名',
            type: 'warning'
          })
        }
      }
    },
    /**
     * @description 点击table组件复选框触发
     * @param Array val 所有选中行数据
     */
    handleSelectionChange: function (val) {
      this.selections = val
    },
    /**
     * @description 分页组件单页总数变化
     * @param Number val 选择的单页总数得值
     */
    sizeChange: function (val) {
      this.pageSize = val
      this.currentPage = 1
      this.search(true)
    },
    /**
     * @description 分页组件当前页变化
     * @param Number val 选择当前页的值
     */
    currentChange: function (val) {
      this.currentPage = val
      this.search(true)
    },
    /**
     * @description 开始人员添加/编辑
     *
     * @param {Object} personInfo @default {} 人员信息
     */
    personEdit: function (personInfo = {}) {
      var Editors = {
        uuid: personInfo.uuid,
        houseUuid: personInfo.houseUuid
      }
      var personInfoTmp
      // 人员编辑
      if (personInfo.uuid) {
        getUser(Editors).then(res => {
          if (res.data.code === '00000') {
            personInfoTmp = res.data.data
            this.$refs['personEdit'].personEdit(personInfoTmp)
          } else {
            this.$message({
              message: res.data.data,
              type: 'warning'
            })
          }
        })
      } else {
        personInfoTmp = Object.assign({}, personInfo)
        this.$refs['personEdit'].personEdit(personInfoTmp)
      }
    },
    /**
     * @description 人员删除
     *
     * @param {Object} personInfo @default {} 人员信息
     */
    delPerson: function (personInfo = {}) {
      this.$confirm('确定要刪除吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
        dangerouslyUseHTMLString: true
      }).then(() => {
        let personInfoobj = { userUuid: personInfo.uuid, houseUuid: personInfo.houseUuid }
        deletePerson(personInfoobj).then(res => {
          if (res.data.code === '00000') {
            this.$message({
              message: res.data.data,
              type: 'success'
            })
          } else {
            this.$message({
              message: res.data.data,
              type: 'warning'
            })
          }
          // 删除成功后重新请求
          this.search(true)
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    // 人员性别过滤
    filtersSex: function (row, column) {
      var fingerFace = row[column.property]
      for (var tmp of this.dictItem.sexList) {
        if (tmp.itemCode === fingerFace) {
          return tmp.itemName
        }
      }
    },
    // 业主类型过滤
    filtersUserType: function (row, column) {
      var fingerFace = row[column.property]
      for (var tmp of this.dictItem.userTypeList) {
        if (tmp.itemCode === fingerFace) {
          return tmp.itemName
        }
      }
    },
    // 证件类型过滤
    filtersIdenType: function (row, column) {
      var fingerFace = row[column.property]
      for (var tmp of this.dictItem.idenTypeList) {
        if (tmp.itemCode === fingerFace) {
          return tmp.itemName
        }
      }
    },
    /**
     * @description 人员批量删除
     *
     * @param {Array} personInfo @default [] 人员信息
     */
    delBatchPerson: function () {
      const personList = [].concat(this.selections)
      let ids = []
      if (personList.length <= 0) {
        this.$message({
          message: '请至少选择一项！',
          type: 'warning'
        })
        return
      }
      for (let i = 0, length = personList.length; i < length; i++) {
        ids.push({ userUuid: personList[i].uuid, houseUuid: personList[i].houseUuid })
      }
      this.$confirm('确定要刪除人员信息吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
        dangerouslyUseHTMLString: true
      }).then(() => {
        batchDeletePerson({ users: ids }).then(res => {
          if (res.data.code === '00000') {
            this.$message({
              message: res.data.data,
              type: 'success'
            })
          } else {
            this.$message({
              message: res.data.data,
              type: 'warning'
            })
          }
          this.search({})
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    // 导入
    personUpload: function (e) {
      this.$refs['personUpload'].openDialog()
    },
    listChange: function () {
      this.search()
    },
    // 查询处理
    query: function () {
      this.search({})
    },
    reset: function () {
      this.personSearch.name = ''
      this.nameCheckResult = 0
      this.personSearch.userType = ''
      this.personSearch.sex = ''
      this.search({})
    },
    search: function (options, isSave) {
      let condition = {}
      this.loading = true
      condition.pageSize = this.pageSize
      condition.currentPage = this.currentPage
      if (options) {
        condition.name = isSave ? '' : this.personSearch.name
        condition.sex = isSave ? '' : this.personSearch.sex
        condition.userType = isSave ? '' : this.personSearch.userType
        condition.orgUuid = this.exportHouseNode.orgUuid
        condition.houseUuid = this.exportHouseNode.houseUuid
      }
      getPersonList(condition)
        .then(res => {
          this.total = res.data.data.totalCount
          var data = res.data.data.result
          for (var tmp in data) {
            data[tmp].age = new Date().getYear() - new Date(data[tmp].birth).getYear() || 0
          }
          this.tableData = data
          this.loading = false
        })
        .catch(err => {
          console.log(err)
          this.loading = false
        })
    },
    // 导出处理
    download: function () {
      // downloadUsers(this.exportHouseNode)
      window.open('/scp-mdmapp/user/downloadUsers?houseUuid=' + this.exportHouseNode.houseUuid + '&orgUuid=' + this.exportHouseNode.orgUuid + '&name=' + this.personSearch.name + '&userType=' + this.personSearch.userType + '&sex=' + this.personSearch.sex)
    }
  },
  mounted: function () {
    getDictItem().then(res => {
      this.dictItem.userTypeList = res.data.data.userType
      this.dictItem.sexList = res.data.data.sex
      this.dictItem.idenTypeList = res.data.data.idenType
      this.dictItem.nationList = res.data.data.nation
      this.dictItem.focusOnPersonnelList = res.data.data.focusOnPersonnel
      console.log(this.dictItem)
    })
    this.search()
  }
}
</script>
<style scoped>
.person-manager {
  width: 100%;
  height: 100%;
  min-width: 1000px;
  min-height: 500px;
}

.person-list {
  flex: 1;
  position: relative;
  margin-top: 10px;
  display: flex;
  flex-flow: column;
}

.tree-view-container {
  height: 100%;
  display: flex;
  flex-flow: column;
  border: 1px solid #dddee1;
  margin-left: 210px;
  padding: 10px;
  box-sizing: border-box;
}

.table-pager {
  padding: 0;
  margin-top: 10px;
  text-align: right;
}
.demo-form-inline {
  padding-top: 15px;
  margin-top: 10px;
  box-sizing: border-box;
  border: 1px solid #cccc;
}
.query {
  margin-left: 30px;
}
.el-table th {
  height: 60px;
}
.primary:focus {
  color: #fff;
  background-color: #409eff;
  border-color: #409eff;
}
.danger:focus {
  color: #fff;
  background-color: #f56c6c;
  border-color: #f56c6c;
}
</style>

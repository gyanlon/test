<template>
  <el-dialog :visible.sync="dialogFormVisible" width="400px" @open="clearValidate">
    <div slot="title">
      <span class="pull-left pl10">{{form.id?'组织编辑':'组织添加'}}</span>
    </div>
    <el-form ref='form' :model="form" label-width="100px" :rules="rules">
      <el-row>
        <el-col :span="20">
          <el-popover v-model="orgPopoverVisible" ref="orgPopover" placement="top-end" width="154" trigger="click">
            <div class="org-select-popover">
              <el-tree :data="orgSelectData" :props="orgSelectProps" :expand-on-click-node="false" @node-click="orgSelectClick"></el-tree>
            </div>
          </el-popover>
          <el-form-item label="上级组织" prop="orgParentName">
            <el-input v-model="form.orgParentName" readonly auto-complete="off" v-popover:orgPopover :disabled="form.orgParentUuid==='0'" :title="form.orgParentName"></el-input>
          </el-form-item>
          <el-form-item label="组织名称" prop="name">
            <el-input v-model.trim="form.name" auto-complete="off" :maxlength="64"></el-input>
          </el-form-item>
          <el-form-item label="内容" prop="memo">
            <el-input resize="none" type="textarea" :rows="4" placeholder="请输入内容" v-model.trim="form.memo" :maxlength="256">
            </el-input>
          </el-form-item>
          <el-form-item label="组织类型" prop="orgType">
            <el-select v-model="form.orgType" no-data-text="请选择" class='selectInput' clearable>
              <el-option v-for="item in orgTypeArr" :key="item.id" :label="item.itemName" :value="item.itemCode"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="开始楼层" prop="startFloor" class='showInput' v-show="form.orgType === '4'">
            <el-input v-model.trim="form.startFloor" auto-complete="off" :maxlength="30"></el-input>
          </el-form-item>
          <el-form-item label="结束楼层" prop="endFloor" class='showInput' v-show="form.orgType === '4'">
            <el-input v-model.trim="form.endFloor" auto-complete="off" :maxlength="30"></el-input>
          </el-form-item>
          <el-form-item label="单元数量" prop="cellNum" class='cellNumInput' v-show="form.orgType === '3'">
            <el-input v-model.trim="form.cellNum" auto-complete="off" :maxlength="30"></el-input>
          </el-form-item>
          <el-form-item label="门类型" prop="doorType" class='doorNumInput' v-show="form.orgType === '6'">
            <el-select v-model="form.doorType" no-data-text="请选择" class='selectInput' clearable>
              <el-option v-for="item in doorTypeArr" :key="item.id" :label="item.itemName" :value="item.itemCode"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="楼层" prop="floorNum" class='floorNumInput' v-show="form.orgType === '5'">
            <el-input v-model.trim="form.floorNum" auto-complete="off" :maxlength="30"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button type="primary" @click="save" :search="search" :disabled="disabledButton">确 定</el-button>
      <el-button @click="cancel">取 消</el-button>
    </div>
  </el-dialog>
</template>
<script>
import { insertOrg, updateOrg, getOrgTree, getOrgAttribute, getOrgType } from '../../apis/orgManager'
export default {
  props: {
    search: {
      type: Function,
      default: function () { }
    },
    exportOrgNode: {
      type: Object
    }
  },
  data () {
    // 组织名称验证
    var orgNameValidate = (rule, value, callback) => {
      if (value.length <= 64) {
        if (!/^[\u4E00-\u9FA5A-Za-z0-9]{1,64}$/.test(value)) {
          callback(new Error('请输入中文、英文或数字组合!'))
        } else {
          callback()
        }
      } else {
        callback(new Error('请输入少于64字节的组织名称!'))
      }
    }
    // 描述内容验证
    var memoValidate = (rule, value, callback) => {
      if (value.length <= 256) {
        if (!/^[\u4E00-\u9FA5A-Za-z0-9_-，。]{0,256}$/.test(value)) {
          callback(new Error('请输入中文、英文或数字!'))
        } else {
          callback()
        }
      } else {
        callback(new Error('描述内容过长，请输入少于256位的内容'))
      }
    }
    // 单元数验证
    var cellNumValidate = (rule, value, callback) => {
      if (value === '' || null) {
        callback()
      } else if (typeof (value) === 'string') {
        if (parseInt(value) < 32767 && parseInt(value) > 0) {
          const isMobile = /^(-|\+)?\d+$/
          if (!isMobile.test(value)) {
            callback(new Error('只允许输入数字且前后不能有空格!'))
          } else {
            callback()
          }
        } else {
          callback(new Error('只允许输入小于32767的正整数'))
        }
      } else {
        callback()
      }
    }
    // 起始楼层验证
    var startFloorValidate = (rule, value, callback) => {
      if (value === '' || null) {
        callback()
      } else if (typeof (value) === 'string') {
        if (parseInt(value) <= 32767 && parseInt(value) > -32768) {
          const isMobile = /^(-|\+)?\d+$/
          if (!isMobile.test(value)) {
            callback(new Error('只允许输入数字且前后不能有空格!'))
          } else {
            callback()
          }
        } else {
          callback(new Error('只允许输入-32768-32767之间的数字!'))
        }
      } else {
        callback()
      }
    }
    // 结束楼层验证
    var endFloorValidate = (rule, value, callback) => {
      if (value === '' || null) {
        callback()
      } else if (typeof (value) === 'string') {
        if (parseInt(value) <= 32767 && parseInt(value) > -32768) {
          const isMobile = /^(-|\+)?\d+$/
          if (!isMobile.test(value)) {
            callback(new Error('只允许输入数字!'))
          } else {
            callback()
          }
        } else {
          callback(new Error('只允许输入-32768-32767之间的数字!'))
        }
      } else {
        callback()
      }
    }
    // 楼层数验证
    var floorNumValidate = (rule, value, callback) => {
      if (value === '' || null) {
        callback()
      } else if (typeof (value) === 'string') {
        if (parseInt(value) <= 32767 && parseInt(value) > -32768) {
          const isMobile = /^(-|\+)?\d+$/
          if (!isMobile.test(value)) {
            callback(new Error('只允许输入数字!'))
          } else {
            callback()
          }
        } else {
          callback(new Error('只允许输入-32768-32767之间的数字!'))
        }
      } else {
        callback()
      }
    }
    // 门类型验证
    var doorTypeValidate = (rule, value, callback) => {
      if (value === '' || null) {
        callback()
      } else if (typeof (value) === 'string') {
        const isMobile = /^[\u4E00-\u9FA5A-Za-z0-9]{0,64}$/
        if (!isMobile.test(value)) {
          callback(new Error('门类型不允许输入特殊字符!'))
        } else {
          callback()
        }
      } else {
        callback()
      }
    }
    return {
      orgPopoverVisible: false,
      orgSelectData: [], // 上级组织选择列表
      orgSelectProps: { // 上级组织树配置属性
        children: 'children',
        label: 'name'
      },
      doorTypeArr: null,
      orgTypeArr: null,
      dialogFormVisible: false, // 显隐dialog
      form: { // 表单信息
        uuid: null,
        name: '', // 名称
        cellNum: '', // 单元数量
        orgType: '', // 组织类型选择
        startFloor: '', // 开始
        endFloor: '', // 结束
        floorNum: '', // 楼层数量
        doorType: '', // 门类型
        orgUuid: null,
        courtUuid: '',
        orgParentName: '',
        memo: ''
      },
      disabledButton: false,
      rules: { // Form表单字段验证规则
        orgType: [ // 组织类型验证规则，必填项
          { required: true, message: '请选择组织类型', trigger: 'blur' }
        ],
        orgParentName: [ // 上级组织名称验证规则，必填项
          { required: true, message: '请选择上级组织', trigger: 'change' }
        ],
        name: [ // 组织名称验证规则，必填项
          { required: true, message: '请输入组织名称', trigger: 'blur' },
          { type: 'string', message: '请输入正确的组织名称', trigger: 'blur' },
          { validator: orgNameValidate, trigger: 'blur' }
        ],
        memo: [ // 描述验证规则，选填项
          { message: '请输入描述内容', trigger: 'blur' },
          { message: '请输入长度在 1 到 256 个字符', trigger: 'blur' },
          { validator: memoValidate, trigger: 'blur' }
        ],
        cellNum: [
          { validator: cellNumValidate, trigger: 'blur' }
        ],
        startFloor: [
          { validator: startFloorValidate, trigger: 'blur' }
        ],
        endFloor: [
          { validator: endFloorValidate, trigger: 'blur' }
        ],
        floorNum: [
          { validator: floorNumValidate, trigger: 'blur' }
        ],
        doorType: [
          { validator: doorTypeValidate, trigger: 'blur' }
        ]
      }
    }
  },
  methods: {
    /**
     * @description 开始组织编辑
     *
     * @param {Object} orgInfo @default {} 组织信息
     */
    orgEdit: function (orgInfo = {}) {
      this.getParentOrgList()
      var self = this
      let editUuid = {}
      editUuid.uuid = orgInfo.uuid
      getOrgAttribute(editUuid).then(res => {
        self.form.cellNum = res.data.data.cellNum || ''
        self.form.doorType = res.data.data.doorType || ''
        self.form.floorNum = res.data.data.floorNum || ''
        self.form.startFloor = res.data.data.startFloor || ''
        self.form.endFloor = res.data.data.endFloor || ''
      })
      this.form.uuid = orgInfo.uuid || null
      this.form.name = orgInfo.name || ''
      this.form.orgParentUuid = orgInfo.orgParentUuid || this.exportOrgNode.uuid || this.exportOrgNode.rootUuid
      this.form.orgParentName = orgInfo.orgParentName || this.exportOrgNode.orgName || '恒大山水城'
      this.form.memo = orgInfo.memo || ''
      this.form.orgType = orgInfo.orgType || ''
      this.dialogFormVisible = true
    },
    /**
     * @description 保存任务信息
     * 确定操作，在添加或者编辑完成时向后台数据库发送请求，完成数据的添加或编辑，返回信息提示，告知用户
     */
    save: function () {
      if (parseInt(this.form.startFloor) > parseInt(this.form.endFloor)) {
        this.$message({
          message: '起始楼层不能大于结束楼层!',
          type: 'warning'
        })
        return
      }
      if (this.form.orgParentUuid === '0') {
        this.$refs['form'].validateField(
          'orgParentName',
          (valid) => {
            if (!valid) {
              this.disabledButton = true
              var func
              func = this.form.uuid ? updateOrg : insertOrg
              func(Object.assign({}, this.form)).then(res => {
                if (res.data.code === '00000') {
                  this.$message({
                    message: res.data.data,
                    type: 'success'
                  })
                  this.$emit('successOrgEdit', true)
                  this.disabledButton = false
                  this.dialogFormVisible = false
                  this.cancel()
                  // this.search({})
                } else {
                  this.$message({
                    message: res.data.data,
                    type: 'warning'
                  })
                  this.disabledButton = false
                  this.dialogFormVisible = true
                  // this.cancel()
                }
              }).catch(err => {
                console.log(err)
              })
            } else {
              this.disabledButton = false
              this.$message({
                message: '内容未填写正确',
                type: 'warning'
              })
              this.dialogFormVisible = true
              return false
            }
          })
      } else {
        this.$refs['form'].validate(
          (valid) => {
            if (valid) {
              this.disabledButton = true
              this.dialogFormVisible = false
              var func
              func = this.form.uuid ? updateOrg : insertOrg
              func(Object.assign({}, this.form)).then(res => {
                if (res.data.code === '00000') {
                  this.$message({
                    message: res.data.data,
                    type: 'success'
                  })
                  this.$emit('successOrgEdit', true)
                  this.disabledButton = false
                  this.dialogFormVisible = false
                  this.cancel()
                  // this.search()
                } else {
                  this.$message({
                    message: res.data.data,
                    type: 'warning'
                  })
                  this.disabledButton = false
                }
              }).catch(err => {
                console.log(err)
              })
            } else {
              this.disabledButton = false
              this.$message({
                message: '内容未填写正确',
                type: 'warning'
              })
              this.dialogFormVisible = true
              return false
            }
          })
      }
    },
    /**
     * @description 关闭任务添加弹出框
     */
    cancel: function () {
      this.dialogFormVisible = false
    },
    /**
     * @description 打开模态框清除表单验证
     * 表单值初始化时会促使表单验证启动，故在模态框打开时清除表单验证
     */
    clearValidate: function () {
      // 需要模态框打开时clearValidate才会生效
      this.$nextTick(() => {
        this.$refs['form'].clearValidate()
      })
      // this.$refs['form'] && this.$refs['form'].clearValidate()
    },
    /**
     * @description 获取组织树信息
     * 添加或编辑时，实时获取最新组织树信息
     */
    getParentOrgList: function () {
      getOrgTree().then(res => {
        this.orgSelectData.splice(0, this.orgSelectData.length)
        this.orgSelectData.push(res.data.data)
        this.form.courtUuid = res.data.data.uuid
      }).catch(err => {
        console.log(err)
      })
    },
    /**
     * @description 点击组织树节点时，获取组织树节点当前的组织名称
     */
    orgSelectClick: function (data, node) {
      this.form.orgParentUuid = data.uuid
      let parentName = ''
      // 组装上级组织名称
      const getName = (node) => {
        parentName = node.data.name + parentName
        this.form.orgParentName = parentName
      }
      getName(node)
      this.form.orgParentUuid = data.uuid
      this.orgPopoverVisible = false
    }
  },
  /**
   * @description vue生命周期开始，就获取组织树信息
   * dom加载完毕，立刻执行此操作
   */
  mounted: function () {
    // this.getParentOrgList()
    getOrgType({ itemType: '6' }).then(res => {
      this.orgTypeArr = res.data.data
    })
    getOrgType({ itemType: '8' }).then(res => {
      this.doorTypeArr = res.data.data
    })
  }
}
</script>
<style lang='less' scoped>
.el-form-item {
  text-align: left;
}
.org-select-popover {
  height: 150px;
  overflow: auto;
}
</style>


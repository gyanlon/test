<template>
  <div class="tree-container">
    <el-input placeholder="按组织名称进行过滤" @keypress.enter.native="filterOrg" prefix-icon="el-icon-search" v-model="searchKey" class="fuzzy-search-tree" :maxlength="30">
    </el-input>
    <el-tree ref="tree" class="fileTree" :data="treeData" node-key="uuid" :default-expanded-keys="defaultExpandKeys" :props="defaultProps" :expand-on-click-node="false" :filter-node-method="filterNode" @node-click="clickNode" :highlight-current="true"></el-tree>
  </div>
</template>
<script>
import { getOrgTree } from '../../apis/orgManager'
export default {
  props: {
    search: {
      type: Function
    },
    exportOrgNode: {}
  },
  watch: {
    searchKey (val) {
      this.$refs.tree.filter(val)
    }
  },
  data () {
    return {
      searchKey: '',
      treeData: [],
      loading: false,
      courtUuid: '',
      defaultProps: {
        children: 'children',
        label: 'name'
      },
      defaultExpandKeys: []
    }
  },
  methods: {
     /**
     * @description 组织树添加，成功返回提示信息
     *
     * @param {condition} orgList @default [] 添加成功后给出相应的用户提示
     */
    addHouse: function () {
      this.$message({
        message: '添加房屋',
        type: 'success'
      })
    },
     /**
     * @description 组织树删除，成功返回提示信息
     *
     * @param {condition} orgList @default [] 删除成功后给出相应的用户提示
     */
    delOrg: function () {
      this.$message({
        message: '删除组织',
        type: 'warning'
      })
    },
    clickNode: function (data, node) {
      this.exportOrgNode.uuid = node.key
      this.exportOrgNode.orgName = node.label
      this.search({ orgUuid: data.uuid })
    },
     /**
     * @description 组织树刷新
     *
     * @param {condition} orgList @default [] 获取组织树
     */
    getArrangerTree: function () {
      this.loading = true
      getOrgTree().then(res => {
        this.exportOrgNode.rootUuid = res.data.data.uuid
        this.treeData.splice(0, this.treeData.length)
        this.defaultExpandKeys.push(res.data.data.uuid)
        this.treeData.push(res.data.data)
        this.loading = false
      }).catch(err => {
        console.log(err)
      })
    },
    filterNode: function (value, data) {
      if (!value) return true
      return data.name.indexOf(value) !== -1
    },
    filterOrg: function () {
      this.$refs.tree.filter(this.searchKey)
    }
  },
  mounted: function () {
    this.getArrangerTree()
    // getOrgTree().then(res => {
    //   this.exportOrgNode.rootUuid = res.data.data.uuid
    // })
  }
}
</script>
<style lang='less' scoped>
.tree-container {
  display: flex;
  flex-flow: column;
  width: 200px;
  float: left;
  height: 100%;
  border: 1px solid #dddee1;
  box-sizing: border-box;
  overflow: auto;
}
.fileTree {
  height: 700px;
}
.el-tree-node>.el-tree-node__children {
  background-color: transparent;
}
.el-tree {
  flex: 1;
  width: 900px;
}
.fuzzy-search-tree {
  margin: 10px;
  width: 178px;
}
</style>



<template>
  <div class="house-manager">
    <org-house-tree-view ref="orgTree" :search="search" class="org-view-tree" :exportOrgNode="exportOrgNode"></org-house-tree-view>
    <div class="tree-view-container">
      <div class="operation pb10 clearfix" style="min-width:1000px">
        <!-- 操作栏 -->
        <el-button type="primary" @click="houseEdit" class="primary">添加</el-button>
        <house-edit :search="search" ref="houseEdit" :exportOrgNode="exportOrgNode" @successHouseEdit="successHouseEdit"></house-edit>
        <el-button @click="houseUpload">导入</el-button>
        <upload title="房屋导入" action="/scp-mdmapp/house/uploadHouses" downloadUrl="/scp-mdmapp/templates/houseTemplate.xlsx" tips="请选择EXCEL文件！" ref='houseUpload' @successUpload="successUpload"></upload>
        <el-button @click="houseDownLoad">导出</el-button>
        <el-button type="danger" @click="delBatchHouse" class="danger">批量删除</el-button>
        <span class="house-num">房屋号：</span>
        <el-input v-model.trim="houseNum" placeholder="请输入房间号" class="house-num-input" :maxlength="30"></el-input>
        <el-button type="primary" @click="lookup" class="lookup-btn, primary">查询</el-button>
        <el-button type="primary" @click="clearup" class="lookup-btn, primary">重置</el-button>
      </div>
      <div class="house-list">
        <!-- 带分页表格 -->
        <div class="house-table">
          <el-table :data="tableData" stripe height="100%" @selection-change="handleSelectionChange">
            <el-table-column fixed="left" type="selection" width="55">
            </el-table-column>
            <el-table-column label="房屋号" prop="houseNum">
            </el-table-column>
            <el-table-column label="房屋名称" prop="houseName" style="min-width:400px">
            </el-table-column>
            <el-table-column label="居住人数" prop="residentNum">
            </el-table-column>
            <el-table-column label="房屋用途" prop="houseUseFor" :formatter="fingerFaceFormat">
            </el-table-column>
            <el-table-column label="面积" prop="buildingArea">
            </el-table-column>
            <el-table-column label="楼层" prop="floor">
            </el-table-column>
            <el-table-column fixed="right" label="操作" width="150">
              <template slot-scope="scope">
                <el-button @click.stop="houseEdit(scope.row)" size="mini">
                  编辑</el-button>
                <el-button @click.stop="delHouse(scope.row)" size="mini" type="danger" class="danger">
                  删除</el-button>
              </template>
            </el-table-column>
          </el-table>
        </div>
        <el-pagination class="table-pager" :current-page="currentPage" :page-sizes="[10, 20, 50, 100]" :page-size="pageSize" layout="total, sizes, prev, pager, next, jumper" :total="total" @size-change="sizeChange" @current-change="currentChange">
        </el-pagination>
      </div>
    </div>
  </div>
</template>
<script>
import OrgHouseTreeView from './OrgHouseTreeView'
import HouseEdit from './HouseEdit'
import Upload from '../../components/Upload'
import { getHouseList, deleteHouse, batchDeleteHouse } from '../../apis/houseManager'
export default {
  data () {
    return {
      exportOrgNode: {
        uuid: '',
        rootUuid: '',
        orgName: ''
      },
      uuid: null,
      orgUuid: null,
      selections: [],
      parentUuid: '',
      total: 1,
      currentPage: 1,
      pageSize: 10,
      tableData: [],
      searchKey: '',
      houseNum: '',
      houseName: '',
      loading: false,
      props: {
        orgSelectClick: {
          type: Function,
          default: function () { }
        }
      }
    }
  },
  components: {
    OrgHouseTreeView,
    HouseEdit,
    Upload
  },
  methods: {
    /**
     * @description 点击table组件复选框触发
     * @param Array val 所有选中行数据
     */
    handleSelectionChange: function (val) {
      this.selections = val
    },
    /**
     * @description 分页组件单页总数变化
     * @param Number val 选择的单页总数得值
     */
    sizeChange: function (val) {
      this.pageSize = val
      this.currentPage = 1
      this.search({ orgUuid: this.exportOrgNode.uuid })
    },
    /**
     * @description 分页组件当前页变化
     * @param Number val 选择当前页的值
     */
    currentChange: function (val) {
      this.currentPage = val
      this.search({ orgUuid: this.exportOrgNode.uuid })
    },
    /**
     * @description 开始房屋添加/编辑
     *
     * @param {Object} houseInfo @default {} 判断房屋用途，选择参数：若为1，则是自住，否则为出租
     */
    fingerFaceFormat: function (row, column) {
      var fingerFace = row[column.property]
      if (fingerFace === '1') {
        return '自住'
      }
      return '出租'
    },
    /**
     * @description 开始房屋添加/编辑
     *
     * @param {Object} houseInfo @default {} 房屋信息，引入子组件houseEdit
     */
    houseEdit: function (houseInfo = {}) {
      const houseInfoTmp = Object.assign({}, houseInfo)
      this.$refs['houseEdit'].houseEdit(houseInfoTmp)
    },
    /**
     * @description 开始房屋添加/编辑
     *
     * @param {Object} houseInfo @default {} 房屋信息成功，立刻刷新房屋列表
     */
    successHouseEdit: function () {
      let condition = {}
      condition.houseNum = this.houseNum || null
      condition.orgUuid = this.exportOrgNode.uuid || this.parentUuid || this.rootUuid
      condition.currentPage = this.currentPage
      condition.pageSize = this.pageSize
      getHouseList(condition)
        .then(res => {
          var self = this
          this.total = res.data.data.totalCount
          self.tableData = res.data.data.result
          self.loading = false
        })
        .catch(err => {
          console.log(err)
          this.loading = false
        })
    },
    /**
     * @description 房屋删除
     *
     * @param {Object} houseInfo @default {} 房屋信息，双层判断，先判断父节点组织Uuid是否为根节点'0',在判断code返回值是否为'00000'，依次返回相应的状态提示信息
     */
    delHouse: function (houseInfo = {}) {
      this.$confirm('您确定要刪除吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
        dangerouslyUseHTMLString: true
      }).then((res) => {
        if (this.parentUuid !== '0') {
          deleteHouse({ uuid: houseInfo.uuid }).then(res => {
            if (res.data.code === '00000') {
              this.$message({
                message: res.data.data,
                type: 'success'
              })
              this.search({ orgUuid: this.exportOrgNode.uuid || this.parentUuid || this.rootUuid })
            } else {
              this.$message({
                message: res.data.data,
                type: 'warning'
              })
            }
          }).catch(err => {
            console.log(err)
          })
        } else {
          this.$message({
            message: res.data.data,
            type: 'warning'
          })
        }
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    /**
     * @description 房屋查询
     *
     * @param {Object} houseInfo @default {} 户主信息;添加一个参数houseNum,按照房屋号重新搜索数据，再次刷新
     */
    lookup: function (options) {
      let condition = {}
      condition.houseNum = this.houseNum
      if (/[^\d]/g.test(this.houseNum)) {
        this.$message({
          message: '只能输入数字!',
          type: 'warning'
        })
        this.houseNum = ''
        return
      }
      condition.orgUuid = this.exportOrgNode.uuid || this.exportOrgNode.rootUuid
      condition.pageSize = this.pageSize
      condition.currentPage = this.currentPage
      getHouseList(condition)
        .then(res => {
          var self = this
          this.total = res.data.data.totalCount
          self.tableData = res.data.data.result
          self.loading = false
        })
        .catch(err => {
          console.log(err)
          this.loading = false
        })
    },
    /**
       * @description 户主查询信息重置
       *
       * @param {Object} houseInfo @default {} 户主重置信息，刷新全部信息
       */
    clearup: function (options) {
      this.houseNum = ''
      let condition = {}
      condition.orgUuid = this.exportOrgNode.uuid || this.exportOrgNode.rootUuid
      condition.pageSize = this.pageSize
      condition.currentPage = this.currentPage
      getHouseList(condition)
        .then(res => {
          var self = this
          this.total = res.data.data.totalCount
          self.tableData = res.data.data.result
          self.loading = false
        })
        .catch(err => {
          console.log(err)
          this.loading = false
        })
    },
    /**
     * @description 房屋批量删除
     *
     * @param {Array} houseInfo @default [] 房屋信息，双层判断，先判断父节点组织Uuid是否为根节点'0',在判断code返回值是否为'00000'，依次返回相应的状态提示信息
     */
    delBatchHouse: function (houseInfo = {}) {
      var parentUuid = this.orgParentUuid
      const houseList = [].concat(this.selections)
      let ids = []
      ids.parentUuid = parentUuid
      if (houseList.length <= 0) {
        this.$message({
          message: '请至少选择一项！',
          type: 'warning'
        })
        return
      }
      for (let i = 0, length = houseList.length; i < length; i++) {
        ids.push(houseList[i].uuid)
      }
      this.$confirm('您确定要刪除组织信息吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
        dangerouslyUseHTMLString: true
      }).then((res) => {
        if (this.parentUuid !== '0') {
          batchDeleteHouse(ids).then(res => {
            if (res.data.code === '00000') {
              this.$message({
                message: res.data.data,
                type: 'success'
              })
              this.search({ orgUuid: this.exportOrgNode.uuid || this.parentUuid || this.exportOrgNode.rootUuid })
            } else {
              this.$message({
                message: res.data.data,
                type: 'warning'
              })
            }
          }).catch(err => {
            console.log(err)
          })
        } else {
          this.$message({
            message: res.data.data,
            type: 'warning'
          })
        }
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '有不可删除选项，已取消删除'
        })
      })
    },
    /**
    * @description 导入模块
    *
    * @param {condition} orgList @default [] elementUI组织树自带函数，详情请查阅elementUI中导入部分
    */
    houseUpload: function () {
      this.$refs['houseUpload'].openDialog()
    },
    /**
     * @description 导入成功
     *
     * @param {condition} orgList @default [] 子组件导入成功后，通知父组件进行相应的操作，这里是触发刷新数据
     */
    successUpload: function () {
      let condition = {}
      condition.orgUuid = this.exportOrgNode.uuid || this.exportOrgNode.rootUuid
      condition.pageSize = this.pageSize
      condition.currentPage = this.currentPage
      getHouseList(condition)
        .then(res => {
          var self = this
          this.total = res.data.data.totalCount
          self.tableData = res.data.data.result
          self.loading = false
        })
        .catch(err => {
          console.log(err)
          this.loading = false
        })
    },
    /**
     * @description 搜索刷新
     *
     * @param {condition} orgList @default [] 具有pagesize与pageNum两个参数，请求所有符合要求的数据，调用接口getHouseList,获取房屋列表
     */
    search: function (options) {
      let condition = {}
      condition.pageSize = this.pageSize
      condition.houseNum = this.houseNum
      condition.currentPage = this.currentPage
      if (options) {
        condition.currentPage = this.currentPage
        this.orgUuid = condition.orgUuid = options.orgUuid || this.orgUuid
      }
      getHouseList(condition)
        .then(res => {
          var self = this
          this.total = res.data.data.totalCount
          self.tableData = res.data.data.result
          self.loading = false
        })
        .catch(err => {
          console.log(err)
          this.loading = false
        })
    },
    /**
     * @description 下载，导出功能
     *
     * @param {condition} orgList @default [] 导入功能，elementUI导出模块自带函数，详情请查阅elementUI导出模块
     */
    houseDownLoad: function () {
      let uuid = this.exportOrgNode.uuid || this.exportOrgNode.rootUuid
      window.open('/scp-mdmapp/house/downloadHouses?orgUuid=' + uuid + '&houseNum=' + this.houseNum)
    }
  },
  /**
    * @description 组织树节点展开选择
    *
    * @param {condition} orgList @default [] elementUI组织树自带函数，详情请查阅elementUI中tree部分
    */
  filterNode: function (value, data) {
    if (!value) return true
    return data.name.indexOf(value) !== -1
  },
  mounted: function () {
    this.search()
  }
}
</script>
<style lang='less' scoped>
.house-manager {
  width: 100%;
  height: 100%;
  min-width: 1000px;
  min-height: 500px;
}
.house-list {
  flex: 1;
  position: relative;
  margin-top: 10px;
  display: flex;
  flex-flow: column;
}
.tree-view-container {
  height: 100%;
  display: flex;
  flex-flow: column;
  border: 1px solid #dddee1;
  margin-left: 210px;
  padding: 10px;
  box-sizing: border-box;
}
.table-pager {
  padding: 0;
  margin-top: 10px;
  text-align: right;
}
.house-table {
  flex: 1;
  position: relative;
}
.house-table .el-table {
  position: absolute;
  width: 100%;
  height: 100%;
}
.house-num {
  width: 10%;
  text-align: center;
  margin-left: 25px;
  padding-top: 10px;
  color: #999999;
  box-sizing: border-box;
}
.house-num-input {
  width: 20%;
  text-align: center;
  padding-top: 5px;
}
.lookup-btn {
  width: 10%;
  margin-left: 5%;
  border-radius: 5px;
}
.primary:focus {
  color: #fff;
  background-color: #409eff;
  border-color: #409eff;
}
.danger:focus {
  color: #fff;
  background-color: #f56c6c;
  border-color: #f56c6c;
}
</style>

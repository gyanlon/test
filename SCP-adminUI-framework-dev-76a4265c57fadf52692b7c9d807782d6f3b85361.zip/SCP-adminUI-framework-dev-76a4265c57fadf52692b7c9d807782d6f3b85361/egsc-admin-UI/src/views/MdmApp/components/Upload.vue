<template>
  <el-dialog :visible.sync="dialogVisible" width="400px" @open="clearFiles">
    <div slot="title">
      <span class="pull-left pl10">{{title}}</span>
    </div>
    <el-upload class="upload-demo" ref="upload" accept="application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" :action="action" :on-change="fileChange" :auto-upload="false" :on-success="successFiles" :on-error="errFiles">
      <el-button slot="trigger" size="small" type="primary">选取文件</el-button>
      <el-button style="margin-left: 10px;" size="small" type="success" @click="submitUpload">上传到服务器</el-button>
      <el-button style="margin-left: 10px;" size="small" type="primary" @click="templateDownload">模版下载</el-button>
      <div slot="tip" class="el-upload__tip">{{tips}}</div>
    </el-upload>
  </el-dialog>
</template>
<script>
export default {
  data () {
    return {
      fileListName: null,
      dialogVisible: false // 显隐dialog
    }
  },
  props: {
    action: {
      type: String,
      required: true
    },
    tips: {
      type: String,
      default: ''
    },
    downloadUrl: {
      type: String,
      required: true
    },
    title: {
      type: String,
      default: '导入'
    }
  },
  methods: {
    openDialog: function () {
      this.dialogVisible = true
    },
    submitUpload: function () {
      if (this.fileListName != null) {
        this.$refs.upload.submit()
        this.fileListName = null
      } else {
        this.$message({
          message: '请选择上传的文件',
          type: 'warning'
        })
      }
    },
    templateDownload: function () {
      window.open(this.downloadUrl)
    },
    handlePreview: function (file) {
    },
    fileExceed: function (files, fileList) {
    },
    successFiles: function (response, file, fileList) {
      if (response.code === '00000') {
        this.$message({
          message: response.data,
          file: response.message,
          type: 'success'
        })
        this.$emit('successUpload', true)
        this.dialogVisible = false
      } else {
        this.$message({
          message: response.data,
          file: response.message,
          type: 'warning'
        })
        this.dialogVisible = true
      }
      this.clearFiles()
    },
    errFiles: function (err, file, fileList) {
      console.log(err.status)
      this.$message({
        message: '网络异常',
        type: 'warning'
      })
    },
    /**
     * @description 上传列表最多只能1个文件
     * 在上传文件时，如果上传列表已经有文件了，则删除此文件
     */
    fileChange: function (files, fileList) {
      var filesName = this.fileListName = files.name.toLowerCase().substring(files.name.lastIndexOf('.') + 1, files.name.length)
      if (files && files.status === 'ready' && fileList.length === 2) {
        fileList.shift()
      }
      if (files && files.status === 'ready' && fileList.length === 1) {
        filesName = files.name.toLowerCase().substring(files.name.lastIndexOf('.') + 1, files.name.length)
        if (filesName === 'xls' || filesName === 'xlsx' || filesName === 'xlsm') {
          if (files.size <= 1024 * 1024) {
            this.$message({
              message: '文件选择成功',
              type: 'success'
            })
          } else {
            this.$message({
              message: '上传文件大小限制1M',
              type: 'warning'
            })
            fileList.shift()
          }
        } else {
          this.$message({
            message: '文件选择失败，请选择Excel表格文件',
            type: 'warning'
          })
        }
      }
    },
    clearFiles: function () {
      this.$nextTick(() => {
        this.$refs.upload.clearFiles()
      })
    }
  }
}
</script>

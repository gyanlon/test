<template>
  <el-dialog :visible.sync="cameraPhotoVisible" width="800px" append-to-body>
    <div slot="title">
      <span>拍照</span>
    </div>
    <div>
    <el-select v-model="value" placeholder="请选择摄像头">
      <el-option v-for="item in usbCameraNameList" :key="item.value" :label="item.label" :value="item.value" @click="GetDeviceList" >
      </el-option>
    </el-select>
    <el-button type="primary" @click="OpenVideo" size="mini" :disabled="openButton">打开摄像头</el-button>
    <el-button type="primary" @click="SnapPicture" size="mini">拍照</el-button>
    </div>
    <object ref="qcapture" CLASSID="CLSID:583A5342-AFE6-4DC7-98B1-F9F5F260ABE0" width="300" height="300" ></object>
    <img :src="this.showImg" alt="" class="showImg" ref="imgShow">
     <div slot="footer" class="dialog-footer">
    <el-button type="primary" @click="saveUpload">确 定</el-button>
    <el-button @click="cancelUpload">取 消</el-button>
  </div>
  </el-dialog>
</template>
 <script>
export default {
  props: {
    uploadImg2: {
      imgName: '',
      imgBase64: ''
    }
  },
  data () {
    return {
      cameraPhotoVisible: false, // 显隐dialog
      appendToBody: true,
      value: '',
      openButton: false,
      usbCameraName: [],
      usbCameraNameList: [],
      showImg: ''
    }
  },
  // mounted: function () {
  //   this.DirectCall('General.Uninit', '{}')
  //   this.DirectCall('General.Init', '{}')
  // },
  methods: {
    CameraPhoto: function () {
      this.cameraPhotoVisible = true
      this.DirectCall('General.Uninit', '{}')
      this.DirectCall('General.Init', '{}')
    },
    // 确认
    saveUpload: function () {
      if (this.showImg !== '') {
        this.uploadImg2.imgBase64 = this.$refs.imgShow.src
        this.$emit('changeImg2', true)
        this.reset()
      } else {
        this.$message({
          message: '请拍照后上传',
          type: 'warning'
        })
      }
    },
    // 取消拍照
    cancelUpload: function () {
      this.reset()
    },
    reset: function (params) {
      this.StopVideo()
      this.DirectCall('General.Uninit', '{}')
      this.showImg = null
      this.openButton = false
      this.cameraPhotoVisible = false
    },
    DirectCall: function (command, param) {
      this.$refs.qcapture.DirectCall(command, param)
    },
    GetDeviceList: function () {
      var command = 'General.GetDeviceList'
      var param = '{"deviceType":"video"}'
      var ret = this.$refs.qcapture.DirectCall(command, param)
      var x = ret.indexOf('[')
      var y = ret.indexOf(']')
      this.usbCameraName = ret.slice(x + 4, y - 2).split(',')
      // for (var tmp of this.usbCameraName) {
      //   var cameraName = {}
      //   cameraName.label = tmp
      //   cameraName.value = tmp
      //   this.usbCameraNameList.push(cameraName)
      // }
      // console.log(this.usbCameraNameList)
    },
    OpenVideo: function () {
      this.GetDeviceList()
      var command = 'Real.OpenVideo'
      var param = '{"videoName":' + this.usbCameraName + ',"videoType":"MJPG","sizeWidth":320,"sizeHeight":240,"frameRate":25}'
      this.$refs.qcapture.DirectCall(command, param)
      this.openButton = true
    },
    SnapPicture: function () {
      var command = 'Record.SnapPicture'
      var param = '{}'
      var ret = this.$refs.qcapture.DirectCall(command, param)
      this.showImg = 'data:image/jpeg;base64,' + ret.slice(17, -20)
    },
    StopVideo: function () {
      var command = 'Real.CloseVideo'
      var param = '{}'
      this.$refs.qcapture.DirectCall(command, param)
    }
  }
}
</script>
<style scoped>
.showImg{
  width:300px;
  height:300px
}
</style scoped>


<template>
  <el-dialog :visible.sync="addPhotoVisible" width="1000px" append-to-body @close='cancelUpload'>
    <div slot="title">
      <span>图片处理</span>
    </div>
    <el-row>
      <el-col :span="14">
        <div class="workArea" ref="workArea" @mousedown="startDrag">
          <div ref="preview" class="preview">
            <img ref="previewImg" class='previewImg' @load="previewImgChanged" :src="previewBase64">
            <div ref="cutPic" class="cutPic"></div>
          </div>
        </div>
      </el-col>
      <el-col :span="10">
        <div class="loadPic">
          <el-button type="primary" @click="uploadPic">浏览...</el-button>
          <input @change="imgInputChanged" ref="imgInput" class="imgInput" type="file" accept="image/jpeg,image/png,image/gif,image/bmp" id='file'>
          <p>请调整图片的大小和位置，选中的部分将作为你的自定照片</p>
          <!-- <el-button type="primary" @click="resizeUp()" size="mini">放大</el-button> -->
          <!-- <el-button type="primary" @click="resizeDown()" size="mini">缩小</el-button> -->
          <el-button type="primary" @click="crop()" size="mini">裁剪</el-button>
          <div class="imgShow">
            <img :src="this.uploadImg.imgBase64" ref="imgShow">
          </div>
        </div>
      </el-col>
    </el-row>
    <div slot="footer" class="dialog-footer">
      <el-button type="primary" @click="saveUpload">确 定</el-button>
      <el-button @click="cancelUpload">取 消</el-button>
    </div>
  </el-dialog>
</template>
<script>
// import imgurl from '@/views/MdmApp/assets/img/pictureError.png'
export default {
  props: {
    faceImg: '',
    uploadImg: {
      imgName: '',
      imgBase64: ''
    }
  },
  data () {
    return {
      addPhotoVisible: false,   // 照片上传显隐dialog
      appendToBody: true,
      previewBase64: '',
      // 鼠标初始位置坐标数值
      mouseStartX: 0,
      mouseStartY: 0,
      // 图片初始化后的尺寸记录
      initSize: {
        width: 0,
        height: 0
      },
      // 图片原始尺寸记录
      originalSize: {
        width: 0,
        height: 0
      },
      // 图片放大缩小的数值
      // resizeValue: 0,
      showSide: '',
      // input选中文件
      fileList: ''
    }
  },
  methods: {
    addPhoto: function () {
      this.addPhotoVisible = true
    },
    // 确认头像上传
    saveUpload: function () {
      if (this.uploadImg.imgBase64 !== '') {
        this.uploadImg.imgName = this.$refs.imgInput.files[0].name
        this.uploadImg.imgBase64 = this.$refs.imgShow.src
        this.addPhotoVisible = false
        this.$emit('changeImg', true)
      } else {
        this.$message({
          message: '请选择或裁剪图片',
          type: 'warning'
        })
      }
    },
    // 取消头像上传
    cancelUpload: function () {
      this.resetPic()
      this.addPhotoVisible = false
    },
    resetPic: function () {
      // 初始化input
      this.$refs.imgInput.type = 'text'
      this.$refs.imgInput.type = 'file'
      this.previewBase64 = ''
      this.uploadImg.imgBase64 = ''
      this.uploadImg.imgName = ''
      // this.resizeValue = 0
    },
    // 触发file类型的input的默认事件
    uploadPic: function () {
      this.previewBase64 = ''
      this.$refs.imgInput.click()
    },
    /**
     * 图片选择元素的值发生变化后，重置图片裁剪区的样式
     * @param {Object} e input数值变化事件
     */
    imgInputChanged: function (event) {
      this.showSide = this.$refs.cutPic.clientWidth
      this.fileList = this.$refs.imgInput.files
      var file = this.fileList[0]
      if (file && this.fileList.length === 1) {
        var fileName = file.name.toLowerCase().substring(file.name.lastIndexOf('.') + 1, file.name.length)
        if (fileName === 'jpg' || fileName === 'jpeg') {
          this.uploadImg.imgName = file.name
          // 判断图片是否大于200K
          if (file.size < 1024 * 200) {
            const self = this
            var reader = new FileReader()
            reader.readAsDataURL(file)
            reader.onload = function () {
              self.previewBase64 = this.result
              self.$refs.previewImg.style.width = 'auto'
              self.$refs.previewImg.style.height = 'auto'
              self.$refs.previewImg.style.top = 'auto'
              self.$refs.previewImg.style.left = 'auto'
            }
          } else {
            this.$message({
              message: '请选择小于200K的图片',
              type: 'warning'
            })
          }
        } else {
          this.$message.error('请选择JPG格式图片上传')
          return false
        }
      }
    },
    /**
     * 图片展示元素数据变动，初始化图片高宽度，位置
     */
    previewImgChanged: function (event) {
      var previewImg = this.$refs.previewImg
      this.showSide = this.$refs.cutPic.clientWidth               //  最小显示宽度或长度 300px
      if (previewImg.offsetWidth >= previewImg.offsetHeight) {
        previewImg.style.top = '100px'
        this.initSize.width = this.showSide * previewImg.offsetWidth / previewImg.offsetHeight
        this.initSize.height = this.showSide
      } else {
        previewImg.style.left = '100px'
        this.initSize.height = this.showSide * previewImg.offsetHeight / previewImg.offsetWidth
        this.initSize.width = this.showSide
      }
      this.originalSize = {
        width: previewImg.offsetWidth,
        height: previewImg.offsetHeight
      }
      previewImg.style.width = this.initSize.width + 'px'
      previewImg.style.height = this.initSize.height + 'px'
    },
    /**
     * 监测鼠标点击，开始拖拽
     * @param {Object} e 鼠标点击事件
     */
    startDrag: function (e) {
      if (this.$refs.previewImg.src) {
        // 记录鼠标初始位置
        this.mouseStartX = e.clientX
        this.mouseStartY = e.clientY
        // 添加鼠标移动以及鼠标点击松开事件监听
        this.$refs.workArea.addEventListener('mousemove', this.dragging, false)
        this.$refs.workArea.addEventListener('mouseup', this.clearDragEvent, false)
      }
    },
    /**
     * 处理拖拽
     * @param {Object} e 鼠标移动事件
     */
    dragging: function (e) {
      var previewImg = this.$refs.previewImg
      // *** 图片不存在 ***
      if (!previewImg.src) return

      // *** 图片存在 ***
      // X轴
      if (previewImg.style.width === '300px') {
        let moveY = previewImg.offsetTop + e.clientY - this.mouseStartY
        if (moveY >= 100) {
          previewImg.style.top = '100px'
          this.mouseStartY = e.clientY
          return
        } else if (moveY <= 400 - previewImg.offsetHeight) {
          moveY = 400 - previewImg.offsetHeight
        }
        previewImg.style.top = moveY + 'px'
        this.mouseStartY = e.clientY
      } else if (previewImg.style.height === '300px') {
        let moveX = previewImg.offsetLeft + e.clientX - this.mouseStartX
        if (moveX >= 100) {
          previewImg.style.left = '100px'
          this.mouseStartX = e.clientX
          return
        } else if (moveX <= 400 - previewImg.offsetWidth) {
          moveX = 400 - previewImg.offsetWidth
        }
        previewImg.style.left = moveX + 'px'
        this.mouseStartX = e.clientX
      // } else {
      //   let moveX = previewImg.offsetLeft + e.clientX - this.mouseStartX
      //   console.log(1, previewImg.offsetLeft, previewImg.offsetWidth, moveX)
      //   if (moveX >= 100) {
      //     previewImg.style.left = '100px'
      //     this.mouseStartX = e.clientX
      //     return
      //   } else if (moveX <= 400 - previewImg.offsetWidth) {
      //     console.log(previewImg.offsetWidth, moveX)
      //     moveX = 400 - previewImg.offsetWidth
      //   }
      //   previewImg.style.left = moveX + 'px'
      //   this.mouseStartX = e.clientX
      //   // Y轴
      //   let moveY = previewImg.offsetTop + e.clientY - this.mouseStartY
      //   if (moveY >= 100) {
      //     previewImg.style.top = '100px'
      //     this.mouseStartY = e.clientY
      //     return
      //   } else if (moveY <= 400 - previewImg.offsetHeight) {
      //     moveY = 400 - previewImg.offsetHeight
      //   }
      //   previewImg.style.top = moveY + 'px'
      //   this.mouseStartY = e.clientY
      // }
      }
    },
    /**
     * 图片放大
     */
    // resizeUp: function () {
    //   if (this.previewBase64 !== '') {
    //     var previewImg = this.$refs.previewImg
    //     console.log(previewImg.style.width.slice(0, -2), previewImg.style.height)
    //     console.log(previewImg.style.width.slice(0, -2) <= 960, previewImg.style.height <= '677px')
    //     if (previewImg.style.width < '960px' && previewImg.style.height < '677px') {
    //       this.resizeValue += 10
    //       this.resize()
    //     } else {
    //       this.$message({
    //         message: '大于弹出框大小了',
    //         type: 'warning'
    //       })
    //     }
    //   } else {
    //     this.$message({
    //       message: '请选择需要裁剪图片',
    //       type: 'warning'
    //     })
    //   }
    // },
    // /**
    //  * 图片缩小
    //  */
    // resizeDown: function () {
    //   if (this.previewBase64 !== '') {
    //     var previewImg = this.$refs.previewImg
    //     if (previewImg.style.width > '300px' && previewImg.style.height > '300px') {
    //       console.log(1111)
    //       this.resizeValue -= 10
    //       this.resize()
    //     //  因IE浏览器style.left = 'auto'||style.left = 'auto'兼容性为题禁用   谷歌、火狐可用
    //     // } else if (previewImg.style.width === '300px' || previewImg.style.height === '300px') {
    //     //   previewImg.style.left = 'auto'
    //     //   previewImg.style.top = 'auto'
    //     //   this.$message({
    //     //     message: '小于裁剪框大小了',
    //     //     type: 'warning'
    //     //   })
    //     } else if (previewImg.style.width === '300px') {
    //       previewImg.style.left = '100px'
    //       previewImg.style.top = 'auto'
    //       this.$message({
    //         message: '小于裁剪框大小了',
    //         type: 'warning'
    //       })
    //     } else if (previewImg.style.height === '300px') {
    //       previewImg.style.left = 'auto'
    //       previewImg.style.top = '100px'
    //       this.$message({
    //         message: '小于裁剪框大小了',
    //         type: 'warning'
    //       })
    //     }
    //   } else {
    //     this.$message({
    //       message: '请选择需要裁剪图片',
    //       type: 'warning'
    //     })
    //   }
    // },
    // /**
    //  * 修改图片比例大小
    //  */
    // resize: function () {
    //   var previewImg = this.$refs.previewImg
    //   var width = (this.resizeValue + 100) / 100 * this.initSize.width + 'px'
    //   var height = (this.resizeValue + 100) / 100 * this.initSize.height + 'px'
    //   console.log(width, height)
    //   if (width >= '300px' && height >= '300px') {
    //     previewImg.style.width = width
    //     previewImg.style.height = height
    //     console.log(previewImg.style.width, previewImg.style.height)
    //   }
    // },
    /**
     * 清除鼠标事件
     */
    clearDragEvent: function () {
      this.$refs.workArea.removeEventListener('mousemove', this.dragging, false)
      this.$refs.workArea.removeEventListener('mouseup', this.clearDragEvent, false)
    },
    crop: function () {
      var previewImg = this.$refs.previewImg
      var imgShow = this.$refs.imgShow
      if (!this.previewBase64) {
        this.$message({
          message: '请选择需要裁剪图片',
          type: 'warning'
        })
        return
      }
      let cropCanvas = document.createElement('canvas')
      let side = (this.showSide / previewImg.offsetWidth) * this.originalSize.width
      cropCanvas.width = side
      cropCanvas.height = side
      let sy = (100 - previewImg.offsetTop) / previewImg.offsetHeight * this.originalSize.height
      let sx = (100 - previewImg.offsetLeft) / previewImg.offsetWidth * this.originalSize.width
      cropCanvas.getContext('2d').drawImage(previewImg, sx, sy, side, side, 0, 0, side, side)
      let _lastImageData = cropCanvas.toDataURL('image/jpeg', 0.7)
      this.uploadImg.imgBase64 = _lastImageData
      imgShow.style.width = this.showSide + 'px'
      imgShow.style.height = this.showSide + 'px'
    }
  }
}
</script>
<style scoped>
/* 图片上传 */
.imgInput {
  display: none;
}
.workArea {
  width: 500px;
  height: 500px;
  border: 3px inset #dcdfe6;
  position: relative;
  overflow: hidden;
}
.preview {
  position: absolute;
  width: 100%;
  height: 100%;
  background: #eeeeee;
  display: flex;
  justify-content: center;
  align-items: center;
  overflow: hidden;
}
.cutPic {
  width: 300px;
  height: 300px;
  border: 100px solid gray;
  opacity: 0.7;
  z-index: 1;
}
.previewImg {
  width: auto;
  height: auto;
  border: none;
  outline: none;
  position: absolute;
}
.imgShow {
  margin: 50px auto;
  width: 300px;
  height: 300px;
  border: 1px solid #010716;
}
.imgShow img {
}
</style scoped>

<template>
  <!--外层容器-->
  <div class="map-config">
    <!--信息区域-->
    <div class="map-content">
      <div class="map-part">
        <el-form ref="form" :model="form" label-width="130px" :rules="rules" class="map-form">
          <!--地图类型模块-->
          <el-form-item label="*地图类型" class="el-chiose-map-style">
            <div class="block">
              <el-select v-model="form.mapType" placeholder="请选择">
                <el-option label="百度地图" value="baidu"></el-option>
              </el-select>
            </div>
          </el-form-item>
          <!--经度模块-->
          <el-form-item label="中心点经度" class="el-center-longitude" prop="mapCenterLongitude">
            <div class="block">
              <el-input v-model="form.mapCenterLongitude" class="center-longitude" ref="input" prop="longitude" :maxlength="10" v-on:blur="blur()"></el-input>
            </div>
          </el-form-item>
          <!--纬度模块-->
          <el-form-item label="中心点纬度" class="el-center-lat" prop="mapCenterLatitude">
            <div class="block">
              <el-input v-model="form.mapCenterLatitude" class="center-lat" ref="input" prop="lat" :maxlength="10" v-on:blur="blur()"></el-input>
            </div>
          </el-form-item>
          <!--滑块-->
          <el-form-item label="*放大等级" class="el-upstep-multiple">
            <div class="block">
              <el-slider v-model="form.mapZLevel" :min="3" :max="18" @change="schange()">
              </el-slider>
            </div>
          </el-form-item>
          <el-form-item label="*是否使用卫星地图" v-model="form.sat">
            <div class="block">
              <el-radio v-model="form.sat" label="1" @change="changeMap()">是</el-radio>
              <el-radio v-model="form.sat" label="0" @change="changeMap()">否</el-radio>
            </div>
          </el-form-item>
        </el-form>
      </div>
      <!-- 图片上传 -->
      <div class="map-part">
        <div class="map-upload">
          <div id="mapDiv" class="upload-content"></div>
        </div>
      </div>
    </div>
    <!--底部-->
    <div class="footer-btn">
      <div class="block">
        <el-button type="primary" plain @click="onSubmit">确定</el-button>
        <el-button type="primary" plain @click="onReset">取消</el-button>
      </div>
    </div>
  </div>
</template>
<script>
import { setMapSetting, getMapSetting } from '@/views/MapApp/apis/index.js'
import hdmap from 'hdmap'
export default {
  data () {
    var mapCenterLongitudeNum = (rule, value, callback) => {
      if (Math.abs(value) > 180) {
        callback(new Error('经度值超出范围-180~180，请重新输入!'))
      } else if (!((/^(-?\d+)(\.\d+)?/).test(value))) {
        this.form.mapCenterLongitude = ''
        callback(new Error('请输入数值!'))
      }
    }
    var mapCenterLatNum = (rule, value, callback) => {
      if (Math.abs(value) > 90) {
        callback(new Error('经度值超出范围-90~90，请重新输入!'))
      } else if (!((/^(-?\d+)(\.\d+)?/).test(value))) {
        this.form.mapCenterLatitude = ''
        callback(new Error('请输入数值!'))
      }
    }
    return {
      dialogTableVisible: false,
      dialogFormVisible: false,
      isSat: 1,
      form: {
        mapType: '',
        mapCenterLatitude: 39.914935,  // 纬度
        mapCenterLongitude: 116.401969, // 经度
        mapZLevel: 8,
        sat: '1'
      },
      data: [],
      rules: {
        mapCenterLatitude: [
          { required: true, message: '请输入纬度值', trigger: 'blur' },
          { min: 2, max: 10, message: '请输入正确的纬度值', trigger: 'blur' },
          { validator: mapCenterLatNum, trigger: 'blur' }
        ],
        mapCenterLongitude: [
          { required: true, message: '请输入经度值', trigger: 'blur' },
          { min: 2, max: 10, message: '请输入正确的经度值', trigger: 'blur' },
          { validator: mapCenterLongitudeNum, trigger: 'blur' }
        ]
      },
      mapObj: {},
      mapObjGPS: {}
    }
  },
  methods: {
    // //返回上一页
    // goBackPage: function () {
    //   location.here = history.go(-1)
    // },
    // 编辑定位信息
    // 经度、纬度字符校验
    blur: function () {
      if ((/^(-?\d+)(\.\d+)?/).test(this.form.mapCenterLongitude)) {
        this.form.mapCenterLongitude = Number(this.form.mapCenterLongitude).toFixed(6)
      }
      if ((/^(-?\d+)(\.\d+)?/).test(this.form.mapCenterLatitude)) {
        this.form.mapCenterLatitude = Number(this.form.mapCenterLatitude).toFixed(6)
      }
      if ((this.form.mapCenterLatitude) && (this.form.mapCenterLongitude)) {
        let tran = this.mapObj.translate_4326_to_3857([Number(this.form.mapCenterLongitude), Number(this.form.mapCenterLatitude)])
        if (this.form.sat === '1') {
          if (hdmap.utils.outOfChina(Number(this.form.mapCenterLongitude), Number(this.form.mapCenterLatitude))) {
            // 中心点设置为北京
            this.mapObjGPS.setCenter(this.mapObj.translate_4326_to_3857([116.46, 39.92]), this.form.mapZLevel)
            // 弹窗提示
            const h = this.$createElement
            this.$message({
              message: h('p', null, [
                h('span', null, ''),
                h('i', { style: 'color: red' }, '坐标不在国内，请重新输入！')
              ])
            })
          } else { this.mapObjGPS.setCenter(tran, this.form.mapZLevel) }
        } else {
          if (hdmap.utils.outOfChina(Number(this.form.mapCenterLongitude), Number(this.form.mapCenterLatitude))) {
            this.mapObj.setCenter(this.mapObj.translate_4326_to_3857([116.46, 39.92]), this.form.mapZLevel)
            const h = this.$createElement
            this.$message({
              message: h('p', null, [
                h('span', null, ''),
                h('i', { style: 'color: red' }, '坐标不在国内，请重新输入！')
              ])
            })
          } else {
            this.mapObj.setCenter(tran, this.form.mapZLevel)
          }
        }
      }
    },
    // 取消按钮，地图信息不变
    onReset: function () {
      getMapSetting().then(res => {
        console.log(res)
        this.form.mapType = res.data.data.mapType
        this.form.mapCenterLatitude = res.data.data.mapCenterLatitude
        this.form.mapCenterLongitude = res.data.data.mapCenterLongitude
        this.form.mapZLevel = parseInt(res.data.data.mapZLevel)
        this.form.sat = res.data.data.sat
      }).catch(err => {
        console.warn(err)
      })
    },
    // 确定按钮，地图信息改变
    onSubmit: function () {
      console.log(this.form)
      setMapSetting(this.form).then(res => {
      }).catch(err => {
        console.warn(err)
      })
    },
    onTest: function () {
      // console.log(this.mapObj._map.getView().getCenter())
      console.log(this.mapObj._map.getView().getZoom())
      // this.form.mapZLevel = 4
    },
    schange: function () {
      if (this.form.sat === '1') {
        this.mapObjGPS._map.getView().setZoom(this.form.mapZLevel)
      } else {
        this.mapObj._map.getView().setZoom(this.form.mapZLevel)
      }
    },
    changeMap: function () {
      if ((/^(-?\d+)(\.\d+)?/).test(this.form.mapCenterLongitude)) {
        this.form.mapCenterLongitude = Number(this.form.mapCenterLongitude).toFixed(6)
      }
      if ((/^(-?\d+)(\.\d+)?/).test(this.form.mapCenterLatitude)) {
        this.form.mapCenterLatitude = Number(this.form.mapCenterLatitude).toFixed(6)
      }
      console.log('before tran' + [this.form.mapCenterLongitude, this.form.mapCenterLatitude])
      let tran = this.mapObj.translate_4326_to_3857([Number(this.form.mapCenterLongitude), Number(this.form.mapCenterLatitude)])
      // tran = this.mapObj.translate_gcj02_to_bd09(tran)
      if (this.form.sat === '1') {
        this.mapObj.getMap().setTarget(null)
        this.mapObjGPS.getMap().setTarget('mapDiv')
        this.mapObjGPS.setCenter(tran, this.form.mapZLevel)
      } else {
        this.mapObjGPS.getMap().setTarget(null)
        this.mapObj.getMap().setTarget('mapDiv')
        this.mapObj.setCenter(tran, this.form.mapZLevel)
      }
    },
    mapInit: function () {
      let that = this
      try {
        // eslint-disable-next-line
        this.mapObj = new hdmap.initMap({
          gisEngine: 'baidu',
          maxZoom: 18,
          minZoom: 3,
          sat: 0,
          center: [this.form.mapCenterLongitude, this.form.mapCenterLatitude],
          popupDom: {
            popup: 'popup',
            popupcloser: 'popup-closer',
            popupcontent: 'popup-content'
          }
        })
        this.mapObj.getMap().getView().on('change:resolution', function (e) {
          var zoom = that.mapObj.getZoom()
          if (Number(zoom).toString().indexOf('.') === -1) {
            // console.log('zoom:' + zoom)
            that.form.mapZLevel = zoom
          }
        })
      } catch (error) {
        console.log(error)
      }
      console.log('mapSatInit end')
      try {
        // eslint-disable-next-line
        this.mapObjGPS = new hdmap.initMap({
          gisEngine: 'baidu',
          maxZoom: 18,
          minZoom: 3,
          sat: 1,
          center: [this.form.mapCenterLongitude, this.form.mapCenterLatitude],
          popupDom: {
            popup: 'popup',
            popupcloser: 'popup-closer',
            popupcontent: 'popup-content'
          }
        })
        this.mapObjGPS.getMap().getView().on('change:resolution', function (e) {
          var zoom = that.mapObjGPS.getZoom()
          if (Number(zoom).toString().indexOf('.') === -1) {
            // console.log('zoom:' + zoom)
            that.form.mapZLevel = zoom
          }
        })
      } catch (error) {
        console.log(error)
      }
      console.log('mapSatInit end')
      this.changeMap()
    },
    initPage: function () {
      getMapSetting().then(res => {
        console.log(res)
        this.form.mapType = res.data.data.mapType
        this.form.mapCenterLatitude = res.data.data.mapCenterLatitude
        this.form.mapCenterLongitude = res.data.data.mapCenterLongitude
        this.form.mapZLevel = parseInt(res.data.data.mapZLevel)
        this.form.sat = res.data.data.sat
      }).catch(err => {
        console.warn(err)
      })
    }
  },
  // 页面加载完成后立即定位当前地点信息
  mounted: function () {
    this.mapInit()
    this.initPage()
    this.mapObj._map.getView().setZoom(4)

    var callback = function (args1, eventType) {
      if (args1.eventType === 'singleclick') {
        // singleclick 触发,args1 为点击的feature对象
        console.log(args1.coordinate)
      } else {
        // singleclick 触发，args1为单机点的位置
      }
    }
    this.mapObj.regEventListener('singleclick', callback)
  }
}
</script>
<style lang="less" scoped>
.map-config {
  box-sizing: border-box;
  position: absolute;
  top: 90px;
  bottom: 20px;
  left: 225px;
  right: 20px;
  display: flex;
  align-content: center;
  flex-direction: column;
  margin-top: 120px;
  .map-content {
    display: flex;
    align-items: center;
    justify-content: space-around;
    .map-form {
      width: 380px;
    }
    .map-upload {
      width: 400px;
      height: 400px;
      border: 10px solid #ccc;
      text-align: center;
      line-height: 300px;
      width: 400px;
      .upload-content {
        width: 100%;
        height: 100%;
      }
    }
  }
}
.return-go-back {
  width: 10px;
  height: 10px;
  border-left: 1px solid #000;
  border-bottom: 1px solid #000;
  transform: rotate(-135deg);
}
.return-go-back:hover {
  transform: rotate(45deg);
}
.el-chiose-map-style,
.el-center-lat,
.el-center-longitude,
.el-upstep-multiple {
  width: 90%;
}
.block {
  width: 200px;
  margin: 0 auto;
}
/* .img-upload {
  width: 400px;
  height: 400px;
  border: 10px solid #ccc;
  text-align: center;
  line-height: 300px;
} */
.img-upload > div {
  width: 100%;
}
.footer-btn {
  margin-top: 100px;
  box-sizing: border-box;
}
.el-button + .el-button {
  margin-left: 50px;
}
</style>

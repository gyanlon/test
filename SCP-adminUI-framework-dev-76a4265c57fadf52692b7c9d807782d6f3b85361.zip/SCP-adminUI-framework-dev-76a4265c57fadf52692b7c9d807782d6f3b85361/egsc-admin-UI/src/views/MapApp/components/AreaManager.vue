
<template>
  <div class="map-app-add">
    <div class="info-item bt">
      <i class="el-icon-back icon-back" @click="closeArea"></i>
      <span class='sp1'>{{ areaSceneInfo.sceneName }}</span>
    </div>
    <div class="location-info">
      <div class="row-flow edit-content">
        <div class="form-area">
          <div class="btns">
            <el-button @click="drawStart">开始绘制</el-button>
            <el-button @click="drawClose">结束绘制</el-button>
          </div>
          <div class="info-item table">
            <table class='table-list' border="0" cellspacing="0">
              <tr v-for="areaItem in areaList" :fit="true" :key="areaItem.id" class="list-item">
                <td class='column-name'> {{areaItem.areaName}}</td>
                <td class='column'>
                  <el-button @click='editArea(areaItem.id,areaItem.areaName,areaItem.areaType)' type="text" class='small'>编辑</el-button>
                </td>
                <td class='column'>
                  <el-button @click='showMap(areaItem,$event)' type="text" class="sh small">显示</el-button>
                </td>
                <td class='column'>
                  <el-button @click='hideMap(areaItem,$event)' type="text" class="sh hide small">隐藏</el-button>
                </td>
                <td class='column'>
                  <el-button @click='delArea(areaItem.id)' type="text" class='delete small'>删除</el-button>
                </td>
              </tr>
            </table>
          </div>
        </div>
        <div class="map-area">
          <div id="mapDiv"></div>
        </div>
      </div>
      <div class="row-flow btn-group">
        <el-button @click="closeArea" class="btn-item">关闭</el-button>
      </div>
    </div>
    <area-edit ref='AreaEdit'></area-edit>
  </div>
</template>

<script>
import {
  getSceneList,
  deleteArea,
  getAreaList,
  getAreaInfo,
  getDictionary
} from '@/views/MapApp/apis/index.js'
// import mapImg from '@/views/MapApp/assets/images/u768.jpg'
import hdmap from 'hdmap'
import AreaEdit from '@/views/MapApp/components/AreaEdit'
import { formatArea } from '@/views/MapApp/assets/js/utils.js'
import { mapOptionFormat, extendObj } from '@/views/MapApp/assets/js/index.js'
// import backIcon from '@/views/MapApp/assets/images/backIcon.png'
// let tempParam = null
export default {
  components: {
    AreaEdit
  },
  props: ['backMessage', 'areaSceneInfo'],
  data () {
    return {
      OrgTree: [],
      // url: backIcon,
      // mapImg: '',
      sceneId: '',
      scene_type: '',
      opions: {},
      isShowPopover: false,
      defaultProps: {
        children: 'children',
        label: 'org_name'
      },
      defaultSceneParam: {
        scene_name: '',
        scene_type: ''
      },
      defaultDeviceParam: {
        scene_name: '',
        org_code: ''
      },
      sceneParam: {
        scene_name: '',
        scene_type: ''
      },
      deviceParam: {
        device_type: '',
        org_code: ''
      },
      sceneList: [],
      // addArea数据
      addAreas: {
        sceneId: '12',
        areaName: '小区东北区',
        areaType: '01',
        linkSceneId: '',
        borderPoints: [],
        childScene: []
      },
      // 点位信息
      borderPoints: [],
      // 点位信息数组
      borderPoint: {
        gpsLongitude: 123.113432,
        gpsLatitude: 45.124322,
        pointX: 100,
        pointY: 200,
        markerType: '1'
      },
      areaList: [],
      mapObj: {},
      addOrEdit: 0,
      option: {
        id: 234,
        name: 'test',
        areaType: '0111',
        visible: true
      }
    }
  },
  methods: {
    dict: function () {
      getDictionary().then((res) => {
        let dictionary = res.data.data
        let sceneTypes = dictionary.dictCodeType.scene_type
        let areaTypes = dictionary.dictCodeType.area_type
        console.log('sceneTypes:' + sceneTypes)
        console.log('areaTypes:' + areaTypes)
      })
    },
    farea: function () {
      console.log(this.areaList)
      console.log('格式化后')
      var alist = formatArea(this.areaList)
      console.log(alist)
    },
    querySceneList: function () {
      getSceneList(this.sceneParam).then(res => {
        this.sceneList = res.data.data
      }).catch(err => {
        console.warn(err)
      })
    },
    queryOrgTree: function () {
      // getOrgTree().then((res) => {
      //   this.OrgTree = res.data
      // })
    },
    handleNodeClick: function (data) {
      this.deviceParam.org_code = data.org_code
      this.isShowPopover = false
    },
    closeArea: function () {
      console.log(this.backMessage)
      // this.mapObj.removeArea({ id: 'ddcebad93c7e4febb2ddbcc419ce72a9' })
      this.$parent.status = '0'
    },
    addArea: function () {
      this.drawStart()
      this.$refs['AreaEdit'].areSceneId = this.sceneId
      this.$refs['AreaEdit'].areSceneType = this.sceneType
      console.log('addArear')
    },
    editArea: function (aid, aname, atype) {
      /* var feat = this.mapObj.showDrawShape(this.option)
      console.log(feat.getGeometry().getCoordinates())
      let that = this
      this.option.borderPoints = feat.getGeometry().getCoordinates()
      that.mapObj.editDrawShape(that.option) */
      // console.log(aid, aname, atype)
      switch (this.areaSceneInfo.sceneType) {
        // 小区全图
        case 1: this.$refs['AreaEdit'].currentAreaType = 1
          break
        // 停车场主图
        case 4: this.$refs['AreaEdit'].currentAreaType = 3
          break
        // 小区区域图
        default: this.$refs['AreaEdit'].currentAreaType = 2
          break
      }
      var data = { areaId: aid }
      var _this = this
      getAreaInfo(data).then(res => {
        var re = res.data.data
        console.log(re)
        _this.$refs['AreaEdit'].addoptions.areaName = re.areaName
        _this.$refs['AreaEdit'].addoptions.areaType = re.areaType
        _this.$refs['AreaEdit'].addoptions.areaId = re.id
        _this.$refs['AreaEdit'].addoptions.linkSceneId = re.linkSceneId
        _this.$refs['AreaEdit'].addoptions.childScene = []
        _this.$refs['AreaEdit'].addoptions.sceneId = re.sceneId
        _this.$refs['AreaEdit'].dialogFormVisible = true
        _this.$refs['AreaEdit'].isLoading = false
        _this.$refs['AreaEdit'].curLinkedScene = re.linkSceneId
        _this.$refs['AreaEdit'].curParentArea = re.id
        _this.$refs['AreaEdit'].initParamEdit()
        _this.addOrEdit = 1
      }).catch(err => {
        console.warn(err)
      })
      // this.$refs['AreaEdit'].areSceneId = aid
      /* this.$refs['AreaEdit'].getdetail(aid)
      this.$refs['AreaEdit'].dialogFormVisible = true
      this.addOrEdit = 1 */
    },
    delArea: function (aid) {
      var obj = { areaIds: [] }
      obj.areaIds.push(aid)
      var _this = this
      this.$confirm('确定要刪除该区域吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
        dangerouslyUseHTMLString: true
      }).then(() => {
        deleteArea(obj).then(res => {
          var data = { sceneId: this.areaSceneInfo.id }
          if (res.status === 200) {
            getAreaList(data).then(res => {
              console.log(res)
              var alist = formatArea(res.data.data)
              _this.areaList = alist
              _this.dialogFormVisible = false
              this.$message({
                message: '数据删除成功',
                type: 'success'
              })
              _this.mapObj.removeArea({ id: aid })
              _this.mapObj.closePopup()
            })
          }
        }).catch(err => {
          console.warn(err)
        })
      })
    },
    showMap: function (areaItem, $event) {
      var aid = areaItem.id
      var data = { 'areaId': aid }
      getAreaInfo(data).then(res => {
        var aitem = res.data.data
        var arr = []
        arr.push(aitem)
        var newarr = formatArea(arr)
        // debugger
        newarr[0].visible = true
        console.log(newarr[0])
        var styleObj = { 'fillColor': 'rgba(100,149,237,0.2)', 'strokeColor': '#1E90FF', 'strokeWidth': '2' }
        this.mapObj.addArea(newarr[0], styleObj)
        console.log(newarr[0])
        let centerPoint = hdmap.utils.getAreaCenter(newarr[0].borderPoints[0])
        console.log(centerPoint)
        this.mapObj.setCenter(centerPoint)
        this.mapObj.popupDefault(centerPoint, aitem.areaName)
      }).catch(err => {
        console.warn(err)
      })
      // $event.currentTarget.style.color = 'orange'
    },
    hideMap: function (areaItem, $event) {
      var aid = areaItem.id
      this.mapObj.removeArea({ id: aid })
      this.mapObj.closePopup()
    },
    drawStart: function () {
      this.borderPoint = {}
      this.borderPoints = []
      this.mapObj.openDrawShapeTool('Polygon', function (e) {
        console.log('begin draw')
        console.log(e)
      })
      // this.mapObj.closeDrawShapeTool()
    },
    drawClose () {
      switch (this.areaSceneInfo.sceneType) {
        // 小区全图
        case 1: this.$refs['AreaEdit'].currentAreaType = 1
          break
        // 停车场主图
        case 4: this.$refs['AreaEdit'].currentAreaType = 3
          break
        // 小区区域图
        default: this.$refs['AreaEdit'].currentAreaType = 2
          break
      }
      this.mapObj.closeDrawShapeTool()
      var feat = this.mapObj.showDrawShape(this.option)
      if (!feat) {
        console.warn('draw a polygon frist')
        return
      }
      console.log(feat)
      this.points = feat.getGeometry().getCoordinates() // 获取点位
      console.log('点位：')
      console.log(this.points[0])
      this.$refs['AreaEdit'].points = this.points
      console.log(this.points[0].length)
      if (this.points[0].length === 0) {
        this.$message({
          message: '请先在地图上绘制区域！',
          type: 'warning'
        })
        return
      }
      for (var i = 0; i < this.points[0].length; i++) {
        // 坐标转换
        this.borderPoint.pointX = this.points[0][i][0]
        this.borderPoint.pointY = this.points[0][i][1]
        console.log('this.borderPoint')
        console.log(this.borderPoint)
        let GPSInfo = [0, 0]
        try {
          this.GPSInfo = this.mapObj.transBitmapToWGS(this.points[0][i])
        } catch (e) {
          this.GPSInfo = [0, 0]
          console.warn(e)
        }
        console.log(GPSInfo)
        this.borderPoints.push({
          gpsLongitude: GPSInfo[0],
          gpsLatitude: GPSInfo[1],
          pointX: this.borderPoint.pointX,
          pointY: this.borderPoint.pointY,
          markerType: '1'
        })
        console.log(this.borderPoints)
      }

      console.log('borderPoints:')
      console.log(this.borderPoints)
      this.mapObj.removeArea(this.option)
      this.addOrEdit = 0
      // console.log(this.areaSceneInfo.id)
      // this.addArea.borderPoints = this.borderPoints
      this.$refs['AreaEdit'].addoptions.borderPoints = this.borderPoints
      this.$refs['AreaEdit'].areSceneId = this.sceneId
      this.$refs['AreaEdit'].addoptions.sceneId = this.areaSceneInfo.id
      this.$refs['AreaEdit'].addoptions.areaName = ''
      this.$refs['AreaEdit'].addoptions.areaType = ''
      this.$refs['AreaEdit'].addoptions.linkSceneId = ''
      this.$refs['AreaEdit'].addoptions.childScene = []
      this.$refs['AreaEdit'].dialogFormVisible = true
      this.$refs['AreaEdit'].isRcShow = true
      this.$refs['AreaEdit'].stype = ''
      this.$refs['AreaEdit'].isLoading = false
      this.$refs['AreaEdit'].curLinkedScene = ''
      this.$refs['AreaEdit'].curParentArea = ''
      this.$refs['AreaEdit'].initParamEdit()
      // console.log('此时的添加参数:')
      // console.log(this.$refs['AreaEdit'].addoptions)
      // let that = this
      // this.option.borderPoints = feat.getGeometry().getCoordinates()
      // setTimeout(function () {
      //   that.mapObj.editDrawShape(that.option)
      // }, 3000)
    },
    mapInit: function () {
      //     this.mapImg = this.areaSceneInfo.url
      var _this = this
      let formatedOption = mapOptionFormat(this.areaSceneInfo)
      let mapOption = extendObj(formatedOption, {
        gisEngine: 'bitmap',
        sizeW: 1920,
        sizeH: 1080,
        domId: 'mapDiv',
        mapUrl: _this.areaSceneInfo.url,
        maxZoom: 10,
        minZoom: 3,
        center: [0, 0],
        popupDom: {
          popup: 'popup',
          popupcloser: 'popup-closer',
          popupcontent: 'popup-content'
        }
      })
      try {
        // eslint-disable-next-line
        this.mapObj = new hdmap.initMap(mapOption)
        this.mapObj.regEventListener('singleclick', function (args) {
          if (args.feature) {
            console.log(args.feature)
            _this.mapObj.popupDefault(args.coordinate, args.feature.areaName)
          }
        })
      } catch (error) {
        console.log(error)
      }
      getAreaList({ sceneId: this.areaSceneInfo.id }).then(res => {
        console.log('getAreaList')
        console.log(res.data.data)
        let alist = formatArea(res.data.data)
        this.areaList = alist
        console.log(this.areaList)
        this.mapObj.addAreas(this.areaList)
      }).catch(err => {
        console.warn(err)
      })
    }
  },
  mounted: function () {
    var _this = this
    _this.mapInit()
    // this.backIcon = this.url
    console.log(this.areaSceneInfo)
    this.$refs['AreaEdit'].addoptions.sceneId = this.areaSceneInfo.id
    //  <relate-scene-dialog ref="RelateSceneDialog" :currentAreaType="currentAreaType" :selectSceneId="selectedSceneId"></relate-scene-dialog>
    // <relate-child-dialog ref="RelateChildDialog" :currentAreaType="currentAreaType" :parentAreaId="parentAreaId"></relate-child-dialog>
  },
  created: function () {
    // 调用getAreaList, "sceneId": "00102201","areaType": "03"
    /* getAreaList().then(res => {
      this.areaList = res.data
    }) */
  }
}
</script>
<style lang="less" scoped>
// 唯一样式或公用样式
/*MapApp.less公共样式start*/
@origin: 10px;
/* div {
  box-sizing: border-box;
} */
.pull-left {
  float: left;
}
.pull-right {
  float: right;
}
.row-flow {
  width: 100%;
}
.clearfix {
  clear: both;
}
.common-input {
  width: @origin*28;
}
.map-app {
  box-sizing: border-box;
  position: absolute;
  top: 90px;
  bottom: 20px;
  left: 225px;
  right: 20px;
}
.filter-tree{
  overflow-x: hidden;
  overflow-y: scroll;
  max-height: 300px
}
/*MapApp.less公共样式end*/

.map-app-add {
  margin: 0 auto;
  padding-top: 50px;
  padding-bottom: 40px;
  .info-item.bt {
    position: relative;
    top: -30px;
  }
  .info-item.table {
    max-height: 500px;
    overflow: auto;
    margin-top: 20px;
    .list-item:nth-child(odd) {
      background: #f0f0f0;
    }
    .list-item {
      height: 40px;
    }
  }
}
.column {
  min-width: 30px;
  background: none;
  cursor: default;
  i {
    font-style: normal;
  }
  .sh {
    margin-left: 7px;
    display: inline-block;
  }
  .hide {
    padding-right: 10px;
  }
}
.column-name {
  width: 50px;
  text-indent: 5px;
}
td:first-child {
  min-width: 145px;
}
.btn-group {
  .btn-item {
    float: right;
    margin: 0 20px 0 0;
  }
}

.location-info {
  .edit-content {
    display: flex;
    .form-area {
      padding-top: 20px;
      height: 100%;
      flex: 0 0 320px;
      overflow: auto;
      order: -1;
      .info-item {
        line-height: 30px;
        margin-bottom: 22px;
        font-size: 14px;
        color: #606266;
      }
    }
    .map-area {
      flex: 1;
      box-sizing: border-box;
      padding: 20px;
      height: 600px;
      #mapDiv {
        width: 100%;
        height: 100%;
        //  background: #66e;
      }
    }
  }
}

.bt {
  .icon-back {
    display: inline-block;
    vertical-align: middle;
    font-size: 30px;
    margin-right: 15px;
  }
  .sp1 {
    display: inline-block;
    vertical-align: middle;
    margin-right: 10px;
    font-size: 18px;
  }
}
.delete {
  color: #ff0000;
}
</style>

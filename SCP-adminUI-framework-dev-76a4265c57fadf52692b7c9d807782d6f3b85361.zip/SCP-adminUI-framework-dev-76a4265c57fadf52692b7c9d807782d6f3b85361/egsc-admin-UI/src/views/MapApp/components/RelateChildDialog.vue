<template>
  <el-dialog title="关联子集场景" :visible.sync="dialogVisible" width="536px">
    <div class="center">
      <div class="demo-input-suffix">
        <span class="wz">场景名称&nbsp;&nbsp;</span>
        <div class="input">
          <el-input>
            <el-button slot="append" icon="el-icon-search" @click.native="search()"></el-button>
          </el-input>
        </div>
        <!--<el-button type="primary" @click.native="search()">搜索</el-button>-->
      </div>
      <div class="tags">
        <el-checkbox-group v-model="checkList">
          <el-checkbox v-for="item in optionDatas" :key="item.id" :label="item.id">{{ item.sceneName }}</el-checkbox>
        </el-checkbox-group>
      </div>
    </div>
    <span slot="footer" class="dialog-footer">
      <el-button @click="Sure" type="primary">确 定</el-button>
      <el-button type="default" @click="Close">取 消</el-button>
    </span>
  </el-dialog>
</template>
<script>
import { getSceneList } from '@/views/MapApp/apis/index.js'
export default {
  data () {
    return {
      dialogVisible: false,
      value: '',
      input: '',
      checkList: [],
      optionDatas: [],
      SceneName: '',
      restaurants: [],
      checkListNames: [],
      SceneTypes: [],
      stype: '',
      defaultScenetype: '',
      curParentArea: '',
      defaultCheckList: []
    }
  },
  /* watch: {
  }, */
  mounted () {
  },
  methods: {
    initParamsDialog: function (currentAreaType, curParentArea) {
      this.curParentArea = curParentArea
      switch (currentAreaType) {
        // 小区分区区域
        case 1: this.defaultSceneType = 2
          break
        // 楼栋
        case 2: this.defaultSceneType = 3
          break
        // 车场分区区域
        default: this.defaultSceneType = 5
          break
      }
    },
    search: function () {
      let data = {}
      data.sceneType = this.defaultSceneType
      data.sceneName = this.value
      this.checkList = []
      getSceneList(data).then(res => {
        if (res.data.code === '00000') {
          let sceneList = res.data.data
          let sceneLength = sceneList.length
          let curParentArea = this.curParentArea
          for (let i = 0; i < sceneLength; i++) {
            if (!!curParentArea && !!sceneList[i].parentArea && (curParentArea === sceneList[i].parentArea)) {
              this.checkList.push(sceneList[i].id)
            }
            /* if (!!curParentArea && !!sceneList[i].parentArea && (curParentArea === sceneList[i].parentArea)) {
              this.checkList.push(sceneList[i].id)
              sceneList[i].checked = true
            } else {
              sceneList[i].checked = false
            } */
          }
          this.optionDatas = sceneList
          this.defaultCheckList = Object.assign([], this.checkList)
        }
      }).catch(err => {
        console.warn(err)
      })
    },
    Close: function () {
      this.dialogVisible = false
      this.checkList = Object.assign([], this.defaultCheckList)
    },
    Open: function () {
      this.dialogVisible = true
    },
    Sure: function () {
      if (this.checkList.length === 0) {
        var str = '请输入完整信息'
        this.$confirm(str, '错误', {
          confirmButtonText: '确定',
          type: 'error',
          dangerouslyUseHTMLString: true
        })
      } else {
        this.dialogVisible = false
        this.$parent.addoptions.childScene = this.checkList
      }
    }
  }
}
</script>
<style lang="less" scoped>
.el-dialog {
  min-width: 536px !important;
}
.center {
  .tags {
    height: 150px;
    margin: 20px auto 0 auto;
    overflow-y: scroll;
  }
  width: 95%;
  min-height: 40px;
  margin: 0 auto;
  background: none;
  .demo-input-suffix {
    min-height: 40px;
    width: 100%;
    margin-top: 10px;
    .wz {
      display: block;
      width: auto;
      height: 40px;
      line-height: 40px;
      float: left;
      margin-right: 5px;
    }
    .input {
      width: auto;
      float: left;
    }
  }
  .el-checkbox-group {
    .el-checkbox {
      display: block;
      width: 100%;
      margin-left: 0;
      margin-top: 10px;
    }
  }
}
</style>

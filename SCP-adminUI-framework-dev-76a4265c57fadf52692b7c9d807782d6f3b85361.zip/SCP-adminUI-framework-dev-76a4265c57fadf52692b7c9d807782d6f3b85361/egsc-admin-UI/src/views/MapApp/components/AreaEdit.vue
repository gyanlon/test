<template>
  <div>
    <el-dialog title="区域信息" :visible.sync="dialogFormVisible" width="536px" height="440px">
      <el-form>
        <el-form-item label="*区域名称" label-width="80px" class="common-input">
          <el-input placeholder="请输入区域名称" v-model='addoptions.areaName'></el-input>
        </el-form-item>
        <el-form-item label="*区域类型" class='formItem'>
          <el-select v-model="currentAreaType" class='small-input' disabled="">
            <el-option :label="item.itemName" :value="item.itemCode" v-for="item in selectList" :key="item.itemCode">{{item.itemName}}</el-option>
          </el-select>
        </el-form-item>
        <el-form-item v-if='isShow' label="关联场景" class="common-input">
        </el-form-item>
        <el-form-item class="common-input">
          <el-button @click='RcShow' type='primary' plain v-show="currentAreaType === 2">关联子场景</el-button>
          <el-button @click='RsShow' type='primary' plain v-show="currentAreaType !== 2">关联场景</el-button>
        </el-form-item>
        <div class="btn-group">
          <el-button type='success' plain @click='save' :disabled="isLoading">保存</el-button>
          <el-button type='info' plain @click='reset'>取消</el-button>
        </div>
      </el-form>
    </el-dialog>
    <relate-scene-dialog ref="RelateSceneDialog"></relate-scene-dialog>
    <relate-child-dialog ref="RelateChildDialog"></relate-child-dialog>
  </div>
</template>
<script>
import {
  addArea,
  updateArea,
  getAreaInfo,
  getAreaList,
  getDictionary
} from '@/views/MapApp/apis/index.js'
import RelateSceneDialog from './RelateSceneDialog' // 关联场景的弹窗
import RelateChildDialog from './RelateChildDialog' // 关联子场景的弹窗
// import { formatArea } from '@/views/MapApp/assets/js/utils.js'
export default {
  components: {
    RelateSceneDialog,
    RelateChildDialog
  },
  data () {
    return {
      isLoading: false,
      selectList: [],
      currentAreaType: '',
      curLinkedScene: '',
      curParentArea: '',
      dialogVisible: false,
      dialogFormVisible: false,
      isShow: false,
      sceneType: '',
      areSceneId: '',
      points: [],
      areaInfo: {},
      addoptions: {
        sceneId: '',
        areaName: '',
        areaType: '',
        linkSceneId: '',
        borderPoints: [
          {
            gpsLongitude: 0.0,
            gpsLatitude: 0.0,
            pointX: 100,
            pointY: 200,
            markerType: 1
          }, // 区域边界点位列表
          {
            gpsLongitude: 0.0,
            gpsLatitude: 0.0,
            pointX: 100,
            pointY: 200,
            markerType: 1
          }
        ],
        childScene: []
      },
      modifyoptions: {}
    }
  },
  methods: {
    RsShow: function () {
      this.$refs['RelateSceneDialog'].Open()
      this.$refs['RelateSceneDialog'].search()
    },
    RcShow: function () {
      this.$refs['RelateChildDialog'].Open()
      this.$refs['RelateChildDialog'].search()
    },
    reset: function () {
      this.sceneType = ''
      this.dialogFormVisible = false
      // alert('hohohoho')
    },
    save: function () {
      this.addoptions.areaType = this.currentAreaType
      console.log('调用addArea接口')
      if (this.currentAreaType === 2) {
        if (this.addoptions.childScene.length > 0) {
          this.addoptions.childScene = this.$refs['RelateChildDialog'].checkList
          this.addoptions.linkSceneId = ''
        } else {
          this.$message({
            message: '楼栋区域必须关联子场景',
            type: 'warning'
          })
          return false
        }
      } else {
        this.addoptions.linkSceneId = this.$refs['RelateSceneDialog'].selecedSceneId
        this.addoptions.childScene = []
      }
      if (this.$parent.addOrEdit === 0) {
        // 调用接口 add
        // var _this = this
        var adds = this.addoptions
        delete adds['id']
        // console.log(this.addoptions)
        this.isLoading = true
        addArea(adds).then(res => {
          // console.log(res.data)
          if (res.data.code === '00000') {
            // 调用getAreaList "sceneId": "00102201", "areaType": "03"
            var data = { sceneId: this.addoptions.sceneId }
            console.log(this.addoptions)
            var _this = this
            getAreaList(data).then(rees => {
              // this.areaList = res.data
              // console.log(res.data.data)
              _this.$parent.areaList = rees.data.data
              _this.dialogFormVisible = false
              this.$message({
                message: '恭喜你，数据添加成功',
                type: 'success'
              })
            }).catch(err => {
              console.warn(err)
            })
          }
        }).catch(err => {
          this.isLoading = false
          console.log(this.isLoading)
          console.warn(err)
          this.$message({
            message: '数据添加失败'
          })
        })
        // console.log(this.addoptions)
      } else {
        // console.log(this.addoptions)
        // 调用接口 update
        updateArea(this.addoptions).then(res => {
          // console.log(res)
          if (res.status === 200) {
            var data = { sceneId: this.addoptions.sceneId }
            // console.log(data)
            var _this = this
            getAreaList(data).then(rees => {
              // this.areaList = res.data
              // console.log(res.data.data)
              _this.$parent.areaList = rees.data.data
              _this.dialogFormVisible = false
              _this.isLoading = true
              this.$message({
                message: '恭喜你，数据修改成功',
                type: 'success'
              })
            })
          }
        }).catch(err => {
          console.log(this.isLoading)
          console.warn(err)
          this.$message({
            message: '数据修改失败'
          })
        })
      }
    },
    getdetail: function (aid) {
      var data = { id: aid }
      getAreaInfo(data).then(res => {
        console.log(res)
      }).catch(err => {
        console.warn(err)
      })
      // alert(aid)
    },
    initParamEdit: function () {
      let currentAreaType = this.currentAreaType
      let curParentArea = this.curParentArea
      let curLinkedScene = this.curLinkedScene
      this.$refs['RelateSceneDialog'].initParamsDialog(currentAreaType, curLinkedScene)
      this.$refs['RelateChildDialog'].initParamsDialog(currentAreaType, curParentArea)
    }
  },
  mounted: function () {
    console.log(this)
    getDictionary().then((res) => {
      let dictionary = res.data.data
      let areaTypes = dictionary.dictCodeType.areaType
      // console.log(areaTypes)
      var len = areaTypes.length
      for (var i = 0; i < len; i++) {
        areaTypes[i].itemCode = parseInt(areaTypes[i].itemCode)
      }
      this.selectList = areaTypes
    }).catch(err => {
      console.warn(err)
    })
  }
}
</script>

<style lang="less" scoped>
/*MapApp.less公共样式start*/
@origin: 10px;
/* div {
  box-sizing: border-box;
} */
.pull-left {
  float: left;
}
.pull-right {
  float: right;
}
.row-flow {
  width: 100%;
}
.clearfix {
  clear: both;
}
.common-input {
  width: @origin*28;
}
.map-app {
  box-sizing: border-box;
  position: absolute;
  top: 90px;
  bottom: 20px;
  left: 225px;
  right: 20px;
}
.filter-tree {
  overflow-x: hidden;
  overflow-y: scroll;
  max-height: 300px;
}
/*MapApp.less公共样式end*/

.el-dialog {
  min-width: 536px !important;
}
.btn-group {
  margin-left: 60%;
  bottom: 10px;
  line-height: 30px;
  padding: 0 24px 0 0;
  width: 50%;
}
.small-input {
  width: 200px;
}
.formItem {
  margin-left: 8px;
}
.btn-groups {
  .pull-right;
  .btn {
    margin-left: @origin*1.2;
    margin-bottom: 5px;
    .pull-left;
  }
}
</style>

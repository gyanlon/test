<template>
  <el-dialog title="关联场景" :visible.sync="dialogVisible" width="536px">
    <div class="center">
      <div class="demo-input-suffix">
        <span class="wz">场景名称&nbsp;&nbsp;</span>
        <div class="input">
          <el-input>
            <el-button slot="append" icon="el-icon-search" @click.native="search()"></el-button>
          </el-input>
          <!--<el-button type="primary" plain @click.native="search">搜索</el-button>-->
        </div>
      </div>
      <div class="tags">
        <!--<el-tag v-for="(item, $index) in restaurants" :key="$index" @click.native="sendVal(item.sceneName, $index)" size="medium" :type="item.color">{{ item.sceneName }}</el-tag>-->
        <a href="javascript:;" :class="{ 'default': selecedSceneId!==item.id, 'warning': selecedSceneId===item.id }" v-for="(item, $index) in restaurants" :key="$index" @click="sendVal(item.id, item.sceneName)">{{ item.sceneName }}</a>
      </div>
    </div>
    <span slot="footer" class="dialog-footer">
      <el-button type="primary" @click="Sure">确 定</el-button>
      <el-button @click="Close">取 消</el-button>
    </span>
  </el-dialog>
</template>
<script>
import { getSceneList } from '@/views/MapApp/apis/index.js'
export default {
  data () {
    return {
      dialogVisible: false,
      selecedSceneId: '',
      value: '',
      input: '',
      SceneTypes: [],
      result: '', // 最后需要传递的值
      restaurants: [],
      svalue: '',
      sname: '',
      stype: '',
      defaultSceneType: ''
    }
  },
  /* watch: {
  }, */
  mounted () {
  },
  methods: {
    initParamsDialog: function (currentAreaType, curLinkedScene) {
      this.selecedSceneId = curLinkedScene
      switch (currentAreaType) {
        // 小区分区区域
        case 1: this.defaultSceneType = 2
          break
        // 楼栋
        case 2: this.defaultSceneType = 3
          break
        // 车场分区区域
        default: this.defaultSceneType = 5
          break
      }
      this.search()
    },
    sendVal: function (val, sname) {
      this.selecedSceneId = val
      this.selecedSceneName = sname
    },
    Close: function () {
      this.dialogVisible = false
    },
    Open: function () {
      this.dialogVisible = true
    },
    Sure: function () {
      if (this.selecedSceneId === '') {
        let str = '请选择关联场景'
        this.$confirm(str, '错误', {
          confirmButtonText: '确定',
          type: 'error',
          dangerouslyUseHTMLString: true
        })
      } else {
        let clist = this.$parent.addoptions.childScene
        let atype = this.currentAreaType
        let linkSceneId = this.selecedSceneId
        if (clist.length !== 0 && atype === 2 && clist.indexOf(linkSceneId) === -1) {
          this.$confirm('关联场景不在子场景中', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'error',
            dangerouslyUseHTMLString: true
          })
        } else {
          let str = '已选择场景' + this.sname + '，' + '是否确定'
          this.$confirm(str, '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'info',
            dangerouslyUseHTMLString: true
          }).then(() => {
            // 在此处调用添加的接口
            console.log(this.result)
            this.$parent.addoptions.linkSceneId = this.selecedSceneId
            this.dialogVisible = false
            this.$message({
              message: '添加成功',
              type: 'success'
            })
          })
            .catch(() => {
              /* this.$message({
              type: 'info',
              message: '已取消添加'
            }) */
            })
        }
      }
    },
    search: function () {
      let data = {}
      data.sceneType = this.defaultSceneType
      data.sceneName = this.svalue
      getSceneList(data).then(res => {
        if (res.data.code === '00000') {
          this.restaurants = res.data.data
        }
      }).catch(err => {
        console.warn(err)
      })
    }

  }
}
</script>
<style lang="less" scoped>
.el-dialog {
  min-width: 536px !important;
}
.center {
  width: 95%;
  min-height: 40px;
  margin: 0 auto;
  background: none;
  .demo-input-suffix {
    width: 100%;
    min-height: 40px;
    margin-top: 10px;
    .wz {
      display: block;
      width: auto;
      height: 40px;
      line-height: 40px;
      float: left;
      margin-right: 5px;
    }
    .input {
      width: 300px;
      float: left;
      .el-input {
        width: 216px !important;
      }
      .el-button {
        float: right;
      }
    }
    .el-autocomplete {
      width: 100% !important;
    }
  }
  .tags {
    width: 100%;
    min-height: 100px;
    max-height: 200px;
    overflow-y: scroll;
    margin-top: 20px;
    a {
      display: block;
      text-decoration: none;
      margin-top: 10px;
      cursor: pointer;
    }
    .warning {
      color: orange;
    }
    .default {
      color: #3098ef;
    }
  }
}
</style>

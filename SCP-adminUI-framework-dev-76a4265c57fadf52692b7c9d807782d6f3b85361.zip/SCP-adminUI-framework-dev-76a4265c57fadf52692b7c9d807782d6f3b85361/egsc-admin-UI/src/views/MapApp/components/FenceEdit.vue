<template>
  <div>
    <el-dialog title="围栏信息" :visible.sync="dialogFormVisible" width="25%">
      <el-form>
        <el-form-item label="*围栏名称" label-width="80px" class="common-input">
          <el-input placeholder="请输入围栏名称" v-model='addoptions.areaName'></el-input>
        </el-form-item>
        <el-popover ref="orgPopover" placement="bottom" width="174">
          <el-tree class="filter-tree" :data="OrgTree" :props="defaultProps" ref="tree" default-expand-all @node-click="handleNodeClick"></el-tree>
        </el-popover>
        <el-form-item label="*所属组织" label-width="80px" class="common-input">
          <el-input v-model="OrgName" readonly placeholder="请选择所属组织" v-popover:orgPopover trigger="focus"></el-input>
        </el-form-item>
        <el-form-item class="button-groups">
          <el-button type="primary" size="small" @click='search'>查询</el-button>
          <el-button type="primary" size="small" @click='reset'>重置</el-button>
        </el-form-item>
        <div class="list-area">
          <div class="equip-list">*设备列表</div>
          <ul class="device-list">
            <li class="list-item" v-for="deviceItem in deviceList" :key="deviceItem.deviceId">
              <dl class="device-text-group">
                <dt class="device-name-text" :title="deviceItem.deviceName">{{deviceItem.deviceName}}</dt>
              </dl>
              <ul class="sub-device-list" v-if="deviceItem.subDevice&&deviceItem.subDevice.length>0">
                <li class="list-item" v-for="subDeviceItem in deviceItem.subDevice" :key="subDeviceItem.subDeviceId">
                  <dl class="device-text-group sub-device">
                    <dt class="device-name-text" :title="subDeviceItem.subDevicName" :class="{ active: subDeviceItem.subDeviceId === addoptions.areaDetailInfo.deviceId }" @click="colorChange(subDeviceItem.subDeviceId)">{{subDeviceItem.subDevicName}}</dt>
                  </dl>
                </li>
              </ul>
            </li>
          </ul>
        </div>
        <div class="btn-group">
          <el-button type='info' plain @click='cancel'>取消</el-button>
          <el-button type='success' plain @click='save'>保存</el-button>
        </div>
      </el-form>
    </el-dialog>
  </div>
</template>

<script>
import { getOrgTree, getDeviceList, addArea, updateArea } from '@/views/MapApp/apis/index.js'
export default {
  data () {
    return {
      OrgTree: [],
      OrgName: '',
      dialogFormVisible: false,
      defaultProps: {
        children: 'children',
        label: 'name'
      },
      addoptions: {
        sceneId: '',
        areaId: '',
        areaName: '',
        areaType: '',
        borderPoints: [
          {
            gpsLongitude: 0,
            gpsLatitude: 0,
            pointX: 0,
            pointY: 0,
            markerType: 1
          },
          {
            gpsLongitude: 0,
            gpsLatitude: 0,
            pointX: 0,
            pointY: 0,
            markerType: 1
          }
        ],
        areaDetailInfo: {
          deviceId: '',
          areaStatus: ''
        }
      },
      deviceList: [],
      uuid: null,
      addOrEdit: '',
      deviceType: '2021'
    }
  },
  methods: {
    // 组织树选中一项后触发事件
    handleNodeClick (data) {
      this.OrgName = data.name
      this.uuid = data.uuid
      console.log(this.uuid)
      // 清空选中项
      this.deviceList = []
      this.addoptions.areaDetailInfo.deviceId = ''
    },
    // 取消按钮，用于关闭围栏弹窗
    cancel () {
      this.dialogFormVisible = false
    },
    // 重置按钮，用于清空所属组织输入框数据
    reset () {
      // 清空选中项
      this.OrgName = ''
      this.deviceList = []
      this.addoptions.areaDetailInfo.deviceId = ''
    },
    // 保存按钮，用于添加围栏
    save () {
      if (this.addOrEdit === 0) {
        let params = {}
        params.areaDetailInfo = {}
        params.sceneId = this.addoptions.sceneId
        params.areaName = this.addoptions.areaName
        params.areaType = this.addoptions.areaType
        params.borderPoints = this.addoptions.borderPoints
        params.areaDetailInfo.deviceId = this.addoptions.areaDetailInfo.deviceId
        params.areaDetailInfo.areaStatus = this.addoptions.areaDetailInfo.areaStatus
        // 判断围栏名字是否为空
        if (this.addoptions.areaName === '') {
          this.$message({
            message: '围栏名称不能为空！',
            type: 'warning'
          })
          return
        }
        // 判断所属组织输入框是否为空
        if (this.addoptions.areaDetailInfo.deviceId === '') {
          this.$message({
            message: '您还未选择设备！',
            type: 'warning'
          })
          return
        }
        // 添加围栏
        addArea(params).then((res) => {
          if (res.data.code === '00001') {
            this.$message({
              message: '该围栏设备已绑定防区' + res.data.data.sceneId + res.data.data.sceneName + res.data.data.areaId + res.data.data.areaName,
              type: 'warning'
            })
            return
          }
          if (res.data.code === '00000') {
            console.log(res.data.data)
            // 调用父组件的方法
            this.$emit('customEvent')
            this.$message({
              message: '恭喜你，数据添加成功',
              type: 'success'
            })
          }
        }).catch(err => {
          console.warn(err)
        })
        // 关闭弹窗
        this.dialogFormVisible = false
      } else if (this.addOrEdit === 1) {
        let params = {}
        params.areaDetailInfo = {}
        params.areaName = this.addoptions.areaName
        params.areaId = this.addoptions.areaId
        params.areaType = this.addoptions.areaType
        params.areaDetailInfo.deviceId = this.addoptions.areaDetailInfo.deviceId
        params.areaDetailInfo.areaStatus = this.addoptions.areaDetailInfo.areaStatus
        // 判断围栏名字是否为空
        if (this.addoptions.areaName === '') {
          this.$message({
            message: '围栏名称不能为空！',
            type: 'warning'
          })
          return
        }
        // 判断所属组织输入框是否为空
        if (this.addoptions.areaDetailInfo.deviceId === '') {
          this.$message({
            message: '您还未选择设备！',
            type: 'warning'
          })
          return
        }
        // 添加围栏
        updateArea(params).then((res) => {
          if (res.data.code === '00001') {
            this.$message({
              message: '该围栏设备已绑定防区' + res.data.data.sceneId + res.data.data.sceneName + res.data.data.areaId + res.data.data.areaName,
              type: 'warning'
            })
            return
          }
          if (res.data.code === '00000') {
            console.log(res.data.data)
            // 调用父组件的方法
            this.$emit('customEvent')
            this.$message({
              message: '恭喜你，数据修改成功',
              type: 'success'
            })
          }
        }).catch(err => {
          console.warn(err)
        })
        // 关闭弹窗
        this.dialogFormVisible = false
      }
    },
    // 单击设备列表中的子设备后，让子设备的颜色处于激活状态
    colorChange (subDeviceId) {
      this.addoptions.areaDetailInfo.deviceId = subDeviceId
      console.log(this.addoptions.areaDetailInfo.deviceId)
    },
    // 点击查询按钮，用于查询设备列表
    search () {
      if (this.OrgName === '') {
        this.$message({
          message: '请先选择组织树！',
          type: 'warning'
        })
        return
      }
      getDeviceList({ OrgId: this.uuid }).then((res) => {
        this.deviceList = res.data.data
        // this.deviceList = [
        //   {
        //     'deviceName': '设备1',
        //     'deviceId': '30044424ac30b9d40001',
        //     'subDevice': [
        //       {
        //         'subDevicName': '设备1-1',
        //         'subDeviceId': '30044424ac30b9d40001'
        //       },
        //       {
        //         'subDevicName': '设备1-2',
        //         'subDeviceId': '30044424ac30b9d40001'
        //       },
        //       {
        //         'subDevicName': '设备1-3',
        //         'subDeviceId': '30044424ac30b9d40001'
        //       }
        //     ]
        //   },
        //   {
        //     'deviceName': '设备2',
        //     'deviceId': '1130044424ac30b9d4000112',
        //     'subDevice': [
        //       {
        //         'subDevicName': '设备2-1',
        //         'subDeviceId': '30044424ac30b9d40001'
        //       },
        //       {
        //         'subDevicName': '设备2-2',
        //         'subDeviceId': '30044424ac30b9d40001'
        //       },
        //       {
        //         'subDevicName': '设备2-3',
        //         'subDeviceId': '30044424ac30b9d40001'
        //       }
        //     ]
        //   }
        // ]
      })
    }
  },
  mounted: function () {
    // 加载组织树
    let _this = this
    getOrgTree().then((res) => {
      console.log('查询组织树')
      console.log(res.data.data)
      if (res.data.data.children) {
        _this.OrgTree = res.data.data.children
      }
    }).catch(err => {
      console.warn(err)
    })
  }
}
</script>
<style lang="less" scoped>
/*MapApp.less公共样式start*/
@origin: 10px;

.pull-left {
  float: left;
}
.pull-right {
  float: right;
}
.row-flow {
  width: 100%;
}
.clearfix {
  clear: both;
}
.common-input {
  width: @origin*28;
}
.map-app {
  box-sizing: border-box;
  position: absolute;
  top: 90px;
  bottom: 20px;
  left: 225px;
  right: 20px;
}
.filter-tree {
  overflow-x: hidden;
  overflow-y: scroll;
  max-height: 300px;
}
/*MapApp.less公共样式end*/
* {
  box-sizing: border-box;
}
.el-dialog {
  .formItem {
    margin-left: 8px;
  }
  .btn-group {
    line-height: 30px;
    padding: 0 24px 0 0;
    overflow: hidden;
    .el-button {
      float: right;
      margin-left: 20px;
    }
  }
  .small-input {
    width: 200px;
  }
  .text {
    font-size: 14px;
  }
  .item {
    padding: 10px 0;
  }
  .button-groups {
    padding-left: 90px;
  }
  .equip-list {
    padding-left: 10px;
  }
  .device-list {
    width: 300px;
    height: 250px;
    border: 1px solid #ddd;
    overflow-y: auto;
    margin-left: 30px;
    margin-bottom: 10px;
    .list-item {
      overflow: hidden;
      border-bottom: 1px solid #ddd;
    }
    .sub-device-list {
      margin-left: 25px;
    }
    .device-text-group {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    li {
      cursor: pointer;
    }
    .active {
      color: white;
      background: rgba(34, 156, 255, 1);
    }
  }
}
</style>

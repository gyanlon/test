<template>
  <div class="map-app">
    <div v-show="status=='0'" class="page-content">
      <div class="row-flow normal-flex-item">
        <el-form ref="param" v-model="param" label-width="80px" class="search-form">
          <el-form-item label="场景类型" class='common-input form-item'>
            <el-select v-model="param.sceneType" class='small-input'>
              <el-option :label="item.itemName" :value="item.itemCode" v-for="item in selectList" :key="item.itemCode">{{item.itemName}}</el-option>
            </el-select>
          </el-form-item>
          <el-popover ref="orgPopover" placement="top-end" width="174" v-model="isShowPopover">
            <el-input placeholder="输入关键字进行过滤" v-model="filterText"></el-input>
            <el-tree class="filter-tree" :data="OrgTree" :props="defaultProps" default-expand-all :filter-node-method="filterNode" @node-click="handleNodeClick" ref="tree"></el-tree>
          </el-popover>
          <el-form-item label="所属组织" label-width="80px" class="common-input">
            <el-input v-model="OrgName" placeholder="请选择组织" readonly v-popover:orgPopover></el-input>
          </el-form-item>
          <el-form-item label="场景名称" label-width="80px" class="common-input">
            <el-input v-model="param.sceneName" placeholder="请输入场景名称" @keyup.enter.native="getPageData()"></el-input>
          </el-form-item>
          <div class="search-toolbar">
            <el-button type="primary" @click="getPageData" class="search-btn">查询</el-button>
            <el-button type="primary" @click="resetParam" class="search-btn">重置</el-button>
          </div>
        </el-form>
      </div>
      <div class="row-flow operation-bar normal-flex-item">
        <el-button type="primary" @click="addScene" class="operation-btn">
          <i class="el-icon-plus"></i>&nbsp;添加</el-button>
        <el-button type="danger" @click="deleteScenes" class="operation-btn">
          <i class="el-icon-close"></i>&nbsp;删除</el-button>
      </div>
      <div class="row-flow clearfix fit-flex-item table-list">
        <el-table :data="tableData" class="row-flow" ref="multipleTable" @selection-change="handleSelectionChange" height="100%" stripe>
          <el-table-column type="selection" width="55"></el-table-column>
          <el-table-column prop="sceneName" label="场景名称"></el-table-column>
          <el-table-column prop="sceneType" label="场景类型" :formatter="filterSceneType"></el-table-column>
          <el-table-column prop="orgName" label="所属组织"></el-table-column>
          <!-- <el-table-column prop="centerLon" label="场景中心经度"></el-table-column>
          <el-table-column prop="centerLat" label="场景中心纬度"></el-table-column> -->
          <el-table-column prop="width" label="图片宽度"></el-table-column>
          <el-table-column prop="height" label="图片高度"></el-table-column>
          <el-table-column prop="scaleType" label="比例尺计算方式"></el-table-column>
          <el-table-column label="操作" width="200">
            <template slot-scope="scope">
              <el-button @click="sceneDetail(scope.row)" type="text" size="small">查看</el-button>
              <el-button @click="itemEdit(scope.row)" type="text" size="small">编辑</el-button>
              <el-button @click="itemDelete(scope.row)" type="text" size="small">删除</el-button>
              <el-button @click="enterArea(scope.row)" type="text" size="small" v-if="scope.row.sceneType===1||scope.row.sceneType===4||scope.row.sceneType===2">区域管理</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <scene-detail ref="sceneDetail" :sceneId='id' @change="changeHandler"></scene-detail>
      <div class="row-flow pagination-bar normal-flex-item">
        <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage" :page-sizes="[10, 20, 50, 100]" :page-size="pageSize" layout="total, sizes, prev, pager, next, jumper" :total="total">
        </el-pagination>
      </div>
    </div>
    <div v-show="status==='1'">
      <scene-info ref="SceneInfo" :currentParams="param"></scene-info>
    </div>
    <div v-if="status===3">
      <!--<area-manager ref="AreaManager" :backMessage='st'></area-manager>-->
      <area-manager ref="AreaManager" :areaSceneInfo='areSceneInfo'></area-manager>
    </div>
  </div>
</template>

<script>
// import { getSceneList, getScenePageList, getOrgTree, getSceneInfo, deleteScene, getDictionary } from '@/views/MapApp/apis/index.js'
import { getSceneList, getScenePageList, getOrgTree, getSceneInfo, deleteScene, getDictionary } from '@/views/MapApp/apis/index.js'

import SceneInfo from '@/views/MapApp/components/SceneInfo'
import SceneDetail from '@/views/MapApp/components/SceneDetail'
import AreaManager from '@/views/MapApp/components/AreaManager'

export default {
  components: {
    SceneInfo,
    SceneDetail,
    AreaManager
  },
  data () {
    return {
      selectList: [],
      areSceneInfo: {},
      sceneGPS: {},
      editUrl: '',
      OrgName: '',
      filterText: '',
      status: '0',
      isShow: false,
      isShowNext: true,
      isShowPopover: false,
      currentRow: {},
      id: '',
      param: {
        sceneName: '',
        sceneType: '',
        orgId: ''
      },
      deleteScene: {
        sceneIds: []
      },
      defaultParam: {
        sceneName: '',
        sceneType: '',
        orgId: ''
      },
      tableData: [
      ],
      pageSize: 10,
      pageNum: 1,
      currentPage: 1,
      total: 0,
      OrgTree: [],
      defaultProps: {
        children: 'children',
        label: 'name'
      },
      multipleSelection: [],
      pageData: [
        {
          id: '123',
          sceneName: '测试数据-停车场',
          url: '/map/scenemap/02/park01.jpg',
          centerLon: '110.121332',
          centerLat: '45.123343',
          scale: '20000',
          height: '1200',
          width: '800',
          orgId: '0010102401',
          sceneType: '02'
        },
        {
          id: '124',
          sceneName: '测试数据一楼大厅',
          url: '/map/scenemap/02/park01.jpg',
          centerLon: '90.121332',
          centerLat: '145.123343',
          scale: '2000',
          height: '1200',
          width: '800',
          orgId: '0010102405',
          sceneType: '01'
        }
      ]
    }
  },
  watch: {
    filterText (val) {
      this.$refs.tree.filter(val)
    }
  },
  methods: {
    handleSizeChange (val) {
      this.pageSize = val
      this.getPageData()
    },
    changeHandler: function (newVal) {
      this.status = newVal
      console.log('this.status:')
      console.log(this.status)
      console.log(typeof this.status)
    },
    handleCurrentChange (val) {
      this.currentPage = val
      this.getPageData()
    },
    filterSceneType: function (row, column) {
      var sceneType = row.sceneType
      switch (sceneType) {
        case 1:
          return '小区全图'
        case 2:
          return '小区区域图'
        case 3:
          return '楼层地图'
        case 4:
          return '停车场主地图'
        case 5:
          return '停车场分区图'
      }
    },
    // 列表查询
    getPageData: function () {
      getScenePageList(this.currentPage, this.pageSize, this.param).then((res) => {
        console.log(res)
        // 接口
        for (let i = 0; i < res.data.data.pageData.length; i++) {
          if (Number(res.data.data.pageData[i].scaleType) === 1) {
            res.data.data.pageData[i].scaleType = '三点定位'
          } else {
            res.data.data.pageData[i].scaleType = '宽高计算'
          }
        }
        this.tableData = res.data.data.pageData
        this.total = res.data.data.total
      }).catch(err => {
        console.warn(err)
      })
    },
    SceneTypeChange: function () {
      let options = {}
      options.sceneType = this.value
      options.sceneName = this.valueName
      getSceneList(options).then((res) => {
        this.sceneList = res.data.data
      }).catch(err => {
        console.warn(err)
      })
    },
    filterNode (value, data) {
      if (!value) return true
      return data.name.indexOf(value) !== -1
    },
    resetParam: function () {
      this.param = Object.assign({}, this.defaultParam)
      this.OrgName = ''
      this.pageSize = 10
      this.currentPage = 1
      this.getPageData()
    },
    /*
    handleNodeClick: function (data) {
      this.param.org_code = data.org_code
      this.isShow = false
    },
    */
    handleNodeClick (data) {
      console.log(data)
      this.OrgName = data.name
      this.param.orgId = data.uuid
      this.isShowPopover = false
      this.filterText = ''
      /*
      while (nodeLeaf.parent) {
        this.orgName = nodeLeaf.data.name + this.orgName
        nodeLeaf = nodeLeaf.parent
      }
      */
    },
    // 查看详情
    sceneDetail: function (row) {
      getSceneInfo({ sceneId: row.id }).then(res => {
        console.log(res.data.data)
        this.$refs['sceneDetail'].sceneDetailTmp = res.data.data
        this.$refs['sceneDetail'].dialogFormVisible = true
        this.$refs['sceneDetail'].mapImage = res.data.data.url
        let sceneType = this.$refs['sceneDetail'].sceneDetailTmp.sceneType
        switch (sceneType) {
          case 1:
            this.$refs['sceneDetail'].sceneDetailTmp.sceneType = '小区全图'
            break
          case 2:
            this.$refs['sceneDetail'].sceneDetailTmp.sceneType = '小区区域图'
            break
          case 3:
            this.$refs['sceneDetail'].sceneDetailTmp.sceneType = '楼层'
            break
          case 4:
            this.$refs['sceneDetail'].sceneDetailTmp.sceneType = '停车场主地图'
            break
          case 5:
            this.$refs['sceneDetail'].sceneDetailTmp.sceneType = '停车场分地图'
            break
        }
        console.log('sceneDetailTmp')
        console.log(this.$refs['sceneDetail'].sceneDetailTmp)
        console.log(this.$refs['sceneDetail'].sceneDetailTmp.locationPoints)
        if (!this.$refs['sceneDetail'].sceneDetailTmp.locationPoints) {
          this.$refs['sceneDetail'].sceneDetailTmp.locationPoints = null
          console.log(this.$refs['sceneDetail'].sceneDetailTmp.locationPoints)
        }
      }).catch(err => {
        console.warn(err)
      })
    },
    addScene: function () {
      this.status = '1'
      this.isShowNext = true
      console.log(this)
      console.log(this.$refs['SceneInfo'])
      console.log(this.$refs['sceneDetail'])
      this.$refs['SceneInfo'].addSceneInfo()
    },
    // 点击编辑，跳转到编辑界面
    itemEdit: function (row) {
      console.log('编辑row:')
      console.log(row)
      this.currentRow = row
      // 调用get接口,保存点位数据供页面初始化
      getSceneInfo({ sceneId: row.id }).then(res => {
        this.status = '1'
        console.log(this)
        console.log("this.$refs['SceneInfo']")
        console.log(this.$refs['SceneInfo'])
        console.log(this.$refs.SceneInfo)
        this.$refs['SceneInfo'].editSceneInfo(res.data.data)
        this.isShowNext = false
      }).catch(err => {
        console.warn(err)
      })
    },
    // 当行表数据删除操作
    itemDelete: function (row) {
      this.$confirm('确定要刪除该场景吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
        dangerouslyUseHTMLString: true
      }).then(() => {
        // 在此处调用批量删除的接口
        console.log('调用删除接口：')
        this.deleteScene.sceneIds.push(row.id)
        console.log(this.deleteScene)
        deleteScene(this.deleteScene).then(res => {
          console.log(res)
          this.getPageData()
        })
        this.$message({
          message: '刪除成功',
          type: 'warning'
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    // 区域管理
    enterArea: function (row) {
      // this.areSceneInfo = row
      var sid = row.id
      var data = { 'sceneId': sid }
      getSceneInfo(data).then(res => {
        console.log(this.areSceneInfo)
        this.areSceneInfo = res.data.data
        // this.$refs['AreaManager'].sceneInfo = this.areSceneInfo
        this.status = 3
      }).catch(err => {
        console.warn(err)
      })
      // console.log(row)
      // console.log(this.areSceneInfo.id)
      // this.$refs['AreaManager'].sceneInfo = row
      // this.status = 3
    },
    // 增加场景
    handleSelectionChange: function (val) {
      this.multipleSelection = val
      console.log(val)
    },
    // 下一步
    next: function () {
      this.status = 2
    },
    // 批量删除
    deleteScenes: function () {
      if (this.multipleSelection.length <= 0) {
        this.$message({
          message: '请至少选择一项！',
          type: 'warning'
        })
        return
      }
      let str = ''
      for (let i = 0, len = this.multipleSelection.length; i < len; i++) {
        console.log('批量删除')
        console.log(this.multipleSelection[i])
        if (this.multipleSelection[i].sceneName && i < this.multipleSelection.length) {
          str += this.multipleSelection[i].sceneName
          this.deleteScene.sceneIds.push(this.multipleSelection[i].id)
          console.log(this.deleteScene)
          if (i < length - 1) {
            str += ','
          }
        }
      }
      str = this.multipleSelection.length > 3 ? (str + '等') : str
      this.$confirm('确定要刪除 ' + str + ' 的场景吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
        dangerouslyUseHTMLString: true
      }).then(() => {
        // 在此处调用批量删除的接口
        console.log('调用删除接口：')
        console.log(this.deleteScene)
        deleteScene(this.deleteScene).then(res => {
          console.log(res)
          this.getPageData()
        })
        this.$message({
          message: '刪除成功',
          type: 'warning'
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    }
  },
  mounted: function () {
    this.params = this.param
    let that = this
    this.getPageData()
    getOrgTree().then(res => {
      if (res.data.data.children) {
        that.OrgTree = res.data.data.children
      }
    }).catch(err => {
      console.warn(err)
    })
    getDictionary().then((res) => {
      let dictionary = res.data.data
      let sceneTypes = dictionary.dictCodeType.sceneType
      // console.log(areaTypes)
      var len = sceneTypes.length
      for (var i = 0; i < len; i++) {
        sceneTypes[i].itemCode = parseInt(sceneTypes[i].itemCode)
      }
      this.selectList = sceneTypes
    })
  }
}
</script>
<style lang="less" scoped>
/*公共样式start*/
@origin: 10px;
.pull-left {
  float: left;
}
.pull-right {
  float: right;
}
.row-flow {
  width: 100%;
}
.clearfix {
  clear: both;
}
.common-input {
  width: @origin*28;
}
.map-app {
  box-sizing: border-box;
  position: absolute;
  top: 90px;
  bottom: 20px;
  left: 225px;
  right: 20px;
  /deep/.cell {
    white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;
  }
  .page-content {
    display: flex;
    flex-direction: column;
    height: 100%;
    .normal-flex-item {
      flex: 0 0 auto;
    }
    .fit-flex-item {
      flex: 1;
    }
  }
  .table-list {
    display: flex;
  }
}
.filter-tree {
  overflow-x: hidden;
  overflow-y: scroll;
  max-height: 300px;
}
/*公共样式end*/
.pagination-bar {
  padding: @origin*2 0;
  text-align: center;
}
.search-form {
  overflow: hidden;
  padding: @origin 0;
  .common-input {
    margin-right: 10px;
    .pull-left;
  }
}
.operation-bar {
  width: 100%;
  height: @origin*4;
  .operation-btn {
    height: 30px;
    padding: @origin*.7 @origin*1.5;
    .pull-left;
  }
}
.search-toolbar {
  width: @origin*20;
  .pull-right;
  .search-btn {
    margin-left: @origin*1.2;
    .pull-left;
  }
}
.scene-img {
  margin: 60px 0 40px;
  border: 1px solid #ccc;
}
</style>
export const formatArea = areasList => {
  let areaArray = []
  for (let i = 0; i < areasList.length; i++) {
    areaArray[i] = []
    areaArray[i][0] = []
    for (let j = 0; j < areasList[i].borderPoints.length; j++) {
      let pointX = areasList[i].borderPoints[j].pointX
      let pointY = areasList[i].borderPoints[j].pointY
      areaArray[i][0][j] = [pointX, pointY]
    }
    areasList[i].borderPoints = areaArray[i]
    areasList[i].areaType = parseInt(areasList[i].areaType)
  }
  return areasList
}

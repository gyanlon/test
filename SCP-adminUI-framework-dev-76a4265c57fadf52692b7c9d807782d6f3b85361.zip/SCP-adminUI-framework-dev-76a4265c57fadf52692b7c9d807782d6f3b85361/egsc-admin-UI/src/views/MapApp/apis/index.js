import Axios from '@/assets/js/AxiosPlugin'
// 代码提交部署时使用/scp-mapapp作上下文
const contextPath = '/scp-mapapp'

// 调试用上下文字段为空
// const contextPath = ''
/* -------------------- 地图通用配置接口 start -------------------- */
// 设置地图通用配置
export const setMapSetting = data => {
  return Axios({
    method: 'post',
    url: contextPath + '/mapService/setMapSetting',
    data
  })
}

// 获取地图通用配置
export const getMapSetting = () => {
  return Axios.get(contextPath + '/mapService/getMapSetting')
}
/* -------------------- 地图通用配置接口 end -------------------- */

/* -------------------- 场景接口 start -------------------- */
// 获取场景分页列表
export const getScenePageList = (pageNum, pageSize, params) => {
  params.pageNum = pageNum
  params.pageSize = pageSize
  return Axios({
    url: contextPath + '/mapService/getScenePageList',
    method: 'get',
    params
  })
}

// 获取场景列表
export const getSceneList = (data) => {
  return Axios({
    url: contextPath + '/mapService/getSceneList',
    method: 'get',
    params: data
  })
}

// 获取车位列表
export const getParkList = (data) => {
  return Axios({
    url: contextPath + '/mapService/getParkList',
    method: 'get',
    params: data
  })
}

// 增加场景
export const addScene = data => {
  return Axios({
    method: 'post',
    url: contextPath + '/mapService/addScene',
    data
  })
}

// 场景信息更新
export const updateScene = data => {
  return Axios({
    method: 'post',
    url: contextPath + '/mapService/updateScene',
    data
  })
}

// 获取场景详情
export const getSceneInfo = (data) => {
  return Axios({
    url: contextPath + '/mapService/getSceneInfo',
    method: 'get',
    params: data
  })
}

// 比例尺相关信息更新
export const setSceneScaleByReal = data => {
  return Axios({
    method: 'post',
    url: contextPath + '/mapService/setSceneScale/byReal',
    data
  })
}
export const setSceneScaleByGPS = data => {
  return Axios({
    method: 'post',
    url: contextPath + '/mapService/setSceneScale/byGPS',
    data
  })
}

// 删除场景
export const deleteScene = data => {
  return Axios({
    method: 'post',
    url: contextPath + '/mapService/deleteScene',
    data
  })
}
/* -------------------- 场景接口 end -------------------- */

/* -------------------- 应用接口 start -------------------- */
// 获取设备列表
export const getDeviceList = (data) => {
  return Axios({
    url: contextPath + '/mapapp/getDeviceList',
    method: 'get',
    params: data
  })
}
// 获取设备信息
export const getDeviceInfo = (data) => {
  return Axios({
    url: contextPath + '/mapapp/getDeviceInfo',
    method: 'get',
    params: data
  })
}
// 获取组织树
export const getOrgTree = (data) => {
  return Axios({
    url: contextPath + '/mapapp/getOrgTree',
    method: 'get',
    params: data
  })
}
// 获取字典表
export const getDictionary = (data) => {
  return Axios({
    url: contextPath + '/mapapp/getDictionary',
    method: 'get',
    params: data
  })
}
/* -------------------- 应用接口 end -------------------- */

/* -------------------- 点位接口 start -------------------- */
// 获取单个点位信息
export const getMarkerInfo = (data) => {
  return Axios({
    method: 'get',
    url: contextPath + '/mapService/getMarkerInfo',
    params: data
  })
}
// 获取点位列表
export const getMarkerList = (data) => {
  return Axios({
    method: 'get',
    url: contextPath + '/mapService/getMarkerList',
    params: data
  })
}
// 增加点位
export const addMarker = (data) => {
  return Axios({
    method: 'post',
    url: contextPath + '/mapService/addMarker',
    data
  })
}
// 更新点位
export const updateMarker = (data) => {
  return Axios({
    method: 'post',
    url: contextPath + '/mapService/updateMarker',
    data
  })
}
// 删除点位
export const deleteMarker = (data) => {
  return Axios({
    method: 'post',
    url: contextPath + '/mapService/deleteMarker',
    data
  })
}
/* -------------------- 点位接口 end -------------------- */

/* -------------------- 区域接口 start -------------------- */
// 新增区域
export const addArea = data => {
  return Axios({
    method: 'post',
    url: contextPath + '/mapService/addArea',
    data
  })
}

// 查询区域列表
export const getAreaList = (data) => {
  return Axios({
    method: 'get',
    url: contextPath + '/mapService/getAreaList',
    params: data
  })
}

// 更新区域信息
export const updateArea = data => {
  return Axios({
    method: 'post',
    url: contextPath + '/mapService/updateArea',
    data
  })
}

// 删除区域信息
export const deleteArea = data => {
  return Axios({
    method: 'post',
    url: contextPath + '/mapService/deleteArea',
    data
  })
}

// 获取区域信息
export const getAreaInfo = (data) => {
  return Axios({
    method: 'get',
    url: contextPath + '/mapService/getAreaInfo',
    params: data
  })
}

/* -------------------- 区域接口 end -------------------- */

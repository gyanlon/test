<template>
  <div class="map-app">
    <div class="row-flow main">
      <div class="content-left">
        <div class="search-sence-area">
          <el-form label-width="80px" class="search-form">
            <el-form-item label="场景类型" class="common-input">
              <el-select v-model="sceneParam.sceneType" placeholder="请选择场景类型" @change="SceneTypeChange">
                <el-option v-for="item in SceneTypes" :label="item.itemName" :value="item.itemCode" :key="item.itemCode"></el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="场景名称" label-width="80px" class="common-input">
              <el-input v-model="sceneParam.sceneName" maxLength="" placeholder="请输入场景名称"></el-input>
            </el-form-item>
            <div class="search-toolbar">
              <el-button type="primary" class="search-btn" @click.stop="querySceneList">查询</el-button>
              <el-button type="primary" class="search-btn" @click="resetSceneParam">重置</el-button>
            </div>
          </el-form>
        </div>
        <div class="list-area">
          <ul class="data-list">
            <li :title="sceneItem.sceneName" v-for="sceneItem in sceneList" :key="sceneItem.id" class="list-item sceneItem" :class="{ active: sceneItem.id == sceneId }" @click="showScene(sceneItem.id)">
              {{ sceneItem.sceneName }}
            </li>
          </ul>
        </div>
        <div class="list-fence">
          <p>围栏列表</p>
          <ul>
            <li v-for="(fenceListItem) in fenceList" :key="fenceListItem.id">
              <div class="fence-list">
                <div class="fence-name" :title="fenceListItem.areaName">
                  <span>{{fenceListItem.areaName}}</span>
                </div>
                <div class="fence-edit">
                  <el-button @click='showMap(fenceListItem,$event)' type="text" size="small">显示</el-button>
                  <el-button @click='hideMap(fenceListItem,$event)' type="text" size="small">隐藏</el-button>
                  <el-button @click='editArea(fenceListItem,$event)' type="text" size="small">编辑</el-button>
                  <el-button @click='delArea(fenceListItem, $event)' type="text" size="small">删除</el-button>
                </div>
              </div>
              <div class="device-list">
                <el-button type="text" size="small">deviceId:</el-button>
                <p :title="fenceListItem.areaDetailInfo.deviceId">{{fenceListItem.areaDetailInfo.deviceId}}</p>
              </div>
            </li>
          </ul>
        </div>
      </div>
      <div class="content-center">
        <div class="button-group">
          <el-button type="primary" class="search-btn" @click="drawStart">开始绘制</el-button>
          <el-button type="primary" class="search-btn" @click="drawClose">绘制结束</el-button>
        </div>
        <div id="mapDiv"></div>
      </div>
    </div>
    <fence-edit ref='FenceEdit' @customEvent="searchFenceList"></fence-edit>
  </div>
</template>

<script>
import { getSceneList, getDictionary, getSceneInfo, getAreaList, getAreaInfo, deleteArea, getDeviceInfo } from '@/views/MapApp/apis/index.js'
import hdmap from 'hdmap'
import FenceEdit from '@/views/MapApp/components/FenceEdit.vue'
import { mapOptionFormat, extendObj } from '@/views/MapApp/assets/js/index.js'
import { formatArea } from '@/views/MapApp/assets/js/utils.js'
export default {
  components: {
    FenceEdit
  },
  data () {
    return {
      // 场景参数
      sceneParam: {
        sceneName: '',
        sceneType: ''
      },
      // 场景类型
      SceneTypes: [],
      // 围栏列表
      sceneList: [],
      // 地图缓存数组
      cacheMapList: [],
      // 地图对象
      mapObj: null,
      // 点位信息
      borderPoints: [],
      // 点位信息数组
      borderPoint: {
        gpsLongitude: 0,
        gpsLatitude: 0,
        pointX: 0,
        pointY: 0,
        markerType: '0'
      },
      // 路线的点位信息
      optionLine: {
        id: '',
        name: '',
        lineType: '',
        borderPoints: []
      },
      points: [],
      // GPS信息
      GPSInfo: [],
      // 围栏列表
      fenceList: [],
      // 场景Id
      sceneId: '',
      areaType: '5',
      areaStatus: '101',
      // 设备名称
      deviceName: '',
      // 设备Id
      deviceId: '',
      beginDraw: '0'
    }
  },
  methods: {
    // 初始化地图
    createMap: function (option) {
      console.log('创建地图的option')
      console.log(option)
      // 获取小区真实地图图片
      let mapImageUrl = option.url
      console.log(mapImageUrl)
      if (this.mapObj) {
        this.mapObj.getMap().setTarget(null)
      }
      // 已经初始化的地图可以直接获取地图对象，进行地图的替换即可
      console.log(this.cacheMapList[option.id])
      if (this.cacheMapList[option.id]) {
        this.mapObj = this.cacheMapList[option.id]
        this.mapObj.getMap().setTarget('mapDiv')
        return
      }
      // 如果没有初始化过，才需要进行地图的初始化
      let formatedOption = mapOptionFormat(option)
      let mapOption = extendObj(formatedOption, {
        gisEngine: 'bitmap',
        domId: 'mapDiv',
        mapUrl: mapImageUrl,
        sizeW: 1920,
        sizeH: 1080,
        maxZoom: 3,
        minZoom: 3,
        center: [112.334403, 39.8],
        popupDom: {
          popup: 'popup',
          popupcloser: 'popup-closer',
          popupcontent: 'popup-content'
        }
      })
      // eslint-disable-next-line
      this.cacheMapList[option.id] = new hdmap.initMap(mapOption)
      this.mapObj = this.cacheMapList[option.id]
      this.mapObj.getMap().setTarget('mapDiv')
    },
    // 切换场景
    showScene: function (id) {
      console.log('获取当前场景信息')
      this.sceneId = id
      let options = {}
      options.sceneId = this.sceneId
      console.log(options)
      getSceneInfo(options).then((res) => {
        console.log('获取请求场景信息的返回值：')
        console.log(res.data.data)
        // TODO 切换地图
        if (res.data.data) {
          this.createMap(res.data.data)
        } else {
          console.log('场景信息为空')
        }
      }).catch(err => {
        console.warn(err)
      })
      // 更新围栏列表
      this.searchFenceList()
    },
    // 开始绘制
    drawStart: function () {
      // 如果已经点击开始绘制，将beginDraw复制为'1'
      this.beginDraw = '1'
      // 判断有无地图被选中
      if (this.sceneId === '') {
        this.$message({
          message: '请先选择地图！',
          type: 'warning'
        })
        return
      }
      this.mapObj.openDrawLineTool({ color: '#ff0033', width: 2 }, function (e) {
        console.log('begin draw')
      })
    },
    // 结束绘制
    drawClose () {
      // 判断是否选中地图，如果sceneId为空弹框提示，如果不为空继续执行下面的代码
      if (this.sceneId === '') {
        this.$message({
          message: '请先选择地图！',
          type: 'warning'
        })
        return
      }
      // 判断是否点击了开始绘制按钮，为'1'继续执行后面的代码，为'0'则return
      if (this.beginDraw !== '1') {
        this.$message({
          message: '请先绘制区域！',
          type: 'warning'
        })
        return
      }
      // 将是否开始绘制状态改成'0'
      this.beginDraw = '0'
      // 将是否开始绘制状态还原
      this.borderPoints = []
      this.mapObj.closeDrawLineTool()
      let optionLine = {
        id: '111',
        name: '111',
        lineType: '111',
        borderPoints: []
      }
      let feat = this.mapObj.showDrawLine(optionLine, { color: '#ff0033', width: 2 })
      optionLine.borderPoints = feat.getGeometry().getCoordinates()
      this.points = optionLine.borderPoints
      console.log('点位：')
      console.log(this.points)
      // 如果没有绘制区域就结束绘制，进行提示
      if (this.points.length === 0) {
        this.$message({
          message: '请先绘制区域！',
          type: 'warning'
        })
        return
      }
      for (let i = 0; i < this.points.length; i++) {
        // 坐标转换
        this.borderPoint.pointX = this.points[i][0]
        this.borderPoint.pointY = this.points[i][1]
        console.log('this.borderPoint')
        console.log(this.borderPoint)
        let GPSInfo = [0, 0]
        try {
          this.GPSInfo = this.mapObj.transBitmapToWGS(this.points[i])
        } catch (e) {
          this.GPSInfo = [0, 0]
          console.warn(e)
        }
        this.borderPoints.push({
          gpsLongitude: GPSInfo[0],
          gpsLatitude: GPSInfo[1],
          pointX: this.borderPoint.pointX,
          pointY: this.borderPoint.pointY,
          markerType: '1'
        })
      }
      // console.log('borderPoints:')
      console.log(this.borderPoints)
      // 将直线从图层上移除
      this.mapObj.removeLine(optionLine)
      // 向子组件传递参数
      this.$refs['FenceEdit'].addoptions.borderPoints = this.borderPoints
      this.$refs['FenceEdit'].addoptions.sceneId = this.sceneId
      this.$refs['FenceEdit'].addoptions.areaType = this.areaType
      this.$refs['FenceEdit'].addoptions.areaName = ''
      this.$refs['FenceEdit'].addoptions.areaDetailInfo.areaStatus = this.areaStatus
      this.$refs['FenceEdit'].addoptions.areaDetailInfo.deviceId = ''
      this.$refs['FenceEdit'].OrgName = ''
      this.$refs['FenceEdit'].dialogFormVisible = true
      this.$refs['FenceEdit'].deviceList = []
      // 判断是新增还是编辑状态
      this.$refs['FenceEdit'].addOrEdit = 0
    },
    // 点击查询按钮，触发事件
    querySceneList: function () {
      let that = this
      console.log(that.currentScene)
      if (this.sceneParam.sceneType === '') {
        this.$message({
          message: '请选择场景类型！',
          type: 'warning'
        })
      } else {
        getSceneList(this.sceneParam).then((res) => {
          console.log('查询场景列表')
          that.sceneList = res.data.data
        }).catch(err => {
          console.warn(err)
        })
      }
      // 直接清空列表
      this.fenceList = []
      // 当sceneId为空是直接return，不用执行后续代码
      if (this.sceneId === '') {
        return
      }
      this.sceneId = ''
      this.mapObj.getMap().setTarget(null)
    },
    // 点击重置按钮，触发事件
    resetSceneParam: function () {
      console.log('重置查询参数')
      this.sceneParam.sceneType = ''
      this.sceneParam.sceneName = ''
      // 直接清空列表
      this.sceneList = []
      this.fenceList = []
      // 当sceneId为空是直接return，不用执行后续代码
      if (this.sceneId === '') {
        return
      }
      this.sceneId = ''
      this.mapObj.getMap().setTarget(null)
    },
    // 改变场景类型
    SceneTypeChange: function () {
      let that = this
      getSceneList(this.sceneParam).then((res) => {
        console.log('查询场景列表-')
        console.log(res)
        that.sceneList = res.data.data
      }).catch(err => {
        console.warn(err)
      })
      // 直接清空列表
      this.fenceList = []
      // 当sceneId为空是直接return，不用执行后续代码
      if (this.sceneId === '') {
        return
      }
      this.sceneId = ''
      this.mapObj.getMap().setTarget(null)
    },
    // 显示围栏方法
    showMap: function (fenceListItem, $event) {
      let data = {}
      data.areaId = fenceListItem.id
      getAreaInfo(data).then(res => {
        let aitem = res.data.data
        let arr = []
        arr.push(aitem)
        let newarr = formatArea(arr)
        console.log(newarr[0])
        let lineStyle = { color: '#ff0033', width: 2 }
        let optionLine = {
          id: newarr[0].id,
          name: newarr[0].areaName,
          lineType: newarr[0].areaType,
          borderPoints: newarr[0].borderPoints[0]
        }
        console.log(optionLine)
        this.mapObj.addLine(optionLine, lineStyle)
        let centerPoint = hdmap.utils.getWarningPosition(optionLine)
        console.log(centerPoint)
        this.mapObj.popupDefault(centerPoint, aitem.areaName)
        this.mapObj.setCenter(centerPoint)
      }).catch(err => {
        console.warn(err)
      })
    },
    // 隐藏围栏方法
    hideMap: function (fenceListItem, $event) {
      let data = {}
      data.areaId = fenceListItem.id
      getAreaInfo(data).then(res => {
        let aitem = res.data.data
        let arr = []
        arr.push(aitem)
        let newarr = formatArea(arr)
        console.log(newarr[0])
        let optionLine = {
          id: newarr[0].id,
          name: newarr[0].areaName,
          lineType: newarr[0].areaType,
          borderPoints: newarr[0].borderPoints[0]
        }
        console.log(optionLine)
        this.mapObj.removeLine(optionLine)
        this.mapObj.closePopup()
      }).catch(err => {
        console.warn(err)
      })
    },
    // 显示围栏列表方法
    searchFenceList: function () {
      let params = {}
      params.sceneId = this.sceneId
      params.areaType = this.areaType
      getAreaList(params).then(res => {
        this.fenceList = res.data.data
        console.log(res.data.data)
      }).catch(err => {
        console.warn(err)
      })
    },
    // 删除围栏方法
    delArea: function (fenceListItem, $event) {
      let obj = { areaIds: [] }
      obj.areaIds.push(fenceListItem.id)
      console.log(obj)
      this.$confirm('确定要刪除该电子围栏吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
        dangerouslyUseHTMLString: true
      }).then(() => {
        // 调用隐藏围栏方法
        this.hideMap(fenceListItem, $event)
        // 删除围栏
        deleteArea(obj).then(res => {
          if (res.status === 200) {
            // 更新围栏列表
            this.searchFenceList()
            this.$message({
              message: '恭喜你，数据删除成功',
              type: 'success'
            })
          }
        }).catch(err => {
          console.warn(err)
        })
      })
    },
    editArea: function (fenceListItem, $event) {
      this.$refs['FenceEdit'].dialogFormVisible = true
      // 判断是新增还是编辑状态
      this.$refs['FenceEdit'].addOrEdit = 1
      this.$refs['FenceEdit'].addoptions.areaType = this.areaType
      this.$refs['FenceEdit'].OrgName = ''
      this.$refs['FenceEdit'].deviceList = []
      this.$refs['FenceEdit'].addoptions.areaDetailInfo.deviceId = ''
      let data = {}
      data.areaId = fenceListItem.id
      getAreaInfo(data).then(res => {
        console.log(res.data.data)
        this.$refs['FenceEdit'].addoptions.areaName = res.data.data.areaName
        this.$refs['FenceEdit'].addoptions.areaId = res.data.data.id
      }).catch(err => {
        console.warn(err)
      })
    },
    searchDevice: function () {
      getDeviceInfo({ deviceId: this.deviceId }).then(res => {
        console.log(res.data.data)
        this.deviceName = res.data.data.deviceName
      }).catch(err => {
        console.warn(err)
      })
    }
  },
  mounted: function () {
    // 初始化弹框隐藏
    this.$refs['FenceEdit'].dialogFormVisible = false
    getDictionary().then((res) => {
      console.log('字典获取')
      // 选取场景类型sceneType.itemCode为1,2的电子围栏
      let list = res.data.data.dictCodeType.sceneType
      let arr = []
      for (let i = 0; i < list.length; i++) {
        if (list[i].itemCode === '1' || list[i].itemCode === '2') {
          arr.push(list[i])
        }
      }
      this.SceneTypes = arr
    }).catch(err => {
      console.warn(err)
    })
  }
}
</script>
<<style lang="less" scoped>
* {
  box-sizing:border-box;
}
/*公共样式start*/
@origin: 10px;
.pull-left {
  float: left;
}
.pull-right {
  float: right;
}
.row-flow {
  width: 100%;
}
.clearfix {
  clear: both;
}
.common-input {
  width: @origin*28;
}
.map-app {
  box-sizing: border-box;
  position: absolute;
  top: 90px;
  bottom: 20px;
  left: 225px;
  right: 20px;
}
.filter-tree{
  overflow-x: hidden;
  overflow-y: scroll;
  max-height: 300px
}
/*公共样式end*/
div {
  box-sizing: border-box;
}
.map-app {
  display: flex;
  flex-direction: column; /* 头、中部、脚纵向显示 */
  border: 1px solid #cccccc;
  min-width: 1000px;
  .main {
    display: flex;
    flex: 1;
    .content-center {
      border-left: 1px solid #cccccc;
      border-right: 1px solid #cccccc;
      height: 100%;
      flex: 1;
      position: relative;
      min-width: 400px;
      overflow: hidden;
      .button-group {
        margin: 20px;
      }
      #mapDiv {
        width: 100%;
        height: 800px;
      }
    }
    .content-left {
      order: -1;
    }
    .content-left {
      display: flex;
      flex-direction: column;
      height: 100%;
      width:350px;
      .search-form {
        overflow: hidden;
        padding: @origin 0;
        .common-input {
          margin: 15px auto;
        }
        .search-toolbar {
          margin-top: 20px;
          padding: 5px 15px 5px 0;
          width: 100%;
          height: 40px;
          text-align: right;
          .search-btn {
            height: 30px;
            width: 30%;
            padding: @origin*.7 @origin*1.5;
          }
        }
      }
      .list-area {
        height: 250px;
        .data-list {
          border-bottom: solid 1px #aaa;
          box-sizing: border-box;
          padding: 15px;
          width: 100%;
          height: 100%;
          line-height: 30px;
          overflow-y: auto;
          overflow-x: hidden;
          .list-item {
            list-style: none;
            padding: 0px 30px;
            text-align: left;
            border-bottom: solid 1px #aaa;
            width: 300px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            cursor: pointer;
          }
          .sceneItem {
            height: 40px;
            line-height: 40px;
          }
          .active {
            color: white;
            background: rgba(34, 156, 255, 1);
          }
        }
      }
      .list-fence {
        ul {
          height:350px;
          overflow-y: auto;
          padding-left:20px;
          padding-right:20px;
          li {
            border-bottom: solid 1px #aaa;
            margin-top:10px;
            padding-top:5px;
            padding-bottom:5px;
            overflow: hidden;
          }
          .fence-list {
            overflow: hidden;
          }
          .fence-name {
            float:left;
            width:140px;
            overflow: hidden;
            text-overflow:ellipsis;
            white-space: nowrap;
          }
          .fence-edit {
            margin-top:-2px;
            float:right;
          }
          .device-list {
             overflow: hidden;
            .el-button {
              float:left;
            }
            p {
              margin-top:5px;
              float:right;
              width:200px;
              overflow: hidden;
              text-overflow:ellipsis;
              white-space: nowrap;
            }
          }
        }  
      }
    }
    .search-sence-area {
      flex: 0 0 200px;
      border-bottom: 1px solid #ccc;
    }
  }
}
</style>

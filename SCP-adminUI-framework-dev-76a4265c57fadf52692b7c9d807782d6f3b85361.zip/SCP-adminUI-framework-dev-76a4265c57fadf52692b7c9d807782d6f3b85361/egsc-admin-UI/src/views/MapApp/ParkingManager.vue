<template>
  <div class="map-app">
    <div class="row-flow main">
      <div class="content-center">
        <div class="top">
          <el-button type="primary" @click="pedit">编辑</el-button>
          <el-button type="primary" @click="pdel">删除</el-button>
          <el-button type="primary" @click="pfinish">完成</el-button>
          <el-button type="primary" @click="editclose">取消编辑</el-button>
          <el-button type="primary" @click="edittest">更新测试</el-button>
        </div>
        <div id="mapDiv" @drop="drop($event)" @dragover="allowDrop($event)"></div>
      </div>
      <div class="content-left">
        <form action="" class="form">
          <div class="row">
            <span class="bt">车场类型</span>
            <el-select @change="areaTypeCheck()" v-model="parkAreaType" clearable placeholder="请选择">
              <el-option v-for="item in parkAreaTypes" :value="item.itemCode" :label="item.itemName" :key="item.id">{{ item.itemName }}</el-option>
            </el-select>
          </div>
          <div class="row">
            <span class="bt">车场名称</span>
            <el-input placeholder="请输入内容" v-model="parkAreaName"></el-input>
          </div>
          <div class="row">
            <el-button type="primary" @click="areaTypeCheck()">查询</el-button>
            <el-button type="primary" native-type="reset">重置</el-button>
          </div>
        </form>
        <div class="llist">
          <span v-for="(item, $index) in llist_data" :key="item.id" @click="parkSceneSelect(item, $index)" :class="{'cur':item.cur}">{{ item.sceneName }}</span>
        </div>
      </div>
      <div class="content-right">
        <form action="" class="form">
          <div class="row">
            <span class="bt">所属组织</span>
            <el-popover ref="orgPopover" placement="bottom">
              <el-tree class="filter-tree" :data="OrgTree" @node-click="handleNodeClick" :props="defaultProps" ref="tree" default-expand-all></el-tree>
            </el-popover>
            <el-input v-model="orga.name" placeholder="请输入内容" v-popover:orgPopover trigger="focus"></el-input>
          </div>
          <div class="row">
            <el-button type="primary" @click="cwcheck()">查询</el-button>
            <el-button type="primary" native-type="reset">重置</el-button>
          </div>
        </form>
        <div class="rlist">
          <span draggable="true" @dragstart="drag($event, item)" v-for="item in rlist_data" :key="item.carportCode" @click="cwclick(item)">{{ item.carportCode }}</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { getOrgTree, getDictionary, getSceneList, getSceneInfo, getParkList, addArea, getAreaList, getAreaInfo, updateArea, deleteArea } from '@/views/MapApp/apis/index.js'
import { mapOptionFormat, extendObj } from '@/views/MapApp/assets/js/index.js'
import hdmap from 'hdmap'
// import { formatArea } from '@/views/MapApp/assets/js/utils.js'
// import { mapOptionFormat, extendObj, markerListFormat, featureToMarker } from '@/views/MapApp/assets/js/index.js'
// import { getImgByType } from '@/views/MapApp/assets/js/ImageManager.js'
// import camerm from '@/views/MapApp/assets/images/camerm.png'
// import radio from '@/views/MapApp/assets/images/radio.png'
// $vue 后面用于保存vue实例的this
// let $vue = null
export default {
  data () {
    return {
      defaultProps: {
        children: 'children',
        label: 'name'
      },
      parkAreaTypes: [],
      rlist_data: [],
      parkAreaType: '5',
      parkAreaName: '',
      orga: {},
      llist_data: [],
      OrgTree: [],
      dragObj: {},
      mapLink: '',
      mapObj: null,
      curSceneId: '',
      addOrEdit: 0,  // 1是添加，0是编辑
      cacheMapList: [],
      parkIdarr: [],
      curEditareas: [],
      selectCarList: ''
    }
  },
  methods: {
    // mapClick: function () {
    //   this.mapObj.regEventListener
    // },
    edittest: function () {
      // alert('edittest')
      var data = { areaId: '624172774f404f8c9f0314add0c869cf' }
      getAreaInfo(data).then(res => {
        // console.log(res.data.data.areaDetailInfo.borderJson.rotate)
        var newarr = [[
          [-73.3203125, -111.875],
          [-33.3203125, -111.875],
          [-33.3203125, -191.875],
          [-73.3203125, -191.875],
          [-73.3203125, -111.875]
        ]]
        var obj = res.data.data
        obj.areaDetailInfo.borderJson.borderPoints = newarr
        obj.areaId = obj.id
        updateArea(obj).then(res => {
          console.log('update success')
          console.log(res)
        }).catch(e => {
          console.log('update fail')
          console.warn(e)
        })
      })

      // var data = {'areaIds': ['18c91c2f1bd24303af79edcb8832c72f']}
      // deleteArea(data).then(res => {
      //   console.log(res)
      // })
    },
    cwclick: function (item) {
      var deviceId = item.carportCode
      let marker = this.mapObj.getMarkerBylayerKey(deviceId, 'commonLayer')
      console.log(marker)
    },
    editclose: function () {
      this.mapObj.closeDrawShapeTool()
      this.mapObj.clearDrawShape()
      this.mapObj.unRegEventListener('singleclick')
      this.selectCarList.length = 0
    },
    createMap: function (option) {
      // console.log('666666')
      this.areaSceneInfo = option
      // let _this = this
      console.log('business init map')
      console.log('创建地图的option')
      console.log(option)
      // 获取小区真实地图图片
      let mapImageUrl = option.url
      console.log(mapImageUrl)
      if (this.mapObj) {
        // this.mapObj.clearMap(this.sceneList)
        this.mapObj.getMap().setTarget(null)
      }
      // 已经初始化的地图可以直接获取地图对象，进行地图的替换即可
      console.log('cacheMapList: ' + option.id)
      console.log(this.cacheMapList)
      console.log(this.cacheMapList[option.id])
      if (this.cacheMapList[option.id]) {
        this.mapObj = this.cacheMapList[option.id]
        this.mapObj.getMap().setTarget('mapDiv')
        return
      }
      // 如果没有初始化过，才需要进行地图的初始化
      let formatedOption = mapOptionFormat(option)
      let mapOption = extendObj(formatedOption, {
        gisEngine: 'bitmap',
        domId: 'mapDiv',
        mapUrl: mapImageUrl,
        sizeW: 1920,
        sizeH: 1080,
        maxZoom: 10,
        minZoom: 1,
        center: [112.334403, 39.8],
        popupDom: {
          popup: 'popup',
          popupcloser: 'popup-closer',
          popupcontent: 'popup-content'
        }
      })
      // eslint-disable-next-line
      this.cacheMapList[option.id] = new hdmap.initMap(mapOption)
      this.mapObj = this.cacheMapList[option.id]
      this.mapObj.getMap().setTarget('mapDiv')
    },
    cwcheck: function () {
      // console.log(this.orga)
      var data = { 'orgId': this.orga.uuid }
      var _this = this
      getParkList(data).then(res => {
        _this.rlist_data = res.data.data
      })
    },
    pedit: function () {
      let that = this
      // alert('here is pedit')
      // console.log('here is the pedit')
      var len = this.curEditareas.length
      for (var j = 0; j < len; j++) {
        this.mapObj.editDrawShape(this.curEditareas[j], function (e) {
          console.log('当前选中对象：')
          console.log(e.feature.extProperties)
          that.selectCarList = e.feature.extProperties.originId
        })
      }
      // var len = this.curEditareas.length
      // for (var j = 0; j < len; j++) {
      //   this.mapObj.updateArea(this.curEditareas[j], function (e) {
      //     console.log('select feature')
      //     console.log(e)
      //   })
      // }
      // this.mapObj.regEventListener('singleclick', function (e) {
      //   // console.log('single click ')
      //   // console.log(e)
      //   if (e.feature) {
      //     // that.selectCarList.push(e.feature.originId)
      //     console.log('Current selected carpot')
      //     console.log(e.feature)
      //     that.mapObj.editDrawShape(e.feature, function (e) {
      //       console.log('当前选中的停车位对象 : ')
      //       console.log(e.feature.extProperties)
      //     })
      //   }
      // })
    },
    pdel: function () {
      let that = this
      // alert('here is pdel')
      console.log('here is the pdel')
      // 获取到当前区域的id
      // console.log(this.selectCarList)
      let deleteCarIdList = []
      deleteCarIdList.push(this.selectCarList)
      console.log('Here is selectCarList')
      console.log(that.selectCarList)
      console.log('Here is curEditareas')
      console.log(that.curEditareas)
      deleteArea({areaIds: deleteCarIdList}).then(res => {
        console.log('delete success')
        for (let i = 0; i < that.curEditareas.length; i++) {
          if (that.selectCarList === that.curEditareas[i].originId) {
            that.mapObj.removeArea(that.curEditareas[i])
            that.mapObj.removeMarkerBylayerKey(that.curEditareas[i].id, 'drawShapeLayer')
          }
        }
        that.$message({
          message: '删除成功',
          type: 'success'
        })
        this.selectCarList = ''
        this.mapObj.closeDrawShapeTool()
        this.mapObj.clearDrawShape()
        var sceneId = this.curSceneId
        var data = {sceneId: sceneId}
        this.mapFresh(data)
      }).catch(e => {
        console.log('delete fail')
        console.warn(e)
        that.$message({
          message: '删除失败',
          type: 'warning'
        })
      })
    },
    pfinish: function () {
      let that = this
      var featArr = this.mapObj.showDrawShape()
      console.log(featArr)
      var len = featArr.length
      var arr = []
      for (var i = 0; i < len; i++) {
        var _Coordinates = featArr[i].getGeometry().getCoordinates()
        var _rotate = featArr[i].getRotate()
        var _center = hdmap.utils.getGeometryCenter(_Coordinates[0])
        var addobj = {
          areaId: featArr[i].extProperties.originId,
          sceneId: this.curSceneId,
          areaType: 7,
          areaName: featArr[i].extProperties.areaName,
          areaDetailInfo: {
            deviceId: featArr[i].extProperties.areaName,
            borderJson: {
              borderPoints: _Coordinates,
              rotate: _rotate,
              center: _center
            }
          }
        }
        arr.push(addobj)
      }
      // this.selectCarList.length = 0
      for (let l = 0; l < len; l++) {
        that.mapObj.removeArea(featArr[l].extProperties)
      }
      // this.mapObj.unRegEventListener('singleclick')
      // this.mapObj.closeDrawShapeTool()
      console.log(arr)
      for (let m = 0; m < len; m++) {
        updateArea(arr[m]).then(res => {
          console.log('update success')
          console.log(res)
        }).catch(e => {
          console.log('update fail')
          console.warn(e)
        })
      }
      // 开始去获取地图
      let sceneId = this.curSceneId
      setTimeout(function () {
        let data = { 'sceneId': sceneId }
        that.mapFresh(data)
      }, 500)
    },
    areaTypeCheck: function () {
      var sceneType = this.parkAreaType
      var sceneName = this.parkAreaName
      if (!sceneType) {
        this.$message({
          message: '请选择场景类型',
          type: 'warning'
        })
      }
      var data = { 'sceneType': sceneType, 'sceneName': sceneName }
      getSceneList(data).then((res) => {
        if (res.data.code === '00000') {
          var listdata = res.data.data
          var len = listdata.length
          for (var i = 0; i < len; i++) {
            listdata[i].cur = 0
          }
        }
        this.llist_data = listdata
      }).catch(e => {
        console.warn(e)
      })
    },
    parkSceneSelect: function (item, $index) {
      var len = this.llist_data.length
      for (var i = 0; i < len; i++) {
        if (i === $index) {
          this.llist_data[i].cur = 1
        } else {
          this.llist_data[i].cur = 0
        }
      }
      var sceneId = item.id
      this.curSceneId = sceneId

      // 开始去获取地图
      var data = { 'sceneId': sceneId }
      this.mapFresh(data)
    },
    mapFresh: function (data) {
      getSceneInfo(data).then(res => {
        if (res.data.data) {
          this.createMap(res.data.data)
          var sdata = { sceneId: data.sceneId, areaType: 7 }
          getAreaList(sdata).then(res => {
            var aarr = res.data.data
            console.log(aarr)
            var len = aarr.length
            var areas = []
            for (var k = 0; k < len; k++) {
              var obj = {}
              obj.originId = aarr[k].id
              obj.id = aarr[k].areaDetailInfo.deviceId
              obj.borderPoints = aarr[k].areaDetailInfo.borderJson.borderPoints
              obj.areaName = aarr[k].areaName
              obj.areaType = aarr[k].areaType
              obj.areaTypesOf = 'parking'
              obj.visible = true
              areas.push(obj)
            }
            this.curEditareas = areas
            var styleObj = { 'fillColor': 'orange', 'strokeColor': 'red', 'strokeWidth': '2' }
            var llen = areas.length
            for (var i = 0; i < llen; i++) {
              this.mapObj.addArea(areas[i], styleObj)
              // this.mapObj.updateArea(areas[i], hdmap.commonConfig.getMouseOverAreaStyle(styleObj))
            }
            // this.pedit()
          })
        } else {
          console.log('场景信息为空')
        }
      })
    },
    drag: function ($event, item) {
      // console.log(item.name + ' --- ' + item.id)
      this.dragObj = item
      this.parkIdarr.push(item.carportCode)
    },
    drop: function ($event) {
      console.log(this.mapObj)
      var re = this.dragObj
      console.log(re)
      // console.log('X坐标 : ' + $event.offsetX)
      // console.log('Y坐标 : ' + $event.offsetY)
      let coordinate = this.mapObj.getMap().getEventCoordinate($event)
      console.log('地图的坐标')
      console.log(coordinate)
      // [34.130859375, 75.9375]
      // debugger
      var res = hdmap.utils.getParkingCoordinates(coordinate)
      // console.log(res)
      let obj = {
        originId: '',
        id: re.carportCode,
        name: re.carportCode,
        areaType: '7',
        borderPoints: res,
        areaTypeOf: 'parking'
      }
      this.mapObj.editDrawShape(obj)
      var featArr = this.mapObj.showDrawShape()
      var len = featArr.length
      var _Coordinates = featArr[len - 1].getGeometry().getCoordinates()
      var _rotate = featArr[len - 1].getRotate()
      var _center = hdmap.utils.getGeometryCenter(_Coordinates[0])
      var addobj = {
        sceneId: this.curSceneId,
        areaType: 7,
        areaName: re.carportCode,
        areaDetailInfo: {
          deviceId: re.carportCode,
          borderJson: {
            borderPoints: _Coordinates,
            rotate: _rotate,
            center: _center
          }
        }
      }
      var that = this
      addArea(addobj).then(res => {
        console.log('打印添加的结果')
        console.log(res)
        // let feature = this.mapObj.getMarkerBylayerKey(obj.id, 'gisLayer')
        // console.log(feature)
        var data = { sceneId: that.curSceneId }
        this.mapFresh(data)
      }).catch(e => {
        console.log('add fail')
        // TODO remove此区域
        var data = { sceneId: that.curSceneId }
        this.mapFresh(data)
      })
    },
    allowDrop: function ($event) {
      $event.preventDefault()
    },
    handleNodeClick: function (data) {
      this.orga = data
      this.$refs.orgPopover.doClose()
    }
  },
  mounted: function () {
    this.areaTypeCheck()
    getOrgTree().then((res) => {
      this.OrgTree = res.data.data.children
      // console.log(this.OrgTree)
    }).catch(e => {
      console.warn(e)
    })

    getDictionary().then((res) => {
      // 选取场景类型为停车场的 4,5
      var list = res.data.data.dictCodeType.sceneType
      var len = list.length
      var arr = []
      for (var i = 0; i < len; i++) {
        if (list[i].itemCode === '4' || list[i].itemCode === '5') {
          arr.push(list[i])
        }
      }
      this.parkAreaTypes = arr
    }).catch(e => {
      console.warn(e)
    })

    var data = { orgId: 'c69aeede4f6341929721e2892beec3cb' }
    getParkList(data).then(res => {
      // console.log(res.data.data)
      this.rlist_data = res.data.data
    }).catch(e => {
      console.warn(e)
    })
  }
}
</script>
<style lang="less" scoped>
/*MapApp.less公共样式start*/
@origin: 10px;
.pull-left {
  float: left;
}
.pull-right {
  float: right;
}
.row-flow {
  width: 100%;
}
.clearfix {
  clear: both;
}
.common-input {
  width: @origin*28;
}
.map-app {
  box-sizing: border-box;
  position: absolute;
  top: 90px;
  bottom: 20px;
  left: 225px;
  right: 20px;
}
.filter-tree{
  overflow-x: hidden;
  overflow-y: scroll;
  max-height: 300px
}
/*MapApp.less公共样式end*/
div {
  box-sizing: border-box;
}
.map-app {
  display: flex;
  flex-direction: column; /* 头、中部、脚纵向显示 */
  border: 1px solid #cccccc;
  min-width: 1000px;
  .header,
  .footer {
    flex: 0 0 50px;
    text-align: center;
    padding: 5px 0;
    // /* background: #3f3f3f; */
  }
  .footer {
    border-top: 1px solid #cccccc;
  }
  .main {
    display: flex;
    flex: 1;
    .content-center {
      border-left: 1px solid #cccccc;
      border-right: 1px solid #cccccc;
      /* background: red; */
      height: 100%;
      flex: 1;
      position: relative;
      min-width: 400px;
      overflow: hidden;
      .top {
        width: 100%;
        height: 40px;
        margin-top: 20px;
        background: none;
        padding-left: 40px;
      }
      #mapDiv {
        width: 96%;
        height: 720px;
        margin: 25px auto;
        background: white;
      }
    }
    .content-left {
      order: -1;
    }
    .content-right,
    .content-left {
      display: flex;
      flex-direction: column;
      height: 100%;
      flex: 0 0 300px;
      .form {
        width: 100%;
        height: 200px;
        border-bottom: 1px solid #ccc;
        overflow: hidden;
        .row {
          width: 100%;
          height: 40px;
          margin-top: 20px;
          background: none;
          text-align: center;
          .el-input,
          .el-select {
            width: 70%;
          }
            display: inline-block;
          .bt {
            width: auto;
            height: 40px;
            line-height: 40px;
            font-size: 14px;
            color: #666;
            margin-right: 5px;
          }
        }
      }
    }
    .content-left .llist,
    .content-right .rlist {
      width: 90%;
      height: 600px;
      background: none;
      margin: 15px auto;
      overflow-y: scroll;
    }
    .content-left .llist span,
    .content-right .rlist span {
      display: block;
      height: 40px;
      line-height: 40px;
      text-decoration: none;
      font-size: 14px;
      color: #666;
      border-bottom: 1px solid #ccc;
      text-indent: 10px;
      cursor: pointer;
    }
    .content-left .llist span:hover,
    .content-right .rlist span:hover {
      background: #3098ef;
      color: #fff;
    }
    .content-left .llist span.cur {
      background: #3098ef;
      color: #fff;
    }
  }
}
</style>
// 引用pages
import carMgmt from '@/views/ParkingLotApp/components/CarMgmt'
import ruleMgmt from '@/views/ParkingLotApp/components/RuleMgmt'
import parkMgmt from '@/views/ParkingLotApp/components/ParkMgmt'
import parkSeatMgmt from '@/views/ParkingLotApp/components/ParkSeatMgmt'
import parkAuthMgmt from '@/views/ParkingLotApp/components/AuthMgmt'
import feeMgmt from '@/views/ParkingLotApp/components/FeeMgmt'
import inoutControl from '@/views/ParkingLotApp/components/InoutControl'
import carInRecord from '@/views/ParkingLotApp/components/CarInRecord'
import outRecord from '@/views/ParkingLotApp/components/OutRecord'
import parkSysSet from '@/views/ParkingLotApp/components/ParkSystem'
import shortParkCard from '@/views/ParkingLotApp/components/ShortParkCard'
import payRecord from '@/views/ParkingLotApp/components/PayRecord'

// 定义路由路径数组列表
export default[
  {
    path: '/carMgmt',
    name: 'carMgmt',
    component: carMgmt
  },
  {
    path: '/ruleMgmt',
    name: 'ruleMgmt',
    component: ruleMgmt
  },
  {
    path: '/parkMgmt',
    name: 'parkMgmt',
    component: parkMgmt
  },
  {
    path: '/parkSeatMgmt',
    name: 'parkSeatMgmt',
    component: parkSeatMgmt
  },
  {
    path: '/parkAuthMgmt',
    name: 'parkAuthMgmt',
    component: parkAuthMgmt
  },
  {
    path: '/feeMgmt',
    name: 'feeMgmt',
    component: feeMgmt
  },
  {
    path: '/inoutControl',
    name: 'inoutControl',
    component: inoutControl
  },
  {
    path: '/carInRecord',
    name: 'carInRecord',
    component: carInRecord
  },
  {
    path: '/outRecord',
    name: 'outRecord',
    component: outRecord
  },
  {
    path: '/parkSysSet',
    name: 'parkSysSet',
    component: parkSysSet
  },
  {
    path: '/shortParkCard',
    name: 'shortParkCard',
    component: shortParkCard
  },
  {
    path: '/payRecord',
    name: 'payRecord',
    component: payRecord
  }
]

<template>
  <div class="inoutControl" style="hight:1000px">
    <section>
      <el-form :inline="true">
        <el-form-item label="">
          <el-input placeholder="请输入车牌号|卡号" v-model="queryCarNum" ></el-input>
        </el-form-item>
        
        <el-form-item>
          <el-button type="primary" @click="queryByNum">查询</el-button>
        </el-form-item>
      </el-form>
    </section>
    <section class="inout-cont">
      <el-table :data="inoutData" border style="width: 100%" highlight-current-row @current-change="handleCurrentChange">
        <el-table-column type="index" width="60" label="序号"></el-table-column>
        <el-table-column prop="parkLotName" label="停车场名称" v-model="inoutData.parkLotName"></el-table-column>
        <el-table-column prop="carNum" label="车牌号码"></el-table-column>
        <el-table-column prop="cardNumber" label="卡号"></el-table-column>
        <el-table-column prop="ownerName" label="业主姓名"></el-table-column>
        <el-table-column prop="packageName" label="规则名称"></el-table-column>
        <el-table-column prop="inTime" label="入场时间"  width="180"></el-table-column>
        <el-table-column prop="channelName" label="入场通道"></el-table-column>
        <el-table-column prop="inImgUrl" label="入场图片">
          <template slot-scope="scope">
            <el-button size="mini" type="primary" @click="handleCheck(scope.$index, scope.row)">查看图片</el-button>
          </template>
        </el-table-column>
        <el-table-column prop="remark" label="备注"></el-table-column>
      </el-table>
      <el-col class="toolbar">
        <el-pagination :current-page="currentPage" :page-sizes="[10, 20, 50, 100]" :page-size="10" background layout="total, sizes, prev, pager, next, jumper" :total="total">
        </el-pagination>
      </el-col>
      <!--<div class="toolbar">
        <el-button @click="$parent.$parent.dialogVisibleExcep = false">取消</el-button>
        <el-button type="primary" @click="greenLight">放行</el-button>
      </div>-->
    </section>
    <el-dialog :visible.sync="dialogImgVisible" title="查看图片" append-to-body>
      <div class="check-img"><img :src="imgUrl"/></div>
      <div style="text-align:center;width:100%">
        <el-button @click="dialogImgVisible = false">关闭</el-button>
      </div>
    </el-dialog>

    <el-dialog :visible.sync="dialogGreenLightVisible" title="场内车辆" append-to-body>
      
    </el-dialog>
  </div>
</template>
<script>
import {
  queryParkInVehicle
} from '@/views/ParkingLotApp/apis'
export default {
  data () {
    return {
      queryCarNum: '',
      queryOwnerName: '',
      dialogImgVisible: false,
      dialogGreenLightVisible: false,
      currentPage: 1,
      total: 10,
      pageSize: '10',
      inoutData: [],
      currentRow: '',
      imgUrl: '',
      artRelForm: {

      }
    }
  },
  props: ['CarInRecord'],
  mounted () {
    this.loadData()
  },
  methods: {
    loadData () {
      var _this = this
      queryParkInVehicle(_this.currentPage, _this.pageSize, '')
        .then(function (response) {
          if (response.code === '0') {
            _this.inoutData = response.data.rows
            _this.total = response.data.total
          }
        })
        .catch(
          function (error) {
            this.loading2 = false
            console.log(error)
          }.bind(this)
        )
    },
    artificRel () {
      this.dialogVisible = true
    },
    handleCheck (index, row) {
      this.imgUrl = row.inImgUrl
      this.dialogImgVisible = true
    },
    handleCurrentChange (val) {
      var _this = this
      _this.currentRow = val
    },
    greenLight () {
      console.log('currentRow' + JSON.stringify(this.currentRow))
      // _this.dialogGreenLightVisible = true
      if (this.currentRow === '') {
        this.$message('还没有选择放行车辆')
      } else {
        this.dialogGreenLightVisible = true
      }
    },
    queryByNum () {
      var _this = this
      var key = _this.queryCarNum
      queryParkInVehicle(_this.currentPage, _this.pageSize, key)
        .then(function (response) {
          if (response.code === '0') {
            _this.inoutData = response.data.rows
            _this.total = response.data.total
          }
        })
        .catch(
          function (error) {
            this.loading2 = false
            console.log(error)
          }.bind(this)
        )
    }
  }
}
</script>
<style lang="less" scoped>
.inout-cont {
  margin-top:20px;
}
.toolbar{
  text-align: right;
  margin-top: 20px;
  float:none;
}
.check-img{
  padding: 15px;
  img{
    max-width: 100%;
  }
}
</style>




<template>
  <div class="outRecord">
    <section class="record-main">
      <el-date-picker v-model="queryTime" value-format="yyyy-MM-dd HH:mm:ss" type="datetimerange" align="right" unlink-panels range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期" 
      :picker-options="pickerOptions">
      </el-date-picker>
      <el-form :inline="true">
        <el-form-item label="">
          <el-input placeholder="请输入车牌号|卡号" v-model="queryCarNum" ></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="queryByNum">查询</el-button>
        </el-form-item>
      </el-form>
    </section>
    <section class="inout-cont">
      <el-table :data="inoutData" border style="width: 100%" max-height="700" v-loading="loading">
        <el-table-column type="index" width="60" label="序号"></el-table-column>
        <el-table-column prop="parkName" label="停车场名称"></el-table-column>
        <el-table-column prop="carNum" label="车牌号码"></el-table-column>
        <el-table-column prop="cardNumber" label="卡号"></el-table-column>
        <el-table-column prop="ownerName" label="业主姓名"></el-table-column>
        <el-table-column prop="ruleName" label="规则名称"></el-table-column>
        <el-table-column prop="inTime" label="入场时间" width="180"></el-table-column>
        <el-table-column prop="parkInChannelName" label="入场通道"></el-table-column>
        <el-table-column prop="outTime" label="出场时间" width="180"></el-table-column>
        <el-table-column prop="parkOutChannelName" label="出场通道"></el-table-column>
        <el-table-column prop="stopTime" label="停车时长"></el-table-column>
        <el-table-column prop="payedMoney" label="缴费金额"></el-table-column>
        <el-table-column prop="inImgUrl" label="入场图片">
          <template slot-scope="scope">
            <el-button size="mini" type="primary" @click="handleCheck(scope.$index, scope.row)">查看图片</el-button>
          </template>
        </el-table-column>
        <el-table-column prop="outImgUrl" label="出场图片">
          <template slot-scope="scope">
            <el-button size="mini" type="primary" @click="handleCheck(scope.$index, scope.row)">查看图片</el-button>
          </template>
        </el-table-column>
        <el-table-column prop="remark" label="备注"></el-table-column>
      </el-table>
      <el-col class="toolbar">
        <el-pagination @size-change="handleSizeChange" @current-change="findPage" :current-page="currentPage" :page-sizes="[10, 20, 50, 100]" :page-size="pageSize" background layout="total, sizes, prev, pager, next, jumper" :total="total">
        </el-pagination>
      </el-col>
    </section>
    <el-dialog :visible.sync="dialogImgVisible" title="查看图片" >
      <div class="check-img"><img src="../assets//images/img001.jpg"/></div>
      <div style="text-align:center;width:100%">
        <el-button @click="dialogImgVisible = false">关闭</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import {
  queryCarInOutRecord
} from '@/views/ParkingLotApp/apis'
export default {
  data () {
    return {
      queryCarNum: '',
      queryOwnerName: '',
      dialogImgVisible: false,
      loading: true,
      currentPage: 1,
      pageSize: 10,
      total: 10,
      inoutData: [],
      parkData: [{
        parkName: '恒大山水',
        allCount: 300,
        residueCount: 147
      }, {
        parkName: '恒大山水库',
        allCount: 500,
        residueCount: 347
      }],
      artRelForm: {

      },
      pickerOptions: {
        shortcuts: [{
          text: '最近一天',
          onClick (picker) {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 3600 * 1000 * 24)
            picker.$emit('pick', [start, end])
          }
        }, {
          text: '最近一周',
          onClick (picker) {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
            picker.$emit('pick', [start, end])
          }
        }, {
          text: '最近一个月',
          onClick (picker) {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
            picker.$emit('pick', [start, end])
          }
        }]
      },
      queryTime: ''
    }
  },
  mounted () {
    this.loadData(this.currentPage, this.pageSize, this.queryCarNum, this.queryTime)
  },
  methods: {
    loadData (currentPage, pageSize, carNum, queryType) {
      var _this = this
      queryCarInOutRecord(currentPage, pageSize, carNum, queryType)
        .then(function (response) {
          _this.loading = false
          if (response.code === '0') {
            _this.inoutData = response.data.rows
            _this.total = response.data.total
          }
        })
        .catch(
          function (error) {
            this.loading = false
            console.log(error)
          }.bind(this)
        )
    },
    queryByNum () {
      let _this = this
      let queryTime = _this.queryTime
      if (queryTime === null) {
        queryTime = ''
      }
      this.loadData(_this.currentPage, _this.pageSize, _this.queryCarNum, queryTime)
    },
    artificRel () {
      this.dialogVisible = true
    },
    handleCheck (index, row) {
      this.dialogImgVisible = true
    },
    handleSizeChange (val) {
      this.pageSize = val
      this.loadData(this.currentPage, this.pageSize, this.queryCarNum, this.queryTime)
    },
    findPage (val) {
      this.currentPage = val
      this.loadData(this.currentPage, this.pageSize, this.queryCarNum, this.queryTime)
    }
  }
}
</script>
<style lang="less" scoped>
.record-main > *{
  display:inline-block;
  vertical-align: top;
  margin-right:20px;
}
.inout-cont {
  margin-top:20px;
}
.toolbar{
  text-align: right;
  margin-top: 20px;
}
.check-img{
  padding: 15px;
  img{
    max-width: 100%;
  }
}
</style>




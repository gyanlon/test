<template>
  <div class="inoutControl">
    <section>
      <el-button type="success" @click="artificRel('in')">人工放行-进场</el-button>
      <el-button type="success" @click="artificRel('out')">人工放行-出场</el-button>
      <el-button type="success" @click="anomalyDis" ref='anomalyDis'>场内车辆</el-button>
      <el-dialog :visible.sync="dialogVisibleExcep" title="场内车辆">
        <car-in-record ref="CarInRecord" :CarInRecord = "inoutData"></car-in-record>
      </el-dialog>
    </section>
    <section class="inout-cont">
      <div class="left-cont">
        <section class="img-inout">
          <img src="../assets/images/img001.jpg">
          <img src="../assets/images/img002.jpg">
        </section>
        <section class="table-cont">
          <el-table :data="inoutData" border style="width: 100%; ">
            <el-table-column type="index" width="50"></el-table-column>
            <el-table-column prop="carNum" label="车牌号码" width="100"></el-table-column>
            <el-table-column prop="recordType" label="进出口类型" width="100" :formatter="typeFormat"></el-table-column>
            <el-table-column prop="channelName" label="出入口通道" width="180"></el-table-column>
            <el-table-column prop="ownerName" label="业主姓名" width="80"></el-table-column>
            <el-table-column prop="cardNO" label="卡号"></el-table-column>
            <el-table-column prop="inTime" label="入场时间" width="160"></el-table-column>
            <el-table-column prop="outTime" label="出场时间" width="160"></el-table-column>
            <el-table-column prop="ruleName" label="规则"></el-table-column>
            <el-table-column prop="cash" label="收费金额"></el-table-column>
            <el-table-column prop="inImg" label="入场图片">
              <template slot-scope="scope">
                <el-button size="mini" type="primary" @click="handleCheck(scope.$index, scope.row, 'in')">查看图片</el-button>
              </template>
            </el-table-column>
            <el-table-column
              prop="outImg"
              label="出场图片">
              <template slot-scope="scope">
                <el-button size="mini" type="primary" @click="handleCheck(scope.$index, scope.row, 'out')">查看图片</el-button>
              </template>
            </el-table-column>
            <el-table-column prop="remark" label="备注"></el-table-column>
            <!-- <el-table-column fixed="right" label="操作" width="140">
              <template slot-scope="scope">
                <el-button type="text" @click="handleEdit(scope.$index,scope.row)">修改</el-button>
              </template>
            </el-table-column> -->
          </el-table>
        </section>
      </div>
      <div class="right-cont">
        <article class="device-img">
          <div v-for="channel in channelData" :key="channel.id">
            <p>
              <img src="../assets/images/img003.png" v-if="channel.isOnLine === 'false'">
              <img src="../assets/images/imgOnline.png" v-else>
            </p>
            <p v-text="channel.deviceName"></p>
          </div>
        </article>
        <article class="park-right">
          <el-table :data="parkData" border style="width: 100%; ">
            <el-table-column prop="parkName" label="车场名称"></el-table-column>
            <el-table-column prop="totalParkSeat" label="总车位数"></el-table-column>
            <el-table-column prop="surplusParkSeat" label="剩余车位数"></el-table-column>
          </el-table>
        </article>
      </div>
    </section>
    <el-dialog :visible.sync="dialogCutOfVisible" class="detail-main" :title="cutOfTitle">
      <el-tabs type="border-card" v-model="tabIndexVal" @tab-click="tabChangeClick">  <!-- // v-if="isOutPark" v-show="detailForm.length > 0" -->
        <el-tab-pane v-for="(item, index) in detailForm" :key="index" :label="item.channelName" :name="item.channelId">
          <el-form ref="item" :model="item" label-width="120px">
            <div class="img-cutoff">
              <img :src="inImgUrl" />
              <img :src="outImgUrl" v-show="isOutPark" />
            </div>
            <ul>
              <li><label>车牌号或卡号</label><input v-model="item.carNum"><el-button size="small" @click="editCarNum(index)" type="primary">车牌矫正</el-button></li>
              <li class="list-inline"><label>车辆类型</label><span v-text="item.carMode" ></span></li>
              <li class="list-inline"><label>规则</label><span v-text="item.ruleName"></span></li>
              <li class="list-inline"><label>进场时间</label><span v-text="item.inTime"></span></li>
              <li class="list-inline" v-show="isOutPark"><label>出场时间</label><span v-text="item.outTime" ></span></li>
              <li v-show="isOutPark"><label>停车时长</label><span v-text="item.timeLength" ></span></li>
              <li v-show="isOutPark" ><label>应缴金额</label><span v-text="item.cash"></span>元</li>
              <li v-show="isOutPark"><label>实缴金额</label><input v-model="item.cashPrice" class="cash-price" @input="changePrice(index)" />元</li>
              <li v-show="isOutPark"><label>找零</label><span v-text="item.billChange"></span>元</li>
              <li><label>备注</label><textarea v-model="item.remark"></textarea></li>
            </ul>
            <el-form-item>
              <el-button size="small" type="primary" @click="getCutOff(index)">开 闸</el-button>
              <el-button size="small" @click="channelCutOff(index, item.channelId)">取消</el-button>
            </el-form-item>
          </el-form>
          <!-- <el-form ref="item" :model="item" label-width="120px" v-else>
            <div class="img-cutoff">
              <img :src="inImgUrl" />
            </div>
            <ul>
              <li><label>车牌号或卡号</label><input v-model="item.carNum"><el-button size="small" @click="editCarNum(index)" type="primary">车牌矫正</el-button></li>
              <li><label>规则</label><span v-text="item.ruleName"></span></li>
              <li class="list-inline"><label>进场时间</label><span v-text="item.inTime"></span></li>
              <li><label>备注</label><textarea v-model="item.remark"></textarea></li>
            </ul>
            <el-form-item>
              <el-button size="small" type="primary" @click="getCutOff(index)">开 闸</el-button>
              <el-button size="small" @click="channelCutOff(item.channelId)">取消</el-button>
            </el-form-item>
          </el-form>  -->
        </el-tab-pane>
      </el-tabs>
    </el-dialog>
    <el-dialog :visible.sync="dialogVisible" :title="artRelTitle" >
      <el-form ref="artRelForm" :model="artRelForm" :rules="formRules" label-width="120px">
        <el-form-item label="旅行类别" prop = "carType" >
          <el-select v-model="artRelForm.passType" placeholder="请选择" style="width:50%" @change="choiseStyle">
            <el-option label="非机动车" value="0"></el-option>
            <el-option label="特权免费车" value="1"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="车牌号" v-show="isPriveCar">
          <el-input v-model="artRelForm.carNum" style="width:50%"></el-input>
        </el-form-item>
        <el-form-item label="车辆类型" prop = "carType"  v-show="isPriveCar">
          <el-select v-model="artRelForm.carType" placeholder="车辆类型" style="width:50%">
            <el-option label="小车" value="0"></el-option>
            <el-option label="大车" value="1"></el-option>
            <el-option label="超大车" value="2"></el-option>
            <el-option label="摩托车" value="3"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="通道" prop="channel">
          <el-select v-model="artRelForm.channel" placeholder="通道" style="width:50%" v-if="isDirect===0">
            <el-option v-for="item in channelInOpt" :key="item.key" :label="item.label" :value="item.value"></el-option>
          </el-select>
          <el-select v-model="artRelForm.channel" placeholder="通道" style="width:50%" v-else>
            <el-option v-for="item in channelOutOpt" :key="item.key" :label="item.label" :value="item.value"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="备注">
          <el-input type="textarea" v-model="artRelForm.remark" style="width:50%"></el-input>
        </el-form-item>
        <el-form-item style="text-align:right;width:100%">
          <el-button @click="dialogVisible = false">取 消</el-button>
          <el-button type="primary" @click="saveData('artRelForm')">确认</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>
    <el-dialog :visible.sync="dialogImgVisible" title="查看图片" >
      <div class="check-img"><img :src="imgUrl"/></div>
      <div style="text-align:center;width:100%">
        <el-button @click="dialogImgVisible = false">关闭</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import CarInRecord from './CarInRecord'
import {
  queryParkAndParkSeatInfo,
  getParkDeviceByLocalIp,
  getWebSocketServerUrl,
  getArtificialRelease,
  getChannelByIp,
  getCutOffData,
  updataCarNum
} from '@/views/ParkingLotApp/apis'
export default {
  data () {
    return {
      currentPage: 1,
      total: 0,
      pageSize: '10',
      showLen: 100,
      dialogVisible: false,
      dialogVisibleExcep: false,
      dialogImgVisible: false,
      dialogCutOfVisible: false,
      isOutPark: false,
      isPriveCar: false,
      isDirect: 0,
      inoutData: [],
      parkData: [],
      channelData: [], // 通道设备
      monitDevice: [], // 监控设备
      cutOfTitle: '进场-车牌或卡号',
      artRelTitle: '人工放行-进场',
      imgUrl: 'http://img1.imgtn.bdimg.com/it/u=958008776,2557398869&fm=27&gp=0.jpg',
      inImgUrl: 'http://imgsrc.baidu.com/imgad/pic/item/c9fcc3cec3fdfc03491c31acde3f8794a4c226ba.jpg',
      outImgUrl: 'http://imgsrc.baidu.com/imgad/pic/item/c9fcc3cec3fdfc03491c31acde3f8794a4c226ba.jpg',
      detailForm: [
        // {
        //   channelName: '用户管理',
        //   name: '1'
        //   // carNum: '',
        //   // carMode: '',
        //   // ownerName: '',
        //   // ruleName: '',
        //   // remark: ''
        // }
      ],
      tabIndexVal: '',
      artRelForm: {
        carNum: '',
        passType: '',
        carType: '0',
        direct: '',
        channel: '',
        remark: ''
      },
      formRules: {
        carType: [
          { required: true, message: '请选择车辆类型', trigger: 'change' }
        ],
        channel: [
          { required: true, message: '请选择通道', trigger: 'change' }
        ]
      },
      channelInOpt: [],
      channelOutOpt: [],
      websocket: '',
      localIp: '',
      webSocketServerUrl: ''
    }
  },
  components: {
    CarInRecord
  },
  mounted () {
    var _this = this
    _this.startWebSockt()
    _this.loadData()
    _this.getChannel(0)
    _this.getChannel(1)
  },
  beforeDestroy () {
    this.websocket && this.websocket.close()
  },
  methods: {
    loadData () {
      var _this = this
      queryParkAndParkSeatInfo()
        .then(function (response) {
          _this.parkData = response.data
        })
        .catch(
          function (error) {
            this.loading2 = false
            console.log(error)
          }.bind(this)
        )
      getParkDeviceByLocalIp()
      .then(function (response) {
        if (response.code === '0') {
          for (let i = 0; i < response.data.length; i++) {
            if (response.data[i].deviceTypeCode === '3024') {
              _this.channelData.push(response.data[i])
            } else {
              _this.monitDevice.push(response.data[i])
            }
          }
        }
      })
      .catch(
        function (error) {
          this.loading2 = false
          console.log(error)
        }.bind(this)
      )
    },
    getChannel (direct) {
      let _this = this
      getChannelByIp(direct)
      .then(function (response) {
        if (response.code === '0') {
          let len = response.data.length
          if (direct === 0) {
            _this.isDirect = 0
            for (let i = 0; i < len; i++) {
              _this.channelInOpt.push({'value': response.data[i].uuid + response.data[i].direct, 'label': response.data[i].name})
            }
          } else if (direct === 1) {
            _this.isDirect = 1
            for (let i = 0; i < len; i++) {
              _this.channelOutOpt.push({'value': response.data[i].uuid + response.data[i].direct, 'label': response.data[i].name})
            }
          }
        }
      })
      .catch(
        function (error) {
          console.log(error)
        }
      )
    },
    artificRel (val) {
      if (val === 'in') {
        this.artRelTitle = '人工放行-进场'
        this.artRelForm.direct = 0
        this.isDirect = 0
      } else {
        this.artRelTitle = '人工放行-出场'
        this.artRelForm.direct = 1
        this.isDirect = 1
      }
      this.artRelForm.carNum = ''
      this.artRelForm.carType = '0'
      this.artRelForm.channel = ''
      this.artRelForm.remark = ''
      this.dialogVisible = true
      // this.getChannel(this.artRelForm.direct)
    },
    anomalyDis () {
      var _this = this
      _this.dialogVisibleExcep = true
    },
    handleCheck (index, row, type) {
      this.dialogImgVisible = true
      if (type === 'in' && row.recordInImage) {
        this.imgUrl = row.recordInImage
      }
      if (type === 'out' && row.recordOutImage) {
        this.imgUrl = row.recordOutImage
      }
    },
    saveData (formData) {
      var _this = this
      var _parmas = {
        category: _this.artRelForm.category,
        carNum: _this.artRelForm.carNum,
        carType: _this.artRelForm.carStyle,
        channelId: _this.artRelForm.channel.substr(0, _this.artRelForm.channel.length - 1),
        direct: _this.artRelForm.channel.substr(_this.artRelForm.channel.length - 1),
        remark: _this.artRelForm.remark
      }
      this.$refs[formData].validate((valid) => {
        if (valid) {
          getArtificialRelease({
            params: JSON.stringify(_parmas)
          }).then(function (response) {
            if (response.code === '0') {
              _this.$message({
                message: '人工放行成功！',
                type: 'success'
              })
            } else {
              _this.$message({
                message: '人工放行失败！',
                type: 'fail'
              })
            }
            _this.dialogVisible = false
          })
        }
      })
    },
    typeFormat (row) {
      let recordType = row.recordType
      if (recordType === 0) {
        return '出场'
      } else if (recordType === 1) {
        return '入场'
      }
    },
    startWebSockt () {
      var _this = this
      getWebSocketServerUrl()
      .then(function (response) {
        if (response.code === '0') {
          _this.webSocketServerUrl = response.data.WEB_SOCKETSERVER_URL
          _this.websocket && _this.websocket.close()
          _this.websocket = new WebSocket(_this.webSocketServerUrl)
          _this.websocket.onopen = function () {
            var message = {
              test: 'hello'
            }
            _this.websocket.send(JSON.stringify(message))
          }
          _this.websocket.onmessage = function (event) {
            let dataArr = JSON.parse(event.data)
            if (dataArr.openWay === 2) {
              _this.dialogCutOfVisible = true
              if (dataArr.recordType === 0) {
                if (dataArr.carNum !== '') {
                  _this.cutOfTitle = '进场-车牌'
                } else if (dataArr.cardNo !== '') {
                  _this.cutOfTitle = '进场-卡号'
                } else {
                  _this.cutOfTitle = '进场-无牌车'
                }
                _this.isOutPark = false
              } else if (dataArr.recordType === 1) {
                _this.isOutPark = true
                if (dataArr.carNum !== '') {
                  _this.cutOfTitle = '出场-车牌'
                } else if (dataArr.cardNo !== '') {
                  _this.cutOfTitle = '出场-卡号'
                } else {
                  _this.cutOfTitle = '出场-无牌车'
                }
              }
              _this.detailForm.push(dataArr)
              // _this.detailForm.channelName = dataArr.channelName
              // _this.detailForm.carNum = dataArr.carNum
              // _this.detailForm.carMode = dataArr.carMode
              // _this.detailForm.ownerName = dataArr.ownerName
              // _this.detailForm.ruleName = dataArr.ruleName
              // _this.detailForm.remark = dataArr.remark
              _this.tabIndexVal = dataArr.channelId
            }
            console.log(event.data)
            _this.inoutData.unshift(dataArr)
            let len = _this.inoutData.length
            if (len > _this.showLen) {
              _this.inoutData.splice(_this.showLen, 1)
            }
          }
          _this.websocket.onerror = function (event) {
            console.log(event)
          }
        }
      })
      .catch(
        function (error) {
          console.log(error)
        }
      )
    },
    handleEdit (index, row) {
      let _this = this
      _this.detailForm = row
      _this.detailForm.channelName = row.channelName
      _this.detailForm.carNum = row.carNum
      _this.detailForm.carMode = row.carMode
      _this.detailForm.ownerName = row.ownerName
      _this.detailForm.ruleName = row.ruleName
      _this.detailForm.remark = row.remark
      console.log(row)
    },
    getCutOff (index) {
      console.log('index : ' + index)
      // this.detailForm
      let _this = this
      let params_ = _this.detailForm[index]
      console.log('detailForm ' + JSON.stringify(params_))
      getCutOffData({
        params: JSON.stringify(params_)
      }).then(function (response) {
        let errorcode = response.code
        if (errorcode === '0') {
          _this.$message({
            message: '开闸',
            type: 'success'
          })
        }
      })
    },
    editCarNum (index) {
      console.log('index : ' + index)
      let _this = this
      let params_ = _this.detailForm[index]
      console.log(params_.carNum)
      console.log('detailForm ' + JSON.stringify(params_))
      updataCarNum({
        params: JSON.stringify(params_)
      }).then(function (response) {
        let errorcode = response.code
        if (errorcode === '0') {
          _this.$message({
            message: '开闸',
            type: 'success'
          })
        }
      })
    },
    choiseStyle (val) {
      if (val === '0') {
        this.isPriveCar = false
      } else if (val === '1') {
        this.isPriveCar = true
      }
    },
    channelCutOff (i, targetName) {
      if (this.detailForm.length === 1) {
        this.detailForm.splice(i, 1)
        this.dialogCutOfVisible = false
      } else {
        let tabs = this.detailForm
        let activeName = this.tabIndexVal
        if (activeName === targetName) {
          tabs.forEach((tab, index) => {
            if (tab.channelId === targetName) {
              let nextTab = tabs[index + 1] || tabs[index - 1]
              if (nextTab) {
                activeName = nextTab.channelId
              }
            }
          })
        }
        this.tabIndexVal = activeName
        this.detailForm = tabs.filter(tab => tab.name !== targetName)
        this.detailForm.splice(i, 1)
      }
    },
    tabChangeClick (tab, event) {
      let index = tab.index
      if (this.detailForm[index].recordType === 1) {
        this.isOutPark = true
        if (this.detailForm[index].carNum !== '') {
          this.cutOfTitle = '出场-车牌'
        } else if (this.detailForm[index].cardNo !== '') {
          this.cutOfTitle = '出场-卡号'
        } else {
          this.cutOfTitle = '出场-无牌车'
        }
      } else {
        this.isOutPark = false
        if (this.detailForm[index].carNum !== '') {
          this.cutOfTitle = '进场-车牌'
        } else if (this.detailForm[index].cardNo !== '') {
          this.cutOfTitle = '进场-卡号'
        } else {
          this.cutOfTitle = '进场-无牌车'
        }
      }
    },
    changePrice (index) {
      if (this.detailForm[index].cashPrice > 0) {
        this.detailForm[index].billChange = this.detailForm[index].cashPrice - this.detailForm[index].cash
      }
    }
  }
}
</script>
<style lang="less" scoped>
@border: 1px solid #dcdfe6;
.inout-cont {
  margin-top:20px;
  overflow: hidden;
  .left-cont{
    float:left;
    width:calc(~"100% - 500px");
    .img-inout{
      font-size:0;
      margin-bottom: 30px;
      height: 410px;
      overflow-y: auto;
      img{
        width:49.5%;
        display:inline-block;
        vertical-align: top;
      }
      img:first-child{
        margin-right:1%
      }
    }
    .table-cont{
      height: 360px;
      overflow-y: auto;
    }
  }
  .right-cont{
    float:right;
    width:500px;
    padding-left: 50px;
    box-sizing: border-box;
    .device-img{
      overflow: hidden;
      margin-bottom: 30px;
      div{
        float: left;
        text-align: center;
        width: 50%;
        p{
          padding: 5px;
        }
      }
    }
    .park-right{
      max-height:500px; 
      overflow-y:auto;
    }
  }
}
 .check-img{
    padding: 15px;
    text-align:center;
    img{
      max-width: 100%;
    }
  }

.detail-main{
  .img-cutoff{
    text-align: center;
    img{
      width: 200px;
      margin: 0 10px;
    }
  }
  margin-top: 20px;
  .el-tabs--border-card>.el-tabs__header .el-tabs__item{
    width: 80px;
    padding: 0 10px;
  }
  ul{
    li{
      list-style: none;
      margin-bottom: 15px;
      min-height: 21px;
      input{
        height: 30px;
        line-height: 30px;
        border: @border;
        padding-left: 10px;
        width: 120px;
        margin-right: 10px;
      }
      .cash-price{
        width: 60px;
      }
      label{
        display: inline-block;
        width: 120px;
        text-align: right;
        margin-right: 15px;
      }
      textarea{
        vertical-align: middle;
        border: @border;
      }
    }
    .list-inline{
      display: inline-block;
      width: 300px;
    }
  }
}
</style>




<template>
  <div id="ower">
    <section v-if="authData === 'car'"> 
      <el-form :inline="true">
        <el-form-item>
            <el-input placeholder="车牌号" v-model="queryValue" ref="queryValue" style="width:100%"></el-input>
        </el-form-item>
        <el-form-item>
            <el-button type="primary" @click="queryByOwer">查询</el-button>
        </el-form-item>
      </el-form>
      <el-table :data="authCarData" ref="authBaseData" highlight-current-row height="400"  @selection-change="handleCurrentChange" border style="width: 100%">
        <el-table-column type="selection" width="60"></el-table-column>
        <el-table-column type="index" label="序号" width="60"></el-table-column>
        <el-table-column prop="carNum" label="车牌号" ></el-table-column>
        <el-table-column prop="type" label="车辆类型" :formatter="typeFormat"></el-table-column>
        <el-table-column prop="remark" label="备注"></el-table-column>
      </el-table>
      <el-col class="toolbar" style="text-align:right; margin:15px 0">
        <el-pagination :current-page="currentPage"  @size-change="handleSizeChange" @current-change="findPage" :page-sizes="[10, 20, 50, 100]" :page-size="10" background layout="total, sizes, prev, pager, next" :total="carTotal">
        </el-pagination>
      </el-col>
    </section>
    <section v-else-if="authData === 'park'">
      <el-form :inline="true">
        <el-form-item>
            <el-input placeholder="输入车场名称" v-model="queryPark" ref="queryPark" style="width:100%"></el-input>
        </el-form-item>
        <el-form-item>
            <el-button  @click="queryAuthPark">查询</el-button>
        </el-form-item>
      </el-form>
      <el-tree :props="defaultProps" ref="tree" height="400" default-expand-all :data="treeData" node-key="parkingName" show-checkbox  @check-change="handleTreeChange"></el-tree>
    </section>
    <section v-else-if="authData === 'seat'">
       <el-form :inline="true">
        <el-form-item>
            <el-input placeholder="请输入车位编号" v-model="queryValue" ref="queryValue" style="width:100%"></el-input>
        </el-form-item>
        <el-form-item>
            <el-button type="primary" @click="queryByOwer">查询</el-button>
        </el-form-item>
      </el-form>
      <el-table :data="authSeatData" ref="authSeatForm" highlight-current-row  @current-change="seatCurrentChange" border style="width: 100%">
        <el-table-column type="selection" width="60"></el-table-column>
        <el-table-column type="index" label="序号" width="60"></el-table-column>
        <el-table-column prop="code" label="车位编号" ></el-table-column>
        <el-table-column prop="status" label="车位类型" ></el-table-column>
        <el-table-column prop="remark" label="备注"></el-table-column>
      </el-table>
      <el-col class="toolbar" style="text-align:right; margin:15px 0">
        <el-pagination :current-page="currentPage" :page-sizes="[10, 20, 50, 100]" :page-size="10" background layout="total, sizes, prev, pager, next" :total="seatTotal">
        </el-pagination>
      </el-col> 
    </section> 
  </div>
</template>
<script>
import {
  listcars,
  queryParkList,
  queryUnAuthParkSeat
} from '@/views/ParkingLotApp/apis'
export default {
  data () {
    return {
      authCarData: [],
      authSeatData: [],
      queryValue: '',
      queryPark: '',
      parkSeatCode: '',
      selectCar: [],
      selectCard: '',
      selectPark: [],
      selectSeat: [],
      carTotal: 0,
      currentPage: 1,
      seatTotal: 0,
      authSeatForm: {
        seatCode: ''
      },
      pageSize: 10,
      carType: -1,
      ownerId: '',
      total: 3,
      sizes: 10,
      treeData: [],
      defaultProps: {
        children: 'subParkingLots',
        label: 'parkingName'
      }
    }
  },
  props: ['authData', 'selectParkId', 'selecrFormCar', 'selectParkName', 'selectSeats'],
  mounted () {
    // alert('selectParkCode' + this.selectParkCode)
    if (this.authData === 'car') {
      this.loadCarData(this.currentPage, this.pageSize, '', this.carType)
    } else if (this.authData === 'park') {
      this.loadParkData()
    } else if (this.authData === 'seat') {
      this.loadSeatData(this.currentPage, this.pageSize, this.selectPark, this.parkSeatCode)
    }
  },
  watch: {
    authData (newValue, oldValue) {
      if (newValue === 'car') {
        this.loadCarData(this.currentPage, this.pageSize, '', this.carType)
      } else if (this.authData === 'park') {
        this.loadParkData()
      } else if (this.authData === 'seat') {
        this.loadSeatData(this.currentPage, this.pageSize, this.selectPark, this.parkSeatCode)
      }
    },
    selecrFormCar (newValue, oldValue) {
      this.loadCarData(this.currentPage, this.pageSize, '', this.carType)
    },
    selectParkName (newValue, oldValue) {
      this.loadParkData()
    },
    selectSeats (newValue, oldValue) {
      this.loadSeatData(this.currentPage, this.pageSize, this.selectPark, this.parkSeatCode)
    }
  },
  methods: {
    queryByOwer () {

    },
    queryAuthPark () {

    },
    loadCarData (currentPage, pageSize, carNum, status) {
      let _this = this
      listcars(currentPage, pageSize, carNum, status)
        .then(function (response) {
          let errorcode = response.code
          if (errorcode === '0') {
            _this.authCarData = response.data.rows
            _this.carTotal = response.data.total
          } else {
            _this.$message.error(response.data.errormsg)
          }
        })
        .then(function () {
          // console.log('_this.selecrFormCar ' + _this.selecrFormCar + _this.authData)
          if (_this.selecrFormCar && _this.authData === 'car') {
            let carNumArr = _this.selecrFormCar.split(',')
            // console.log('carNumArr ' + carNumArr)
            for (let i = 0; i < _this.authCarData.length; i++) {
              if (carNumArr.indexOf(_this.authCarData[i].carNum) !== -1) {
                _this.$refs.authBaseData.toggleRowSelection(_this.authCarData[i])
              }
            }
          }
        })
    },
    handleSizeChange (val) {
      this.loadCarData(this.currentPage, val, '', this.carType)
    },
    findPage (currentPage) {
      this.loadCarData(currentPage, this.pageSize, '', this.carType)
    },
    loadParkData () {
      let _this = this
      console.log('id : ' + _this.selectParkName)
      queryParkList()
        .then(function (response) {
          console.log(response)
          if (response.code === '0') {
            _this.treeData = response.data
          } else {
            _this.$message.error('查询失败!')
          }
        })
        .then(function () {
          let parksArr
          if (_this.selectParkName) {
            parksArr = _this.selectParkName.split(',')
          }
          console.log(_this.$refs.tree)
          _this.$refs.tree.setCheckedKeys(parksArr)
        })
    },
    loadSeatData (currentPage, pageSize, parkIds, parkSeatCode) {
      var _this = this
      if (parkIds.length > 0) {
        let ids = []
        for (let i = 0; i < parkIds.length; i++) {
          ids.push(parkIds[i].id)
        }
        queryUnAuthParkSeat(currentPage, pageSize, ids, parkSeatCode)
        .then(function (response) {
          var errorcode = response.code
          if (errorcode === '0') {
            _this.authSeatData = response.data.rows
            _this.seatTotal = response.data.total
          } else {
            _this.$message.error(response.data.errormsg)
          }
        })
        .then(function () {
          if (_this.selectSeats && _this.authData === 'seat') {
            let seatArr = _this.selectSeats.split(',')
            console.log('seatArr ' + seatArr)
            for (let i = 0; i < _this.authSeatData.length; i++) {
              if (seatArr.indexOf(_this.authSeatData[i].code) !== -1) {
                _this.$refs.authSeatData.toggleRowSelection(_this.authSeatData[i])
              }
            }
          }
        })
      } else {
        _this.$message.error('请先选中要授权的车场')
      }
    },
    getSelectData: function () {
      return this.selections
    },
    handleCurrentChange (val) {
      this.selectCar = val
    },
    handleTreeChange () {
      if (this.$refs.tree.getCheckedNodes()) {
        this.selectPark = this.$refs.tree.getCheckedNodes()
      }
    },
    seatCurrentChange (val) {
      this.selectSeat.push(val)
    },
    getCheckedNodes () {

    },
    // 状态格式化
    typeFormat: function (row, column) {
      var type = row.type
      if (type === 1) {
        return '特殊车'
      }
      return '普通车'
    }
    // selectOwer (ev) {
    //   console.log('innerThis ' + this.$parent)
    // }
  }
}
</script>


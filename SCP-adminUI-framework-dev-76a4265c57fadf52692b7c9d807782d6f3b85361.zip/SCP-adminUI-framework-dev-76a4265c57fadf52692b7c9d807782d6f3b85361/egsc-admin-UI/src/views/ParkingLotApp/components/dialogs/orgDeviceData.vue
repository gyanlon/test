<template>
  <section>
    <div class="tree-left">
      <el-tree :data="orgData" node-key="uuid" ref="tree" highlight-current :props="orgTreeProps" @node-click="orgDeviceNodeClick" style="width:800px;"></el-tree>
    </div>
    <div class="table-right">
      <el-table :data="tableData5" @current-change="handleCurrentChangeDevice" border highlight-current-row max-height = "300">
        <el-table-column type="index" label="序号" width="80px">
        </el-table-column>
        <el-table-column prop="deviceName" label="设备名" width="140px">
        </el-table-column>
        <el-table-column prop="deviceModel" label="型号" width="140px">
        </el-table-column>
        <el-table-column prop="deviceIP" label="设备IP" >
        </el-table-column>
      </el-table>
    </div>
  </section>
</template>
<script>
import { getOrgInfo, queryDeviceByOrgId } from '@/views/ParkingLotApp/apis'
export default {
  data () {
    return {
      orgData: [],
      tableData5: [],
      selectDevice: '',
      orgTreeProps: {
        children: 'children',
        label: 'name',
        isLeaf: 'leaf'
      },
      deviceInfo: {
        deviceName: '',
        deviceModel: '',
        deviceIP: '',
        deviceCode: ''
      }
    }
  },
  mounted () {
    this.getOrgInfo()
  },
  methods: {
    getOrgInfo () {
      let _this = this
      getOrgInfo()
        .then(function (response) {
          if (response.code === '0') {
            _this.orgData.push(response.data)
          } else {
            _this.orgData = []
          }
        }).then(function () {
          _this.getDeviceByOrgId(_this.orgData[0].uuid)
        })
        .catch(() => {})
    },
    handleCurrentChangeDevice (val) {
      this.selectDevice = val
    },
    orgDeviceNodeClick (data) {
      console.log(data)
      this.getDeviceByOrgId(data.uuid)
    },
    getDeviceByOrgId (orgId) {
      let _this = this
      queryDeviceByOrgId(orgId, '').then(function (response) {
        if (response.code === '0' && response.data !== null) {
          _this.tableData5 = response.data
          _this.deviceInfo.deviceName = response.data.deviceName
          _this.deviceInfo.deviceModel = response.data.deviceModel
          _this.deviceInfo.deviceIP = response.data.deviceIP
          console.log(_this.deviceInfo)
        } else {
          _this.tableData5 = []
        }
      })
    }
  }
}
</script>
<style lang="less" scoped>
.tree-left{
  display: inline-block;
  vertical-align: top;
  width: 30%;
  height: 500px;
  overflow: auto;
}
.table-right{
  display: inline-block;
  vertical-align: top;
  width: 68%;
}
</style>



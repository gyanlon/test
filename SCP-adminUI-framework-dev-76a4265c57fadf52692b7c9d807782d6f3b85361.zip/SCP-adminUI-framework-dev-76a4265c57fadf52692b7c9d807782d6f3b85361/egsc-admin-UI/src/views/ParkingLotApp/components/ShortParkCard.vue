<template>
  <section class="short-park">
    <div class="park-tree">
      <p>选择车场</p>
      <el-tree :data="parkTreeData" show-checkbox node-key="id" ref="tree" highlight-current :props="defaultProps" @check-change="handleNodeClick">
      </el-tree>
    </div>
    <div class="card-cont">
      <el-form :inline="true">
        <el-form-item>
          <el-input placeholder="请输入卡号" v-model="queryCardNo" ></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="queryByNo">查询</el-button>
        </el-form-item>
      </el-form>
      <el-table border :data="cardTableData" v-loading="listLoading" @selection-change = "selectCardCharge">
			  <el-table-column type="selection" width="60"></el-table-column>
        <el-table-column type="index" label="序号" width="60"></el-table-column>
        <el-table-column prop="uniqueCode" label="卡号"></el-table-column>
        <el-table-column prop="cardType" label="卡类型"></el-table-column>
      </el-table>
      <el-col class="toolbar">
        <el-pagination @size-change="handleSizeChange" @current-change="findPage" :current-page="currentPage" :page-sizes="[10, 20, 50, 100]" :page-size="pageSize" background layout="total, sizes, prev, pager, next, jumper" :total="total">
        </el-pagination>
      </el-col>
      <section class="auth-btn">
        <el-button type="primary" @click="saveAccredit">确定授权</el-button>
      </section>
    </div>
  </section>
</template>
<script>
import { getCard, queryParkList, updateCardAuth } from '@/views/ParkingLotApp/apis'
export default {
  data () {
    return {
      cardTableData: [],
      parkTreeData: [],
      selectCard: [],
      listLoading: true,
      currentPage: 1,
      pageSize: 10,
      total: 0,
      queryCardNo: '',
      selectParkCode: [],
      defaultProps: {
        children: 'subParkingLots',
        label: 'parkingName'
      }
    }
  },
  mounted () {
    this.loadData(this.currentPage, this.pageSize, this.queryCardNo)
    this.queryParkTree()
  },
  methods: {
    loadData (currentPage, pageSize, queryCardNo) {
      let _this = this
      getCard(currentPage, pageSize, queryCardNo)
      .then(function (response) {
        _this.cardTableData = response.data.rows
        _this.total = response.data.total
        _this.listLoading = false
        console.log(response.data)
      })
    },
    queryParkTree () {
      var _this = this
      this.loading2 = true
      queryParkList()
        .then(
          function (response) {
            if (response.code === '0') {
              _this.noData = true
              _this.parkTreeData = response.data
            } else {
              _this.noData = true
            }
          }
        )
    },
    handleNodeClick () {
      this.selectParkCode = this.$refs.tree.getCheckedNodes()
      console.log(this.selectParkCode)
    },
    queryByNo () {
      this.loadData(this.currentPage, this.pageSize, this.queryCardNo)
    },
    selectCardCharge (val) {
      this.selectCard = val
    },
    handleSizeChange (val) {
      this.pageSize = val
      this.loadData(this.currentPage, this.pageSize, this.queryCardNo)
    },
    findPage (val) {
      this.currentPage = val
      this.loadData(this.currentPage, this.pageSize, this.queryCardNo)
    },
    saveAccredit () {
      let _this = this
      let cardNums = []
      let parkArr = []
      for (let i = 0; i < _this.selectParkCode.length; i++) {
        parkArr.push(_this.selectParkCode[i].parkingCode)
      }
      for (let i = 0; i < _this.selectCard.length; i++) {
        cardNums.push(_this.selectCard[i].uniqueCode)
      }
      updateCardAuth(parkArr, cardNums).then(
          function (response) {
            if (response.code === '0') {
              _this.$message({
                type: 'success',
                message: '授权成功'
              })
            } else {
              _this.$alert('授权失败', '提示', {
                confirmButtonText: '确定',
                callback: action => {}
              })
            }
            _this.loadData()
          }
        ).catch(() => {})
    }
  }
}
</script>
<style lang="less" scoped>
@import "~@/views/ParkingLotApp/assets/css/parkLotApp.less";
</style>



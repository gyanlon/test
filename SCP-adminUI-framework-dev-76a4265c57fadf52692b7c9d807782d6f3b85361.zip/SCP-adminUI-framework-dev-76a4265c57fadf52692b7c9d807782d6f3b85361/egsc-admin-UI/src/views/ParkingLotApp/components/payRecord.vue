<template>
  <div>缴费记录</div>
</template>
<script>
export default {
  data () {
    return {

    }
  }
}
</script>


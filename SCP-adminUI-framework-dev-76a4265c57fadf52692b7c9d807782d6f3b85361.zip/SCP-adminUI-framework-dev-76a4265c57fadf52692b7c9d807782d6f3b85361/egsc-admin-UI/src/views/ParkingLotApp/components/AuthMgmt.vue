<template>
    <el-main>
      <section class="from-btns">
        <el-button type="primary" @click="addAuth" >新增</el-button>      
        <el-button type="danger" @click="deleteAuth">删除</el-button>	
      </section>
      <el-form :inline="true" style="line-height:40px">
        <span class="label-text">车牌号</span>
        <el-form-item>
            <el-input placeholder="请输入车牌号" v-model="queryCarNum" ref="queryCarNum" style="width:100%"></el-input>
        </el-form-item>
        <span class="label-text">车位编号</span>
        <el-form-item>
            <el-input placeholder="请输入车位编号" v-model="queryParkSeatCode" ref="queryParkSeatCode" style="width:100%"></el-input>
        </el-form-item>
        <el-form-item>
            <el-button type="primary" @click="queryByNum">查询</el-button>
        </el-form-item>
      </el-form>
        <el-table :data="authData" ref="authData" v-loading="loading" @selection-change="handleSelectionChange" border style="width: 100%">
          <el-table-column type="selection" width="60"></el-table-column>
          <el-table-column type="index" label="序号" width="60"></el-table-column>
          <el-table-column prop="ownerName" label="业主姓名" ></el-table-column>
          <el-table-column prop="carNum" label="车牌号" ></el-table-column>
          <el-table-column prop="cardNo" label="卡号" ></el-table-column>
          <el-table-column prop="authParkNames" label="停车场名" ></el-table-column>
          <el-table-column prop="ruleName" label="规则" ></el-table-column>
          <el-table-column prop="parkSeatCode" label="车位" ></el-table-column>
          <el-table-column prop="beginTime" label="开始时间" ></el-table-column>
          <el-table-column prop="endTime" label="结束时间" ></el-table-column>
          <el-table-column prop="remark" label="备注"></el-table-column>
          <el-table-column fixed="right" label="操作" fit="true" width="220">
            <template slot-scope="scope">
              <el-button size="mini" @click="editAuth(scope.$index,scope.row)">修改</el-button>
              <el-button size="mini" @click="carPay(scope.$index,scope.row)">缴费</el-button>
              <el-button size="mini" @click="paymentRecord(scope.$index,scope.row)">记录</el-button>
            </template>
          </el-table-column>
        </el-table>
        <el-col class="toolbar">
          <el-pagination :current-page="currentPage" :page-sizes="[10, 20, 50, 100]" :page-size="10" background layout="total, sizes, prev, pager, next, jumper" :total="total">
          </el-pagination>
        </el-col>
        <el-dialog :title="dialogTitle" :visible.sync="dialogFormVisible" width="50%">
          <el-form ref="addAuthform" :model="addAuthform" :rules = "addAuthRules" label-width="80px">
            <el-form-item label="业主" prop="name">
              <el-input v-model="addAuthform.name" :disabled="true"></el-input>
              <i class="el-icon-search" @click="selectFrom('auth')" v-show="isAdd"></i>
            </el-form-item>
            <el-form-item label="授权类型" prop="authStyle" v-show="isAdd">
              <el-radio-group v-model="authStyle" @change="choiseStyle">
                <el-radio :label="0">车牌号</el-radio>
                <el-radio :label="1">卡号</el-radio>
              </el-radio-group>
            </el-form-item>
            <el-form-item label="卡号" prop="cardNum" v-if="choiseCard">
              <el-input v-model="addAuthform.cardNum" :disabled="true"></el-input>
              <i class="el-icon-search" @click="selectFrom('card')"></i>
            </el-form-item>
            <el-form-item label="车牌号" prop="car" v-else>
              <el-input v-model="addAuthform.car" :disabled="true"></el-input>
              <i class="el-icon-search" @click="selectFrom('car')"></i>
            </el-form-item>
            <el-form-item label="停车场" prop="parks">
              <el-input v-model="addAuthform.parks" :disabled="true"></el-input>
              <i class="el-icon-search" @click="selectFrom('park')"></i>
            </el-form-item>
            <el-form-item label="车位" prop="parkSeatCode">
              <el-input v-model="addAuthform.parkSeatCode" :disabled="true"></el-input>
              <i class="el-icon-search" @click="selectFrom('seat')"></i>
            </el-form-item>
            <el-form-item label="车位类型" prop="parkSeatType">
              <el-select v-model="addAuthform.parkSeatType" placeholder="请选择">
                <el-option
                v-for="item in seatStyle"
                :key="item.value"
                :label="item.label"
                :value="item.value">
              </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="规则" prop="ruleId">
              <el-select v-model="addAuthform.ruleId" placeholder="请选择" :disabled = "!isAdd">
                <el-option
                v-for="item in ruleOpt"
                :key="item.value"
                :label="item.label"
                :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
            <!-- <el-checkbox v-model="addAuthform.authPay" class="pay-checkbox">立即缴费</el-checkbox>
            <section v-show="addAuthform.authPay">
              <el-form-item label="月数" style="width:30%">
                <el-input v-model="addAuthform.name"></el-input>
              </el-form-item>
              <el-form-item label="缴费" style="width:30%">
                <el-input v-model="addAuthform.name"></el-input>
                <em class="price-unit">元</em>
              </el-form-item>
              <el-form-item label="开始时间" style="width:30%">
                <el-input v-model="addAuthform.name"></el-input>
              </el-form-item>
              <el-form-item label="结束时间" style="width:30%">
                <el-input v-model="addAuthform.name"></el-input>
              </el-form-item>
              <el-form-item label="备注">
                <el-input v-model="addAuthform.name"></el-input>
              </el-form-item>              
            </section>-->
            <el-form-item label="备注">
                <el-input type="textarea" v-model="addAuthform.remark"></el-input>
              </el-form-item> 
            <el-form-item style="text-align:right;">
              <el-button @click="dialogFormVisible = false">取 消</el-button>
              <!-- <el-button @click="resetForm('addAuthform')">重置</el-button> -->
              <el-button type="primary" @click="saveAuth">保 存</el-button>
            </el-form-item>
          </el-form>
          <!-- <el-dialog width="50%" :title="innerTitle" :visible.sync="innerVisible" append-to-body>
            <owner ref="diaglo" v-if="isAuth"></owner>
            <section slot="footer" class="dialog-footer" style="text-align:right">
              <el-button @click="innerVisible = false">取 消</el-button>
              <el-button type="primary" @click="selectOwer">确认</el-button>
            </section>
          </el-dialog> -->
        </el-dialog>
        <el-dialog width="50%" :title="dialogData" :visible.sync="innerCardVisible" append-to-body>
          <owner ref="diaglo" v-show="selectName ==='auth'"></owner>
          <section v-show="selectName ==='card'"> 
            <el-table :data="authCardData" ref="authCardForm" highlight-current-row  @current-change="handleCurrentCard" border style="width: 100%">
              <el-table-column width="60" type="index" label="序号"></el-table-column>
              <el-table-column prop="cardNo" label="卡号" ></el-table-column>
              <el-table-column prop="cardType" label="卡类型"></el-table-column>
            </el-table>
          </section>
          <section v-show="selectName === 'car'"> 
            <el-table :data="authCarData" ref="authBaseData" highlight-current-row max-height="400"  @selection-change="carCurrentChange" border style="width: 100%">
              <el-table-column type="selection"></el-table-column>
              <el-table-column width="60" type="index" label="序号"></el-table-column>
              <el-table-column prop="carNum" label="车牌号" ></el-table-column>
              <el-table-column prop="status" label="状态" :formatter="statusFormat"></el-table-column>
              <el-table-column prop="remark" label="备注"></el-table-column>
            </el-table>
          </section>
          <section v-show="selectName === 'park'">
            <el-tree :props="defaultProps" ref="parkTree" height="400" default-expand-all :data="parkTreeData" 
            node-key="parkingName" show-checkbox  @check-change="handleTreeChange"></el-tree>
          </section>
          <section v-show="selectName === 'seat'">
            <div class="org-leftTree">
              <el-tree :data="parkTreeData" ref="seatParkTree" node-key="parkOrgId" :props="defaultProps" default-expand-all @node-click="orgNodeClick" style="width:800px;"></el-tree>
            </div> 
            <article class="seatTable">
              <el-form :inline="true">
                <el-form-item><el-input placeholder="请输入车位编号" style="width:100%"></el-input></el-form-item>
                <el-form-item> <el-button type="primary">查询</el-button></el-form-item>
              </el-form>
              <el-table :data="authSeatData" ref="authSeatForm" highlight-current-row max-height="380"  @current-change="seatCurrentChange" border style="width: 100%">
                <el-table-column type="index" label="序号" width="60"></el-table-column>
                <el-table-column prop="code" label="车位编号" ></el-table-column>
                <el-table-column prop="status" label="车位类型" ></el-table-column>
                <el-table-column prop="remark" label="备注"></el-table-column>
              </el-table>
              <el-col class="toolbar" style="text-align:right; margin:15px 0">
                <el-pagination :current-page="currentPage" :page-sizes="[10, 20, 50, 100]" :page-size="10" background layout="total, sizes, prev, pager, next" :total="seatTotal">
                </el-pagination>
              </el-col> 
            </article>
          </section>
          <section slot="footer" class="dialog-footer" style="text-align:right">
            <el-button @click="innerCardVisible = false">取 消</el-button>
            <el-button type="primary" @click="selectCardBtn">确认</el-button>
          </section>
        </el-dialog>
        <!-- 缴费弹出框 -->
        <el-dialog :title="payTitle" :visible.sync="dialogPayVisible" class="pay-popwin">
          <el-form :inline="true" ref="payAuthform" :model="payAuthform" :rules = "payAuthRule" label-width="120px" v-if="dialogPay">
            <el-form-item label="业主姓名">
              <el-input v-model="payAuthform.ownerName" :disabled="true"></el-input>
            </el-form-item>
            <el-form-item label="车牌号">
              <el-input v-model="payAuthform.carNum" :disabled="true"></el-input>
            </el-form-item>
            <el-form-item label="车位编码">
              <el-input v-model="payAuthform.seatCode" :disabled="true"></el-input>
            </el-form-item>
            <el-form-item label="规则">
              <el-input v-model="payAuthform.rule" :disabled="true"></el-input>
            </el-form-item>
            <el-form-item label="生效时间" v-if="payAuthform.startTime != ''" >
              <span v-text="payAuthform.startTime" class="disabled-text"></span>
            </el-form-item>
            <el-form-item label="失效时间" v-if="payAuthform.endTime != ''" >
              <span v-text="payAuthform.endTime" class="disabled-text"></span>
            </el-form-item>
            <el-form-item label="开始时间" v-if="payAuthform.startTime == ''" prop="beginTime">
              <div class="block">
                <el-date-picker
                  v-model="payAuthform.beginTime" :editable="false"
                  type="datetime"
                  placeholder="选择日期时间" value-format="yyyy-MM-dd HH:mm:ss" :picker-options="pickerBeginDateAfter">
                </el-date-picker>
              </div>
            </el-form-item>
            <el-form-item label="缴费单位" style=" width:100%">
              <span v-text="payAuthform.payPrice" class="disabled-text"></span>
            </el-form-item>
            <el-form-item label="缴费数量" prop="amount">
              <el-input-number v-model="payAuthform.amount" :min="1" :max="10" @change="selectPrice"></el-input-number>
            </el-form-item>
            <el-form-item label="应缴金额" prop="payMoney">
              <el-input v-model="payAuthform.payMoney" :disabled="true"></el-input>
            </el-form-item>
            <!-- <el-form-item label="支付方式">
              <el-select v-model="payAuthform.payStyle" placeholder="请选择">
                <el-option
                v-for="item in payStyle"
                :key="item.value"
                :label="item.label"
                :value="item.value">
                </el-option>
              </el-select>
            </el-form-item> -->
            <el-form-item label="备注" class="pay-ramker" style="width:100%">
              <el-input type="textarea" v-model="payAuthform.remark"></el-input>
            </el-form-item>
            <el-form-item style="text-align:right;width:100%">
              <el-button @click="dialogPayVisible = false">取 消</el-button>
              <el-button type="primary" @click="toPay('payAuthform')">缴 费</el-button>
            </el-form-item>
          </el-form>
          <div v-else>
            <el-table :data="recordData" border style="width: 100%" max-height="500">
              <el-table-column type="index"></el-table-column>
              <el-table-column prop="ownerName" label="业主姓名"></el-table-column>
              <el-table-column prop="carNum" label="车牌号"></el-table-column>
              <el-table-column prop="cardNo" label="卡号"></el-table-column>
              <el-table-column prop="parkSeatCode" label="车位编号"></el-table-column>
              <el-table-column prop="chargeMoney" label="缴费金额"></el-table-column>
              <el-table-column prop="chargeTime" label="缴费时间"></el-table-column>
              <el-table-column prop="remark" label="备注"></el-table-column>
            </el-table>
            <el-col class="toolbar" style="text-align:right; margin:15px 0">
              <el-pagination @size-change="paymentRecordSizeChange" @current-change="paymentRecordCurrentChange" :current-page="paymentRecordCurrentPage" :page-sizes="[10, 20, 50, 100]" :page-size="10" background layout="total, sizes, prev, pager, next" :total="paymentRecordTotal">
              </el-pagination>
            </el-col>
            <span slot="footer" class="text-center">
              <el-button @click="dialogPayVisible = false">关 闭</el-button>
            </span>
          </div>
        </el-dialog>
    </el-main>
</template>
<script>
import owner from '@/views/ParkingLotApp/components/dialogs/owner'
import { queryAuth, addAuth, editAuth, deleteAuthById, getMonthRule, getPayMent, toPay, getCardNoByOwnerId, queryParkList, listcars, getOrgInfo, queryUnAuthParkSeat, paymentRecord } from '@/views/ParkingLotApp/apis'

export default {
  components: { owner },
  data () {
    return {
      authData: [],
      authCardData: [],
      authCarData: [],
      parkTreeData: '',
      authSeatData: [],
      recordData: [],
      orgTreeData: [],
      queryValueCar: '',
      carStatus: '',
      payAuthform: {
        authId: '',      //  id
        ownerName: '',   //  业主姓名
        ownerId: '',     //  业主ID
        carNum: '',      //  车牌号
        seatCode: '',    //  车位编号
        rule: '',        //  规则
        startTime: '',   //  服务开始时间
        endTime: '',     //  服务结束时间
        beginTime: '',   // 第一次缴费，授权开始时间
        payPrice: '',    //  金额
        paypriceVal: '', //  金额值
        payUnit: '', // 缴费单位
        amount: '',       //  数量
        payMoney: ''    //  应缴金额
      },
      addAuthform: {
        name: '',
        car: '',
        parks: '',
        cardNum: '',
        parksCodes: '',
        parkSeatCode: '',
        parkSeatType: '',
        ruleId: '',
        remark: ''
      },
      authStyle: 0,
      seatStyle: [{
        value: '1',
        label: '月保车位'
      }, {
        value: '2',
        label: '产权车位'
      }],
      ruleOpt: [],
      payStyle: [{
        value: '1',
        label: '微信'
      }, {
        value: '2',
        label: '支付宝'
      }],
      authId: '',
      queryCarNum: '',
      queryParkSeatCode: '',
      formParkSeatCode: '',
      total: 0,
      sizes: 10,
      currentPage: 1,
      seatCurrPage: 1,
      seatSize: 10,
      seatTotal: 0,
      loading: false,
      dialogFormVisible: false,
      dialogPayVisible: false,
      innerCardVisible: false,
      choiseCard: false,
      selectName: 'auth',
      dialogTitle: '新增授权',
      innerTitle: '选择业主',
      payTitle: '缴费',
      dialogData: '选择卡号',
      dialogPay: true,
      selectAuth: [],
      selectParkId: '',
      selectCardVal: [],
      selectParkData: [],
      selectCarData: [],
      selectSeatData: {},
      parkOrgId: '',
      ownerId: '',
      isAdd: false,
      innerVisible: false,
      addAuthRules: {
        name: [
          { required: true, message: '请选择业主', trigger: 'blur' }
        ],
        car: [
          { required: true, message: '请选择授权车辆', trigger: 'blur' }
        ],
        cardNum: [
          { required: true, message: '请选择卡号', trigger: 'blur' }
        ],
        parks: [
          { required: true, message: '请选择授权停车场', trigger: 'blur' }
        ],
        parkSeatCode: [
          { required: true, message: '请选择授权车位', trigger: 'blur' }
        ],
        parkSeatType: [
          { required: true, message: '请选择车位类型', trigger: 'blur' }
        ],
        ruleId: [
          { required: true, message: '请输选择授权规则', trigger: 'blur' }
        ]
      },
      payAuthRule: {
        beginTime: [
          { required: true, message: '请输入开始时间', trigger: 'blur' }
        ],
        amount: [
          { required: true, message: '请输入数量', trigger: 'blur' },
          {pattern: /^[0-9]*[1-9][0-9]*$/, message: '只能输入数字'}
        ]
      },
      pickerBeginDateAfter: {
        disabledDate (time) {
          return time.getTime() < Date.now() - 8.64e7
        }
      },
      defaultProps: {
        children: 'subParkingLots',
        label: 'parkingName'
      },
      orgTreeProps: {
        children: 'children',
        label: 'name',
        isLeaf: 'leaf'
      },
      paymentRecordPageSize: 10,
      paymentRecordCurrentPage: 1,
      paymentRecordTotal: 0,
      paymentRecordAuthId: ''
    }
  },
  mounted () {
    this.loadAuthList(this.currentPage, this.sizes, this.queryCarNum, this.queryParkSeatCode) // 获取权限数据
    this.getMonthRule()  // 获取月卡规则
    this.loadParkData() // 获取车场
    this.getOrgInfo()  // 获取组织树
  },
  methods: {
    loadAuthList (currentPage, sizes, queryCarNum, queryParkSeatCode) {
      let _this = this
      _this.loading = true
      queryAuth(currentPage, sizes, queryCarNum, queryParkSeatCode)
        .then(function (response) {
          _this.loading = false
          var errorcode = response.code
          if (errorcode === '0') {
            _this.authData = response.data.rows
            _this.total = response.data.total
          } else {
            _this.$message.error(response.data.errormsg)
          }
        })
        .catch(function (error) {
          this.loading = false
          console.log(error)
        }.bind(this)
      )
    },
    queryByNum () {
      this.loadAuthList(this.currentPage, this.sizes, this.queryCarNum, this.queryParkSeatCode)
    },
    getMonthRule () {
      let _this = this
      getMonthRule()
        .then(function (response) {
          var errorcode = response.code
          if (errorcode === '0') {
            _this.ruleOpt = _this.formatString(response.data.MONTH_CAR_RULE)
          } else {
            _this.$message.error(response.data.errormsg)
          }
        })
    },
    getOrgInfo () { // 获取组织树
      let _this = this
      getOrgInfo()
        .then(function (response) {
          _this.defaultId = response.data.uuid
          if (response.code === '0') {
            _this.orgTreeData = response.data
          }
        })
        .catch(() => {})
    },
    handleSelectionChange (val) {
      this.selectAuth = val
    },
    addAuth () {
      this.addAuthform = {}
      this.addAuthform.parkSeatType = '1'
      this.dialogTitle = '新增授权'
      this.dialogFormVisible = true
      this.isAdd = true
    },
    loadCardData (ownerId) {
      var _this = this
      getCardNoByOwnerId(ownerId).then(function (response) {
        var code = response.code
        if (code === '0') {
          _this.authCardData = response.data
        }
      })
    },
    deleteAuth () {
      let _this = this
      let authIds = []
      for (let i = 0; i < _this.selectAuth.length; i++) {
        authIds.push(_this.selectAuth[i].id)
      }
      if (authIds.length < 1) {
        _this.$message('请选择需要删除的授权信息')
        return false
      }
      _this
        .$confirm('是否要删除此授权信息', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        })
        .then(() => {
          deleteAuthById(authIds)
            .then(function (response) {
              var errorcode = response.code
              if (errorcode === '0') {
                _this.$message({
                  message: '删除成功',
                  type: 'success'
                })
                _this.loadAuthList(_this.currentPage, _this.sizes, _this.queryCarNum, _this.queryParkSeatCode)
              } else {
                _this.$alert('删除失败', '提示', {
                  confirmButtonText: '确定',
                  callback: action => {}
                })
              }
            })
            .catch(() => {})
        })
        .catch(() => {})
    },
    saveAuth () {
      let _this = this
      let paramsData = {
        id: '', // 授权ID
        ownerId: _this.ownerId, // 业主ID
        cars: _this.addAuthform.car, // 授权车牌号
        cardNo: _this.addAuthform.cardNum,
        parks: _this.addAuthform.parks, // 授权车场编号
        parkSeatCode: _this.addAuthform.parkSeatCode, // 授权车位编号
        parkSeatType: _this.addAuthform.parkSeatType, // 授权车位类型,1:月保,2：产权
        ruleId: _this.addAuthform.ruleId, // 规则ID
        remark: _this.addAuthform.remark // 备注
      }
      console.log('data ' + JSON.stringify(paramsData))
      if (_this.dialogTitle === '新增授权') {
        _this.$refs.addAuthform.validate((valid) => {
          if (valid) {
            addAuth({
              params: JSON.stringify(paramsData)
            }).then(function (response) {
              var errorcode = response.code
              if (errorcode === '0') {
                _this.dialogFormVisible = false
                _this.$message({
                  message: '保存成功！',
                  type: 'success'
                })
                _this.loadAuthList(_this.currentPage, _this.sizes, _this.queryCarNum, _this.queryParkSeatCode)
              } else {
                _this.dialogFormVisible = false
                _this.$message.error(response.message || '授权失败!')
              }
            })
          }
        })
      } else {
        paramsData.id = _this.authId
        _this.$refs.addAuthform.validate((valid) => {
          if (valid) {
            editAuth({
              params: JSON.stringify(paramsData)
            }).then(function (response) {
              var errorcode = response.code
              if (errorcode === '0') {
                _this.dialogFormVisible = false
                _this.$message({
                  message: '修改成功！',
                  type: 'success'
                })
                _this.loadAuthList(_this.currentPage, _this.sizes, _this.queryCarNum, _this.queryParkSeatCode)
              } else {
                _this.dialogFormVisible = false
                _this.$message.error(response.message || '修改授权信息失败!')
              }
            })
          }
        })
      }
    },
    editAuth (index, row) {
      console.log('row' + JSON.stringify(row))
      this.authId = row.id
      this.addAuthform.name = row.ownerName
      this.addAuthform.car = row.carNum
      this.addAuthform.parks = row.authParkNames
      this.addAuthform.parkSeatCode = row.parkSeatCode
      this.addAuthform.parkSeatType = row.parkSeatType
      this.addAuthform.remark = row.remark
      this.addAuthform.ruleId = row.ruleId
      this.ownerId = row.ownerId
      this.dialogTitle = '修改授权'
      if (row.carNum !== '') {
        this.choiseCard = false
      } else {
        this.choiseCard = true
      }
      this.dialogFormVisible = true
      this.isAdd = false
    },
    carPay (index, row) {
      let _this = this
      _this.dialogPayVisible = true
      _this.dialogPay = true
      _this.payTitle = '缴费'
      _this.payAuthform.ownerName = row.ownerName
      _this.payAuthform.authId = row.id
      _this.payAuthform.ownerId = row.ownerId
      _this.payAuthform.carNum = row.carNum    //  车牌号
      _this.payAuthform.seatCode = row.parkSeatCode  //  车位编号
      _this.payAuthform.rule = row.ruleName     //  规则
      _this.payAuthform.startTime = row.beginTime //  服务开始时间
      _this.payAuthform.endTime = row.endTime   //  服务结束时间
      _this.payAuthform.beginTime = ''
      _this.payAuthform.amount = ''
      _this.payAuthform.payMoney = ''
      _this.payAuthform.remark = ''
      getPayMent(_this.payAuthform.authId)
        .then(function (response) {
          _this.payAuthform.paypriceVal = response.data.billingUnitPrice
          _this.payAuthform.payPrice = (response.data.billingUnitPrice).toFixed(2) + ' ' + response.data.unitDesc // 缴费金额
          _this.payAuthform.payUnit = response.data.payUnit // 缴费单位
          _this.payAuthform.payMoney = response.data.billingUnitPrice
        })
        .catch(function (error) {
          console.log('获取缴费信息失败,error：' + error)
          _this.payAuthform.payPrice = ''
          _this.payAuthform.paypriceVal = ''
          _this.$message.error('获取缴费信息失败' || error)
        })
    },
    selectPrice (val) {
      if ((typeof Number(val) === 'number') && (typeof Number(this.payAuthform.payPrice) === 'number')) {
        this.payAuthform.payMoney = (Number(this.payAuthform.paypriceVal) * Number(val)).toFixed(2)
      }
    },
    toPay (payAuthform) { // 去缴费
      let _this = this
      let paramsData = _this.payAuthform
      console.log(JSON.stringify(paramsData))
      _this.$refs.payAuthform.validate((valid) => {
        if (valid) {
          toPay({
            params: JSON.stringify(paramsData)
          }).then(function (response) {
            var errorcode = response.code
            _this.$refs[payAuthform].resetFields()
            if (errorcode === '0') {
              _this.dialogPayVisible = false
              _this.loadAuthList(_this.currentPage, _this.sizes, _this.queryCarNum, _this.queryParkSeatCode)
              _this.$message({
                message: '缴费成功！',
                type: 'success'
              })
            } else {
              _this.dialogPayVisible = false
              _this.$message.error('缴费失败!')
            }
          })
        }
      })
    },
    loadCarData (currentPage, pageSize, carNum, status, ownerId) {
      let _this = this
      listcars(currentPage, pageSize, carNum, status, ownerId)
        .then(function (response) {
          let errorcode = response.code
          if (errorcode === '0') {
            _this.authCarData = response.data.rows
            _this.carTotal = response.data.total
          } else {
            _this.$message.error(response.data.errormsg)
          }
        })
        // .then(function () {
        //   // console.log('_this.selecrFormCar ' + _this.selecrFormCar + _this.authData)
        //   if (_this.selecrFormCar && _this.authData === 'car') {
        //     let carNumArr = _this.selecrFormCar.split(',')
        //     // console.log('carNumArr ' + carNumArr)
        //     for (let i = 0; i < _this.authCarData.length; i++) {
        //       if (carNumArr.indexOf(_this.authCarData[i].carNum) !== -1) {
        //         _this.$refs.authBaseData.toggleRowSelection(_this.authCarData[i])
        //       }
        //     }
        //   }
        // })
    },
    loadParkData () {
      let _this = this
      queryParkList()
        .then(function (response) {
          if (response.code === '0') {
            _this.parkTreeData = response.data
          } else {
            _this.$message.error('查询失败!')
          }
        })
        // .then(function () {
        //   let parksArr
        //   if (_this.selectParkName) {
        //     parksArr = _this.selectParkName.split(',')
        //     _this.$refs.tree.setCheckedKeys(parksArr)
        //   }
        // })
    },
    loadSeatData (currentPage, pageSize, orgId, formParkSeatCode) {
      let _this = this
      queryUnAuthParkSeat(currentPage, pageSize, orgId, formParkSeatCode)
      .then(function (response) {
        let errorcode = response.code
        if (errorcode === '0') {
          _this.authSeatData = response.data.rows
          _this.seatTotal = response.data.total
        } else {
          _this.$message.error(response.data.errormsg)
        }
      })
      // .then(function () {
      //   if (_this.selectSeats && _this.authData === 'seat') {
      //     console.log(_this.selectSeats)
      //     let seatArr = _this.selectSeats.split(',')
      //     console.log('seatArr ' + seatArr)
      //     for (let i = 0; i < _this.authSeatData.length; i++) {
      //       if (seatArr.indexOf(_this.authSeatData[i].code) !== -1) {
      //         _this.$refs.authSeatData.toggleRowSelection(_this.authSeatData[i])
      //       }
      //     }
      //   }
      // })
    },
    handleTreeChange () {
      if (this.$refs.parkTree.getCheckedNodes()) {
        this.selectParkData = this.$refs.parkTree.getCheckedNodes()
        // console.log(this.$refs.tree.getCheckedNodes())
      }
    },
    handleCurrentCard (val) {
      this.selectCardVal = val
    },
    orgNodeClick (data) {
      console.info(data.parkOrgId)
      console.info(this.formParkSeatCode)
      this.loadSeatData(this.seatCurrPage, this.seatSize, data.parkOrgId, this.formParkSeatCode)
    },
    seatCurrentChange (val) {
      this.selectSeatData = val
    },
    resetForm (addAuthform) {
      this.$refs[addAuthform].resetFields()
    },
    noSelectTip () {
      this.$confirm('还没选择确定关闭窗口?', '提示', {
        onfirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.innerVisible = false
      }).catch(() => {
        this.innerVisible = true
      })
    },
    selectFrom (fromName) { // 选择车场
      this.selectName = fromName
      if (fromName === 'park') {
        this.dialogData = '选择车场'
        console.log(this.$refs)
        if (this.addAuthform.parks && this.$refs.parkTree) {
          let parkArr = this.addAuthform.parks.split(',')
          console.log(this.$refs)
          this.$refs.parkTree.setCheckedKeys(parkArr)
        } else {
          if (this.$refs.parkTree) {
            this.$refs.parkTree.setCheckedKeys([])
          }
        }
        console.log(this.addAuthform.parks)
      } else if (fromName === 'auth') {
        this.dialogData = '选择业主'
      } else if (fromName === 'card') {
        if (this.addAuthform.name) {
          this.loadCardData(this.ownerId)
          this.dialogData = '选择卡号'
        } else {
          this.$message('请先选择业主信息！')
          return false
        }
      } else if (fromName === 'car') {
        if (this.addAuthform.name) {
          this.loadCarData(this.currentPage, this.sizes, this.queryValueCar, this.carStatus, this.ownerId)
          this.dialogData = '选择车辆'
        } else {
          this.$message('请先选择业主信息！')
          return false
        }
      } else if (fromName === 'seat') {
        if (this.addAuthform.parks) {
          this.dialogData = '选择车位'
          // let orgArr = this.parkOrgId.split(',')
          // this.$refs.seatParkTree.setCheckedKeys(orgArr)
          // this.loadSeatData(this.seatCurrPage, this.seatSize, this.parkOrgId, this.formParkSeatCode)
        } else {
          this.$message('请先选中要授权的车场')
          return false
        }
      }
      this.innerCardVisible = true
    },
    choiseStyle (val) {
      if (val === 0) {
        this.choiseCard = false
      } else {
        this.choiseCard = true
      }
    },
    selectCardBtn () {
      if (this.selectName === 'auth') {
        if (this.$refs.diaglo && this.$refs.diaglo.selectAuto && this.$refs.diaglo.selectAuto.ownerName) {
          this.addAuthform.name = this.$refs.diaglo.selectAuto.ownerName
          this.ownerId = this.$refs.diaglo.selectAuto.ownerId
        } else {
          this.noSelectTip()
        }
      } else if (this.selectName === 'park') { // 车场
        this.addAuthform.parks = ''
        this.selectParkId = ''
        this.parkOrgId = ''
        for (let park of this.selectParkData) {
          this.addAuthform.parks += ',' + park.parkingName
          this.selectParkId += ',' + park.parkingCode
          this.parkOrgId += ',' + park.parkOrgId
        }
        this.addAuthform.parks = (this.addAuthform.parks).substr(1)
        this.selectParkId = (this.selectParkId).substr(1)
        this.parkOrgId = (this.parkOrgId).substr(1)
        this.addAuthform.parksCodes = this.selectParkId
      } else if (this.selectName === 'car') {
        this.addAuthform.car = ''
        for (let park of this.selectCarData) {
          this.addAuthform.car += ',' + park.carNum
        }
        if (this.addAuthform.car) {
          this.addAuthform.car = (this.addAuthform.car).substr(1)
        }
      } else if (this.selectName === 'seat') {
        this.addAuthform.parkSeatCode = this.selectSeatData.code
      } else if (this.selectName === 'card') {
        if (this.selectCardVal !== '') {
          this.addAuthform.cardNum = this.selectCardVal.cardNo
        }
      }
      this.innerCardVisible = false
    },
    paymentRecord (index, row) { // 缴费记录
      this.dialogPayVisible = true
      this.dialogPay = false
      this.payTitle = '缴费记录'
      this.paymentRecordCurrentPage = 1
      this.paymentRecordPageSize = 10
      this.paymentRecordAuthId = row.id
      this.loadPaymentRecord(this.paymentRecordCurrentPage, this.paymentRecordPageSize, this.paymentRecordAuthId)
    },
    loadPaymentRecord (currentPage, pageSize, authId) {
      var _this = this
      paymentRecord(currentPage, pageSize, authId)
      .then(function (response) {
        let errorcode = response.code
        if (errorcode === '0') {
          _this.recordData = response.data.rows
          _this.paymentRecordTotal = response.data.total
        } else {
          this.$message.error('获取缴费记录异常')
        }
      })
    },
    paymentRecordSizeChange (paymentRecordPageSize) {
      this.paymentRecordPageSize = paymentRecordPageSize
      this.loadPaymentRecord(this.paymentRecordCurrentPage, paymentRecordPageSize, this.paymentRecordAuthId)
    },
    paymentRecordCurrentChange (paymentRecordCurrentPage) {
      this.paymentRecordCurrentPage = paymentRecordCurrentPage
      this.loadPaymentRecord(paymentRecordCurrentPage, this.paymentRecordPageSize, this.paymentRecordAuthId)
    },
    formatString (dataString) {
      var keyArrs = []
      var valuArrs = []
      var dataArrObj = []
      for (var keyArr in dataString) {
        keyArrs.push('"' + keyArr + '"')
      }
      for (var valueArr in dataString) {
        valuArrs.push('"' + dataString[valueArr] + '"')
      }
      for (let i = 0; i < keyArrs.length; i++) {
        var arrObj = '{value:' + keyArrs[i] + ',label:' + valuArrs[i] + '}'
        dataArrObj.push(this.myEval(arrObj))
      }
      return dataArrObj
    },
    // carSizeChange (val) {
    //   this.loadCarData(this.currentPage, val, this.queryValueCar, this.carStatus)
    // },
    // findPage (val) {
    //   this.loadCarData(val, this.sizes, this.queryValueCar, this.carStatus)
    // },
    // queryCarByNum () {
    //   this.loadCarData(this.currentPage, this.sizes, this.queryValueCar, this.carStatus)
    // },
    statusFormat: function (row, column) {
      var status = row.status
      if (status === 1) {
        return '白名单'
      } else if (status === 2) {
        return '黑名单'
      }
      return '正常'
    },
    carCurrentChange (val) {
      console.log(val)
      this.selectCarData = val
    },
    myEval (str) {
      var Fn = Function
      return new Fn('return ' + str)()
    }
  }
}
</script>
<style lang="less" scoped>
@import "~@/views/ParkingLotApp/assets/css/parkLotApp.less";
.el-input{
  width: 60%
}
.pay-popwin .el-input{
  width: 100%
}
.pay-checkbox{
  margin-left: 80px;
  margin-bottom: 10px;
}
.price-unit{
  font-style: normal;
  font-size: 18px;
}
.pay-ramker .el-textarea{
  width: 550px;
}
.disabled-text{
  display: inline-block;
  width: 202px
}
</style>


























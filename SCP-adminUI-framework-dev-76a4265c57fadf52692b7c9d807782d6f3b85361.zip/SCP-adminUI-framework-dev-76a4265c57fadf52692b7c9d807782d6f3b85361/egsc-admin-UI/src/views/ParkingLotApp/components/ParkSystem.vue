<template>
  <section>
    <el-form ref="sysForm" :model="sysForm"  label-width="240px" >
      <el-form-item :label="item.configName" prop="time" v-for="item in sysFormData" :key = "item.key">
        <el-input v-model="item.configPar1" style="width:80px;margin-right:20px;"></el-input>{{item.configPar2}}
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="saveSetSys">保存</el-button>
      </el-form-item>
    </el-form>
  </section>
</template>
<script>
import { getSysSet, updateConfig } from '@/views/ParkingLotApp/apis'
export default {
  data () {
    return {
      sysForm: {

      },
      sysFormData: []
    }
  },
  mounted () {
    this.getSysSet()
  },
  methods: {
    getSysSet () {
      let _this = this
      getSysSet()
      .then(function (response) {
        _this.sysFormData = response.data
      })
    },
    saveSetSys () {
      let _this = this
      let params = []
      for (let i = 0; i < _this.sysFormData.length; i++) {
        params.push({
          'configType': _this.sysFormData[i].configType,
          'configName': _this.sysFormData[i].configName,
          'configPar1': _this.sysFormData[i].configPar1
        })
      }
      updateConfig(params)
      .then(function (response) {
        if (response.code === '0') {
          _this.$message({
            message: '保存成功！',
            type: 'success'
          })
          _this.getSysSet()
        } else {
          _this.$notify.error({
            title: '错误',
            message: '操作失败'
          })
        }
        _this.getSysSet()
      })
    }
  }
}
</script>

<template>
  <el-form :inline="true" ref="facePictureForm">
    <el-form-item label="开始时间">
      <el-date-picker type="datetime" placeholder="选择日期时间" v-model="beginTime"></el-date-picker>
    </el-form-item>
    <el-form-item label="结束时间">
      <el-date-picker type="datetime" placeholder="选择日期时间" v-model="endTime"></el-date-picker>
    </el-form-item>
    <el-form-item>
      <el-button type="primary" @click="getPicture">查询</el-button>
    </el-form-item>
    <div class="pictrue-box">
      <img v-for="(item,index) in imageUrls" :src="item.url" :key="index" class="face-image" />
    </div>
    <el-pagination @current-change="getPicture" layout="total, prev,pager,next,jumper" :total="page.total" :page-size="page.size">
    </el-pagination>
  </el-form>
</template>
<style type="text/css">
.pictrue-box {
  margin: 10px 0px 10px 0px;
  min-height: 10px;
}
.pictrue-box:after {
  content: " ";
  clear: both;
  display: block;
}
.face-image {
  float: left;
  height: 150px;
  width: 150px;
  margin: 10px;
}
</style>
<script>
import { getFacePicture } from '@/views/VideoGatewayApp/apis/facePicture.js'

export default {
  name: 'facePicture',
  data () {
    return {
      beginTime: '',
      endTime: '',
      imageUrls: [],
      page: {
        total: 0,
        pageSize: 20
      }
    }
  },
  methods: {
    getPicture () {
      if (!this.beginTime && !this.endTime) {
        this.$message({ message: '请选择时间', type: 'warning' })
        return
      }
      var beginTamp = this.beginTime ? (new Date(this.beginTime)).getTime() : -1
      var endTamp = this.endTime ? (new Date(this.endTime)).getTime() : -1
      if ((beginTamp !== -1) && (endTamp !== -1) && (beginTamp > endTamp)) {
        this.$message({ message: '结束时间不能小于开始时间', type: 'warning' })
        return
      }
      let reqData = {
        'begin_time': '',
        'End_time': ''
      }
      reqData.begin_time = this.timeConverte(this.beginTime)
      reqData.End_time = this.timeConverte(this.endTime)
      getFacePicture(reqData).then(
        result => {
          this.imageUrls = result.pictureUrls
          this.page.total = result.pictureUrls.length
        }
      )
    },
    timeConverte (date) { //  时间格式化
      const d = new Date(date)
      return d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate() + ' ' + d.getHours() + ':' + d.getMinutes() + ':' + d.getSeconds()
    }
  }
}
</script>
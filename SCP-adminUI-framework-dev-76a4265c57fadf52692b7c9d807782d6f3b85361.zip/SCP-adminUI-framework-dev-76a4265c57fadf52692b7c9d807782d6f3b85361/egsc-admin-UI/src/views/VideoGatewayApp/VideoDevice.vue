<template>
  <div>
    <el-form :inline="true" :model="searchData" ref="searchForm" :rules="searchFormRules">
      <el-form-item label="设备名称">
        <el-input v-model="searchData.deviceName" clearable placeholder="设备名称" :maxlength="64"></el-input>
      </el-form-item>
      <el-form-item label="IP地址" prop="deviceIp">
        <el-input v-model="searchData.deviceIp" clearable placeholder="IP地址" :maxlength="32"></el-input>
      </el-form-item>
      <el-form-item label="端口" prop="devicePort">
        <el-input v-model="searchData.devicePort" clearable placeholder="端口" :maxlength="32"></el-input>
      </el-form-item>
      <el-form-item label="设备类型">
        <el-select v-model="searchData.deviceType" clearable placeholder="请选择">
          <el-option v-for="(value,key) in deviceTypeArr" :label="value" :value="key" :key="key"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="resetSearchForm">重置</el-button>
      </el-form-item>
      <div>
        <el-button type="primary" @click="search(1)">查询</el-button>
        <el-button type="primary" @click="btnAdd">新增设备</el-button>
        <el-button type="primary" @click="selectDelete">删除设备</el-button>
      </div>
      <el-table :data="deviceList" border style="margin-top:30px" @selection-change="selectChange" ref="deviceListForm">
        <el-table-column align="center" type="selection" width="55"></el-table-column>
        <el-table-column align="center" prop="deviceName" label="设备名称"></el-table-column>
        <el-table-column align="center" prop="deviceIp" label="IP地址"></el-table-column>
        <el-table-column align="center" prop="devicePort" label="端口"></el-table-column>
        <el-table-column align="center" prop="deviceType" label="设备类型" :formatter="getDeviceTypeLabel"></el-table-column>
        <el-table-column align="center" label="操作">
          <template slot-scope="scope">
            <el-button size="mini" @click="btnModify(scope.$index, scope.row)">编辑</el-button>
            <el-button size="mini" @click="btnDelete(scope.$index, scope.row)">删除</el-button>
            <el-button size="mini" @click="btnSee(scope.$index, scope.row)">查看</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class='video-pagination'>
        <el-pagination @size-change="sizeChange" @current-change="search" :current-page="curPageNo" :page-sizes="[10, 20, 50, 100]" :page-size="searchData.pageSize" layout="total, sizes, prev, pager, next, jumper" :total="numTotal">
        </el-pagination>
      </div>
    </el-form>
    <el-dialog :title="dialog.isAdd?'添加视频设备':'修改视频设备'" :visible.sync="dialog.visible" :close-on-click-modal="false">
      <el-form :model="device" ref="deviceForm" :rules="dialogRules" label-width="80px">
        <el-form-item label="设备厂商" prop="manufacturer">
          <el-select v-model="device.manufacturer" clearable placeholder="请选择">
            <el-option v-for="(value,key) in deviceMaker" :label="value" :value="key" :key="key"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="设备名称" prop="deviceName">
          <el-input v-model.trim="device.deviceName" clearable placeholder="设备名称" :maxlength="64"></el-input>
        </el-form-item>
        <el-form-item label="设备类型" prop="deviceType">
          <el-select v-model="device.deviceType" clearable placeholder="请选择">
            <el-option v-for="(value,key) in deviceTypeArr" :label="value" :value="key" :key="key"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="IP地址" prop="deviceIp">
          <el-input v-model="device.deviceIp" placeholder="IP地址" :disabled="disabledInput" :maxlength="32"></el-input>
        </el-form-item>
        <el-form-item label="端口" prop="devicePort">
          <el-input v-model="device.devicePort" clearable placeholder="端口" :maxlength="32"></el-input>
        </el-form-item>
        <el-form-item label="用户名" prop="deviceUserName">
          <el-input v-model.trim="device.deviceUserName" clearable placeholder="用户名" :maxlength="64"></el-input>
        </el-form-item>
        <el-form-item label="密码" prop="deviceUserPwd">
          <el-input v-model.trim="device.deviceUserPwd" clearable placeholder="密码" type="password" :maxlength="32"></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialog.visible = false">取 消</el-button>
        <el-button type="primary" @click="addItem()" v-if="dialog.isAdd">确 定</el-button>
        <el-button type="primary" @click="modifyItem()" v-else>确 定</el-button>
      </span>
    </el-dialog>
    <el-dialog :title="seeName" :visible.sync="dialogTableVisible">
      <el-table :data="seeDataList" border style="padding-top:10px" fit>
        <el-table-column align="center" prop="channelLogicId" label="NVR通道号"></el-table-column>
        <el-table-column align="center" prop="cameraIp" label="监控点IP"></el-table-column>
        <el-table-column align="center" prop="online" label="监控点状态" :formatter="getOnline"></el-table-column>
        <el-table-column align="center" prop="cameraChannelNo" label="监控点通道号"></el-table-column>
        <el-table-column align="center" prop="cameraCode" label="监控点编号"></el-table-column>
      </el-table>
      <div class='video-pagination'>
        <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="curpageNo" :page-size='seeDataList.pageSize' :page-sizes="[2,5, 10]" layout="total, sizes, prev, pager, next, jumper" :total="total">
        </el-pagination>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import { isValidIP, emptyObj } from '@/views/VideoGatewayApp/apis/common.js'
import { getDevice, addDevice, deleteDevice, modifyDevice, seeDevice } from '@/views/VideoGatewayApp/apis/videoDevice.js'
import { copyObject } from '../../packages/utils/util'

const deviceTypeArr = { '1': 'NVR' }
// const deviceMaker = { '1': '海康', '2': '大华' }
const deviceMaker = { '1': '海康' }
const onLine = { '0': '不在线', '1': '在线' }

export default {
  name: 'videoDevice',
  data () {
    return {
      searchData: { // 获取设备列表
        //  uuid: '',
        deviceName: '',
        deviceType: '',
        deviceIp: '',
        devicePort: '',
        pageNo: 0,
        pageSize: 20
      },
      device: this.getEmptyDevice(), // 设备属性
      numTotal: 0,
      curPageNo: 1,
      curpageNo: 1,
      deviceTypeArr: deviceTypeArr,
      deviceMaker: deviceMaker,
      deviceList: [],  // 设备列表
      selection: [],
      seeData: {
        uuid: '',
        pageNo: 1,
        pageSize: 10
      },
      seeDataList: [], // 查看属性
      dialogTableVisible: false,
      seeName: '',
      onLine: onLine,
      total: '',
      disabledInput: false,
      dialog: {
        visible: false,
        isAdd: true,
        curIndex: 0
      },
      dialogRules: {
        manufacturer: [{ required: true, message: '请选择设备厂商', trigger: 'change' }],
        deviceName: [{ required: true, message: '请输入设备名称', trigger: 'blur' }],
        deviceType: [{ required: true, message: '请选择设备类型', trigger: 'change' }],
        deviceIp: [
          { required: true, message: '请输入IP地址', trigger: 'blur' },
          {
            validator: (rule, value, callback) => {
              if (!isValidIP(value)) {
                callback(new Error('IP地址格式不正确'))
              } else {
                callback()
              }
            },
            trigger: 'blur'
          }
        ],
        devicePort: [
          { required: true, message: '请输入端口', trigger: 'blur' },
          { validator: this.deviceFormDevicePort, trigger: 'blur' }
        ],
        deviceUserName: [{ required: true, message: '请输入用户名', trigger: 'blur' }],
        deviceUserPwd: [{ required: true, message: '请输入密码', trigger: 'blur' }]
      },
      searchFormRules: {
        deviceIp: [
          { required: false, trigger: 'blur' },
          {
            validator: (rule, value, callback) => {
              if (value === '') return false
              if (!isValidIP(value)) {
                callback(new Error('IP地址格式不正确'))
              } else {
                callback()
              }
            },
            trigger: 'blur'
          }
        ],
        devicePort: [
          { required: false, trigger: 'blur' },
          { validator: this.searchDataDevicePort, trigger: 'blur' }
        ]
      }
    }
  },
  mounted () {
    this.search(this.curPageNo)
  },
  methods: {
    search (pageNo) { // 查询设备列表
      if (this.checkSearchForm()) {
        this.searchData.pageNo = pageNo // 查询页码
        getDevice(this.searchData).then(
          result => {
            this.deviceList = result.rows
            //   this.deviceList.sort((a, b) => b.createTime - a.createTime)
            this.numTotal = result.total
            this.curPageNo = pageNo
          }
        ).catch(() => {
        })
      }
    },
    addItem () {
      this.$refs['deviceForm'].validate(
        (valid) => {
          if (valid) {
            let reqData = this.getReqData(this.device, true)
            addDevice(reqData).then(
              result => {
                this.dialog.visible = false
                this.search(this.curPageNo)
                this.$message({ type: 'success', message: '添加成功！' })
              }
            ).catch(() => {
            })
          } else {
            return false
          }
        }
      )
    },
    btnAdd () {
      this.device = this.getEmptyDevice()
      this.dialog.visible = true
      this.dialog.isAdd = true
      this.disabledInput = false
      if (this.$refs['deviceForm']) this.$refs['deviceForm'].resetFields()
    },
    selectDelete () { // 删除用户选择的设备
      if (this.selection.length <= 0) {
        this.$alert('先勾选设备,才能删除设备', '提示', {
          confirmButtonText: '确定',
          type: 'warning',
          center: true,
          callback: () => { return false }
        })
      } else {
        this.$confirm('删除设备可能影响录像查询功能, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
          center: true
        }).then(() => {
          var oidArr = this.selection.map(item => item.uuid)
          let reqData = { deviceIdList: oidArr }
          deleteDevice(reqData).then(
            result => {
              this.numTotal -= this.selection.length
              this.deviceList = this.deviceList.filter(
                item => oidArr.indexOf(item.uuid) === -1
              )
              this.$message({ type: 'success', message: '删除成功!' })
            }
          ).catch(() => {
            this.$message({ type: 'error', message: '删除失败！' })
          })
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
          this.$refs.deviceListForm.clearSelection()
        })
      }
    },
    btnSee (index, item) {
      if (item) this.seeData.uuid = item.uuid
      seeDevice(this.seeData).then(
        result => {
          this.dialogTableVisible = true
          this.seeName = '设备名称:' + item.deviceName
          this.total = result.total
          this.seeDataList = result.rows
        }
      ).catch(() => {
        return false
      }
        )
    },
    btnDelete (index, item) {
      this.$confirm('删除设备可能影响录像查询功能, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
        center: true
      }).then(() => {
        let reqData = { deviceIdList: [item.uuid] }
        deleteDevice(reqData).then(
          result => {
            this.deviceList.splice(index, 1)
            this.numTotal--
            this.$message({ type: 'success', message: '删除成功!' })
          }
        ).catch(() => {
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
        this.$refs.deviceListForm.clearSelection()
      })
    },
    modifyItem () {
      this.$refs['deviceForm'].validate((valid) => {
        if (valid) {
          let reqData = this.getReqData(this.device, false)
          modifyDevice(reqData).then(
            result => {
              this.dialog.visible = false
              this.deviceList.splice(this.dialog.curIndex, 1, copyObject(this.device))
              this.$message({ type: 'success', message: '编辑成功！' })
            }
          ).catch(() => {
          })
        } else {
          return false
        }
      })
    },
    btnModify (index, item) {
      this.device = copyObject(this.deviceList[index])
      this.dialog.curIndex = index
      this.dialog.visible = true
      this.dialog.isAdd = false
      this.disabledInput = true
      if (this.$refs['deviceForm']) this.$refs['deviceForm'].resetFields()
    },
    resetSearchForm () {
      emptyObj(this.searchData)
      this.searchData.pageSize = 20
    },
    checkSearchForm () {
      // if (this.isNothing(this.searchData)) return false  // 查询关键字可以为空
      if (this.searchData.deviceIp) {
        if (!isValidIP(this.searchData.deviceIp)) {
          this.$message({ message: 'IP地址格式不正确！', type: 'warning' })
          return false
        }
      }
      if (this.searchData.devicePort) {
        if (isNaN(this.searchData.devicePort)) {
          this.$message({ message: '端口不正确！', type: 'warning' })
          return false
        }
      }
      return true
    },
    isNothing (obj) {
      for (var item in obj) {
        if (obj[item]) return false
      }
      return true
    },
    selectChange (val) {
      this.selection = val
    },
    getDeviceTypeLabel (row, column, cellValue) {  // 转换格式
      return deviceTypeArr[cellValue]
    },
    getOnline (row, column, cellValue) {
      return onLine[cellValue]
    },
    getReqData (item, isAdd) {
      let reqData = {
        'deviceType': item.deviceType,
        'deviceName': item.deviceName,
        'devicePort': item.devicePort,
        'deviceIp': item.deviceIp,
        'deviceManufacturer': item.manufacturer,
        'deviceUsername': item.deviceUserName,
        'devicePassword': item.deviceUserPwd
      }
      if (!isAdd) reqData.uuid = item.uuid
      return reqData
    },
    getEmptyDevice () {
      return {
        uuid: '',
        deviceType: '',
        deviceName: '',
        devicePort: '',
        deviceIp: '',
        manufacturer: '',
        deviceUserName: '',
        deviceUserPwd: ''
      }
    },
    searchDataDevicePort (rule, value, callback) {
      if (value === '') return false
      if (value !== '') {
        if (!this.isRegex(value)) {
          return callback(new Error('请输入1-65535的整数！'))
        }
      }
      if (value < 1 || value > 65535) {
        return callback(new Error('请输入1-65535的整数！'))
      } else {
        callback()
      }
    },
    deviceFormDevicePort (rule, value, callback) {
      if (!this.isRegex(value)) {
        return callback(new Error('请输入1-65535的整数！'))
      } else {
        if (value < 1 || value > 65535) {
          return callback(new Error('请输入1-65535的整数！'))
        } else {
          callback()
        }
      }
    },
    isRegex (string) {
      var reg = /^[1-9]\d*$/
      return reg.test(string)
    },
    sizeChange (val) {
      this.searchData.pageSize = val
      this.search(1)
    },
    handleCurrentChange (val) {
      console.log(`当前页: ${val}`)
      this.seeData.pageNo = val
      seeDevice(this.seeData).then(
        result => {
          this.seeDataList = result.rows
        }
      ).catch(() => {
      }
        )
    },
    handleSizeChange (val) {
      this.seeData.pageSize = val
      seeDevice(this.seeData).then(
        result => {
          this.seeDataList = result.rows
        }
      ).catch(() => {
      }
        )
    }
  }
}
</script>
<style scoped lang="less">
.video-pagination {
  text-align: center;
  margin-top: 15px;
}
</style>

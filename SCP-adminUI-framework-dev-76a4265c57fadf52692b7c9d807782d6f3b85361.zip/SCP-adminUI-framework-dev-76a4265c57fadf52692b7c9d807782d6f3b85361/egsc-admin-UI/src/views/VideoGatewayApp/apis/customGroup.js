import { request, cmd } from '@/views/VideoGatewayApp/apis/common.js'

// 根据名称查询自定义组
export const groupList = (data) => {
  return request(cmd['customgroup_list'], data, 'get')
}
// 获取自定义组下的摄像头
export const getCamerasByGroup = (data) => {
  return request(cmd['customgroup_get'], data, 'get')
}
// 添加自定义组
export const groupAdd = (data) => {
  return request(cmd['customgroup_insert'], data)
}
// 删除组
export const groupDelete = (data) => {
  return request(cmd['customgroup_delete'], data)
}
// 修改自定义组
export const groupUpdate = (data) => {
  return request(cmd['customgroup_update'], data)
}
// 获取组织下的摄像头
export const getCameraTree = (data) => {
  return request(cmd['cameraTree_get'], data, 'get')
}
// 根据组织uuid获取组织下的摄像头
export const getCameraTreeNode = (data) => {
  return request(cmd['cameraTree_node_get'], data, 'get')
}

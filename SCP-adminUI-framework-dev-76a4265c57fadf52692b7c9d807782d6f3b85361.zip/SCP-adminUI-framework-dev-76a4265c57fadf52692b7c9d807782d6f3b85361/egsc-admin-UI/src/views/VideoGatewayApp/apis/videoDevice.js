import { request, cmd } from '@/views/VideoGatewayApp/apis/common.js'

export const getDevice = (data) => {
  return request(cmd['device_list'], data)
}
export const addDevice = (data) => {
  return request(cmd['device_save'], data)
}
export const deleteDevice = (data) => {
  return request(cmd['device_delete'], data)
}
export const modifyDevice = (data) => {
  return request(cmd['device_update'], data)
}
export const seeDevice = (data) => {
  return request(cmd['queryVideoDeviceChannelInfo'], data, 'get')
}

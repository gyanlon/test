import { request, cmd } from '@/views/VideoGatewayApp/apis/common.js'

export const getFacePicture = (data) => {
  return request(cmd['getHumanFaceCaptureInfo'], data)
}

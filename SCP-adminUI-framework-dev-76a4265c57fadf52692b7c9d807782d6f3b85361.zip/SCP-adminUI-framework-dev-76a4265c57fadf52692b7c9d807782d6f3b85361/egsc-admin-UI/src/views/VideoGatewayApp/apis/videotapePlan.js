import { request, cmd } from '@/views/VideoGatewayApp/apis/common.js'

export const getTapeDevice = (data) => {
  return request(cmd['plan_list'], data)
}
export const setTapePlan = (data) => {
  return request(cmd['plan_save'], data)
}
export const clearTapePlan = (data) => {
  return request(cmd['plan_delete'], data)
}
export const getOrganizations = (data) => {
  return request(cmd['get_organizations'], data, 'get')
}

import { request, cmd } from '@/views/VideoGatewayApp/apis/common.js'

export const getVideoOption = (data) => { // 获取视频参数
  return request(cmd['parameter_get'], data, 'get')
}
export const setVideoOption = (data) => { // 设置视频参数
  return request(cmd['parameter_save'], data)
}
// export const getImageFormat = (data) => { // 获取图片格式
//   return request(cmd['parameter_captureformat_list'], data)
// }
// export const getPackSize = (data) => { // 获取录像打包大小列表
//   return request(cmd['parameter_recordpackagesize_list'], data)
// }

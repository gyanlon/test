import { request, cmd } from '@/views/VideoGatewayApp/apis/common.js'
// 获取流媒体服务器列表
export const getServiceList = (data) => {
  return request(cmd['streamMedia_list'], data, 'get')
}
// 设置流媒体服务器
export const setService = (data) => {
  return request(cmd['streamMedia_update'], data)
}
// 删除流媒体服务器
export const deleteService = (data) => {
  return request(cmd['streamMedia_delete'], data)
}
// 添加流媒体服务器
export const addService = (data) => {
  return request(cmd['streamMedia_save'], data)
}
// 查询流媒体服务器
export const searchService = (data) => {
  return request(cmd['streamMedia_search'], data, 'get')
}
// 修改单条数据
export const editService = (data) => {
  return request(cmd['streamMedia_edit'], data, 'get')
}
// 获取添加修改的流媒体组织树信息
export const getAddedOrgService = (data) => {
  return request(cmd['streamMedia_getAddedStreamMediaOrg'], data, 'get')
}

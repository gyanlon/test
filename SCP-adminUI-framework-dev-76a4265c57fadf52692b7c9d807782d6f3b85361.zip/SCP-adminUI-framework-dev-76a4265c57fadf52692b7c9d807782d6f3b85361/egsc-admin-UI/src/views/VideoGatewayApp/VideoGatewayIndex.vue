<template>
</template>
<script>
export default {
  name: 'videoGatewayIndex'
}
</script>
// 引用pages
// import demoindex from '@/views/demo/index'
import logServiceComponentindex from '@/views/LogServiceComponent/index'

// 定义路由路径数组列表
export default [
  {
    path: '/logservicecomponent/logserviceindex',
    name: '日志管理',
    component: logServiceComponentindex
  }

]

# LogServiceComponent 日志管理

#示例页面，可以删除，如删除则需要将相关的关联删除，目前首页有引用
# src/views/LogServiceComponent/index.vue


# 日志管理的apis配置src/views/LogServiceComponent/apis/index.js

# 日志管理的mock配置src/views/LogServiceComponent/mocks/mock.js

# 日志管理的路由配置 src/views/LogServiceComponent/routers/index.js
 
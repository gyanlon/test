# login 用户登录

#示例页面，目前首页有引用
# src/views/UserMgmt/login/Login.vue

 
# UserMgmt\login示例的apis配置src/views/UserMgmt/login/routers/index.js

# UserMgmt\login示例的mock配置src/views/UserMgmt/login/mocks/mock.js

# UserMgmt\login示例的路由配置src/views/UserMgmt/login/routers/index.js
 
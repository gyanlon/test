<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'app'
}
</script>
 
<style lang="less">
@import "assets/css/main.less";
@import "assets/css/common.less";
@import "assets/css/color-dark.less";
</style>



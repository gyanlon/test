// 引用子模块的mock文件
// import '@/views/demo/mocks/mock.js'

// import Mock from 'mockjs'
// 引用子模块的mock文件
import '@/views/demo/mocks/mock.js'
import '@/views/UserMgmt/login/mocks/mock.js'
import '@/views/deviceManagement/register/mocks/mock.js'
import '@/views/modelManagement/mocks/mock.js'
import '@/views/UserMgmt/userManagement/mocks/mock.js'
import '@/views/CommunitySafetyApp/mocks/mock.js'
import '@/views/PatrolApp/mocks/mock.js'
// 引用子模块的mock文件
// import '@/views/MdmApp/mocks/mock.js'
// 引用子模块的mock文件
// import '@/views/MapApp/mocks/mock.js'
// 引用子模块的mock文件
// import '@/views/VisitorApp/mocks/mock.js'
// 引用子模块的mock文件
import '@/views/BroadcastApp/mocks/mock.js'

// 引用日志管理模块的mock文件
import '@/views/LogServiceComponent/mocks/mock.js'
import '@/views/AccessControlApp/mocks/mock.js'
import '@/views/VideoGatewayApp/mocks/mock.js'
// 信息展示屏mock数据
import '@/views/InformationReleaseApp/mocks/mock.js'
// 梯控应用展示mock数据
import '@/views/LadderControlApp/mocks/mock.js'
// 短信网关
import '@/views/IsmgApp/mocks/mock.js'

/**
 * 复制对象
 * author wzp
 * date 2017/12/26
 * @param {obj}
 */
export const copyObject = obj => { return JSON.parse(JSON.stringify(obj)) }
